#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;

int a[1001],b[1001];
int ans=0;
int main()
{
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
       cin>>a[i];
    b[1]=1;//��ʾ��a[1]Ϊ���������ұߵĳ���Ϊ1
    for(int s=2;s<=n;s++)
    {
        b[s]=1;//��ʼ��ÿ������ĳ��ȶ���1. 
        for(int t=1;t<s;t++)
          if(a[t]<a[s] && b[t]+1>b[s]) b[s]=b[t]+1;  
    }
      for(int i=1;i<=n;i++)
        ans=max(ans,b[i]);
      cout<<ans<<endl;
    return 0;
}
