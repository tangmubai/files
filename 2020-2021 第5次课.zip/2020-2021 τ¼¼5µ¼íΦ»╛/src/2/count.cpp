#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;

int n,ans=1;
int a[1005];

int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
    cin>>n;
    for(int i=0;i<n;i++)
      cin>>a[i];
    sort(a,a+n);
    int t;
    t=a[0];
    for(int i=1;i<n;i++)
    {
    	if(a[i]==t) ans++;
    	else 
		{
    		cout<<t<<' '<<ans<<endl;
    		t=a[i];
    		ans=1;
    	}
    }
    cout<<t<<' '<<ans<<endl;
    return 0;
}
