#include <cstdio>
int n,t[1000003],maxx=-1;
int main(){
	freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		int x;scanf("%d",&x);
		++t[x];
		if(maxx<x) maxx=x;
	}
	for(int i=1;i<=maxx;i++) if(t[i]) printf("%d %d\n",i,t[i]);
	return 0;
}
