#include <cstdio>
#include <algorithm>
int n,d[1003],len,a;
int main(){
	freopen("long.in","r",stdin);freopen("long.out","w",stdout);
	scanf("%d%d",&n,&a);
	d[++len]=a;
	while(--n){
		scanf("%d",&a);
		//printf("%d\n",d[len]);
		if(d[len]<a) d[++len]=a;
		else *std::lower_bound(d+1,d+1+len,a)=a;
	}
	printf("%d\n",len);
	return 0;
}
