#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <map>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return -1;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


map<int, int> t;

int main()
{
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	
	
	int n;
	in(n);
	
	for(int i=1; i<=n; i++)
	{
		int num;
		in(num);


		t[num]++;
	}
	
	
	for(map<int, int>::iterator it = t.begin(); it != t.end(); it++)
		out(it->first), space, out(it->second), enter;
}

