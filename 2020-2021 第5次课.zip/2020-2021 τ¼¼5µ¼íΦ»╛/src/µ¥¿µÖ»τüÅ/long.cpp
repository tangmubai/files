#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return -1;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


vector<int> ans;

int main()
{
	freopen("long.in", "r", stdin);
	freopen("long.out", "w", stdout);
	
	
	int n;
	in(n);
	
	
	for(int i=1; i<=n; i++)
	{
		int num;
		in(num);
		
		
		if(ans.empty() || *(ans.end() - 1) < num)
			ans.push_back(num);
		
		else
			*lower_bound(ans.begin(), ans.end(), num) = num;
	}
	
	
	out(ans.size());
}

