#include<iostream>
#include<map>
#include<algorithm>
using namespace std;
map<int,int>mp;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin>>n;
	int a[1005];
	for(int i=1;i<=n;i++){
		cin>>a[i];
		mp[a[i]]++;
	}
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++)if(a[i]!=a[i-1])cout<<a[i]<<" "<<mp[a[i]]<<endl;
	return 0;
}
