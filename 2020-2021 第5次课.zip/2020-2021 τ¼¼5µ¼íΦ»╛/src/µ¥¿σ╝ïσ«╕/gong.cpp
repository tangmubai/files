#include<iostream>
using namespace std;
int a[1005],b[1005];
int m,n;
bool find(int k,int s){
	for(int i=s;i<=n;i++)if(k==b[i])return true;
	return false;
}
int num(int k){
	for(int i=1;i<=n;i++)if(k==b[i])return i;
}
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>m>>n;
	for(int i=1;i<=m;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	int f[1005],ans=1;
	for(int i=1;i<=m;i++){
		if(find(a[i],f[ans]))f[++ans]=num(a[i]);
		else f[ans]=num(a[i]);
	}
	cout<<ans;
	return 0;
}
