#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin>>n;
	int a[1005];
	for(int i=1;i<=n;i++)cin>>a[i];
	int f[1005],ans=1;
	f[1]=a[1];
	for(int i=2;i<=n;i++){
		if(a[i]>f[ans])f[++ans]=a[i];
		else{
			int j=lower_bound(f+1,f+ans+1,a[i])-f;
			f[j]=a[i];
		}
	}
	cout<<ans;
	return 0;
}
