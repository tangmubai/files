#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
#include<map>
using namespace std;
map<ll,ll>a;
map<ll,ll>::iterator it;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	ll n,t,x;
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++){
		scanf("%lld",&x);a[x]++;
	}
	for(it=a.begin();it!=a.end();it++)cout<<it->first<<' '<<it->second<<endl;
	return 0;
}



