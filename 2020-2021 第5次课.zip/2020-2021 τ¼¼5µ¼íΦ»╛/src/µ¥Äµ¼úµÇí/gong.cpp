#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<set>
#include<cstring>
#define ll long long
using namespace std;
ll f[1005],a[1005],b[1005];
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	ll n,m,ans=0;
	scanf("%lld%lld",&n,&m);
	for(ll i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(ll i=1;i<=m;i++)scanf("%lld",&b[i]);
	for(ll i=1;i<=n;i++){
		if(a[i]>f[ans]){
			f[++ans]=a[i];
		}
		else{
			ll j=lower_bound(f+1,f+ans+1,a[i])-f;
			f[j]=a[i];
		}
	}
	printf("%lld\n",ans);
	return 0;
}



