#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
ll a[105][105],sum[105][105];
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	ll n,ans=0;
	scanf("%lld",&n);
	while(n!=0){
		for(ll i=1;i<=n;i++){
			for(ll j=1;j<=i;j++)scanf("%lld",&a[i][j]);
		}
		for(ll i=1;i<=n;i++){
			for(ll j=1;j<=i;j++)
				sum[i][j]=max(sum[i-1][j],sum[i-1][j-1])+a[i][j];
		}
		for(ll i=1;i<=n;i++)ans=max(ans,sum[n][i]);
		printf("%lld\n",ans);
		scanf("%lld",&n);
	}
	return 0;
}



