#include<stdio.h>
#include<algorithm>
#pragma GCC(2,3,'Ofast','inline')
using std::sort;
#define file(n)freopen(n".in","r",stdin),freopen(n".out","w",stdout)
struct Node{
	int num,tim;
}a[1050];
bool cmp(Node a,Node b){
	return a.num<b.num;
}
int main(){
	file("count");
	int n;
	int len=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int tmp;
		scanf("%d",&tmp);
		bool flag=0;
		for(int i=1;i<=len;i++){
			if(tmp==a[i].num){
				a[i].tim++;
				flag=1;
			}
		}
		if(!flag){
			a[++len].num=tmp;
			a[len].tim=1;
		}
	}
	sort(a+1,a+len+1,cmp);
	for(int i=1;i<=len;i++){
		printf("%d %d\n",a[i].num,a[i].tim);
	}
}
