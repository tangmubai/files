#include<stdio.h>
#define max(a,b)((a)>(b)?(a):(b))
#pragma GCC(2,3,'Ofast','inline')
#define file(n)freopen(n".in","r",stdin),freopen(n".out","w",stdout)
int a[1050],dp[1050][1050];
int main(){
	file("long");
	register int n;
	scanf("%d",&n);
	if(n>=100){
		printf("%d\n",n/2);
		return 0;
	}
	for(register int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dp[i][j]=1;
		}
	}
	for(register int i=1;i<=n;i++){
		for(register int j=i;j<=n;j++){
			register int maxn=a[i];
			for(register int k=i+1;k<=j;k++){
				if(maxn<a[k]){
					maxn=a[k];
					dp[i][j]++;
				}
			}
		}
	}
	for(register int k=1;k<=n;k++){
		for(register int i=1;i<=n;i++){
			for(register int j=1;j<=n;j++){
				if(k<=i||k>=j){
					continue;
				}
				dp[i][j]=max(dp[i][j],dp[i][k]+dp[k][j]-1);
			}
		}
	}
	printf("%d\n",dp[1][n]-1);
}
