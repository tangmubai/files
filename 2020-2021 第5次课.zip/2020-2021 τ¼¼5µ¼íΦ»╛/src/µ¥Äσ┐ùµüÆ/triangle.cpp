#include<stdio.h>
#define max(a,b)((a)>(b)?(a):(b))
#pragma GCC(2,3,'Ofast','inline')
#define file(n)freopen(n".in","r",stdin),freopen(n".out","w",stdout)
int dp[150][150];
int main(){
	file("triangle");
	while(1){
		int n;
		scanf("%d",&n);
		if(n==0){
			return 0;
		}
		for(int i=0;i<150;i++){
			for(int j=0;j<150;j++){
				dp[i][j]=0;
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=i;j++){
				scanf("%d",&dp[i][j]);
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=i;j++){
				dp[i][j]+=max(dp[i-1][j],dp[i-1][j-1]);
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			ans=max(ans,dp[n][i]);
		}
		printf("%d\n",ans);
	}
}
