#include <cstdio>
#include <algorithm>

using namespace std;

int a[1010],n,j,i;

int main () {
	freopen ("count.in","r",stdin);
	freopen ("count.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++)
		scanf ("%d",&a[i]);
	sort (a+1,a+1+n);
	for (i=1;i<=n;i++) {
		printf ("%d ",a[i]);
		j=1;
		while (a[i]==a[i+1]) i++,j++;
		printf ("%d\n",j);//rp++;
	}
	return 0;
}
