#include <cstdio>
#include <cstring>

using namespace std;

int a[110][110],f[110][110],i,j,n;

int max (int a,int b) {
	return a > b ? a : b;
}

int main () {
	freopen ("triangle.in","r",stdin);
	freopen ("triangle.out","w",stdout);
	while (scanf ("%d",&n)!=EOF) {
		if (n==0) 
			return 0;
		memset (f,0,sizeof (f));
		for (i=1;i<=n;i++)
			for (j=1;j<=i;j++)
				scanf ("%d",&a[i][j]);
		for (i=1;i<=n;i++)
			for (j=1;j<=i;j++) 
				if (i==n)
					f[i][j]=a[i][j];
		for (i=n;i>=1;i--)
			for (j=1;j<=i;j++) 
				f[i][j]=max (f[i+1][j]+a[i][j],f[i+1][j+1]+a[i][j]);
		printf ("%d\n",f[1][1]);//rp++;
	}
	return 0;
}
