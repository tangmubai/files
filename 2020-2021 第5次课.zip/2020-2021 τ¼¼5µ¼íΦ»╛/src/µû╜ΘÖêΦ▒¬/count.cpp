#include<stdio.h>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;
int a[1005];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	int s=1;
	a[n+1]=(-1);
	for(int i=1;i<=n;i++){
		if(a[i]!=a[i+1]){
			printf("%d %d\n",a[i],s);
			s=1;
		}else s++;
	}
	return 0;
}
