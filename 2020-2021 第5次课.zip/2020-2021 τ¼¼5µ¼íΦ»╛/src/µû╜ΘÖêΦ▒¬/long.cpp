#include<stdio.h>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;
int f[1005]={0};
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	int n,l=0,x;
	scanf("%d",&n);
	while(n--){
		scanf("%d",&x);
		if(x>f[l])f[++l]=x;
		else f[lower_bound(f+1,f+1+l,x)-f]=x;
	}
	printf("%d",l);
	return 0;
}
