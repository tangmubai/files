#include<stdio.h>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;
int a[105][105],f[105][105],n;
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(258000){
		scanf("%d",&n);
		if(n==0)return 0;
		memset(f,0,sizeof(f));
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++){
			for(int j=1;j<=i;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(int i=1;i<=n;i++)f[n][i]=a[n][i];
		for(int i=n-1;i>=1;i--){
			for(int j=1;j<=n;j++){
				f[i][j]=max(f[i+1][j],f[i+1][j+1])+a[i][j];
			}
		}
		printf("%d\n",f[1][1]);
	}
	return 0;
}
