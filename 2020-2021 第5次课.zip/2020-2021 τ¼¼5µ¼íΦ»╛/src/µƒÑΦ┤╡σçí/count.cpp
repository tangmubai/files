#include <cstdio>
#include <algorithm>
using namespace std;

int n,x,i,j;
int a[1005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	n=read();
	for(i=1;i<=n;++i){
		a[i]=read();
	}
	sort(a+1,a+n+1);
	for(i=1;i<=n;){
		for(j=i;j<=n;++j){
			if(a[i]!=a[j]){
				break;
			}
		}
		printf("%d %d\n",a[i],j-i);
		i=j;
	}
	return 0;
}
