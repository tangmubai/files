#include <cstdio>

int n,i,j;
int a[105][105],f[105][105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Max(int x,int y){
	return x>y?x:y;
}

int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(1){
		n=read();
		if(n==0)break;
		for(i=1;i<=n;++i){
			for(j=1;j<=i;++j){
				f[i][j]=a[i][j]=read();
			}
		}
		for(i=n-1;i;--i){
			for(j=1;j<=i;++j){
				f[i][j]+=Max(f[i+1][j],f[i+1][j+1]);
			}
		}
		printf("%d\n",f[1][1]);
	}
	return 0;
}
