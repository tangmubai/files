#include<stdio.h>
#include<algorithm>
using namespace std;
int a[1005];
int n;
int main(){
	freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;++i)scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	for(register int i=1,j=2;i<=n;i=j){
		while(a[i]==a[j]&&j<=n)++j;
		printf("%d %d\n",a[i],j-i);
	}
}
