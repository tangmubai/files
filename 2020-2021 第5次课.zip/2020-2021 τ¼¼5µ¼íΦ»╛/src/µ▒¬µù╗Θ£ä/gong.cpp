#include<stdio.h>
int f[1005][1005],a[1005],b[1005],n,m,xx=0,yy=1;
int max(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("gong.in","r",stdin);freopen("gong.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(register int i=1;i<=n;++i)scanf("%d",&a[i]);
	for(register int i=1;i<=m;++i)scanf("%d",&b[i]);
	for(register int i=1;i<=n;++i)
	for(register int j=1;j<=m;++j){
		if(a[i]==b[j])f[i][j]=f[i-1][j-1]+1;
		else f[i][j]=max(f[i-1][j],f[i][j-1]);
	}
	printf("%d",f[n][m]);
}
