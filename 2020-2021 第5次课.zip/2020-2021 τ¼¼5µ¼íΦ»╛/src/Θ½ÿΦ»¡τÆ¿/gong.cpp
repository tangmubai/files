#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int m,n,p1[1010],p2[1010],ans,f[1010][1010];
int maxn(int a,int b){
	return (a>b?a:b);
}
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=m;i++)
	    scanf("%d",&p1[i]);
	for(int i=1;i<=n;i++)
	    scanf("%d",&p2[i]);
	for(int i=1;i<=m;i++)
	    for(int j=1;j<=n;j++){
		    if(p1[i]==p2[j])f[i][j]=f[i-1][j-1]+1;
		    else f[i][j]=maxn(f[i-1][j],f[i][j-1]);
	    }
	printf("%d\n",f[m][n]);
	return 0;
}
