#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int n,a[1010],f[1010],ans;
int maxn(int a,int b){
	return (a>b?a:b);
}
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	    scanf("%d",&a[i]);
	f[1]=1;
	for(int i=2;i<=n;i++){
		f[i]=1;
		for(int j=1;j<i;j++){
			if(a[j]<a[i])
			    f[i]=maxn(f[i],f[j]+1);
		}
		ans=maxn(ans,f[i]);
	}
	printf("%d\n",ans);
	return 0;
};

