#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int n,a[105][105],f[105][105];
int maxn(int a,int b){
	return (a>b?a:b);
}
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	scanf("%d",&n);
	while(n!=0){
		for(int i=1;i<=n;i++)
			for(int j=1;j<=i;j++)
			    scanf("%d",&a[i][j]);
		for(int j=1;j<=n;j++)
		    f[n][j]=a[n][j];
		for(int i=n-1;i;i--){
			for(int j=1;j<=i;j++){
				f[i][j]=maxn(f[i+1][j]+a[i][j],f[i+1][j+1]+a[i][j]);
			}
		}
		printf("%d\n",f[1][1]);
		scanf("%d",&n);
	}
	return 0;
};
