#include <iostream>
#include <algorithm>
using namespace std;
int n;
int a[1005];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	sort(a+1,a+1+n);
	int now=a[1],s=0;
	cout<<now<<' ';
	for(int i=1;i<=n;i++){
		if(a[i]==now)s++;
		else{
			cout<<s<<endl<<a[i]<<' ';
			s=1;
			now=a[i];
		}
	}
	cout<<s;
}
