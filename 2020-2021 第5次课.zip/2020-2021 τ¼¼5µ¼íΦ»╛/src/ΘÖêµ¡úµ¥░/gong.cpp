#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;
int n,m;
int a[1005],b[1005];
int f[1005][1005];
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	for(int j=1;j<=m;j++)
	scanf("%d",&b[j]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++){
		if(a[i]==b[j])f[i][j]=f[i-1][j-1]+1;
		f[i][j]=max(f[i][j],max(f[i-1][j],f[i][j-1]));
	}
	cout<<f[n][m];
}

