#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n;
int d[1005];
int len;
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		int x;cin>>x;
		int wz=lower_bound(d+1,d+1+len,x)-d;
		d[wz]=x;
		len=max(len,wz);
	}
	cout<<len;
}
