#include<stdio.h>
#include<iostream>
#include<cmath>
using namespace std;

int a[1006],b[1005];
int main()
{

freopen("gong.in","r",stdin);
freopen("gong.out","w",stdout);

	int n,m,i,j,x=0,l=0;
	cin>>m>>n;
	for(int i=0;i<m;i++)cin>>a[i];
		for(int i=0;i<n;i++)cin>>b[i];
	for(i=0;i<max(i,j);i++)
	{
		for(j=0;j<max(i,j);j++)
		{
			if(a[i]==a[j])l++;
			else {
				if(x<l)x=l;
			l=0;
			}
		}
	}
	cout<<x;
}


