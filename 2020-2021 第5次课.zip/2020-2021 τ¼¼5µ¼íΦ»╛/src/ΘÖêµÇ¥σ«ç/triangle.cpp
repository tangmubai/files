#include<stdio.h>
#include<iostream>
#include<cmath>
using namespace std;

int a[105][105];
int main()
{

freopen("triangle.in","r",stdin);
freopen("triangle.out","w",stdout);

	int n,i,j;
	long long x=0;
	while(cin>>n)
	{
		x=0;
		if(n==0)return 0;
		for( i=1;i<=n;i++)
			for(j=1;j<=i;j++)
				scanf("%d",&a[i][j]);
		
		for(i=1;i<=n;i++)
		for(j=1;j<=i;j++)
		{
			a[i][j]+=max(a[i-1][j-1],a[i-1][j]);
			if(x<a[i][j])x=a[i][j];
		}
			
		printf("%lld\n",x);
	}
	
}


