#include<cstdio>
#include<algorithm>
using namespace std;

int n,a[1005];

int main(){
	freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	int cnt=0;
	for(int i=1;i<=n;i++){
		cnt++;
		if(a[i]!=a[i+1]){
			printf("%d %d\n",a[i],cnt);
			cnt=0;
		}
	}
	return 0;
}
