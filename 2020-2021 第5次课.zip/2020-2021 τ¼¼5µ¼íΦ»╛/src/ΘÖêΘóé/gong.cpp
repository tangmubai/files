#include<cstdio>
#include<algorithm>
using namespace std;

int m,n,a[1005],b[1005],f[1005][1005];

int main(){
	freopen("gong.in","r",stdin);freopen("gong.out","w",stdout);
	scanf("%d %d",&m,&n);
	for(int i=1;i<=m;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	for(int i=1;i<=m;i++)
		for(int j=1;j<=n;j++){
			f[i][j]=max(f[i-1][j],f[i][j-1]);
			if(a[i]==b[j]) f[i][j]=max(f[i][j],f[i-1][j-1]+1);
		}
	printf("%d\n",f[m][n]);
	return 0;
}
