#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int n;
int a[1005];
int tmp,cnt;
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline bool cmp(int p,int q){
	return p<q;
}
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++) read(a[i]);
	sort(a+1,a+n+1,cmp);
	tmp=a[1];cnt=1;
	for(int i=2;i<=n;i++)
	{
		if(tmp==a[i]) cnt++;
		else{
			printf("%d %d\n",tmp,cnt);
			tmp=a[i];cnt=1;
		}
	}
	if(cnt) printf("%d %d\n",tmp,cnt);
	return 0;
}

