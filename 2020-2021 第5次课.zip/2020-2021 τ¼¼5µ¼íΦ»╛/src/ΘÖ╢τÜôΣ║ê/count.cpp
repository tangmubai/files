#include<stdio.h>
#include<map>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
map<int,int>a;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++){int x=read();a[x]++;}
	map<int,int>::iterator it=a.begin();
	for(;it!=a.end();it++)printf("%d %d\n",it->first,it->second);
	return 0;
}

