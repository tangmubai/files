#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
int max(int a,int b){return a>b?a:b;}
int a[1005],b[1005],dp[1005][1005];
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++)b[i]=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			dp[i][j]=max(dp[i-1][j-1]+(a[i]==b[j]),max(dp[i-1][j],dp[i][j-1]));
	printf("%d",dp[n][m]);
	return 0;
}

