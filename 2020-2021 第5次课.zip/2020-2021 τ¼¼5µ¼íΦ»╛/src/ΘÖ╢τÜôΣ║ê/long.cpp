#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
int a[1005],dp[1005];
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	int n=read(),ans=0;
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=n;i++){
		int j=lower_bound(dp+1,dp+1+ans,a[i])-dp;
		dp[j]=a[i];ans=max(ans,j);
	}
	printf("%d",ans);
	return 0;
}

