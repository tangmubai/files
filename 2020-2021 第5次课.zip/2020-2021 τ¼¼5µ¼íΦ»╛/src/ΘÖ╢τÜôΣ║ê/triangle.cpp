#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
int max(int a,int b){return a>b?a:b;}
int a[105][105],dp[105][105];
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	int n=read();
	while(n){
		for(int i=1;i<=n;i++)for(int j=1;j<=i;j++)a[i][j]=read();
		for(int i=1;i<=n;i++)dp[n][i]=a[n][i];
		for(int i=n-1;i>=1;i--)
			for(int j=1;j<=i;j++)
				dp[i][j]=max(dp[i+1][j],dp[i+1][j+1])+a[i][j];
		printf("%d\n",dp[1][1]);n=read();
	}
	return 0;
}

