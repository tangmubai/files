#include<cstdio>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
int n,x;
map<int,int>mp;
map<int,int>::iterator it;
int main(){
	freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		mp[x]++;
	}
	for(it=mp.begin();it!=mp.end();it++) cout<<it->first<<" "<<it->second<<endl;
	return 0;
}

