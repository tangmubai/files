#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int a[110][110],f[110][110];
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	int n;scanf("%d",&n);
	while(n!=0){
		memset(a,0,sizeof(a));
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++)
			for(int j=1;j<=i;j++)
				scanf("%d",&a[i][j]);
		f[1][1]=a[1][1];
		for(int i=1;i<=n;i++)
			for(int j=1;j<=i;j++)
				f[i][j]=max(f[i-1][j],f[i-1][j-1])+a[i][j];
		int ans=0;
		for(int i=1;i<=n;i++)
			ans=max(f[n][i],ans);
		printf("%d\n",ans);
		scanf("%d",&n);
	}
	return 0;
}
