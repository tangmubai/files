#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n,m,a[1005],b[1005],f[1005][1005];
void read(int &x)
{
	char c = getchar(); int f = 1; x = 0;
	while (c < '0' || c > '9')
	{
		if (c == '-') f = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9')
	{
		x = x * 10 + c - '0';
		c = getchar();
	}
	x *= f;
}
int main()
{
	freopen("gong.in", "r", stdin);
	freopen("gong.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; i++) read(a[i]);
	for (int i = 1; i <= m; i++) read(b[i]);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			f[i][j] = max(f[i - 1][j - 1] + (a[i]==b[j]) , max(f[i - 1][j], f[i][j - 1]));
	printf("%d", f[n][m]);
	return 0;
}

