#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n, a[100005], f[100005], ans;
void read(int &x)
{
	char c = getchar(); int f = 1; x = 0;
	while (c < '0' || c > '9')
	{
		if (c == '-') f = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9')
	{
		x = x * 10 + c - '0';
		c = getchar();
	}
	x *= f;
}
int main()
{
	freopen("long.in", "r", stdin);
	freopen("long.out", "w", stdout);
	read(n);
	for (int i = 1; i <= n; i++) read(a[i]);
	f[1] = 1;
	for (int i = 2; i <= n; i++)
	{
		for (int j = 1; j < i; j++)
			if (a[i] > a[j]) f[i] = max(f[i], f[j] + 1);
	}
	for (int i = 1; i <= n; i++) ans = max(ans, f[i]);
	printf("%d", ans);
	return 0;
}

