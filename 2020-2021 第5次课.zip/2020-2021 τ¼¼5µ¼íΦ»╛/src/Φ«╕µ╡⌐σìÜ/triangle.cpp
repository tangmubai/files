#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n, a[1005][1005], f[1005][1005], ans;
int main()
{
	freopen("triangle.in", "r", stdin);
	freopen("triangle.out", "w", stdout);
	while(scanf("%d", &n) && n)
	{
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= i; j++)
				scanf("%d", &a[i][j]); 
		memset(f, 0, sizeof(f)); ans = 0;
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= i; j++)
				f[i][j] = max(f[i - 1][j], f[i - 1][j - 1]) + a[i][j];
		for (int i = 1; i <= n; i++) ans = max(ans, f[n][i]);
		printf("%d", ans);
	}
	return 0;
}

