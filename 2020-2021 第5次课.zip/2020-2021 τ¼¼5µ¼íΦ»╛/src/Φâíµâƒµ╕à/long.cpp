#include<stdio.h>
#include<iostream>
const int N = 1e3;
using namespace std;
int n, a[N + 5], f[N + 5], ans;
int max(int x, int y) {return x > y ? x : y;} 
int main() {
	freopen("long.in", "r", stdin);
	freopen("long.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);	
		f[i] = 1;
		for(int j = 1; j < i; ++j)
			if (a[j] < a[i])
				f[i] = max(f[i], f[j] + 1);
		ans = max(ans, f[i]);		
	}
	printf("%d\n", ans);
	return 0;
}
