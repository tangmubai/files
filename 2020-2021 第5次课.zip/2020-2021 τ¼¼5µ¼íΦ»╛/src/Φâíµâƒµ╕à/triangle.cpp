#include<stdio.h>
#include<string.h>
const int N = 100;
int n, a[N + 5][N + 5], f[N + 5][N + 5];
int max(int x, int y) {return x > y ? x : y;} 
int main() {
	freopen("triangle.in", "r", stdin);
	freopen("triangle.out", "w", stdout);
	while(scanf("%d", &n) != EOF) {
		memset(f, 0, sizeof(f));
		if (n == 0)
			return 0;
		for(int i = 1; i <= n; ++i)
			for(int j = 1; j <= i; ++j)
				scanf("%d", &a[i][j]);
		for(int i = n; i >= 1; --i)
			for(int j = 1; j <= i; ++j)
				f[i][j] = max(f[i + 1][j], f[i + 1][j + 1]) + a[i][j];
		printf("%d\n", f[1][1]);					
	}
	return 0;
}
