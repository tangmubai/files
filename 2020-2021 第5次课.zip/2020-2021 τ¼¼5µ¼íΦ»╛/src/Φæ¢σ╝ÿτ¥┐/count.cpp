#include <stdio.h>
#include <algorithm>
using namespace std;
int n,t[1000005],a[1005],t2[1000005];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		t[a[i]]++;
	}
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++)
		if(t2[a[i]]==0){
			printf("%d %d\n",a[i],t[a[i]]);
			t2[a[i]]=1;
		}
	return 0;
}
