#include <stdio.h>
int n,f[1005],a[1005],ans;
int mx(int a,int b){
	if(a>b)return a;
	else return b;
}
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		f[i]=1;
	}
	for(int i=2;i<=n;i++)
		for(int j=1;j<i;j++)
			if(a[i]>a[j])
				f[i]=mx(f[i],f[j]+1);
	for(int i=1;i<=n;i++)
		ans=mx(ans,f[i]);
	printf("%d",ans);		
	return 0;
}
