#include <cstdio>
#include <algorithm>
using namespace std;
int d[1005],len;
int main(){
	freopen("long.in","r",stdin);freopen("long.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;++i){
		int x;scanf("%d",&x);
		int k=lower_bound(d+1,d+len+1,x)-d;
		if(k>len) ++len;
		d[k]=x;
	}
	printf("%d\n",len);
	return 0;
}
