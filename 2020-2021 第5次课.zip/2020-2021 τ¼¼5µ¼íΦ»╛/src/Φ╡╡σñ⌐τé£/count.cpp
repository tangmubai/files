#include <cstdio>
#include <queue>
#include <algorithm>
using namespace std;
int n;
const int N = 1005;
int a[N];
int main () {
	freopen ("count.in", "r", stdin);
	freopen ("count.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i ++) {
		scanf ("%d", &a[i]);	
	}
	sort (a + 1, a + n + 1);
	int i = 1;
	while (i <= n) {
		int j = i, s = 0;
		while (a[j] == a[i] && j <= n)
			j ++, s ++;
		printf ("%d %d\n", a[i], s);
		i = j;
	}
}
