#include <cstdio>
#include <cstring>
int n, m;
const int N = 1005;
int a[N], b[N];
int mem[N][N];
int max (int a, int b) {
	return a > b ? a : b;
}
int search (int step1, int step2) {
	if (mem[step1][step2] != -1)
		return mem[step1][step2];
	if (step1 == n + 1 && step2 == m + 1)
		return 0;
	int res = 0;
	if (step1 <= n)
		res = max (res, search (step1 + 1, step2));
	if (step2 <= m)
		res = max (res, search (step1, step2 + 1));
	if (a[step1] == b[step2] && step1 <= n && step2 <= m)
		res = max (res, search (step1 + 1, step2 + 1) + 1);
	return mem[step1][step2] = res;
}
int main () {
	freopen ("gong.in", "r", stdin);
	freopen ("gong.out", "w", stdout);
	memset (mem, -1, sizeof(mem));
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= n; i ++)
		scanf ("%d", &a[i]);
	for (int i = 1; i <= m; i ++)
		scanf ("%d", &b[i]);
	int ans = search (1, 1);
	printf ("%d", ans);
}
/*
f[i][j] aǰi����bǰj����� 

a[i] = b[j]
f[i][j] = f[i-1][j-1] + 1

a[i] != b[j]
f[i][j] = max {f[i-1][j], f[i][j-1]}
for i 1 ~ n
	for j 1 ~ m
*/
