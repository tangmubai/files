#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int bin[1000006]={0};
int main(){freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	ll n,x;
	scanf("%d",&n);
	for(ll i=1;i<=n;i++)scanf("%d",&x),bin[x]++;
	for(ll i=1;i<=1000000;i++)if(bin[i]>=1)printf("%d %d\n",i,bin[i]);
	return 0;
}



