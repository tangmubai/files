#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int f[1005][1005]={0};
int a[1005]={0};
int b[1005]={0};
int main(){freopen("gong.in","r",stdin);freopen("gong.out","w",stdout);
	ll n,m;
	scanf("%d%d",&n,&m);
	for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
	for(ll i=1;i<=m;i++)scanf("%d",&b[i]);
	for(ll i=1;i<=n;i++)f[i][i]=a[i]==b[i];
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=m;j++){
			f[i][j]=max(f[i][j],f[i-1][j-1]+(a[i]==b[j] ? 1 : 0));
			f[i][j]=max(f[i][j],f[i-1][j]);
			f[i][j]=max(f[i][j],f[i][j-1]);
		}
	}
	printf("%d",f[n][m]);
	return 0;
}



