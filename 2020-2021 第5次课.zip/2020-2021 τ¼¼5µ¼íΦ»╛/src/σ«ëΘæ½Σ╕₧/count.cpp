#include<stdio.h>
#include<map>
using namespace std;
map<int,int> a;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n,i,k;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&k);
		a[k]++;
	}
	map<int,int>::iterator it;
	for(it=a.begin();it!=a.end();it++){
		printf("%d %d\n",it->first,it->second);
	}
	return 0;
}
