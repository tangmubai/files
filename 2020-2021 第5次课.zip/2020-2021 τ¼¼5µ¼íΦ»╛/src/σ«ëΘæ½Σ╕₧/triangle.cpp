#include<stdio.h>
using namespace std;
int a[105][105];
int max(int x,int y){
	if(x<y)return y;
	else return x;
}
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	int n;
	scanf("%d",&n);
	while(n!=0){
		int i,j;
		for(i=1;i<=n;i++){
			for(j=1;j<=i;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(i=n-1;i>0;i--){
			for(j=1;j<=i;j++){
				a[i][j]+=max(a[i+1][j],a[i+1][j+1]);
			}
		}
		printf("%d\n",a[1][1]);
		scanf("%d",&n);
	}
	return 0;
}
