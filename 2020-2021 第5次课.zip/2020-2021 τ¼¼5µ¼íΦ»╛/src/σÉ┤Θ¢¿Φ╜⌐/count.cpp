#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int n,a[1005],ans,ok;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++){
		if(ok==0)ans++,ok=1;
		if(a[i]==a[i+1])ans++;
		else printf("%d %d\n",a[i],ans),ans=ok=0;
	}
	return 0;
}
