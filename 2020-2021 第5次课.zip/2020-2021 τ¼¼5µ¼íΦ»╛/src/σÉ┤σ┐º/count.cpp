#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<map>
using namespace std;
map<int,int> mp;
map<int,int> ::iterator it;
int a;
int n;
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a;
		mp[a]++;
	}
	for(it=mp.begin();it!=mp.end();it++)
	{
		cout<<(it->first)<<" "<<(it->second)<<endl;
	}
	return 0;
}

