#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n;
int a[1100],b[1100],ans,flag;
int f[1100][1100],maxn;
int main()
{
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(a[i]==b[j])
			{
				f[i][j]=max(f[i-1][j],f[i][j-1])+1;
				ans=max(ans,f[i][j]);
			}
			else
			{
				f[i][j]=max(f[i-1][j],f[i][j-1]);
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
/*
5 5 
3 2 1 4 5
1 2 3 4 5
*/
