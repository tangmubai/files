#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,num,a[1100],b[1100];
int main()
{
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	b[1]=a[1];
	num=1;
	for(int i=2;i<=n;i++)
	{
		int j=lower_bound(b+1,b+num+1,a[i])-b;
		if(j>num)
		{
			num++;
			b[num]=a[i];
		}
		else
		{
			b[j]=a[i];
		}
	}
	printf("%d\n",num);
	return 0;
}

