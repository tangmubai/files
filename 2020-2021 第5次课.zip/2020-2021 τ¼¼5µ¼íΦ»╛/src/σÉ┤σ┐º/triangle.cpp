#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,a[110][110],f[110][110],ans;
int main()
{
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	ios::sync_with_stdio(false);
	while(1)
	{
		cin>>n;
		memset(f,0,sizeof(f));
		if(n==0)
		{
			return 0;
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				cin>>a[i][j];
			}
		}
		f[1][1]=a[1][1];
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				f[i][j]=max(f[i-1][j],f[i-1][j-1])+a[i][j];
			}
		}
		for(int i=1;i<=n;i++)
		{
			ans=max(ans,f[n][i]);
		}
		printf("%d\n",ans);
	}
	return 0;
}
