#include<stdio.h>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(short&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
short a[100][100];
inline short max(const short&x,const short&y){return x>y?x:y;}
main()
{
	freopen("triangle.in","r",stdin);freopen("triangle.out","w",stdout);
	for(register short n;read(n),n;printf("%d\n",(int)(a[0][0])))
	{
		for(register short i=0;i<n;++i)for(register short j=0;j<=i;read(a[i][j++]));
		for(register short i=n-2;i>=0;--i)
			for(register short j=0;j<=i;++j)a[i][j]+=max(a[i+1][j],a[i+1][j+1]);
	}
}
