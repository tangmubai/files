#include <cstdio>
#include <algorithm>
using namespace std;

int a[1005], t[1000005], tot;

void in(int &x)
{
	int w = 0, f = 1;
	char c = getchar();
	while (c < '0' || c > '9')	{if (c == '-')f = -1;c = getchar();}
	while (c >= '0' && c <= '9'){w = w * 10 + c - '0';c = getchar();}
	x = w * f;
}

int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n;
	in(n);
	for (int i = 1; i <= n; i++)
	{
		int x;
		in(x);
		if (!t[x])
			a[++tot] = x;
		t[x]++;
	}
	sort(a + 1, a + 1 + tot);
	for (int i = 1; i <= tot ; i++)
	{
		printf("%d %d\n", a[i], t[a[i]]);
	}
	return 0;
}

