#include <cstdio>
#include <cstring>
using namespace std;

int f[105][105], a[105][105];

void in(int &x)
{
	int w = 0, f = 1;
	char c = getchar();
	while (c < '0' || c > '9')	{if (c == '-')f = -1;c = getchar();}
	while (c >= '0' && c <= '9'){w = w * 10 + c - '0';c = getchar();}
	x = w * f;
}

int max(int x, int y)
{
	return x > y ? x : y;
}

int main()
{
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	int n;
	in(n);
	while (n != 0)
	{
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= i; j++)
			{
				in(a[i][j]);
//				f[i][j] = a[i][j];
			}
		}
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= i; j++)
			{
				if (i == n)
					f[i][j] = a[i][j];
				else
					f[i][j] = 0;
			}
		}
		for (int i = n; i >= 1; i--)
		{
			for (int j = 1; j <= i; j++)
			{
				f[i][j] = max(f[i + 1][j], f[i + 1][j + 1]) + a[i][j];
			}
		}
		printf("%d\n", f[1][1]);
		in(n);
		memset(a, 0, sizeof(a));
		memset(f, 0, sizeof(f));
	}
	return 0;
}
