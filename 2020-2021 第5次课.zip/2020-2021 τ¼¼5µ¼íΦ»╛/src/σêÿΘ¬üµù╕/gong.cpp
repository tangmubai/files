#include <stdio.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int m, n, a[1005], b[1005], f[1005][1005];
int main(void) {
	freopen("gong.in", "r", stdin);
	freopen("gong.out", "w", stdout);
	read(m); read(n);
	for (int i = 1; i <= m; ++i)
		read(a[i]);
	for (int i = 1; i <= n; ++i)
		read(b[i]);
	for (int i = 1; i <= m; ++i)
		for (int j = 1; j <= n; ++j)
			if (a[i] == b[j])
				f[i][j] = f[i - 1][j - 1] + 1 > f[i][j] ? f[i - 1][j - 1] + 1 : f[i][j];
			else
				f[i][j] = f[i - 1][j] > f[i][j - 1] ? f[i - 1][j] : f[i][j - 1];
	printf("%d\n", f[m][n]);
	return 0;
}
