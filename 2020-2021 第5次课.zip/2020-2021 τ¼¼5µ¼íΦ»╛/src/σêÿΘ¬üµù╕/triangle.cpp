#include <stdio.h>
#include <string.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, a[105][105], f[105][105];
int main(void) {
	freopen("triangle.in", "r", stdin);
	freopen("triangle.out", "w", stdout);
	read(n);
	while (n) {
		memset(f, 0, sizeof f);
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= i; ++j)
				read(a[i][j]);
		f[1][1] = a[1][1];
		for (int i = 2; i <= n; ++i)
			for (int j = 1; j <= i; ++j)
				f[i][j] = (f[i - 1][j - 1] > f[i - 1][j] ? f[i - 1][j - 1] : f[i - 1][j]) + a[i][j];
		int ans = 0;
		for (int j = 1; j <= n; ++j)
			ans = f[n][j] > ans ? f[n][j] : ans;
		printf("%d\n", ans);
		read(n);
	}
	return 0;
}
