#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n,m;
int a[N],b[N],f[N][N];
int main()
{
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1; i <= n; ++i)
		scanf("%d", a + i);
	for(int i = 1; i <= m; ++i)
		scanf("%d", b + i);	
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
				
		if(a[i]==b[j]) f[i][j]=f[i-1][j-1]+1;
		else f[i][j]=max(f[i-1][j],f[i][j-1]);

	printf("%d",f[n][m]);
	return 0;
}
