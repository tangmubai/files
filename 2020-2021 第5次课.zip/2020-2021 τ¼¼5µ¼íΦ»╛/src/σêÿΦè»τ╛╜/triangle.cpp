#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n,ans;
int a[N][N];
int main()
{
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(scanf("%d",&n))
	{
		if(n==0) return 0;
		memset(a,0,sizeof(a));
		ans=0;
		for(int i=1;i<=n;i++)
		for(int j=1;j<=i;j++)
		{
			scanf("%d",&a[i][j]);
			a[i][j]+=max(a[i-1][j-1],a[i-1][j]);
			ans=max(ans,a[i][j]);
		}
		printf("%d\n",ans);
	}
	return 0;
}
