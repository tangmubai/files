#include<algorithm>
#include<iostream>
using namespace std;int a[1000000];
int main(){
    freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	int n,ans=1;cin>>n;for(int i=1;i<=n;i++)cin>>a[i];
	sort(a+1,a+n+1);
	for(int i=2;i<=n+2;i++){
	    if(a[i]==a[i-1])ans++;
	    if(a[i]!=a[i-1]){cout<<a[i-1]<<" "<<ans<<endl;ans=1;}}return 0;}
