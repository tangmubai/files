#include<stdio.h>
#include<algorithm>
using namespace std;
int n,a[1010],f[1010];
int main(){
	freopen("long.in","r",stdin);freopen("long.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	f[1]=1;
	int ans = 1;
	for(int i=2;i<=n;i++){
		f[i]=1;
		for(int j=1;j<i;j++){
			if(a[i]>a[j])
				f[i]=max(f[j]+1,f[i]);
		}
	}
	printf("%d",f[n]);
	return 0;
}

