#include<stdio.h>
#include<algorithm>
using namespace std;
int n,a[1010][1010],b[1010][1010];
int main(){
	freopen("triangle.in","r",stdin);freopen("triangle.out","w",stdout);
	while(scanf("%d",&n)){
		if(n==0)break;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=i;j++)scanf("%d",&a[i][j]);
		}
		for(int i=1;i<=n;i++)b[n][i]=a[n][i];
		for(int i=n;i>=1;i--){
			for(int j=1;j<2*n-i;j++){
				b[i-1][j]=max(b[i][j]+a[i-1][j],b[i][j+1]+a[i-1][j]);
			}
		}
		printf("%d\n",b[1][1]);
	}
	return 0;
}
