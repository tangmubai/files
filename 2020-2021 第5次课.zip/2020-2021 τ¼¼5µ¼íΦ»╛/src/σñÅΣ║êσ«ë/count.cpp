#include<cstdio>
#include<algorithm>
using namespace std;
int n;
int a[1010];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	int tmp=1;
	for(int i=2;i<=n;i++)
		if(a[i]==a[i-1]) tmp++;
		else printf("%d %d\n",a[i-1],tmp),tmp=1;
	printf("%d %d\n",a[n],tmp);
	return 0;
}
