#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,m;
int a[1010],b[1010],f[1010][1010];
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=m;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	for(int i=1;i<=m;i++)
		for(int j=1;j<=n;j++){
			f[i][j]=max(f[i-1][j],f[i][j-1]);
			if(a[i]==b[i]) f[i][j]=max(f[i][j],f[i-1][j-1]+1);
		}
	printf("%d\n",f[m][n]);
	return 0;
}
