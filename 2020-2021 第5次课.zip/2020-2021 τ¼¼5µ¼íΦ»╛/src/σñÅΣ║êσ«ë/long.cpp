#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,len=0;
int f[1010];
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int x;
		scanf("%d",&x);
		int kkk=lower_bound(f+1,f+1+len,x)-f;
		f[kkk]=x;
		len=max(len,kkk);
	}
	printf("%d\n",len);
	return 0;
}
