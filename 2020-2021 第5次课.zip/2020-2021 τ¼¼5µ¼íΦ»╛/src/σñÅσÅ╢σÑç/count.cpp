#include <map>
#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

int n;
map <int, int> mp;
map <int, int> :: iterator it;

int main() {
	ios :: sync_with_stdio(false);
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin >> n;
	int x;
	for (int i = 1; i <= n; i++) {
		cin >> x;
		mp[x]++;
	}
	for (it = mp.begin(); it != mp.end(); it++) {
		cout << it->first << ' ' << it->second << '\n';
	}
	return 0;
}
