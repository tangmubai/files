#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e3 + 5;

int la, lb;
int a[N], b[N];
int f[N][N];

int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	cin >> la >> lb;
	for (int i = 1; i <= la; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= lb; i++) {
		cin >> b[i];
	}
	int ans = 0;
	for (int i = 1; i <= la; i++) {
		for (int j = 1; j <= lb; j++) {
			if (a[i] == b[j]) 
				f[i][j] = Max(f[i -1][j], f[i][j - 1]) + 1;
			else f[i][j] = Max(f[i -1][j], f[i][j - 1]);
			ans = Max(f[i][j], ans);
		}
	}
	cout << ans << '\n';
	return 0;
}
/*
5 4
1 2 3 4 5
4 3 1 2
*/
