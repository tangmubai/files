#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e3 + 5;

int n, mx;
int a[N];
int f[N];

int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j < i; j++) {
			if (a[j] < a[i] and f[j] + 1 > f[i]) {
				f[i] = f[j] + 1;		
			}
		}
		mx = Max(f[i], mx);
	}
	cout << mx + 1 << '\n';
	return 0;
}
/*
5
5 4 3 2 1
*/
