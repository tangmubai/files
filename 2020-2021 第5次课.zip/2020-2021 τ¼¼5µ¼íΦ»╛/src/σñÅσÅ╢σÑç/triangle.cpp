#include <iostream>
#include <algorithm>
using namespace std;
const int N = 1e2 + 5;

int a[N][N];
int n;

int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("triangle.in", "r", stdin);
	freopen("triangle.out", "w", stdout);
	while (cin >> n and n != 0) {
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) {
				cin >> a[i][j];
			}
		}
		for (int i = n - 1; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				a[i][j] += Max(a[i + 1][j], a[i + 1][j + 1]);
			}
		}
		cout << a[1][1] << '\n';
	}
	return 0;
}
/*
5
7
3 8
8 1 1000
2 7 4 4
4 5 2 6 5
0
*/
