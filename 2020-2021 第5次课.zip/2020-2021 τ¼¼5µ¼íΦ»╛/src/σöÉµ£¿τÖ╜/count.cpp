#include <map>
#include <cstdio>

std :: map <int, int> tot;

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

int main() {
    freopen("count.in", "r", stdin);
    freopen("count.out", "w", stdout);
    int n;
    for (read(n); n; n--) {
        int num;
        read(num);
        tot[num]++;
    }
    for (std :: map <int, int> :: iterator it = tot.begin(); it != tot.end(); it++)
        printf("%d %d\n", it -> first, it -> second);
    return 0;
}
