#include <cstdio>

const int N = 1001;

int dp[N][N], num1[N], num2[N];

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

template <typename Tp>
inline Tp max(const Tp num1, const Tp num2) {
    return num1 > num2 ? num1 : num2;
}

int main() {
    freopen("gong.in", "r", stdin);
    freopen("gong.out", "w", stdout);
    int n, m, ans = 0;
    read(n); read(m);
    for (int i = 1; i <= n; i++) read(num1[i]);
    for (int i = 1; i <= m; i++) read(num2[i]);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            if (num1[i] == num2[j]) dp[i][j] = max(dp[i][j], dp[i - 1][j - 1] + 1);
            if (dp[i][j] > ans) ans = dp[i][j];
        }
    printf("%d\n", ans);
    return 0;
}