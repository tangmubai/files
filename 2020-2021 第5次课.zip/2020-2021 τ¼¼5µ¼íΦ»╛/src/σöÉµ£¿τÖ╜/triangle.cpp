#include <cstdio>

const int N = 1000;

int dp[N][N], num[N][N];

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

template <typename Tp>
inline Tp max(const Tp num1, const Tp num2) {
    return num1 > num2 ? num1 : num2;
}

int main() {
    freopen("triangle.in", "r", stdin);
    freopen("triangle.out", "w", stdout);
    int n;
    while (~scanf("%d", &n) && n) {
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= i; j++)
                read(num[i][j]);
        for (int i = 1; i <= n; i++) dp[n][i] = num[n][i];
        for (int i = n - 1; i; i--)
            for (int j = 1; j <= i; j++)
                dp[i][j] = max(dp[i + 1][j], dp[i + 1][j + 1]) + num[i][j];
        printf("%d\n", dp[1][1]);
    }
    return 0;
}