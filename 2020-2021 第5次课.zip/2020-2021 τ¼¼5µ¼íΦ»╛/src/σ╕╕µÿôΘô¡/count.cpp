#include <stdio.h>
#include <algorithm>
using namespace std;

int a[1005];
main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n,sb;scanf("%d",&n);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	for(int i=1;i<=n;++i){
		sb=1;
		while(a[i]==a[i+1]){
			sb++;
			++i;
		}
		printf("%d %d\n",a[i],sb);
//		i+=sb;
	}
	return 0;
}

