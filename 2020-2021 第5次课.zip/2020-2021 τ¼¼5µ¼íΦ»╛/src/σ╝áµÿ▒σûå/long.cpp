#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,dp[10005],len=0,x;
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
dp[0]=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		if(x>dp[len])dp[++len]=x;
		else dp[lower_bound(dp+1,dp+1+len,x)-dp]=x;
	}
	printf("%d\n",len);
	return 0;
}
