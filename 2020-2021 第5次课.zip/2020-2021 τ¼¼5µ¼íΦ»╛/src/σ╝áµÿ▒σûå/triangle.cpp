#include<cstdio>
#include<cstring>
#include<algorithm>

inline int ma_x(int p,int q){return p>q?p:q;}
int n,a[101][101],f[101][101];
int main(){
		freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	
	scanf("%d",&n);
	while(n!=0){
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++)
		for(int j=1;j<=i;j++)scanf("%d",&a[i][j]);
		for(int i=1;i<=n;i++)f[n][i]=a[n][i];
		for(int i=n;i>=1;i--)
			for(int j=1;j<=n;j++)
			f[i][j]=ma_x(f[i+1][j],f[i+1][j+1])+a[i][j];
		printf("%d\n",f[1][1]);
		scanf("%d",&n);
	}
	return 0;
}
