#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[1005];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	int i=1;
	while(i<=n){
		int j=i,s=0;
		while(a[i]==a[j] && j<=n){
			j++,s++;
		}
		cout<<a[i]<<" "<<s<<endl;
		i=j;
	}
	return 0;
}
