#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int n,x[1005],ans[1005],k=1;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x[i]);
		ans[x[i]]++;
	}
	sort(x+1,x+n+1);
	for(int i=1;i<=n;i++){
		printf("%d ",x[i]);
		printf("%d ",ans[x[i]]);
		printf("\n");
		i+=ans[x[i]]-1;
	}
	return 0;
}
