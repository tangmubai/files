#include<stdio.h>
#include<iostream>
#include<algorithm>
int n,ans=0,x;
int a[105][105];
int max(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(scanf("%d",&n)){
		for(int i=1;i<=n&&scanf("%d",&a[i][1])!=0;i++)
		    for(int j=2;j<=i;j++)
			    scanf("%d",&a[i][j]);
		scanf("%d",&x);
		for(int i=1;i<=n;i++)
		    for(int j=1;j<=i;j++){
		    	a[i][j]=max(a[i-1][j],a[i-1][j-1])+a[i][j];
				ans=max(ans,a[i][j]);
		    }
	    printf("%d\n",ans);
	}
	return 0;
}
