#include "cstdio"
#include "algorithm"
using namespace std;
int a[10005],f[10005],n;
int main(){
	freopen ("long.in","r",stdin);
	freopen ("long.out","w",stdout);
	scanf ("%d",&n);
	for (int i=1;i<=n;i++) scanf ("%d",&a[i]);
	for (int i=1;i<=n;i++){
		f[i]=1;
		for (int j=1;j<i;j++){
			if (a[i]>a[j]) f[i]=max(f[i],f[j]+1);
		}
	}
	int mx=0;
	for (int i=1;i<=n;i++) mx=max(mx,f[i]);
	printf ("%d\n",mx);
	return 0;
}
