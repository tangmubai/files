#include "cstdio"
#include "cstring"
#include "algorithm"
using namespace std;
int a[1005][1005],f[1005][1005],n;
int main(){
	freopen ("triangle.in","r",stdin);
	freopen ("triangle.out","w",stdout);
	while (1){
		memset (f,0,sizeof f);
		memset (a,0,sizeof a);
		scanf ("%d",&n);
		if (n==0) return 0;
		for (int i=1;i<=n;i++)
			for (int j=1;j<=i;j++)
				scanf ("%d",&a[i][j]);
		for (int i=n;i>=1;i--){
			for (int j=1;j<=i;j++){
				f[i][j]=max(f[i+1][j],f[i+1][j+1])+a[i][j];
			}
		}
		printf ("%d\n",f[1][1]);
	}
	return 0;
}
