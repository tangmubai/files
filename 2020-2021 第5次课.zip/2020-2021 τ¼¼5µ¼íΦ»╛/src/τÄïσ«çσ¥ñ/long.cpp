#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
int xl[1005];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("long.in","r",stdin);freopen("long.out","w",stdout);
	int n=qread(),ans=0;
	for(int i=1,a,j;i<=n;++i){
		j=lower_bound(xl+1,xl+1+ans,(a=qread()))-xl;
		xl[j]=a;
		ans=max(ans,j);
	}
	printf("%d\n",ans);
	return 0;
}
