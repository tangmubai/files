#include <cstdio>
using namespace std;
int n,x,i,t[1000001];
int main () {
	freopen ("count.in","r",stdin);
	freopen ("count.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) {scanf ("%d",&x); t[x]++;}
	for (i=1;i<=1000000;i++) if (t[i]>0) printf ("%d %d\n",i,t[i]);
	return 0;
}
