#include <cstdio>
using namespace std;
int m,n,i,j,a[1001],b[1001],f[1001][1001];
int max (int a,int b) {return a>b?a:b;}
int main () {
	freopen ("gong.in","r",stdin);
	freopen ("gong.out","w",stdout);
	scanf ("%d%d",&m,&n);
	for (i=1;i<=m;i++) scanf ("%d",&a[i]);
	for (i=1;i<=n;i++) scanf ("%d",&b[i]);
	for (i=1;i<=m;i++) for (j=1;j<=n;j++) {
		if (a[i]==b[j]) f[i][j]=f[i-1][j-1]+1;
		else f[i][j]=max (f[i-1][j],f[i][j-1]);
	}
	printf ("%d",f[m][n]);
	return 0;
}
