#include <cstdio>
using namespace std;
int n,i,j,a[101][101];
int max (int a,int b) {return a>b?a:b;}
int main () {
	freopen ("triangle.in","r",stdin);
	freopen ("triangle.out","w",stdout);
	while (1) {
		scanf ("%d",&n);
		if (n==0) return 0;
		for (i=1;i<=n;i++) for (j=1;j<=i;j++) scanf ("%d",&a[i][j]);
		for (i=n-1;i;i--) for (j=1;j<=i;j++) a[i][j]+=max(a[i+1][j],a[i+1][j+1]);
		printf ("%d\n",a[1][1]);
	}
}
