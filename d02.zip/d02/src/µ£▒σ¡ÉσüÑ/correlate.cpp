#include <cstdio>
#include <algorithm>
#include <cstring>
#define max(a,b) ((a)>(b)?(a):(b))
char s1[253],s2[253],s3[253];
int len1,len2,t[27],f[253][253],len3;
int main(){
	freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
	scanf("%s%s",s1+1,s2+1);
	int len1=strlen(s1+1),len2=strlen(s2+1);
	for(int i=1;i<=len1;i++) ++t[s1[i]-'A'];
	for(int i=1;i<=len1;i++){
		for(int j=1;j<=len2;j++){
			if(s1[i]==s2[j]) f[i][j]=f[i-1][j-1]+1;
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	if(!f[len1][len2]) puts("Unique");
	else if(f[len1][len2]==1){
		puts("Middling");
		for(int i=1;i<=len2;i++) if(t[s2[i]-'A']){putchar(s2[i]);break;}
	}
	else{
		printf("Gloomy\n%d\n",f[len1][len2]);
		bool first=1;
		for(int i=1;i<=len2;i++) if(t[s2[i]-'A']) s3[++len3]=s2[i];
		std::sort(s3+1,s3+1+len3);
		for(int i=1;i<=len3;i++){
			if(first) first=0,putchar(s3[i]);
			else printf("-%c",s3[i]);
		}
	}
	return 0;
}
