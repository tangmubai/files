#include <cstdio>
#define max(a,b) ((a)>(b)?(a):(b))
char s1[103],s2[103];
int len1,len2,f[103][103];
const int a[5][5]={
	{5,-1,-2,-1,-3},
	{-1,5,-3,-2,-4},
	{-2,-3,5,-2,-2},
	{-1,-2,-2,5,-1},
	{-3,-4,-2,-1}
};
int trans(char c){
	if(c=='A') return 0;
	else if(c=='C') return 1;
	else if(c=='G') return 2;
	else if(c=='T') return 3;
	else if(c=='-') return 4;
}
int main(){
	freopen("gene.in","r",stdin);freopen("gene.out","w",stdout);
	scanf("%d%s%d%s",&len1,s1+1,&len2,s2+1);
	for(int i=1;i<=len1;i++) f[i][0]=a[trans(s1[i])][trans('-')];
	for(int i=1;i<=len2;i++) f[0][i]=a[trans('-')][trans(s2[i])];
	for(int i=1;i<=len1;i++)
		for(int j=1;j<=len2;j++)
			f[i][j]=max(f[i-1][j-1]+a[trans(s1[i])][trans(s2[j])],max(f[i-1][j]+a[trans('-')][trans(s2[j])],f[i][j-1]+a[trans(s1[i])][trans('-')]));
	//for(int i=0;i<=len1;i++){for(int j=0;j<=len2;j++) printf("%d ",f[i][j]);puts("");}
	printf("%d\n",f[len1][len2]);
	return 0;
}
