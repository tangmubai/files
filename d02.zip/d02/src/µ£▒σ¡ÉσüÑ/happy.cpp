#include <cstdio>
#define max(a,b) ((a)>(b)?(a):(b))
int n,v[203],c[203],f[103];
int main(){
	freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&v[i]);
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	for(int i=1;i<=n;i++) for(int j=100;j>v[i];j--) f[j]=max(f[j],f[j-v[i]]+c[i]);
	printf("%d\n",f[100]);
	return 0;
}
