#include <cstdio>
#define max(a,b) ((a)>(b)?(a):(b))
int k,m,x[1003],f[1003][1003];
bool buy[1003][1003];
int main(){
	freopen("shopping.in","r",stdin);freopen("shopping.out","w",stdout);
	scanf("%d%d",&k,&m);
	for(int i=1;i<=k;i++) scanf("%d",&x[i]);
	for(int i=1;i<=m;i++){
		int a,b;scanf("%d%d",&a,&b);
		buy[a][b]=1;
	}
	for(int i=1;i<=k;i++){
		for(int j=i+1;j<=k;j++){
			if(buy[i][j]) f[i][j]=f[i-1][j-1]+max(x[i],x[j]);
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	printf("%d\n",f[k][k]);
	return 0;
}
