#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
	{
		ch = getchar(), flag |= (ch == '-');
		if(ch == EOF)
		{
			n = EOF;
			return;
		}
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


char a[260], b[260];
bool ta[30], tb[30];

int main()
{
	freopen("correlate.in", "r", stdin);
	freopen("correlate.out", "w", stdout);
	
	
	scanf("%s%s", a, b);
	int sizea = strlen(a), sizeb = strlen(b);
	
	
	for(int i=0; i<sizea; i++)
		ta[a[i]-'A'] = 1;
	
	for(int i=0; i<sizeb; i++)
		tb[b[i]-'A'] = 1;
	
	
	vector<char> ans;
	
	for(int i=0; i<26; i++)
		if(ta[i] && tb[i])
			ans.push_back('A' + i);
	
	
	if(ans.size() == 0)
		puts("Unique");
	
	else if(ans.size() == 1)
		puts("Middling"), putchar(ans[0]);
	
	else
	{
		puts("Gloomy"), putchar(ans[0]);
		
		for(unsigned i=1; i<ans.size(); i++)
			putchar('-'), putchar(ans[i]);
	}
}

