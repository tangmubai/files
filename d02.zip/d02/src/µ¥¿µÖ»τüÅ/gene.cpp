#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
	{
		ch = getchar(), flag |= (ch == '-');
		if(ch == EOF)
		{
			n = EOF;
			return;
		}
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int w[10][10] =
{
	{5, 	-1,	-2,	-1,	-3}, 
	{-1,	 5,	-3,	-2,	-4},
	{-2,	-3,	 5,	-2,	-2},
	{-1,	-2,	-2,	 5,	-1},
	{-3,	-4,	-2,	-1,	0},
};

int f[110][110], a[110], b[110];


int main()
{
	freopen("gene.in", "r", stdin);
	freopen("gene.out", "w", stdout);
	
	
	int na, nb;
	
	in(na);
	
	for(int i=1; i<=na; i++)
	{
		char ch;
		cin >> ch;
		
		if(ch == 'A')
			a[i] = 0;
		else if(ch == 'C')
			a[i] = 1;
		else if(ch == 'G')
			a[i] = 2;
		else
			a[i] = 3;
	}
	
	in(nb);
	
	for(int i=1; i<=nb; i++)
	{
		char ch;
		cin >> ch;
		
		if(ch == 'A')
			b[i] = 0;
		else if(ch == 'C')
			b[i] = 1;
		else if(ch == 'G')
			b[i] = 2;
		else
			b[i] = 3;
	}
	
	
	for(int i=1; i<=na; i++)
		f[i][0] = f[i-1][0] + w[a[i]][4];
	
	for(int j=1; j<=nb; j++)
		f[0][j] = f[0][j-1] + w[4][b[j]];
		
	
	for(int i=1; i<=na; i++)
		for(int j=1; j<=nb; j++)
			f[i][j] = max(f[i-1][j-1] + w[a[i]][b[j]], max(f[i-1][j] + w[a[i]][4], f[i][j-1] + w[4][b[j]]));
	
	
	out(f[na][nb]);
}

