#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
	{
		ch = getchar(), flag |= (ch == '-');
		if(ch == EOF)
		{
			n = EOF;
			return;
		}
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int f[110], c[210], w[210];

int main()
{
	freopen("happy.in", "r", stdin);
	freopen("happy.out", "w", stdout);
	
	
	int n;
	in(n);
	
	for(int i=1; i<=n; i++)
		in(c[i]);
	
	for(int i=1; i<=n; i++)
		in(w[i]);
	
	
	for(int i=1; i<=n; i++)
		for(int j=99; j>=c[i]; j--)
			f[j] = max(f[j - c[i]] + w[i], f[j]);
	
	
	out(f[99]);
}

