#include<iostream>
#include<cstdio>
#include<cstring>
#include<map>
#include<algorithm>
using namespace std;
map<char,int>mp1;
map<char,int>mp2;
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	char a[255],b[255];
	cin>>a>>b;
	for(int i=0;i<strlen(a);i++)mp1[a[i]]=1;
	for(int i=0;i<strlen(b);i++)mp2[b[i]]=1;
	int ans=0,k=1;
	char ansn[30];
	for(int i=1;i<=26;i++)if(mp1[(char)64+i]==1&&mp2[(char)64+i]==1){
		ans++;
		ansn[k]=(char)64+i;
		k++;
	}
	if(ans==0){
		cout<<"Unique";
		return 0;
	}
	if(ans==1){
		cout<<"Middling"<<endl;
		cout<<ansn[1];
		return 0;
	}
	cout<<"Gloomy"<<endl;
	cout<<k-1<<endl;
	sort(ansn+1,ansn+k);
	for(int i=1;i<k-1;i++)cout<<ansn[i]<<"-";
	cout<<ansn[k-1];
	return 0;
}
