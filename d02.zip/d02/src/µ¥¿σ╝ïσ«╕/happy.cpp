#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int f[99][99];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n,v=100;
	cin>>n;
	int a[205],b[205];
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	for(int i=1;i<=n;i++){
		for(int j=1;j<=99;j++){
			if(j>=a[i]){
				f[i][j]=max(f[i-1][j-a[i]]+b[i],f[i-1][j]);
			}
		}
	}
	cout<<f[n][99];
	return 0;
}
