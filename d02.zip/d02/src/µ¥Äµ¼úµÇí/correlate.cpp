#include<cstring>
#include<string>
#include<stdio.h>
#include<iostream>
#include<algorithm>
#define ll long long
#include<set>
using namespace std;
set<char>s;
set<char>::iterator it,it1;
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	string a,b;
	ll len1,len2,ans=0;char an[300];
	cin>>a>>b;
	len1=a.size();
	len2=b.size();
	for(int i=0;i<len1;i++)
		for(int j=0;j<len2;j++)if(a[i]==b[j])s.insert(a[i]);
	ans=s.size();
	if(ans==0){
		printf("Unique\n");
		return 0;
	}
	if(ans==1){
		printf("Middling\n");
		it=s.begin();
		printf("%c\n",*it);
		return 0;
	}
	printf("Gloomy\n%lld\n",ans);
	for(it=s.begin();it!=s.end();it++){
		it1=++it;it--;
		if(it1==s.end())cout<<*it<<endl;
		else cout<<*it<<'-';
	}
	return 0;
}
