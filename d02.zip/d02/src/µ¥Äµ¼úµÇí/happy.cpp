#include<cstring>
#include<string>
#include<stdio.h>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
ll c[300],w[300],f[1005];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	ll n;
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++)scanf("%lld",&w[i]);
	for(ll i=1;i<=n;i++)scanf("%lld",&c[i]);
	for(ll i=1;i<=n;i++)
		for(ll v=n;v>=w[i];v--)
			if(f[v]<f[v-w[i]]+c[v])f[v]=f[v-w[i]]+c[v];
	printf("%lld\n",f[n]);                           
	return 0;          
}
