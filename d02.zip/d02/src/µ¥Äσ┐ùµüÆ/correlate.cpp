#include<stdio.h>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
char a[300],b[300];
bool v[50];
int main(){
	file("correlate");
	scanf("%s%s",a,b);
	int cnt=0;
	for(int i=0;a[i];i++){
		for(int j=0;b[j];j++){
			if(a[i]==b[j]){
				cnt+=(!v[a[i]-64]);
				v[a[i]-64]=1;
			}
		}
	}
	if(cnt==0){
		printf("Unique\n");
	}
	if(cnt==1){
		printf("Middling\n");
	}
	if(cnt>1){
		printf("Gloomy\n%d\n",cnt);
	}
	int flag=0;
	for(int i=1;i<=26;i++){
		if(v[i]){
			if(flag){
				putchar('-');
				putchar(i+64);
			}else{
				putchar(i+64);
				flag=1;
			}
		}
	}
}
