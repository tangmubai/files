#include<stdio.h>
#define max(a,b)((a)>(b)?(a):(b))
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
int w[250],v[250],dp[150];
int main(){
	file("happy");
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&w[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=100;j>=w[i];j--){
			dp[j]=max(dp[j],dp[j-w[i]]+v[i]);
		}
	}
	printf("%d\n",dp[99]);
}
