#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
char a[300],b[300],c[300];
int la,lb,i,sa[30],sb[30],ans;
int main () {
	freopen ("correlate.in","r",stdin);
	freopen ("correlate.out","w",stdout);
	scanf ("%s%s",a+1,b+1);
	la=strlen (a+1);
	lb=strlen (b+1);
	for (i=1;i<=la;i++) 
		sa[a[i]-64]++;
	for (i=1;i<=lb;i++) 
		sb[b[i]-64]++;
	for (i=1;i<=26;i++) 
		if (sa[i]>0&&sb[i]>0) {
			ans++;
			c[ans]=i+64;
		}
	if (ans==0) {
		puts ("Unique");
		return 0;
	}
	if (ans==1) {
		printf ("Middling\n%c\n",c[ans]);
		return 0;
	}
	if (ans>1) {
		printf ("Gloomy\n%d\n",ans);
		for (i=1;i<ans;i++)
			printf ("%c-",c[i]);
		printf ("%c\n",c[i]);
		return 0;
	}
	return 0;
}
