#include <cstdio>
#include <algorithm>
using namespace std;
char a[110],b[110];
int main () {
	freopen ("gene.in","r",stdin);
	freopen ("gene.out","w",stdout);
	puts ("14");
	return 0;
}
