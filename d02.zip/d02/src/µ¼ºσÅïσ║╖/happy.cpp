#include <cstdio>
#include <algorithm> 
using namespace std;
struct Node {
	int v;
	int w;
}a[210];
int n,i,f[2010],t=99,j;
int main () {
	freopen ("happy.in","r",stdin);
	freopen ("happy.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) 
		scanf ("%d",&a[i].v);
	for (i=1;i<=n;i++)
		scanf ("%d",&a[i].w);
	for (i=1;i<=n;i++) 
		for (j=t;j>=a[i].v;j--)
			f[j]=max (f[j],f[j-a[i].v]+a[i].w);
	printf ("%d\n",f[t]);
	return 0;
}
