#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
char a[255],b[255];
bool ok1[205]={0},ok2[205]={0};
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s",a+1);scanf("%s",b+1);
	int l1=strlen(a+1),l2=strlen(b+1);
	for(int i=1;i<=l1;i++)ok1[a[i]-'A']=1;
	for(int i=1;i<=l2;i++)ok2[b[i]-'A']=1;
	int ans=0;
	for(int i=0;i<26;i++)if(ok1[i]&&ok2[i])ans++;
	if(ans==0){
		printf("Unique");return 0;
	}
	if(ans==1){
		printf("Middling\n");
		for(int i=0;i<26;i++){
			if(ok1[i]&&ok2[i]){
				printf("%c",i+'A');
				break;
			}
		}
		return 0;
	}
	if(ans>=2){
		bool p=1;
		printf("Gloomy\n%d\n",ans);
		for(int i=0;i<26;i++){
			if(ok1[i]&&ok2[i]){
				if(p==1){
					printf("%c",i+'A');p=0;
				}
				else {
					printf("-%c",i+'A');
				}
			}
		}
	}
	return 0;
}


