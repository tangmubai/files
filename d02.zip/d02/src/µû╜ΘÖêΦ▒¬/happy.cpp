#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int c[205],v[205];
int dp[205][105];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&c[i]);
	for(int i=1;i<=n;i++)scanf("%d",&v[i]);
	memset(dp,0,sizeof(dp));
	for(int i=1;i<=n;i++){
		for(int j=100;j>c[i];j--){
			dp[i][j]=max(dp[i-1][j],dp[i-1][j-c[i]]+v[i]);
		}
	}
	printf("%d",dp[n][100]);
	return 0;
}


