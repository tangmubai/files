#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
char s1[260],s2[260];
bool a[30];int ans[30];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s%s",s1,s2);
	int l1=strlen(s1),l2=strlen(s2);
	for(int i=0;i<l1;i++)
		a[s1[i]-'A']=1;
	int s=0;
	for(int i=0;i<l2;i++)
		if(a[s2[i]-'A']==1){
			s++;
			ans[s]=s2[i]-'A';
		}
	if(s==0)printf("Unique");
	else if(s==1){
		puts("Middling");
		printf("%c",ans[1]+'A');
	}
	else{
		puts("Gloomy");
		printf("%d\n",s);
		sort(ans+1,ans+1+s);
		for(int i=1;i<s;i++)
			printf("%c-",ans[i]+'A');
		printf("%c",ans[s]+'A');
	}
	return 0;
}

