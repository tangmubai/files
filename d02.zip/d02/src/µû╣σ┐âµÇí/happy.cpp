#include <cstdio>
struct Node{
	int a,b;
}p[210];
int f[110];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&p[i].a);
	for(int i=1;i<=n;i++)
		scanf("%d",&p[i].b);
	for(int i=1;i<=n;i++)
		for(int j=100;j>p[i].a;j--)
			if(f[j-p[i].a]+p[i].b>f[j])
				f[j]=f[j-p[i].a]+p[i].b;
	printf("%d\n",f[100]);
	return 0;
}

