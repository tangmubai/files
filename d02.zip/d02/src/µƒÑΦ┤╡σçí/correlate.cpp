#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n,m,com;
char a[255],b[255],ans[255];
bool t[35];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s%s",a+1,b+1);
	n=strlen(a+1),m=strlen(b+1);
	for(int i=1;i<=m;++i){
		t[b[i]-'A']=1;
	}
	for(int i=1;i<=n;++i){
		if(t[a[i]-'A']){
			t[a[i]-'A']=0;
			ans[++com]=a[i];
		}
	}
	if(com==0){
		printf("Unique");
		return 0;
	}
	if(com==1){
		printf("Middling\n");
		putchar(ans[1]);
		return 0;
	}
	printf("Gloomy\n%d\n",com);
	sort(ans+1,ans+com+1);
	putchar(ans[1]);
	for(int i=2;i<=com;++i){
		putchar('-');
		putchar(ans[i]);
	}
	return 0;
}
