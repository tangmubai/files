#include <cstdio>

int n,m;
int f[105][105],mp[35],mp2[35][35];
char a[105],b[105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Max(int x,int y){
	return x>y?x:y;
}

int main(){
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	n=read();
	scanf("%s",a+1);
	m=read();
	scanf("%s",b+1);
	mp[0]=-3,mp[2]=-4,mp[6]=-2,mp[19]=-1;
	mp2[0][2]=mp2[2][0]=-1;
	mp2[0][6]=mp2[0][6]=-2;
	mp2[0][19]=mp2[0][19]=-1;
	mp2[2][6]=mp2[6][2]=-3;
	mp2[2][19]=mp2[19][2]=-2;
	mp2[6][19]=mp2[19][6]=-2;
	for(int i=1;i<=n;++i){
		f[i][0]=f[i-1][0]+mp[a[i]-'A'];
	}
	for(int j=1;j<=m;++j){
		f[0][j]=f[0][j-1]+mp[b[j]-'A'];
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			if(a[i]==b[j]){
				f[i][j]=f[i-1][j-1]+5;
			}else {
				f[i][j]=Max(f[i-1][j-1]+mp2[a[i]-'A'][b[j]-'A'],Max(f[i-1][j]+mp[a[i]-'A'],f[i][j-1]+mp[b[j]-'A']));
			}
		}
	}
	printf("%d",f[n][m]);
	return 0;
}
