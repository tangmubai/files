#include <cstdio>

struct Person{
	int need,happy;
}a[205];

int n;
int f[105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Max(int x,int y){
	return x>y?x:y;
}

int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i){
		a[i].need=read();
	}
	for(int i=1;i<=n;++i){
		a[i].happy=read();
	}
	for(int i=1;i<=n;++i){
		for(int j=100;j>a[i].need;--j){
			f[j]=Max(f[j],f[j-a[i].need]+a[i].happy);
		}
	}
	printf("%d",f[100]);
	return 0;
}
