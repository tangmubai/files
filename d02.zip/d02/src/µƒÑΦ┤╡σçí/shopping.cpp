#include <cstdio>

struct Edge{
	int to,nxt;
}a[2000005];

int n,m,ans,sum,edge_num;
int p[1005],head[1005],f[1005][3];
bool vis[1005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Max(int x,int y){
	return x>y?x:y;
}

void add_edge(int x,int y){
	a[++edge_num].nxt=head[x];
	a[edge_num].to=y;
	head[x]=edge_num;
}

void dfs(int i,int fa){
	vis[i]=1;
	for(int j=head[i];j;j=a[j].nxt){
		if(a[j].to==fa || vis[a[j].to])continue;
		dfs(a[j].to,i);
		f[i][1]+=f[a[j].to][0];
		f[i][0]+=f[a[j].to][1];
	}
	f[i][1]+=p[i];
	return;
}

int main(){
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i){
		p[i]=read();
	}
	for(int i=1;i<=m;++i){
		int x=read(),y=read();
		add_edge(x,y);
		add_edge(y,x);
	}
	for(int i=1;i<=n;++i){
		if(!vis[i]){
			dfs(i,0);
			ans+=Max(f[i][1],f[i][0]);
		}
	}
	printf("%d",ans);
	return 0;
}
