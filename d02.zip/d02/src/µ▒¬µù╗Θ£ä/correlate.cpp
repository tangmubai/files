#include<stdio.h>
#include<string.h>
bool a[35],b[35];
char x[255],y[255];
int lena,lenb,ans;
int main(){
	freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
	scanf("%s%s",x+1,y+1);
	lena=strlen(x+1);lenb=strlen(y+1);
	for(register int i=1;i<=lena;++i)
	a[x[i]-'A']=1;
	for(register int i=1;i<=lenb;++i)
	b[y[i]-'A']=1;
	for(register int i=0;i<26;++i)
	ans+=a[i]&&b[i];
	if(!ans){
		printf("Unique");return 0;
	}
	if(ans==1){
		printf("Middling\n");
		for(register int i=0;i<26;++i)
		a[i]&&b[i]?printf("%c",i+'A'):0;
		return 0;
	}
	printf("Gloomy\n%d\n",ans);
	for(register int i=0;i<26;++i)
	a[i]&&b[i]?ans>1?--ans,printf("%c-",i+'A'):printf("%c",i+'A'):0;
}
