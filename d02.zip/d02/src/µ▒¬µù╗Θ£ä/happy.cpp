#include<stdio.h>
#define m 100
int c[205],w[205],f[105],n;
#define max(a,b) a>b?a:b
int main(){
	freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;++i)scanf("%d",&c[i]);
	for(register int i=1;i<=n;++i)scanf("%d",&w[i]);
	for(register int i=1;i<=n;++i)
	for(register int j=m;j>c[i];--j)f[j]=max(f[j],f[j-c[i]]+w[i]);
	printf("%d",f[m]);
}
