#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int ans,la,lb;
char a[300],b[300],c[300];
bool v[30];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s%s",a,b);
	la=strlen(a),lb=strlen(b);
	for(int i=0;i<la;i++)
	    for(int j=0;j<lb;j++)
	        if(a[i]==b[j])
	        	if(!v[a[i]-'A']){
			        c[ans++]=a[i];
			        v[a[i]-'A']=1;
	            }
	if(ans==0){
		printf("Unique\n");
		return 0;
	}
	if(ans==1){
		printf("Middling\n%c",c[0]);
	}
	sort(c,c+ans);
	printf("Gloomy\n%d\n%c",ans,c[0]);
	for(int i=1;i<ans;i++)
	    printf("-%c",c[i]);
	return 0;
}

