#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int main(){
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	printf("14");
	return 0;
}

