#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int n,sum,ans;
struct node{
	int l,w;
}a[250];
bool cmp(node x,node y){
	if(x.l==y.l)
	    return x.w>y.w;
	return x.l<y.l;
}
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	    scanf("%d",&a[i].l);
	for(int i=1;i<=n;i++)
	    scanf("%d",&a[i].w);
	sort(a+1,a+1+n,cmp);
	int i=1;
	while(i<=n&&sum+a[i].l<100){
	    ans+=a[i].w;
		sum+=a[i].l;
		i++;
	}
	printf("%d\n",ans);
	return 0;
}

