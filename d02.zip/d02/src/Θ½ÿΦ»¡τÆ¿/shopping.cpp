#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<map>
using namespace std;
int k,m,v[110],x,y,ans;
struct node{
	int i,num;
}a[1010];
bool cmp(node x,node y){
	return x.num>y.num;
}
int main(){
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	scanf("%d%d",&k,&m);
	for(int i=1;i<=k;i++){
		scanf("%d",&a[i].num);
		a[i].i=i;
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		if(v[x]==0&&v[y]==0){
			   ans+=max(a[x].num,a[y].num);
			   v[x]=1;
			   v[y]=1;
		}
		else if(!v[x]) ans+=a[x].num,v[x]=1;
		else if(!v[y]) ans+=a[y].num,v[y]=1;
	}
	for(int i=1;i<=k;i++)
		if(!v[i])
		    ans+=a[i].num;
	printf("%d\n",ans);
	return 0;
}

