#include <iostream>
#include <cstring>
using namespace std;
char c1[255];
char c2[255];
int f1[30];
int f2[30];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	cin>>c1>>c2;
	for(int i=0;i<strlen(c1);i++)
	f1[c1[i]-'A']++;
	for(int i=0;i<strlen(c2);i++)
	f2[c2[i]-'A']++;
	int s=0;
	for(int i=0;i<26;i++)
	if(f1[i]&&f2[i])s++;
	if(!s){
		cout<<"Unique";
		return 0;
	}
	if(s==1)cout<<"Middling"<<endl;
	else cout<<"Gloomy"<<endl<<s<<endl;
	bool f=1;
	for(int i=0;i<26;i++){
		if(f1[i]&&f2[i]){
			if(f)f=0;
			else cout<<'-';
			cout<<char(i+'A');
		}
	}
}
