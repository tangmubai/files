#include<iostream>
#include <algorithm>
using namespace std;
int n;
int a[205],b[205];
int f[105];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	for(int i=1;i<=n;i++)
	cin>>b[i];
	for(int i=1;i<=n;i++)
	for(int j=100;j>a[i];j--)
	f[j]=max(f[j],f[j-a[i]]+b[i]);
	cout<<f[100];
}
