#include <iostream>
#include<algorithm>
using namespace std;
int k,m;
int a[1005];
bool f[1005][1005];
int ans=-1;
bool vis[1005];
void dfs(int now,int sum){
	if(now>k){
		ans=max(ans,sum);
		return;
	}
	dfs(now+1,sum);
	for(int i=1;i<now;i++){
		if(vis[i]&&!f[i][now]){
			vis[now]=1;
			dfs(now+1,sum+a[now]);
			vis[now]=0;
		}
		if(f[i][now]&&!vis[i]){
			vis[now]=1;
			dfs(now+1,sum+a[now]);
			vis[now]=0;
		}
	}
}
int main(){
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	cin>>k>>m;
	for(int i=1;i<=k;i++)
	cin>>a[i];
	for(int i=1;i<=m;i++){
		int x,y;cin>>x>>y;
		f[x][y]=f[y][x]=1;
	}
	dfs(1,0);
	cout<<ans;
} 
