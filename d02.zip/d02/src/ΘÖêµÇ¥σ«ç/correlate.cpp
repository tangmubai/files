#include<algorithm>
#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;

char s1[255],s2[255];
int a1[26],a2[26];
char s[26];

int cmp(int i)
{
	
	if(a1[i]>a2[i]||a1[i]==a2[i]&&a2[i]!=0&&a1[i]!=0)return 1;
	return 0;
}
int main()
{
	int ls1,ls2,i,x=0,j=0;
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s",s1);scanf("%s",s2);
	ls1=strlen(s1)-1;
	ls2=strlen(s2)-1;
	
	sort(s1,s1+ls1);sort(s2+1,s2+ls2);

	for(i=0;i<ls1;i++)a1[s1[i]-'A']++;
	for(i=0;i<ls2;i++)a2[s2[i]-'A']++;
	
	for(i=0;i<26;i++)
	{
		if(cmp(i)==1)x++,s[i]=i+'A';
	}
	
	if(x==0)printf("Unique");
	else if(x==1){
	printf("Middling\n");
	for(i=0;i<26;i++)if(cmp(i)==1)printf("%c",s[i]);

	}
	else {
	printf("Gloomy\n%d\n",x);
	
	for(i=0;i<26;i++)
	{
		if(j==x-1)break;
		if(cmp(i)==1){cout<<s[i]<<'-';j++;}
	}
	
	for(;i<26;i++)if(cmp(i)==1)printf("%c",s[i]);

	}
}
