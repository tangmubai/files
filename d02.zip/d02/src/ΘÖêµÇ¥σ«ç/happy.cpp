#include<iostream>
using namespace std;
int c[1001],w[1001],f[1001][1001],i,j,n,m;
int main()
{
	m=100;
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)cin>>w[i];
	for(i=1;i<=n;i++)cin>>c[i];
	for(i=1;i<=n;i++)
	{
		for(j=m;j>=1;j--)
		{
			if(w[i]<j)f[i][j]=max(f[i-1][j],f[i-1][j-w[i]]+c[i]);
  		 	else f[i][j]=f[i-1][j];
		}
	}
	cout<<f[n][m];
    return 0;
}
