#include<cstdio>
#include<cstring>
using namespace std;

int n;
char a[255],b[255],same[30];
bool f1[30],f2[30];

int main(){
	freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
	scanf("%s%s",a+1,b+1);
	for(int i=1;i<=strlen(a+1);i++) f1[a[i]-'A']=1;
	for(int i=1;i<=strlen(b+1);i++) f2[b[i]-'A']=1;
	for(int i=0;i<26;i++) if(f1[i]&&f2[i]) same[++n]='A'+i;
	if(n==0) printf("Unique\n");
	else if(n==1) printf("Middling\n%c\n",same[1]);
	else{
		printf("Gloomy\n%d\n",n);
		for(int i=1;i<n;i++) printf("%c-",same[i]);
		printf("%c\n",same[n]);
	}
	return 0;
}
