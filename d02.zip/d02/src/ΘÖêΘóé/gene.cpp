#include<cstdio>
using namespace std;
int main(){
	freopen("gene.in","r",stdin);freopen("gene.out","w",stdout);
	printf("14");
	return 0;
}

