#include<cstdio>
#include<algorithm>
using namespace std;

const int v=100;
int n,c[205],w[205],f[205][105];

int main(){
	freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	for(int i=1;i<=n;i++)
		for(int j=c[i]+1;j<=v;j++)
			f[i][j]=max(f[i-1][j],f[i-1][j-c[i]]+w[i]);
	printf("%d\n",f[n][v]);
	return 0;
}
