#include<cstdio>
#define max(i,j) i>j?i:j
using namespace std;

int n,m,ans,a[1005];
bool f[1005][1005],v[1005];

void dfs(int now,int sum){
	if(now>n){
		ans=max(ans,sum);
		return;
	}
	dfs(now+1,sum);
	if(v[now]) return;
	for(int i=1;i<=n;i++) if(f[i][now]) v[i]=1;
	dfs(now+1,sum+a[now]);
	for(int i=1;i<=n;i++) if(f[i][now]) v[i]=0;
}

int main(){
	freopen("shopping.in","r",stdin);freopen("shopping.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d %d",&x,&y);
		f[x][y]=f[y][x]=1;
	}
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}
