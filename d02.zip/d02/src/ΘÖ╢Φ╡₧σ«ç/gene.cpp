#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int f[105][105];
char a[105];
char b[105];
int lena,lenb; 
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
inline int cal(char c1,char c2){
	if(c1=='A')
	{
		if(c2=='A') return 5;
		if(c2=='C') return -1;
		if(c2=='G') return -2;
		if(c2=='T') return -1;
		if(c2=='-') return -3;
	}
	if(c1=='C')
	{
		if(c2=='A') return -1;
		if(c2=='C') return 5;
		if(c2=='G') return -3;
		if(c2=='T') return -2;
		if(c2=='-') return -4;
	}
	if(c1=='G')
	{
		if(c2=='A') return -2;
		if(c2=='C') return -3;
		if(c2=='G') return 5;
		if(c2=='T') return -2;
		if(c2=='-') return -2;
	}
	if(c1=='T')
	{
		if(c2=='A') return -1;
		if(c2=='C') return -2;
		if(c2=='G') return -2;
		if(c2=='T') return 5;
		if(c2=='-') return -1;
	}
	if(c1=='-')
	{
		if(c2=='A') return -3;
		if(c2=='C') return -4;
		if(c2=='G') return -2;
		if(c2=='T') return -1;
	}
}
int main()
{
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	read(lena);scanf("%s",1+a);
	read(lenb);scanf("%s",1+b);
	for(int i=1;i<=lena;i++) f[i][0]=f[i-1][0]+cal(a[i],'-');
	for(int i=1;i<=lenb;i++) f[0][i]=f[0][i-1]+cal('-',b[i]);
	for(int i=1;i<=lena;i++)
		for(int j=1;j<=lenb;j++)
		{
			int t1=cal(a[i],'-')+f[i-1][j];
			int t2=cal('-',b[j])+f[i][j-1];
			int t3=cal(a[i],b[j])+f[i-1][j-1];
			f[i][j]=mx(t1,mx(t2,t3));
		}
	printf("%d\n",f[lena][lenb]);
	return 0;
}
