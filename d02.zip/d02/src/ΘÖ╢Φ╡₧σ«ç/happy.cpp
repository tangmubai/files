#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
ll f[105];
ll w[205],c[205];
ll n;
inline void read(ll &x)
{
	ll f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline ll mx(ll _x,ll _y)
{
	return _x>_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
int main()
{
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++) read(c[i]);
	for(int i=1;i<=n;i++) read(w[i]);
	for(int i=1;i<=n;i++)
	{
		for(int j=100;j>c[i];j--)
			f[j]=mx(f[j],f[j-c[i]]+w[i]);
	}	
	printf("%lld\n",f[100]);
	return 0;
}
