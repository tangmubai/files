#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
struct node
{
	int nxt;
	int p;
}e[1000005];
int head[1005],tot;
int f[1005],g[1005],c[1005];
int ans;
int n,m;
int x,y;
bool vis[1005];
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
inline void add(int from,int to)
{
	e[++tot].p=to;
	e[tot].nxt=head[from];
	head[from]=tot;
}
inline void dfs(int p)
{
	vis[p]=true;
	for(int i=head[p];i;i=e[i].nxt)
	{
		int v=e[i].p;
		if(vis[v]) continue;
		dfs(v);
		f[p]=f[p]+g[v];
		g[p]=g[p]+mx(g[v],f[v]);
	}
	f[p]+=c[p];return ;
}
int main()
{
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	read(n);read(m);
	for(int i=1;i<=n;i++) read(c[i]);
	for(int i=1;i<=m;i++){
		read(x);read(y);
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=n;i++)
	{
		if(vis[i]) continue;
		dfs(i);
		ans+=mx(f[i],g[i]);
	}
	printf("%d\n",ans);
	return 0;
}
