#include<stdio.h>
#include<cstring>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
char a[255],b[255];int d[30],c[30];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s%s",a,b);
	sort(a,a+strlen(a));sort(b,b+strlen(b));
	int ja=strlen(a),jb=strlen(b),js=0;
	for(int i=0;i<ja;i++)d[a[i]-'A']=1;
	for(int i=0;i<jb;i++)if(d[b[i]-'A']&&!c[b[i]-'A'])js++,c[b[i]-'A']=1;
	if(js==0){printf("Unique");}
	else if(js==1){printf("Middling\n");for(int i=0;i<=25;i++)if(c[i])printf("%c",i+'A');}
	else{
		printf("Gloomy\n%d\n",js);int t=0;
		for(int i=0;i<=25;i++)if(c[i]){t++;printf("%c",i+'A');if(t!=js)printf("-");}
	}
	return 0;
}

