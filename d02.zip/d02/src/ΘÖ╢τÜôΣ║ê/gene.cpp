#include<stdio.h>
#include<iostream>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int t[6][6]={{0,0,0,0,0,0},{0,5,-1,-2,-1,-3},{0,-1,5,-3,-2,-4},
{0,-2,-3,5,-2,-2},{0,-1,-2,-2,5,-1},{0,-3,-4,-2,-1,0}
},a[105],b[105],dp[105][105];
int main(){
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	int n=read(),m;
	for(int i=1;i<=n;i++){
		char x;cin>>x;if(x=='A')a[i]=1;if(x=='C')a[i]=2;if(x=='G')a[i]=3;if(x=='T')a[i]=4;
	}m=read();
	for(int i=1;i<=m;i++){
		char x;cin>>x;if(x=='A')b[i]=1;if(x=='C')b[i]=2;if(x=='G')b[i]=3;if(x=='T')b[i]=4;
	}
	for(int i=1;i<=n;i++)dp[i][0]+=t[a[i]][5],dp[0][i]+=t[b[i]][5];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			dp[i][j]=max(dp[i][j-1]+t[a[i]][5],max(dp[i-1][j]+t[b[j]][5],dp[i-1][j-1]+t[a[i]][b[j]]));
		}
	printf("%d",dp[n][m]);
	return 0;
}

