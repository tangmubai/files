#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int c[205],w[205],dp[105];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++)c[i]=read();
	for(int i=1;i<=n;i++)w[i]=read();
	for(int i=1;i<=n;i++)
		for(int j=100;j>c[i];j--)
			dp[j]=max(dp[j],dp[j-c[i]]+w[i]);
	printf("%d",dp[100]);
	return 0;
}

