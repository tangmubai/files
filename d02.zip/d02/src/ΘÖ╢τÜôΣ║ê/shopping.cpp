#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[1005],b[1005][1005],c[1005],d[1005];
int main(){
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++){
		c[i]=read(),d[i]=read();
		b[c[i]][d[i]]=b[d[i]][c[i]]=-1;
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		int t=1;
		for(int j=1;j<=n;j++)
			if(b[i][j]){t=0;break;}
		if(t)ans+=a[i];
	}
	for(int i=1;i<=m;i++)ans+=max(a[d[i]],a[c[i]]);
	printf("%d",ans);
	return 0;
}

