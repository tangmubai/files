#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<set>
using namespace std;
char a[255],b[255],ans[255];
int lena,lenb,k=0,ss;
set<char>s;
set<char>::iterator it,ir;
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s\n%s",a,b);
	lena=strlen(a);
	lenb=strlen(b);
	for(int i=0;i<lena;i++){
		int s=0;
		for(int j=0;j<lenb;j++){
			if(a[i]==b[j]) s++;
		}
		if(s>=1) ss++,ans[k]=a[i],k++;
	}
	k--;
	if(!ss) printf("Unique");
	else{
		if(ss==1){
			printf("Middling\n");
			printf("%c\n",ans[0]);
		}
		if(ss>=2){
			printf("Gloomy\n");
			printf("%d\n",ss);
			for(int i=0;i<ss;i++) s.insert(ans[i]);
			for(it=s.begin();it!=s.end();it++){
				ir=it;
				ir++;
				if(ir!=s.end()) printf("%c-",*it);
				else{
					printf("%c",*it);
					break;
				} 
			} 
		}
	}	
	return 0;
}

