#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,w[205],c[205],f[1000005];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	for(int i=1;i<=n;i++)
		for(int j=100;j>w[i];j--)
			f[j]=max(f[j-w[i]]+c[i],f[j]);
	printf("%d\n",f[100]);
	return 0;
}

