#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int k,m,c[1005],ans=0,x,y;
int main(){
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	scanf("%d%d",&k,&m);
	for(int i=1;i<=k;i++) scanf("%d",&c[i]),ans+=c[i];
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		if(c[x]<c[y]) ans-=c[x];
		else ans-=c[y];
	} 
	printf("%d\n",ans);
	return 0;
}

