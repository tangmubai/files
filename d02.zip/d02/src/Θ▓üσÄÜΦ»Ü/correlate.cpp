
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
char a[300],b[300],d[300];
int cnt,ans,c[30];
int main()
{freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
 cin>>a+1;cin>>b+1;
 int n=strlen(a+1),m=strlen(b+1);
 for(int i=1;i<=n;i++)
{for(int j=1;j<=m;j++)
{if(a[i]==b[j]) c[a[i]-'A']++;
}
}
 for(int i=0;i<26;i++)
 if(c[i]!=0) ans++,d[++cnt]=char('A'+i);
 if(ans==0) cout<<"Unique"<<endl;
 else if(ans==1)
{cout<<"Middling"<<endl<<d[1]<<endl;
}
 else
{cout<<"Gloomy"<<endl;
 cout<<ans<<endl;
 for(int i=1;i<cnt;i++) cout<<d[i]<<"-";
 cout<<d[cnt]<<endl;
}
 return 0;
}
