
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,d[10][10]=
{{0,0,0,0,0,0},
 {0,5,-1,-2,-1,-3},
 {0,-1,5,-3,-2,-4},
 {0,-2,-3,5,-2,-2},
 {0,-1,-2,-2,5,-1},
 {0,-3,-4,-2,-1,0}
};
int f[110][110];
int a[110],b[110];
int main()
{freopen("gene.in","r",stdin);freopen("gene.out","w",stdout);
 memset(f,128,sizeof(f));
 for(int i=0;i<=100;i++) f[0][i]=0,f[i][0]=0;
 cin>>n;
 for(int i=1;i<=n;i++)
{char x;
 cin>>x;
 if(x=='A') a[i]=1;
 if(x=='C') a[i]=2;
 if(x=='G') a[i]=3;
 if(x=='T') a[i]=4;
}
 cin>>m;
 for(int i=1;i<=m;i++)
{char x;
 cin>>x;
 if(x=='A') b[i]=1;
 if(x=='C') b[i]=2;
 if(x=='G') b[i]=3;
 if(x=='T') b[i]=4;
}
 for(int i=1;i<=n;i++)
 for(int j=1;j<=m;j++)
{f[i][j]=max(max(f[i][j],f[i-1][j-1]+d[a[i]][b[j]]),max(f[i-1][j]+d[a[i]][5]+d[5][b[j]],f[i][j-1]+d[a[i]][5]+d[5][b[j]]));
}
 cout<<f[n][m]<<endl;
 return 0;
}
