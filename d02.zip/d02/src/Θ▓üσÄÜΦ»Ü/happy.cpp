
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int n,f[210],w[210],c[210];
int main()
{freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++) cin>>w[i];
 for(int j=1;j<=n;j++) cin>>c[j];
 for(int j=1;j<=n;j++)
 for(int k=99;k>=w[j];k--)
 f[k]=max(f[k],f[k-w[j]]+c[j]);
 cout<<f[99]<<endl;
 return 0;
}
