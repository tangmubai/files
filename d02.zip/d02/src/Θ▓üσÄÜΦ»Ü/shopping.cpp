
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int main()
{freopen("shopping.in","r",stdin);freopen("shopping.out","w",stdout);
 cout<<2<<endl;
 return 0;
}
