#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"vector"
#include"map"
#include"set"
#include"queue"
#include"iomanip"
using namespace std;
int l1,l2,ans;char c1[255],c2[255];bool a[30],b[30];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s\n%s",c1,c2);
	l1=strlen(c1);l2=strlen(c2);
	for(register int i=0;i<l1;i++){
		a[c1[i]-'A'+1]=1;
	}
	for(register int i=0;i<l2;i++){
		if(a[c2[i]-'A'+1]&&!b[c2[i]-'A'+1]){
			ans++;b[c2[i]-'A'+1]=1;
		}
	}	
	if(ans==0) printf("Unique");
	else if(ans==1){
		printf("Middling\n");
		for(register int i=1;i<=26;i++)
		if(b[i]){printf("%c",(char)(i+64));break;}
	}
	else{
		int t=0;
		printf("Gloomy\n%d\n",ans);
		for(register int i=1;i<=26;i++){
			if(b[i]){
				if(t==ans-1){
					printf("%c",(char)(i+64));
					break;
				}
				else{
					t++;
					printf("%c-",(char)(i+64));
				}
			}
		}
	}
	return 0;
}
