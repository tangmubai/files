#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
char a[260],b[260];
bool a1[35],b1[35];
bool c[35];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s%s",a,b);
	int ans=0;
	for(int i=0;i<strlen(a);i++) a1[a[i]-'A']=1;
	for(int i=0;i<strlen(b);i++) b1[b[i]-'A']=1;
	for(int i=0;i<26;i++){
		if(a1[i]==1&&b1[i]==1){
			c[i]=1;
			ans++;
		}
	}
	if(ans==0) printf("Unique\n");
	if(ans==1){
		printf("Middling\n");	
		for(int i=0;i<26;i++)
			if(c[i]==1) printf("%c\n",'A'+i);
	} 
	if(ans>1){
		printf("Gloomy\n%d\n",ans);
		bool flag=1;
		for(int i=0;i<26;i++){
			if(c[i]==1){
				if(flag==1){
					printf("%c",'A'+i);
					flag=0;
				}
				else printf("-%c",'A'+i);
			}
		}
	}
	return 0;
}
