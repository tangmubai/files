#include<cstdio>
#include<algorithm>
using namespace std;
int c[210],w[210];
int f[210][210];
int n;
int ans=0;
void dfs(int x,int t,int sum){
	if(f[x][t]!=0){
		ans=max(ans,f[x][t]);
		return;
	}
	ans=max(ans,sum);
	f[x][t]=sum;
	for(int i=x+1;i<=n;i++){
		if(t-c[i]>0){
			dfs(i,t-c[i],sum+w[i]);
		}
	}
}
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);
	int v=100;
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	dfs(0,100,0);
	printf("%d",ans);
	return 0;
}
