#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
char a[1005], b[1005];
int lena, lenb;
int ta[30], tb[30];
int ans[35];
int main()
{
	freopen("correlate.in", "r", stdin);
	freopen("correlate.out", "w", stdout);
	scanf("%s", a); scanf("%s", b);
	lena = strlen(a), lenb = strlen(b);
	for (int i = 0; i < lena; i++) ta[a[i] - 'A']=1;
	for (int i = 0; i < lenb; i++) tb[b[i] - 'A']=1;
	for (int i = 0; i <= 29; i++)
	{
		if (ta[i] && tb[i]) 
		{
			ans[++ans[0]] = i;
		}
	}
	if (ans[0] == 0) puts("Unique");
	else
	{
		if (ans[0] == 1) printf("Middling\n%c\n", 'A' + ans[1]);
		else 
		{
			printf("Gloomy\n%d\n", ans[0]);
			for (int i = 1; i < ans[0]; i++) printf("%c-", 'A'+ans[i]);
			printf("%c\n", 'A'+ans[ans[0]]);
		}
	}
	return 0;
}

