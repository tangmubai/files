#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int f[105];//f[i]��ʾ����Ϊiʱ��������ֵ 
int w[1005], c[1005], n;
int max(int a, int b)
{
	if (a > b) return a;
	else return b;
}
int main()
{
	freopen("happy.in", "r", stdin);
	freopen("happy.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) scanf("%d", &c[i]);
	for (int i = 1; i <= n; i++) scanf("%d", &w[i]);
	for (int i = 1; i <= n; i++)
	{
		for (int j = 100; j > c[i]; j--)
			f[j] = max(f[j], f[j - c[i]] + w[i]);
	}
	printf("%d", f[100]);
	return 0;
}

