#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
struct Node
{
	int nxt, p;
}e[1000005];
int head[1005], tot;
int f[1005], g[1005], c[1005], ans;
int n, m, x, y;
bool vis[1005];
void add(int from, int to)
{
	e[++tot].p = to;
	e[tot].nxt = head[from];
	head[from] = tot;
}
void dfs(int p)
{
	vis[p] = true;
	for (int i = head[p]; i ; i = e[i].nxt)
	{
		int v = e[i].p;
		if (vis[v]) continue;
		dfs(v);
		f[p] = f[p] + g[v];
		g[p] = g[p] + max(f[v], g[v]);
	}
}
int main()
{
	freopen("shopping.in", "r", stdin);
	freopen("shopping.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) scanf("%d", &c[i]);
	for (int i = 1; i <= m; i++) 
	{
		scanf("%d%d", &x, &y);
		add(x, y);
		add(y, x); 
	}
	for (int i = 1; i <= n; i++) 
	{
		if (vis[i]) continue;
		dfs(i);
		ans += max(f[i], g[i]);
	}
	printf("%d", ans);
	return 0;
}

