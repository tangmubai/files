#include<stdio.h>
#include<algorithm>
using namespace std;
char s1[255], s2[255];
int a[30];char ans[27], tot;
int b[30];
int main() {
	freopen("correlate.in", "r", stdin);
	freopen("correlate.out", "w", stdout);
	scanf("%s %s", s1, s2);
	for(int i = 0; s2[i]; ++i)
		a[s2[i] - 'A']  = 1;
	for(int i = 0; s1[i]; ++i)
		b[s1[i] - 'A'] = 1;
	for(int i = 0; i < 26; ++i)
		if (b[i] && a[i])
			ans[++tot] = i + 'A';	
	if (tot == 0)
	 	puts("Unique");
	else if (tot == 1)
		puts("Middling");
	else {
		puts("Gloomy");
		printf("%d\n", tot);
		sort(ans + 1, ans + tot + 1);
		printf("%c", ans[1]);
		for(int i = 2; i <= tot; ++i)
			printf("-%c", ans[i]);
		puts("");	
	}		 		
	return 0;		 
}
