#include<stdio.h>
#include<iostream>
const int N = 100;
using namespace std;
int w[20][20];
int n, m, f[N + 5][N + 5];
char s1[N + 5], s2[N + 5];
int a[N + 5], b[N + 5];
void make() {
	for(int i = 1; i <= 4; ++i)
		w[i][i] = 5;
	w[1][2] = -1;	w[1][3] = -2;
	w[1][4] = -1;	w[1][5] = -3;	w[2][1] = -1;	w[2][3] = -3;
	w[2][4] = -2; w[2][5] = -4;	w[3][1] = -2;
	w[3][2] = -3;	w[3][4] = -2;	w[3][5] = -2;
	w[4][1] = -1;	w[4][2] = -2;	w[4][3] = -2;	w[4][5] = -1;
	w[5][1] = -3;	w[5][2] = -4;	w[5][3] = -2;	w[5][4] = -1;	
}
int max(int x, int y) {
	if (x > y)
		return x;
	else return y;	
}
int main() {
	freopen("gene.in", "r", stdin);
	freopen("gene.out", "w", stdout);
	make();
	scanf("%d %s %d %s", &n, s1 + 1, &m, s2 + 1);
	a[0] = b[0] = 5;
	for(int i = 1; i <= n; ++i)
		if (s1[i] == 'A')
			a[i] = 1;
		else if (s1[i] == 'C')
			a[i] = 2;
		else if (s1[i] =='G')
			a[i] = 3;
		else if (s1[i] == 'T')
			a[i] = 4;
	for(int i = 1; i <= m; ++i)
		if (s2[i] == 'A')
			b[i] = 1;
		else if (s2[i] == 'C')
			b[i] = 2;
		else if (s1[i] =='G')
			b[i] = 3;
		else if (s2[i] == 'T')
			b[i] = 4;		
	for(int i = 1; i <= n; ++i)
		f[i][0] = f[i - 1][0] + w[a[i]][5];
	for(int i = 1; i <= m; ++i)
		f[0][i] = f[0][i - 1] + w[5][b[i]];						
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
			if (s1[i] == s2[j])
				f[i][j] = f[i - 1][j - 1] + 5;
			else 
				f[i][j] = max(max(f[i - 1][j] + w[5][a[i]], f[i][j - 1] + w[b[j]][5]), f[i - 1][j - 1] + w[a[i]][b[j]]);

	printf("%d\n", f[n][m]);
	return 0;		
}
