#include<stdio.h>
const int N = 200;
int n, c[N + 5], w[N + 5], f[N + 5], ans;
int max(int x, int y) {
	if (x < y)
		return y;
	else return x;	
}
int main() {
	freopen("happy.in", "r", stdin);
	freopen("happy.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i) 
		scanf("%d", &c[i]);
	for(int i = 1; i <= n; ++i)
		scanf("%d", &w[i]);
	for(int i = 1; i <= n; ++i)
		for(int j = 100; j >= c[i]; --j)
			f[j] = max(f[j], f[j - c[i]] + w[i]);
	for(int i = 0; i < 100; ++i)
		ans = max(ans, f[i]);
	printf("%d\n", ans);
	return 0;					
}
