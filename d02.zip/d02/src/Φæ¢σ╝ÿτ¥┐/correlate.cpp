#include <stdio.h>
#include <cstring>
#include <iostream>
using namespace std;
int a[100],len1,b[105],len2,tmp,x;
char s[105],ans[105];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	cin>>s;
	len1=strlen(s);
	for(int i=0;i<=len1-1;i++)
		a[s[i]-65]++;
	cin>>s;
	len2=strlen(s);
	for(int i=0;i<=len2-1;i++)
		b[s[i]-65]++;
	for(int i=0;i<=25;i++){
		if(a[i]>0&&b[i]>0){
			x++;
			ans[++tmp]=(char)i+65;
		}
	}
	if(x<1){
		printf("Unique\n");
		return 0;
	}
	if(x==1){
		printf("Middling\n");
		printf("%c",ans[1]);
		return 0;
	}
	if(x>1){
		printf("Gloomy\n");
		printf("%d\n",tmp);
		for(int i=1;i<=tmp-1;i++)
			printf("%c-",ans[i]);
		printf("%c",ans[tmp]);
	}
	return 0;
}
