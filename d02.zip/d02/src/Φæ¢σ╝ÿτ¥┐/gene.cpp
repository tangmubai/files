#include <stdio.h>
#include <cstring>
const int sm[10][10]={
{0},
{0,5,-1,-2,-1,-3},
{0,-1,5,-3,-2,-4},
{0,-2,-3,5,-2,-2},
{0,-1,-2,-2,5,-1},
{0,-3,-4,-2,-1}};
int n,m,len1,len2,a[105],b[105],f[105][105];
char s1[105],s2[105];
int Max(int a,int b){
	if(a>b)return a;
	else return b;
}
void in(){
	scanf("%d %s",&n,s1);
	scanf("%d %s",&m,s2);
	len1=strlen(s1);len2=strlen(s2);
	for(int i=0;i<=len1-1;i++){
		if(s1[i]=='A')a[i+1]=1;
		if(s1[i]=='C')a[i+1]=2;
		if(s1[i]=='G')a[i+1]=3;
		if(s1[i]=='T')a[i+1]=4;
	}
	for(int i=0;i<=len2-1;i++){
		if(s2[i]=='A')b[i+1]=1;
		if(s2[i]=='C')b[i+1]=2;
		if(s2[i]=='G')b[i+1]=3;
		if(s2[i]=='T')b[i+1]=4;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			f[i][j]=-1000;
	for(int i=1;i<=m;i++)
		f[0][i]=sm[5][b[i]];
	for(int i=1;i<=n;i++)
		f[i][0]=sm[5][a[i]];
}
int main(){
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	in();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			f[i][j]=Max(f[i][j],f[i-1][j-1]+sm[a[i]][b[j]]);
			f[i][j]=Max(f[i][j],f[i-1][j]+sm[a[i]][5]);
			f[i][j]=Max(f[i][j],f[i][j-1]+sm[b[j]][5]);
		}
	printf("%d",f[n][m]);
	return 0;
}
