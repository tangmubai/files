#include <stdio.h>
int n,a[205],b[205],f[40005];
int Max(int a,int b){
	if(a>b)return a;
	else return b;
} 
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	for(int i=n;i>=1;i--)
		for(int j=100;j>a[i];j--)
			f[j]=Max(f[j-a[i]]+b[i],f[j]);
	printf("%d",f[100]);
	return 0;
}
