#include <cstdio>
#include <cstring>
using namespace std;
char str[255];
int a[255],b[255];
int x[255];
int main(){
    freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
    scanf("%s",str+1);
    for(int i=1;str[i];++i) a[str[i]]=1;
    scanf("%s",str+1);
    for(int i=1;str[i];++i) b[str[i]]=1;
    int tot=0;
    for(int i='A';i<='Z';++i){
        if(a[i]&&b[i]){
            x[++tot]=i;
        }
    }
    if(tot==0) puts("Unique");
    else if(tot==1){
        puts("Middling");
        printf("%c",x[1]);
    }
    else{
        puts("Gloomy");
        printf("%d\n",tot);
        for(int i=1;i<tot;++i) printf("%c-",x[i]);
        printf("%c",x[tot]);
    }
    return 0;
}
