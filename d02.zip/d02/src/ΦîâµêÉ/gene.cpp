#include <cstdio>
#include <algorithm>
using namespace std;
int mp[5][5]=
{
    { 5,-1,-2,-1,-3},
    {-1, 5,-3,-2,-4},
    {-2,-3, 5,-2,-2},
    {-1,-2,-2, 5,-1},
    {-3,-4,-2,-1, 0}
};
int dp[105][105];
char a[105],b[105];
int main(){
    freopen("gene.in","r",stdin);freopen("gene.out","w",stdout);
    int l1,l2;scanf("%d %s",&l1,a+1);
    for(int i=1;i<=l1;++i){
        if(a[i]=='A') a[i]=0;
        if(a[i]=='C') a[i]=1;
        if(a[i]=='G') a[i]=2;
        if(a[i]=='T') a[i]=3;
    }
    scanf("%d %s",&l2,b+1);
    for(int i=1;i<=l2;++i){
        if(b[i]=='A') b[i]=0;
        if(b[i]=='C') b[i]=1;
        if(b[i]=='G') b[i]=2;
        if(b[i]=='T') b[i]=3;
    }
    for(int i=1;i<=l1;++i) dp[i][0]=dp[i-1][0]+mp[a[i]][4];
    for(int i=1;i<=l2;++i) dp[0][i]=dp[0][i-1]+mp[b[i]][4];
    for(int i=1;i<=l1;++i){
        for(int j=1;j<=l2;++j){
            dp[i][j]=dp[i-1][j-1]+mp[a[i]][b[j]];
            dp[i][j]=max(dp[i][j],dp[i-1][j]+mp[a[i]][4]);
            dp[i][j]=max(dp[i][j],dp[i][j-1]+mp[b[j]][4]);
        }
    }
    printf("%d",dp[l1][l2]);
    return 0;
}
