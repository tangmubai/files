#include <cstdio>
#include <algorithm>
using namespace std;
int dp[105];
int w[205],c[205];
int main(){
    freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
    int hp=99;
    int n;scanf("%d",&n);
    for(int i=1;i<=n;++i) scanf("%d",w+i);
    for(int i=1;i<=n;++i) scanf("%d",c+i);
    for(int i=1;i<=n;++i){
        for(int j=99;j>=w[i];--j){
            dp[j]=max(dp[j],dp[j-w[i]]+c[i]);
        }
    }
    printf("%d",dp[hp]);
    return 0;
}
