#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <sstream>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
#include <iostream>
using namespace std;
typedef long long ll;
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
char c1[300], c2[300];
char ans[300];
char ans_true[300];
int k;
int t;
map<char, int> t1;
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf ("%s %s", c1+1, c2+1);
	int len1 = strlen(c1+1);
	int len2 = strlen(c2+1);
	for (register int i = 1; i <= len1; i ++) t1[c1[i]] ++;
	for (register int i = 1; i <= len2; i ++) if (t1[c2[i]]) ans[++k] = c2[i];
	if (k == 0) {
		puts ("Unique");
		return 0;
	}
	sort (ans+1, ans+k+1);
	for (register int i = 1; i <= k; i ++) printf ("%c ", ans[i]);
	for (register int i = 1, j = i+1; i <= k && j <= k; i ++) {
		ans_true[++t] = ans[i];
		while (ans[i] == ans[j]) j ++;
		i = j;
	}
	//for (register int i = 1; i <= k; i ++) printf ("%c ", ans[i]);
	//ans_true[1] = ans[1];
	/*for (register int i = 2; i < k; i ++) if (ans[i] != ans[i+1]) ans_true[++t] = ans[i];
	if (ans[k-1] != ans[k]) ans_true[++t] = ans[k];*/
	if (t == 1) {
		puts ("Middling");
		printf ("%c\n", ans_true[1]);
	}
	else {
		puts ("Gloomy");
		printf ("%d\n", t);
		for (register int i = 1; i < t; i ++) printf ("%c-", ans_true[i]);
		printf ("%c\n", ans_true[t]);
	}
	return 0;
}
