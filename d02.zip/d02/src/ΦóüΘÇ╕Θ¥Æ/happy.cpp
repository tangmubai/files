#include <algorithm>
#include <string.h>
#include <string>
#include <sstream>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
#include <iostream>
using namespace std;
typedef long long ll;
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
int f[205][105];
int w[205];
int c[205];
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n;
	read(n);
	for (register int i = 1; i <= n; i ++) scanf ("%d", &w[i]);
	for (register int i = 1; i <= n; i ++) scanf ("%d", &c[i]);
	for (register int i = 1; i <= n; i ++)
		for (register int j = 100; j > w[i]; j --)
			f[i][j] = mx(f[i-1][j], f[i-1][j-w[i]] + c[i]);
	printf ("%d\n", f[n][100]);
}
