#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
#include <algorithm>
#include <map>
using namespace std;
const int N = 255;
char a[N], b[N];
map <char, bool> m;
string ans;
int sum;
int main () {
	freopen("correlate.in", "r", stdin);
	freopen("correlate.out", "w", stdout);
	
	scanf ("%s%s", a + 1, b + 1);
	unique (a + 1, a + strlen(a + 1) + 1);
	unique (b + 1, b + strlen(b + 1) + 1);
	for (int i = 1; i <= strlen(a + 1); i ++)
		m[a[i]] = 1;
	for (int i = 1; i <= strlen(b + 1); i ++)
		if (m[b[i]]) {
			ans += b[i];
			sum ++;
		}
	if (sum == 0) {
		puts("Unique");
	}
	if (sum == 1) {
		puts("Middling");
		cout << ans[0];
	}
	if (sum > 1) {
		puts("Gloomy");
		sort (ans.begin(), ans.end());
		for (int i = 0; i < sum - 1; i ++)
			cout << ans[i] << '-';
		cout << ans[sum - 1];
	}
}
