#include <cstdio>
#include <cstring>
const int N = 105;
int n, m;
char a[N], b[N];
int mem[N][N];
const int f[5][5] = {
	{5, -1, -2, -1, -3},
	{-1, 5, -3, -2, -4},
	{-2, -3, 5, -2, -2},
	{-1, -2, -2, 5, -1},
	{-3, -4, -2, -1, 0}
};
int max (int a, int b) {
	return a > b ? a : b;
}
int id (char c) {
	if (c == 'A')
		return 0;
	if (c == 'C')
		return 1;
	if (c == 'G')
		return 2;
	if (c == 'T')
		return 3;
	return 4;
}
int search (int step1, int step2) {
	if (mem[step1][step2] != -1)
		return mem[step1][step2];
	if (step1 == n + 1 && step2 == m + 1)
		return 0;
	int res = 0;
	if (step1 <= n) {
		res = max (res, search (step1 + 1, step2) + f[id('-')][id(b[step2])]);
	} 
	if (step2 <= m) {
		res = max (res, search (step1, step2 + 1) + f[id('-')][id(a[step1])]);
	} 
	if (step1 <= n && step2 <= m) {
		res = max (res, search (step1 + 1, step2 + 1) + f[id(a[step1])][id(b[step2])]);
	}
	return mem[step1][step2] = res;
}
int main () {
	freopen("gene.in", "r", stdin);
	freopen("gene.out", "w", stdout);
	memset (mem, -1, sizeof(mem));
	scanf ("%d%s%d%s", &n, a + 1, &m, b + 1);
	int ans = search (1, 1);
	printf ("%d", ans);
}
