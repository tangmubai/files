#include <cstdio>
#include <cstring>
const int N = 205;
int s[N], w[N], v[N];
int n;
int mem[N][105];
int max (int a, int b) {
	return a > b ? a : b;
}
int search (int step, int tl) {
	if (mem[step][tl] != -1)
		return mem[step][tl];
	if (step == n + 1)
		return 0;
	int res = search (step + 1, tl);
	if (tl - w[step] > 0)
		res = max (res, search (step + 1, tl - w[step]) + v[step]);
	return mem[step][tl] = res;
}
int main () {
	freopen("happy.in", "r", stdin);
	freopen("happy.out", "w", stdout);
	memset (mem, -1, sizeof(mem));
	scanf ("%d", &n);
	for (int i = 1; i <= n; i ++) {
		scanf ("%d", &w[i]);
	}
	for (int i = 1; i <= n; i ++) {
		scanf ("%d", &v[i]);
	}
	int ans = search (1, 100);
	printf ("%d", ans);
}
