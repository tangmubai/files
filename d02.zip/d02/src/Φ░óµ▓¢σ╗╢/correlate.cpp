#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
char c[255],s[255];
int f[200]={0};
int ans[255]={0};
int main(){freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
	scanf("%s%s",c+1,s+1);
	ll cnt=0;
	ll n=strlen(c+1),m=strlen(s+1);
	for(ll i=1;i<=n;i++)f[c[i]]=1;
	for(ll i=1;i<=m;i++)if(f[s[i]])ans[++cnt]=s[i];
	sort(ans+1,ans+1+cnt);
	if(cnt==0)printf("Unique");
	else if(cnt==1)printf("Middling\n%c",ans[1]);
	else{
		printf("Gloomy\n%d\n%c",cnt,ans[1]);
		for(ll i=2;i<=cnt;i++)printf("-%c",ans[i]);
	}
	return 0;
}

