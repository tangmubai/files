#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
int c[6][6]={
	0,0,0,0,0,0,
	0,5,-1,-2,-1,-3,
	0,-1,5,-3,-2,-4,
	0,-2,-3,5,-2,-2,
	0,-1,-2,-2,5,-1,
	0,-3,-4,-2,-1,0,
};
int a[105],b[105];
int n,m;
int f[205][205];
char s[200];
void init(){
	scanf("%d %s",&n,s+1);
	for(ll i=1;i<=n;i++){
		if(s[i]=='A')a[i]=1;
		if(s[i]=='C')a[i]=2;
		if(s[i]=='G')a[i]=3;
		if(s[i]=='T')a[i]=4;
	}
	scanf("%d %s",&m,s+1);
	for(ll i=1;i<=m;i++){
		if(s[i]=='A')b[i]=1;
		if(s[i]=='C')b[i]=2;
		if(s[i]=='G')b[i]=3;
		if(s[i]=='T')b[i]=4;
	}
}
int main(){freopen("gene.in","r",stdin);freopen("gene.out","w",stdout);
	init();
	for(ll i=1;i<=n;i++)for(ll j=1;j<=m;j++)f[i][j]=-oo;
	for(ll i=1;i<=m;i++)f[0][i]=c[b[i]][5];
	for(ll i=1;i<=n;i++)f[i][0]=c[a[i]][5];
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=m;j++){
			f[i][j]=max(f[i][j],f[i-1][j]+c[a[i]][5]);
			f[i][j]=max(f[i][j],f[i][j-1]+c[b[i]][5]);
			f[i][j]=max(f[i][j],f[i-1][j-1]+c[a[i]][b[j]]);
		}
		
	}
	printf("%d",f[n][m]);
	return 0;
}

