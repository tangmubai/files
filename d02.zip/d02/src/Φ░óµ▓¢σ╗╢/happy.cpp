#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
int c[205],w[205];
int f[100]={0};
int main(){freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
	ll n,m=100;
	scanf("%d",&n);
	for(ll i=1;i<=n;i++)scanf("%d",&c[i]);
	for(ll i=1;i<=n;i++)scanf("%d",&w[i]);
	for(ll i=1;i<=n;i++){
		for(ll j=m;j>c[i];j--)
			f[j]=max(f[j],f[j-c[i]]+w[i]);
	}
	printf("%d",f[m]);
	return 0;
}

