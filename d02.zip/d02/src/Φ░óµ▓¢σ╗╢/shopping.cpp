#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;

int main(){freopen("shopping.in","r",stdin);freopen("shopping.out","w",stdout);
	 
	return 0;
}

