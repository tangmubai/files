#include<stdio.h>
using namespace std;
char a[255],b[255];
int a1[30],b1[30];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s%s",a,b);
	int i;
	for(i=0;a[i];i++)a1[a[i]-'A']=1;
	for(i=0;b[i];i++)b1[b[i]-'A']=1;
	int ans=0;
	for(i=0;i<26;i++){
		if(a1[i]&&b1[i])ans++;
	}
	if(ans==0){
		printf("Unique\n");return 0;
	}
	if(ans==1){
		printf("Middling\n");
	}
	else printf("Gloomy\n%d\n",ans);
	int flag=1;
	for(i=0;i<26;i++){
		if(a1[i]&&b1[i]){
			if(flag==0)printf("-");
			printf("%c",i+'A');
			flag=0;
		}
	}
	return 0;
}
