#include<stdio.h>
#include<iostream>
using namespace std;
char a[105],b[105];
int f[105][105],f1[8][8]={{5,-1,-2,-1,-3},{-1,5,-3,-2,-4},{-2,-3,5,-2,-2},{-1,-2,-2,5,-1},{-3,-4,-2,-1,0}};
int find(char k){
	if(k=='A')return 0;
	if(k=='C')return 1;
	if(k=='G')return 2;
	if(k=='T')return 3;
	if(k=='-')return 4;
}
int main(){
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	int n,m,i,j;
	scanf("%d%s%d%s",&n,a,&m,b);
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			f[i][j]=-2147483648;
		}
	}
	f[0][0]=f1[find(a[0])][find(b[0])];
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(i==0&&j==0)continue;
			if(i>0)f[i][j]=max(f[i-1][j]+f1[find('-')][find(a[i])],f[i][j]);
			if(j>0)f[i][j]=max(f[i][j],f[i][j-1]+f1[find('-')][find(b[j])]);
			if(i>0&&j>0)f[i][j]=max(f[i][j],f[i-1][j-1]+f1[find(a[i])][find(b[j])]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<m;j++)printf("%d ",f[i][j]);
		printf("\n");
	}
	printf("%d",f[n-1][m-1]);
	return 0;
}
