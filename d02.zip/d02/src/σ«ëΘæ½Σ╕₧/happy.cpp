#include<stdio.h>
#include<iostream>
using namespace std;
int a[205],b[205],f[105];
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n,i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++)scanf("%d",&a[i]);
	for(i=1;i<=n;i++)scanf("%d",&b[i]);
	for(i=1;i<=n;i++){
		for(j=100;j>=0;j--){
			if(j-a[i]>=0){
				f[j]=max(f[j],f[j-a[i]]+b[i]);
			}
			else break;
		}
	}
	printf("%d",f[99]);
	return 0;
}
