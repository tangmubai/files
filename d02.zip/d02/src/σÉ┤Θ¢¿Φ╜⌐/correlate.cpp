#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
int len1,len2,ans,t[30];
char s1[255],s2[255],s[255],si;
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);	
	scanf("%s",s1);len1=strlen(s1);
	scanf("%s",s2);len2=strlen(s2);
	for(int i=0;i<len1;i++){
		for(int j=0;j<len2;j++){
			if(s1[i]==s2[j]&&t[s1[i]-'A'+1]==0){
				t[s1[i]-'A'+1]=1;
				ans++;
				s[si++]=s1[i];
			}
		}
	}
	sort(s,s+si);
	if(ans==0)printf("Unique");
	if(ans==1){
		printf("Middling\n");
		printf("%c",s[0]);
	}
	if(ans>=2){
		printf("Gloomy\n");
		printf("%d\n",ans);
		for(int i=0;i<si;i++){
			printf("%c",s[i]);
			if(i!=si-1)printf("-");
		}
	}
	return 0;
}
