#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
int n,a[205],b[205],f[205][205];
int ans;
void dfs(int x,int y,int z){
	if(y<=0)return;
	if(x==n){
		if(z>ans)ans=z;
		return;
	}
	dfs(x+1,y-a[x],z+b[x]);
	dfs(x+1,y,z);
}
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)scanf("%d",&b[i]);
	memset(f,-1,sizeof(f));
	dfs(1,100,0);
	printf("%d",ans);
	return 0;
}
