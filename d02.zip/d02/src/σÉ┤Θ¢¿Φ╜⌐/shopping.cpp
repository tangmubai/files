#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
int n,m,a[1005],b1[1005],b2[1005],t[1005],ans;
void dfs(int x,int y){
	if(x>n){
		if(y>ans)ans=y;
		return;
	}
	if(t[x]==0){
		t[x]=1;
		for(int i=1;i<=m;i++)
			if(b1[i]==x||b2[i]==x)t[b1[i]]=t[b2[i]]=1;
		dfs(x+1,y+a[x]);
		t[x]=0;
		for(int i=1;i<=m;i++)
			if(b1[i]==x||b2[i]==x)t[b1[i]]=t[b2[i]]=0;
	}
	else dfs(x+1,y);
}
int main(){
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d %d",&b1[i],&b2[i]);
	dfs(1,0);
	printf("%d",ans);
	return 0;	
}
