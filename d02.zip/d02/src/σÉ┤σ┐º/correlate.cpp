#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<set>
using namespace std;
inline int read()
{
	int s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
string s1,s2;
set<char> ::iterator it;
set<char> se;
int main()
{
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	cin>>s1>>s2;
	int l1=s1.size(),l2=s2.size();
	for(int i=0;i<l1;i++)
	{
		for(int j=0;j<l2;j++)
		{
			if(s1[i]==s2[j])
			{
				se.insert(s1[i]);
			}
		}
	}
	if(se.size()==0)
	{
		printf("Unique\n");
		return 0;
	}
	if(se.size()==1)
	{
		printf("Middling\n");
		it=se.begin();
		printf("%c",(*it));
	}
	else
	{
		printf("Gloomy\n");
		printf("%d\n",se.size());
		it=se.end();
		it--;
		char c=(*it);
		se.erase(it);
		for(it=se.begin();it!=se.end();it++)
		{
			printf("%c-",(*it));
		}
		printf("%c\n",c);
	}
	return 0;
}

