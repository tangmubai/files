#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
inline int read()
{
	int s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
string s1,s2;
int n,m;
int main()
{
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	n=read();
	cin>>s1;
	m=read();
	cin>>s2;
	return 0;
}

