#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
inline long long read()
{
	long long s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
long long f[1100];
long long w[1100],v[1100];
int n;
int main()
{
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		w[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		v[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=99;j>=w[i];j--)
		{
			f[j]=max(f[j],f[j-w[i]]+v[i]);
		}
	}
	printf("%lld\n",f[99]);
	return 0;
}

