#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
inline int read()
{
	int s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
inline long long read2()
{
	long long s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
int n,m,x,y;
long long sum,a[11000];
int main()
{
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	n=read();
	m=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read2();
		sum+=a[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		sum-=min(a[x],a[y]);
	}
	printf("%lld\n",sum);
	return 0;
}

