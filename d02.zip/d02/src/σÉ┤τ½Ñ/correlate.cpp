#include<stdio.h>
main()
{
	freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
	register bool a[26]={},b[26]={};register char s[255],ans[26];register int sz=0;
	scanf("%s",s);for(register int i=0;s[i];a[s[i++]-'A']=1);
	scanf("%s",s);for(register int i=0;s[i];b[s[i++]-'A']=1);
	for(register int i=0;i<26;a[i]&&b[i]&&(ans[sz++]=i+'A'),++i);
	if(!sz)puts("Unique");
	if(sz==1)puts("Middling"),putchar(ans[0]);
	if(sz>1)
	{
		puts("Gloomy"),printf("%d\n",sz);
		putchar(ans[0]);for(register int i=1;i<sz;++i)putchar('-'),putchar(ans[i]);
	}
}
