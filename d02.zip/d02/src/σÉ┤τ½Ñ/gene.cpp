#include<stdio.h>
#define N 111
inline int get(const char&x,const char&y)
{
	if(x=='A')switch(y)
	{
		case'A':return 5;
		case'C':return-1;
		case'G':return-2;
		case'T':return-1;
		case'-':return-3;
	}
	if(x=='C')switch(y)
	{
		case'A':return-1;
		case'C':return 5;
		case'G':return-3;
		case'T':return-2;
		case'-':return-4;
	}
	if(x=='G')switch(y)
	{
		case'A':return-2;
		case'C':return-3;
		case'G':return 5;
		case'T':return-2;
		case'-':return-2;
	}
	if(x=='T')switch(y)
	{
		case'A':return-1;
		case'C':return-2;
		case'G':return-2;
		case'T':return 5;
		case'-':return-1;
	}
	if(x=='-')switch(y)
	{
		case'A':return-3;
		case'C':return-4;
		case'G':return-2;
		case'T':return-1;
	}
}
int ans[N][N];
inline int max(const int&x,const int&y){return x>y?x:y;}
main()
{
	freopen("gene.in","r",stdin);freopen("gene.out","w",stdout);
	register int n,m;register char a[N],b[N];
	scanf("%d%s%d%s",&n,a+1,&m,b+1);
	for(register int i=1;i<=n;++i)ans[i][0]=ans[i-1][0]+get(a[i],'-');
	for(register int j=1;j<=m;++j)ans[0][j]=ans[0][j-1]+get('-',b[j]);
	for(register int i=1;i<=n;++i)for(register int j=1;j<=m;++j)
		ans[i][j]=max(ans[i-1][j-1]+get(a[i],b[j]),\
			max(ans[i-1][j]+get(a[i],'-'),ans[i][j-1]+get('-',b[j])));
	printf("%d",ans[n][m]);
}
