#include<stdio.h>
inline char nc()
{
	static char buf[999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
inline void max(int&x,const int&y){if(x<y)x=y;}
main()
{
	freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
	register int n,a[222],b,ans[111]={};
	read(n);for(register int i=0;i<n;read(a[i++]));
	for(register int i=0;i<n;++i)
		{read(b);for(register int j=100;j>a[i];--j)max(ans[j],ans[j-a[i]]+b);}
	printf("%d",ans[100]);
}
