#include<stdio.h>
#include<vector>
#define N 1000
inline char nc()
{
	static char buf[9999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,9999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
int n,m,a[N],ans1[N],ans2[N],tot;std::vector<int>e[N];
/*ans1[i]:choose i
 *ans2[i]:not choose i
 */
int dfs1(const int&,const int&);
int dfs2(const int&,const int&);
inline int max(const int&x,const int&y){return x>y?x:y;}
main()
{
	freopen("shopping.in","r",stdin);freopen("shopping.out","w",stdout);
	read(n);read(m);
	for(register int i=0;i<n;read(a[i++]));
	for(register int u,v;m--;read(u),read(v),--u,--v,e[u].push_back(v),e[v].push_back(u));
	for(register int i=0;i<n;++i)if(!ans1[i])tot+=max(dfs1(i,-1),dfs2(i,-1));
	printf("%d",tot);
}
inline int dfs1(const int&i,const int&f)
{
	if(ans1[i])return ans1[i];
	ans1[i]=a[i];
	for(register int j=0;j<e[i].size();++j)
		if(e[i][j]!=f)ans1[i]+=dfs2(e[i][j],i);
	return ans1[i];
}
inline int dfs2(const int&i,const int&f)
{
	if(ans2[i])return ans2[i];
	for(register int j=0;j<e[i].size();++j)
		if(e[i][j]!=f)ans2[i]+=max(dfs1(e[i][j],i),dfs2(e[i][j],i));
	return ans2[i];
}
