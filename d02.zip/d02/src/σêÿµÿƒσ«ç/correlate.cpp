#include <cstdio>

int ans_num;
char ans[255];
char s1[255], s2[255];
int t1[30], t2[30];

int main()
{
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s %s", s1 + 1, s2 + 1);
	for (int i = 1; s1[i]; i++)
		t1[s1[i] - 'A' + 1]++;
	for (int i = 1; s2[i]; i++)
		t2[s2[i] - 'A' + 1]++;
	for (int i = 1; i <= 26; i++)
	{
		if (t1[i] && t2[i])
		{
			ans_num++;
			ans[ans_num] = i + 'A' - 1;
		}
	}
	if (ans_num == 0)
	{
		printf("Unique\n");
		return 0;
	}
	if (ans_num == 1)
	{
		printf("Middling\n");
		printf("%c\n", ans[ans_num]);
		return 0;
	}
	if (ans_num > 1)
	{
		printf("Gloomy\n");
		printf("%d\n", ans_num);
		printf("%c", ans[1]);
		for (int i = 2; i <= ans_num; i++)
			printf("-%c", ans[i]);
		printf("\n");
	}
	return 0;
}
