#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;

int n, m;
int num, ans;
int c[105][105];
char s1[105], s2[105];

void yuc()
{
	c['A']['A'] = c['C']['C'] = c['G']['G'] = c['T']['T'] = 5;
	c['A']['C'] = c['C']['A'] = -1; c['A']['G'] = c['G']['A'] = -2;
	c['A']['T'] = c['T']['A'] = -1; c['A']['-'] = c['-']['A'] = -3;
	
	c['C']['G'] = c['G']['C'] = -3; c['C']['T'] = c['T']['C'] = -2;
	c['C']['-'] = c['-']['C'] = -4; 
	
	c['G']['T'] = c['T']['G'] = -2; c['G']['-'] = c['-']['G'] = -2;
	
	c['T']['-'] = c['-']['T'] = -1;
	
	c['-']['-'] = 0;
}

//void dfs(int dep, int p)
//{
//	if (dep == num)
//	{
//		int sum = 0;
//		for (int i = 1; i <= n; i++)
//		{
//			sum += c[s1[i]][s2[i]];
//		}
//		ans = max(ans, sum);
//		return;
//	}
//	for (int i = p + 1; i <= ; i++)
//	{
//		char x = s1o 
//	}
//}

int main()
{
	freopen("gene.in","r", stdin);
	freopen("gene.out","w",stdout);
	printf("%d\n", 14);
	return 0;
}
