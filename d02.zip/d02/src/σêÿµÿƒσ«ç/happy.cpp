#include <cstdio>

int f[205], w[205], c[205];

int max(int x, int y)
{
	return x > y ? x : y;
}

int main()
{
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		scanf("%d", &w[i]);
	for (int i = 1; i <= n; i++)
		scanf("%d", &c[i]);
	for (int i = 1; i <= n; i++)
	{
		for (int j = 99; j >= w[i]; j--)
		{
			f[j] = max(f[j], f[j - w[i]] + c[i]);
		}
	}
	printf("%d\n", f[99]);
	return 0;
}
