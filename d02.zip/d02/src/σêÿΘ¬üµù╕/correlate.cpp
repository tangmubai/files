#include <stdio.h>
char a[255], b[255];
int aa[30], bb[30];
int main(void) {
	freopen("correlate.in", "r", stdin);
	freopen("correlate.out", "w", stdout);
	scanf("%s %s", a, b);
	for (int i = 0; a[i] != '\0'; ++i)
		++aa[a[i] - 'A'];
	for (int i = 0; b[i] != '\0'; ++i)
		++bb[b[i] - 'A'];
	int same = 0;
	for (int i = 0; i < 26; ++i)
		same += aa[i] > 0 && bb[i] > 0;
	if (same == 0)
		puts("Unique");
	else {
		if (same == 1)
			puts("Middling");
		else {
			puts("Gloomy");
			printf("%d\n", same);
		}
		bool first = true;
		for (int i = 0; i < 26; ++i)
			if (aa[i] > 0 && bb[i] > 0)
				if (first) {
					putchar('A' + i);
					first = false;
				}
				else
					printf("-%c", 'A' + i);
		puts("");
	}
	return 0;
}
