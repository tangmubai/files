#include <stdio.h>
const int same[5][5] = {
	{ 5, -1, -2, -1, -3},
	{-1,  5, -3, -2, -4},
	{-2, -3,  5, -2, -2},
	{-1, -2, -2,  5, -1},
	{-3, -4, -2, -1, -214748364}
};
int n, m, f[105][105];
char a[105], b[105];
inline int mx(int p, int q) {
	return p > q ? p : q;
}
inline int D(char c) {
	if (c == 'A')
		return 0;
	if (c == 'C')
		return 1;
	if (c == 'G')
		return 2;
	if (c == 'T')
		return 3;
}
int main(void) {
	freopen("gene.in", "r", stdin);
	freopen("gene.out", "w", stdout);
	scanf("%d %s %d %s", &n, a + 1, &m, b + 1);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (a[i] == b[j])
				f[i][j] = mx(f[i - 1][j - 1] + 5, f[i][j]);
			else
				f[i][j] = mx(f[i - 1][j], f[i][j - 1]) + same[D(a[i])][D(b[j])];
	printf("%d\n", f[n][m]);
	return 0;
}
