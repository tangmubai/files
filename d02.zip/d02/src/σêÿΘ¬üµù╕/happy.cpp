#include <stdio.h>
int n, c[205], v[205], f[105];
int main(void) {
	freopen("happy.in", "r", stdin);
	freopen("happy.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
		scanf("%d", &c[i]);
	for (int i = 1; i <= n; ++i)
		scanf("%d", &v[i]);
	for (int i = 1; i <= n; ++i)
		for (int j = 100; j > c[i]; --j)
			f[j] = f[j - c[i]] + v[i] > f[j] ? f[j - c[i]] + v[i] : f[j];
	printf("%d\n", f[100]);
	return 0;
}
