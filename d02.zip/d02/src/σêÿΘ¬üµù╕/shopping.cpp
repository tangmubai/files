#include <stdio.h>
int k, m, sumw, w[1005], f[1005];
bool cannot[1005][1005];
int main(void) {
	freopen("shopping.in", "r", stdin);
	freopen("shopping.out", "w", stdout);
	scanf("%d %d", &k, &m);
	for (int i = 1; i <= k; ++i) {
		scanf("%d", &w[i]);
		sumw += w[i];
	}
	for (int i = 1, a, b; i <= m; ++i) {
		scanf("%d %d", &a, &b);
		cannot[a][b] = cannot[b][a] = true;
	}
	for (int i = 1; i <= k; ++i)
		for (int j = sumw; j >= w[i]; --j)
			if (!cannot[i][i - 1])
				f[j] = f[j - w[i]] + w[i] > f[j] ? f[j - w[i]] + w[i] : f[j];
	printf("%d\n", f[sumw]);
	return 0;
}
