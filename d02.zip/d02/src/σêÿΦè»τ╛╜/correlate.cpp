#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n,m,ans;
string a,b;
string ans1[N];
map<char,int> mp;
int main()
{
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	cin>>a;
	cin>>b;
	n=a.size();
	m=b.size();
	for(int i=0;i<n;i++) mp[a[i]]=1;
	for(int i=0;i<m;i++)
	{
		if(mp[b[i]]) mp[b[i]]=2;
	}
	for(int i=0;i<25;i++)
	{
		if(mp[i+'A']==2) ans1[++ans]=i+'A';
	}
	if(!ans) printf("Unique");
	if(ans==1) printf("Middling");
	else
	{
		printf("Gloomy\n%d\n",ans);
		cout<<ans1[1];
		for(int i=2;i<=ans;i++) cout<<"-"<<ans1[i];
	}
	return 0;
}
