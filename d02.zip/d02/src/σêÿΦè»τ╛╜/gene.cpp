#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
int s[6][6]={{0,0,0,0,0,0},
		   {0,5,-1,-2,-1,-3},
		   {0,-1,5,-3,-2,-4},
		   {0,-2,-3,5,-2,-2},
		   {0,-1,-2,-2,5,-1},
		   {0,-3,-4,-2,-1,0}};
int n,m,ans,x,y;
string a,b;
int main()
{
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	scanf("%d",&n);
	cin>>a;
	scanf("%d",&m);
	cin>>b;
	for(int i=0;i<min(n,m);i++)
	{
		if(a[i]=='A') x=1;
		if(a[i]=='C') x=2;
		if(a[i]=='G') x=3;
		if(a[i]=='T') x=4;
		if(b[i]=='A') y=1;
		if(b[i]=='C') y=2;
		if(b[i]=='G') y=3;
		if(b[i]=='T') y=4;
		ans+=s[x][y];
	}
	for(int i=min(n,m);i<max(n,m);i++)
	{
		if(i>n)
		{
			if(b[i]=='A') x=1;
			if(b[i]=='C') x=2;
			if(b[i]=='G') x=3;
			if(b[i]=='T') x=4;
		}
		else
		{
			if(a[i]=='A') x=1;
			if(a[i]=='C') x=2;
			if(a[i]=='G') x=3;
			if(a[i]=='T') x=4;
		}
		ans+=s[5][x];
	}
	printf("%d",ans);
}//A->1 C->2 G->3 T->4
