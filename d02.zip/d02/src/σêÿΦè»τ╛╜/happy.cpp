#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n,ans;
int a[N],b[N],f[N];
int main()
{
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
	for(int j=100;j>=a[i]+1;j--)
	{
		f[j]=max(f[j],f[j-a[i]]+b[i]);
		ans=max(ans,f[j]);
	}
	printf("%d",ans);
	return 0;
}
