#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int ans,n,m,x,y;
int a[N],f[N][N],vis[N],g[N];
inline void dfs(int i,int sum)
{
	if(g[i]>=sum) return;
	g[i]=sum;
	ans=max(ans,sum);
	for(int j=1;j<=n;j++)
	{
		if(vis[j]) continue;
		for(int k=1;k<=n;k++)
		{
			if(f[j][k]) vis[k]=1;
		}
		vis[j]=1;
		dfs(j,sum+a[j]);
		vis[j]=0;
		for(int k=1;k<=n;k++)
		{
			if(f[j][k]) vis[k]=0;
		}
	}
	return;
}
int main()
{
	memset(g,-1,sizeof(g));
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		f[x][y]=1;
		f[y][x]=1;
	}
	for(int i=1;i<=n;i++)
	{
		memset(vis,0,sizeof(vis));
		vis[i]=1;
		for(int j=1;j<=n;j++)
		{
			if(f[i][j]) vis[j]=1;
		}
		dfs(i,a[i]);
	}
	printf("%d",ans);
	return 0;
}
