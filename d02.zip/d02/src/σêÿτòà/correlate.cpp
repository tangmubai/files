#include<iostream>
#include<cstring>
#include<algorithm>
#include<stdio.h>
using namespace std;
char a[260],b[260],c[260];
int ans=0;
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s %s",a,b);
	int len1=strlen(a);
	int len2=strlen(b);
	for(int i=1;i<=len1;i++)
	    for(int j=1;j<=len2;j++)
	        if(a[i]-'A'==b[j]-'A'){ans++;c[i]=a[i];}
	if(ans==0){
	   cout<<"Unique"<<endl;
	   return 0;
	}
	if(ans==1){
		cout<<"Middling"<<endl;
		cout<<c[1]<<endl;
		return 0;
	}
	if(ans>1){
		cout<<"Gloomy"<<endl;
		sort(c+1,c+ans+1);
		for(int i=2;i<=ans;i++)cout<<c[i]<<"-";
		cout<<c[ans+1];
	}/**/
	return 0;
}
