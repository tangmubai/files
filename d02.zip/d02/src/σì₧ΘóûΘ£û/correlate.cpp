#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
int s,w[100];
char a[300],b[300];
int main(){
	freopen("correlate.in","r",stdin);freopen("correlate.out","w",stdout);
	scanf("%s",&a);
	scanf("%s",&b);
	for(int i=0;i<strlen(a);i++){
		for(int j=0;j<strlen(b);j++){
			if(a[i]==b[j]){
				w[a[i]]=1;
			}
		}
	}
	for(int i=65;i<100;i++){
		if(w[i]!=0){
			s++;
		}
	}
	if(s==0){
		printf("Unique\n");
	}
	if(s==1){
		printf("Middling\n");
	}
	if(s>1){
		printf("Gloomy\n%d\n",s);
	}int u;
	for(int i=65;i<100;i++){
		if(w[i]!=0){
			printf("%c",i);
			u=i+1;break;
		}
	}
	for(int i=u;i<100;i++){
		if(w[i]!=0){
			printf("-%c",i);
		}
	}
	return 0;
}
