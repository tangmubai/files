#include <iostream>
#include <algorithm>
#include <cstring>	 
using namespace std;	 
int DP[101][101] = {0}; 
int Cal[5][5]={{0,-3,-4,-2,-1},{-3,5,-1,-2,-1},{-4,-1,5,-3,-2},{-2,-2,-3,5,-2},{-1,-1,-2,-2,5}};
int Pro(char ch){
	switch(ch){
		case 'A': return 1;
		case 'C': return 2;
		case 'G': return 3;
		case 'T': return 4;
	}
	return 0;
}
int main(){
	freopen("gene.in","r",stdin);freopen("gene.out","w",stdout);
	int N,R;
	char DNA1[102],DNA2[102];
	cin >> N >> DNA1;
	cin >> R >> DNA2;	
	int DNALine1[102] = {0},DNALine2[102] = {0};
	for(int i=1;i<=N;i++)DNALine1[i]=Pro(DNA1[i-1]);
	for(int i=1;i<=R;i++)DNALine2[i]=Pro(DNA2[i-1]);
	memset(DP,-127,sizeof(DP)); 
	DP[0][0]=0;
	for(int i=1;i<=N;i++)DP[i][0]=DP[i-1][0]+Cal[DNALine1[i]][0];
	for(int j=1;j<=R;j++)DP[0][j]=DP[0][j-1]+Cal[0][DNALine2[j]];
	for(int i = 1;i <= N;i++){
		for(int j = 1;j <= R;j++){
			DP[i][j] = max(DP[i-1][j-1] + Cal[DNALine1[i]][DNALine2[j]],DP[i][j]);
			DP[i][j] = max(DP[i-1][j] + Cal[DNALine1[i]][0],DP[i][j]);
			DP[i][j] = max(DP[i][j-1] + Cal[0][DNALine2[j]],DP[i][j]);
		}
	}
	cout << DP[N][R] << endl;
	return 0;
}
