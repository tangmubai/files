#include<stdio.h>
#include<algorithm>
using namespace std;
int t,v,a[1005],b[1005],c[1005];
int main(){
	freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
	scanf("%d",&t);
	for(int i=0;i<t;i++)scanf("%d",&a[i]);
	for(int i=0;i<t;i++)scanf("%d",&b[i]);
	for(int i=0;i<t;i++){
		for(int j=100;j>=1;j--){
			if(j-a[i]>0)c[j]=max(c[j],c[j-a[i]]+b[i]);
		}
	}
	printf("%d",c[100]);
}
