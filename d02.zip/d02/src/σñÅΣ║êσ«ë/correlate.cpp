#include<algorithm>
#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char s1[260],s2[260];
bool a[30];
int ans[30];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s%s",s1,s2);
	int len1=strlen(s1),len2=strlen(s2);
	for(int i=0;i<len1;i++)
		a[s1[i]-'A']=1;
	int s=0;
	for(int i=0;i<len2;i++)
		if(a[s2[i]-'A']==1){
			s++;
			ans[s]=s2[i]-'A';
		}
	if(s==0){
		puts("Unique");
		return 0;
	}
	else if(s==1){
		puts("Middling");
		printf("%c",ans[1]+'A'); 
		return 0;
	}
	else {
		puts("Gloomy");
		printf("%d\n",s);
		printf("%c",ans[s]+'A');
		for(int i=s-1;i>=1;i--)
			printf("-%c",ans[i]+'A');
		return 0;
	}
	return 0;
}
