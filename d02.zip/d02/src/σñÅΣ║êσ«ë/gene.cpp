#include<algorithm>
#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int l1,l2;
char s1[110],s2[110],ts[110];
int d(char x,char y){
	if(x=='A'){
		if(y=='A') return 5;
		if(y=='C') return -1;
		if(y=='G') return -2;
		if(y=='T') return -1;
		if(y=='-') return -3;
	}
	if(x=='C'){
		if(y=='A') return -1;
		if(y=='C') return 5;
		if(y=='G') return -3;
		if(y=='T') return -2;
		if(y=='-') return -4;
	}
	if(x=='G'){
		if(y=='A') return -2;
		if(y=='C') return -3;
		if(y=='G') return 5;
		if(y=='T') return -2;
		if(y=='-') return -2;
	}
	if(x=='T'){
		if(y=='A') return -1;
		if(y=='C') return -2;
		if(y=='G') return -2;
		if(y=='T') return 5;
		if(y=='-') return -1;
	}
	if(x=='-'){
		if(y=='A') return -3;
		if(y=='C') return -4;
		if(y=='G') return -2;
		if(y=='T') return -1;
		if(y=='-') return 0;
	}
	return 0;
}
int f[110][110],s[110];
int main(){
//	freopen("gene.in","r",stdin);
//	freopen("gene.out","w",stdout);
	scanf("%d%d",&l1,s1+1,&l2,s2+1);
	if(l1<l2){
		for(int i=1;i<=l1;i++)
			ts[i]=s1[i];
		for(int i=1;i<=l2;i++)
			s1[i]=s2[i];
		for(int i=1;i<=l1;i++)
			s2[i]=ts[i];
		int t=l1;l1=l2;l2=t;
	}
	for(int i=1;i<=l1;i++)
		s[i]=s[i-1]+d(s1[i],'-');
	for(int i=1;i<=l1;i++){
		for(int j=1;j<=i;j++){
//			if(j<=l2) f[i][j]=f[i-1][j-1]+d(s1[i],s2[j]);
//			else f[i][j]=-2147483647;
//			f[i][j]=max(f[i][j],f[i-1][j]+d(s1[i],'-'));
//			f[i][j]=max(f[i][j],f[i][j-1]+d('-',s2[i]));
			f[i][j]=-2147483647;
			for(int k=j-1;k<=i-1;k++)
				f[i][j]=max(f[i][j],f[k][j-1]+s[i-1]-s[k]+d(s1[i],s2[i]));
		}
	}
	
	return 0;
}
