#include<algorithm>
#include<iostream>
#include<cstdio>
using namespace std;
struct Node{
	int a,b;
}a[220];
int f[110],n;
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i].a);
	for(int i=1;i<=n;i++)	
		scanf("%d",&a[i].b);
	for(int i=1;i<=n;i++)
		for(int j=100;j>a[i].a;j--){
			if(f[j-a[i].a]+a[i].b>f[j]) f[j]=f[j-a[i].a]+a[i].b;
		}
	printf("%d\n",f[100]);
	return 0;
}
