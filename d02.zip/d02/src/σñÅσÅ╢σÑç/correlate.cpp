#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string>
#include <set>
using namespace std;
typedef long long ll;
const int N = 2e3 + 5;

set<char> n, p;
string name, s;
char a[N];
int cnt;

int main() {
	ios :: sync_with_stdio(false);
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	cin >> name >> s;
	int ln = name.size(), ls = s.size();
	for (int i = 0; i < ln; i++) {
		n.insert(name[i]);
	}
	for (int i = 0; i < ls; i++) {
		p.insert(s[i]);
	}
	set<char> :: iterator it;
	for (it = n.begin(); it != n.end(); it++) {
		if (p.count(*it) == 1) a[++cnt] = *it;
	}
	
	if (cnt == 0) {
		cout << "Unique\n";
		return 0;
	}
	else if (cnt == 1) {
		cout << "Middling\n";
		cout << a[cnt] <<'\n';
		return 0;
	}
	else {
		cout << "Gloomy\n" << cnt << '\n';
		for (int i = 1; i < cnt; i++) {
			cout << a[i] << '-';
		}
		cout <<a[cnt];
	}
	return 0;
}
/*
OPEN
CLOSE
*/
