#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

template <typename T>
T Max(T x, T y) {
	if (x > y) return x;
	return y;
}

int n, w = 100;
int v[N], c[N], f[N];

int main() {
	ios :: sync_with_stdio(false);
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);

	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> v[i];
	for (int i = 1; i <= n; i++) 
		cin >> c[i];
		
	for (int i = 1; i <= n; i++) {
		for (int j = w; j > v[i]; j--) {
			f[j] = Max(f[j], f[j - v[i]] + c[i]);
		}
	}
	
	cout << f[100];
	return 0;
}

