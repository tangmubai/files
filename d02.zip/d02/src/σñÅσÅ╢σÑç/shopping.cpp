#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <set>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

int Max(int x, int y){
	if (x > y) return x;
	return y;
}

int n, m;
int a[N], f[N], y[N], cnt;
set<int> e[N];

void Dfs(int di,int sum) {
	f[di] = Max(f[di], sum);
//	if (f[di] > sum) return;
	for (int i = di + 1; i <= n; i++) {
		bool flag = true;
		for (int j = 1; j <= cnt; j++) {
			if (e[i].count(y[j]) == 1) flag = false;
		}
		if (flag == true) {
			y[++cnt] = i;
			Dfs(i, sum + a[i]);
			cnt--;
		}
	}
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	cin >> n >> m;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= m; i++) {
		int A, B;
		cin >> A >> B;
		e[A].insert(B);
		e[B].insert(A);
	} 

	Dfs(0, 0);
	
	cout << f[n] <<'\n';
	return 0;
}
/*
3 1
1 
1 
1
1 2
*/
