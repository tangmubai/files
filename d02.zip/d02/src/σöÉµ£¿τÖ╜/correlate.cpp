#include <cstdio>
#include <string>
#include <iostream>

const int N = 100;

bool ans[N], hash[N];
std :: string s1, s2;

int main() {
    freopen("correlate.in", "r", stdin);
    freopen("correlate.out", "w", stdout);
    int n1, n2, tot = 0;
    std :: cin >> s1 >> s2;
    n1 = s1.length(); n2 = s2.length();
    for (int i = 0; i < n1; i++) hash[s1[i] - 'A'] = true;
    for (int i = 0; i < n2; i++)
        if (hash[s2[i] - 'A'] && !ans[s2[i] - 'A']) {
            tot++;
            ans[s2[i] - 'A'] = true;
        }
    if (tot == 0) puts("Unique");
    else if (tot == 1) {
        puts("Middling");
        for (int i = 0; i < 26; i++)
            if (ans[i]) {
                putchar(i + 'A');
                break;
            }
    } else {
        bool flag = false;
        puts("Gloomy");
        printf("%d\n", tot);
        for (int i = 0; i < 26; i++)
            if (ans[i]) {
                if (flag) putchar('-');
                putchar(i + 'A');
                flag = true;
            }
    }
    return 0;
}
