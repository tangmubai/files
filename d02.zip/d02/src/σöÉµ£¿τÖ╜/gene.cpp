#include <cstdio>
#include <string>
#include <iostream>

const int N = 101, val[5][5] = {{0, -3, -4, -2, -1}, {-3, 5, -1, -2, -1}, {-4, -1, 5, -3, -2}, {-2, -2, -3, 5, -2}, {-1, -1, -2, -2, 5}};

std :: string s1, s2;
int g1[N], g2[N], dp[N][N];

int main() {
    freopen("gene.in", "r", stdin);
    freopen("gene.out", "w", stdout);
    int n1, n2;
    std :: cin >> n1 >> s1 >> n2 >> s2;
    for (int i = 0; i < n1; i++)
        if (s1[i] == 'A') g1[i + 1] = 1;
        else if (s1[i] == 'C') g1[i + 1] = 2;
        else if (s1[i] == 'G') g1[i + 1] = 3;
        else if (s1[i] == 'T') g1[i + 1] = 4;
    for (int i = 0; i < n2; i++)
        if (s2[i] == 'A') g2[i + 1] = 1;
        else if (s2[i] == 'C') g2[i + 1] = 2;
        else if (s2[i] == 'G') g2[i + 1] = 3;
        else if (s2[i] == 'T') g2[i + 1] = 4;
    dp[1][0] = val[g1[1]][0];
    dp[0][1] = val[0][g2[1]];
    for (int i = 1; i <= n1; i++)
        for (int j = 1; j <= n2; j++) {
            int tmp1 = dp[i - 1][j] + val[g1[i]][0], tmp2 = dp[i][j - 1] + val[0][g2[j]];
            dp[i][j] = dp[i - 1][j - 1] + val[g1[i]][g2[j]];
            if (tmp1 > dp[i][j]) dp[i][j] = tmp1;
            if (tmp2 > dp[i][j]) dp[i][j] = tmp2;
        }
    printf("%d\n", dp[n1][n2]);
    return 0;
}
