#include <cstdio>
#include <cstring>

const int N = 201;

int dp[N], cost[N], happy[N];

int main() {
    freopen("happy.in", "r", stdin);
    freopen("happy.out", "w", stdout);
    int n, ans = 0;
    scanf("%d", &n);
    memset(dp, -1, sizeof dp);
    for (int i = 1; i <= n; i++) scanf("%d", &cost[i]);
    for (int i = 1; i <= n; i++) scanf("%d", &happy[i]);
    dp[100] = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= 100 - cost[i]; j++)
            if (dp[j + cost[i]] != -1) {
                int tmp = dp[j + cost[i]] + happy[i];
                if (tmp > dp[j]) dp[j] = tmp;
                if (dp[j] > ans) ans = dp[j];
            }
    printf("%d\n", ans);
    return 0;
}
