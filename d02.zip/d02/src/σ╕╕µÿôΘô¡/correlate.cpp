#include <stdio.h>
#include <algorithm>
#include <cstring>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}

char a[305],b[305],c[305];
int t[30];
bool vis[30];
main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s",a+1);scanf("%s",b+1);
	int len1=strlen(a+1),len2=strlen(b+1),len=0;
	for(int i=1;i<=len1;++i){
		t[a[i]-64]++;
	}
	for(int i=1;i<=len2;++i){
		if(t[b[i]-64]&&!vis[b[i]-64]){
			vis[b[i]-64]=true;
			c[++len]=b[i];
		}
	}
	if(len==0){
		printf("Unique\n");
	}
	if(len==1){
		printf("Middling\n%c\n",c[1]);
	}
	else {
		sort(c+1,c+1+len);
		printf("Gloomy\n%d\n",len);
		for(int i=1;i<len;++i){
			printf("%c-",c[i]);
		}
		printf("%c\n",c[len]);
	}
	return 0;
}

