#include <stdio.h>
#include <algorithm>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}

int a[105][105],f[105][105];
char s1[105],s2[105];
int b[105],c[105];
main(){
	freopen("gene.in","r",stdin);
	freopen("gene.out","w",stdout);
	int n=re(),m=re();scanf("%s",s1+1);scanf("%s",s2+1);
	for(int i=1;i<=n;++i){
		if(s1[i]=='A')b[i]=1;
		if(s1[i]=='C')b[i]=2;
		if(s1[i]=='G')b[i]=3;
		if(s1[i]=='T')b[i]=4;
	}
	for(int j=1;j<=m;++j){
		if(s2[j]=='A')c[j]=1;
		if(s2[j]=='C')c[j]=2;
		if(s2[j]=='G')c[j]=3;
		if(s2[j]=='T')c[j]=4;
	}
	a[1][1]=a[2][2]=5;
	a[3][3]=a[4][4]=5;a[5][5]=-21474836;
//	1
	a[1][2]=a[2][1]=-1;
	a[1][3]=a[3][1]=-2;
	a[1][4]=a[4][1]=-1;
	a[1][5]=a[5][1]=3;
//	2
	a[2][3]=a[3][2]=-3;
	a[2][4]=a[4][2]=-2;
	a[2][5]=a[5][2]=-4;
//	3
	a[3][4]=a[4][3]=-2;
	a[3][5]=a[5][3]=-2;
	
//	for(int i=1;i<=n;++i){
//		for(int j=1;j<=m;++j){
//			if(b[i]==c[j])a[i][j]=5;
//			if()
//		}
//	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
//			printf("%d %d %d\n",b[i],c[j],a[b[i]][c[j]]);
			f[i][j]=max(f[i][j-1]+a[5][c[j]],f[i-1][j]+a[b[i]][5]);
//			printf("%d %d %d  ",i,j,f[i][j]);
			f[i][j]=max(f[i][j],f[i-1][j-1]+a[b[i]][c[j]]);
//			printf("%d %d %d\n",i,j,f[i][j]);
		}
	}
	printf("%d\n",f[n][m]);
	return 0;
}

