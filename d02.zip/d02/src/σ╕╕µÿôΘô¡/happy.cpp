#include <stdio.h>
#include <algorithm>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
int a[205],b[205],f[205];
main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n=re();
	for(int i=1;i<=n;++i)a[i]=re();
	for(int i=1;i<=n;++i)b[i]=re();
	for(int i=1;i<=n;++i){
		for(int j=100;j>a[i];--j){
			f[j]=max(f[j],f[j-a[i]]+b[i]);
		}
	}
	printf("%d\n",f[100]);
	return 0;
}

