#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
char a[300],b[300];
int ok[27];
int main(){ freopen("correlate.in","r",stdin);
freopen("correlate.out","w",stdout);
	scanf("%s",a+1);
	scanf("%s",b+1);
	int len1=strlen(a+1),len2=strlen(b+1);
	for(int i=1;i<=len1;i++)ok[a[i]-'A']=1;
	int tot=0;
	for(int i=1;i<=len2;i++)if(ok[b[i]-'A'])tot++,ok[b[i]-'A']=2;
	if(tot==0){
		puts("Unique");
		return 0;
	}
	if(tot==1){
		puts("Middling");
		for(int i=0;i<26;i++)
		if(ok[i]==2){
			printf("%c\n",i+'A');
			return 0;	
		}
	}
	if(tot>1){
		puts("Gloomy");
		char ans[28];
		int all=0;
		for(int i=0;i<26;i++)
		if(ok[i]==2)ans[++all]=i+'A';
		printf("%d\n%c",all,ans[1]);
		for(int i=2;i<=all;i++)printf("-%c",ans[i]);
		puts("");
	}
}
