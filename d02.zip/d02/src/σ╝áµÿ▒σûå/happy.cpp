#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int f[201][101],c[201],w[201],n;
int main(){
	freopen("happy.in","r",stdin);
freopen("happy.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&c[i]);
	for(int i=1;i<=n;i++)scanf("%d",&w[i]);
	memset(f,0,sizeof(f));
	for(int i=0;i<=n;i++)
	for(int j=99;j>=c[i];j--)
	f[i][j]=max(f[i-1][j],f[i-1][j-c[i]]+w[i]);
	printf("%d\n",f[n][99]);
	return 0;
}
