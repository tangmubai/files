#include<cstdio>
#include<algorithm>
using namespace std;
int a[1010];
int main(){
	freopen("shopping.in","r",stdin);
	freopen("shopping.out","w",stdout);
	int k,m;
	scanf("%d%d",&k,&m);
	for(int i=1;i<=k;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
	}
	puts("2");
	return 0;
}
