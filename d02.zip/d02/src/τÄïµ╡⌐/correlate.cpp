#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
char a[255],b[255];
int main(){
	freopen("correlate.in","r",stdin);
	freopen("correlate.out","w",stdout);
	scanf("%s",a);
	scanf("%s",b);
	cout<<"Unique"<<endl;
	return 0;
}
