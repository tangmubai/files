#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
const int maxm=32767, maxn=205;
int n;
int w[maxn],c[maxn];
int f[maxm];
int main() {
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	scanf("%d",&n);         
    for(int i=1;i<=n;i++){
    	cin>>w[i];
    }
	for (int i=1;i<=n; i++){
		cin>>c[i];
	} 
	for (int i=1; i<=n; i++)             
		for (int v=99; v>=w[i]; v--)
			if (f[v-w[i]]+c[i]>f[v])
				f[v]=f[v-w[i]]+c[i];
	printf("%d",f[99]);                   
	return 0;
}



