#include <iostream> 
#include <cstdio>
#include <cstring>

using namespace std;

const int N = 300;

int res = 0;
char cf[N], s[N];
bool TaoZanYuAKIOI[30];

int main()
{
	freopen("correlate.in", "r", stdin);
	freopen("correlate.out", "w", stdout);
	
	cin >> (cf + 1) >> (s + 1);
	
	int n = strlen(cf + 1);
	int m = strlen(s + 1);
	
	for (int i = 1; i <= n; i ++ )
		for (int j = 1; j <= m; j ++ )
			if (cf[i] == s[j])
				res ++ , TaoZanYuAKIOI[s[j] - 'A'] = true;
	
	if (res == 0)
		puts("Unique");
	else	if (res == 1)
	{
		puts("Middling");
		for (int i = 0; i < 26; i ++ )
			if (TaoZanYuAKIOI[i])
			{
				cout << char(i + 'A') << endl;
				return 0;
			}
	}
	else
	{
		puts("Gloomy");
		cout << res << endl;
		int ans = 1;
		for (int i = 0; i < 26; i ++ )
		{
			if (TaoZanYuAKIOI[i])
			{
				if (ans == res)
				{
					cout << char(i + 'A') << endl;
					return 0;
				}
				else cout << char(i + 'A') << '-';
				ans ++ ;
			}
		}
	}
	
	return 0;
}
