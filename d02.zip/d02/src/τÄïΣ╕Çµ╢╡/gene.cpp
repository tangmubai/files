#include <iostream>
#include <cstdio>

using namespace std;

const int N = 110;

int ch(char a, char b)
{
	if (a == 'A')
	{
		if (b == 'A') return 5;
		if (b == 'C') return -1;
		if (b == 'G') return -2;
		if (b == 'T') return -1;
		if (b == '-') return -3;
	}
	if (a == 'C')
	{
		if (b == 'A') return -1;
		if (b == 'C') return 5;
		if (b == 'G') return -3;
		if (b == 'T') return -2;
		if (b == '-') return -4;
	}
	if (a == 'G')
	{
		if (b == 'A') return -2;
		if (b == 'C') return -3;
		if (b == 'G') return 5;
		if (b == 'T') return -2;
		if (b == '-') return -2;
	}
	if (a == 'T')
	{
		if (b == 'A') return -1;
		if (b == 'C') return -2;
		if (b == 'G') return -2;
		if (b == 'T') return 5;
		if (b == '-') return -1;
	}
	if (a == '-')
	{
		if (b == 'A') return -3;
		if (b == 'C') return -4;
		if (b == 'G') return -2;
		if (b == 'T') return -1;
	}
}

int la, lb;
int f[N][N];
char a[N], b[N];

int main()
{
	freopen("gene.in", "r", stdin);
	freopen("gene.out", "w", stdout);
	
	cin >> la >> (a + 1);
	cin >> lb >> (b + 1);
	
	for (int i = 1; i <= la; i ++ )
		f[i][0] = f[i - 1][0] + ch(a[i], '-');
	for (int j = 1; j <= lb; j ++ )
		f[0][j] = f[0][j - 1] + ch('-', b[j]);
	
	for (int i = 1; i <= la; i ++ )
		for (int j = 1; j <= lb; j ++ )
		{
			if (a[i] == b[j])
				f[i][j] = f[i - 1][j - 1] + 5;
			f[i][j] = max(f[i][j], max(f[i - 1][j - 1] + ch(a[i], b[j]), max(f[i - 1][j] + ch(a[i], '-'), f[i][j - 1] + ch('-', b[j]))));
		}
	
	cout << f[la][lb] << endl;
	return 0;
}
