#include <iostream>

using namespace std;

const int N = 210;

int w[N], v[N], f[N];

int main()
{
	freopen("happy.in", "r", stdin);
	freopen("happy.out", "w", stdout);
	
	int n;
	cin >> n;
	
	for (int i = 1; i <= n; i ++ )	cin >> w[i];
	for (int i = 1; i <= n; i ++ )	cin >> v[i];
	
	for (int i = 1; i <= n; i ++ )
		for (int j = 100; j > w[i]; j -- )
			f[j] = max(f[j], f[j - w[i]] + v[i]);
	
	cout << f[100] << endl;
	return 0;
}
