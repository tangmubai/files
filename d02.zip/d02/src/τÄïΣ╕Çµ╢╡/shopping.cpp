#include <iostream>

using namespace std;

const int N = 1010;

int a[N], f[N];

int find(int x)
{
	if (x != f[x])	return f[x] = find(f[x]);
	return f[x];
}

int main()
{
	freopen("shopping.in", "r", stdin);
	freopen("shopping.out", "w", stdout);
	
	int n, k;
	cin >> n >> k;
	
	for (int i = 1; i <= n; i ++ )
		f[i] = i;
	
	for (int i = 1; i <= n; i ++ )	cin >> a[i];
	
	for (int i = 1; i <= k; i ++ )
	{
		int x, y;
		cin >> x >> y;
		
		if (find(x) != find(y))
		{
			a[find(x)] = max(a[find(x)], a[find(y)]);
			f[find(x)] = f[find(y)];
		}
	}
	
	int ans = 0;
	for (int i = 1; i <= n; i++ )
		if (find(i) == i)
			ans += a[i];
			
	cout << ans << endl;
	return 0;
}
