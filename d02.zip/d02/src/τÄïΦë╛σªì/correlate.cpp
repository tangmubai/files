#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<map>
using namespace std;
map<char,int>t1;
int main(){
	//freopen("correlate.in","r",stdin);
	//freopen("correlate.out","w",stdout);
	int k=0;
	char c1[255],c2[255],ans[255];
	scanf("%s%s",&c1+1,&c2+1);
	int len1=strlen(c1);
	int len2=strlen(c2);
	for(int i=1;i<=len1;i++)
	    t1[c1[i]]++;
	for(int i=1;i<=len2;i++)
	    if(t1[c2[i]])
		    ans[++k]=c2[i];
	if(k==0)printf("Unique\n");
	if(k==1)printf("Middling\n");
	else{
		printf("Gloomy\n");
		printf("%d\n",k-1);
		sort(ans,ans+k);
		for(int i=1;i<=k;i++){
			if(ans[i]!=ans[i+1])
			cout<<ans[i]<<"-";
		}
		cout<<ans[k-1];
	}
	printf("\n");
	return 0;
}
