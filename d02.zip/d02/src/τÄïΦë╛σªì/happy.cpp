#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
using namespace std;
struct node{
	int x;
	int y;
}a[1005];
bool cmp(struct node a,struct node b){
	return a.x<b.x;
}
int main(){
	freopen("happy.in","r",stdin);
	freopen("happy.out","w",stdout);
	int n,sum=0,ans=0,k=0;
	scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d",&a[i].x);
	for(int i=0;i<n;i++)scanf("%d",&a[i].y);
	sort(a,a+n,cmp);
	while(sum+a[k].x<100){
		sum+=a[k].x;
		ans+=a[k].y;
		k++;
	}
	printf("%d\n",ans);
	return 0;
}
