#include "cstdio"
#include "cstring"
#include "algorithm"
using namespace std;
char a[1005],b[1005];
int f[1005][1005],n,m,t[1005],ans;
int main(){
	freopen ("correlate.in","r",stdin);
	freopen ("correlate.out","w",stdout);
	scanf ("%s",a+1);
	scanf ("%s",b+1);
	n=strlen(a+1),m=strlen(b+1);
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			if (a[i]==b[j]&&t[a[i]]==0) t[a[i]]++,ans++;
		}
	}
	if (ans==0) printf ("Unique\n");
	else if (ans==1){
		printf ("Middling\n");
		for (int i=1;i<=200;i++) if (t[i]) printf ("%c",(char)i);
	}
	else{
		printf ("Gloomy\n");
		printf ("%d\n",ans);
		int i=1;
		for (;i<=200;i++){
			if (t[i]){
				printf ("%c",(char)i);
				break;	
			}
		}
		i++;
		for (;i<=200;i++) if (t[i]) printf ("-%c",(char)i);
	}
	return 0;
}
