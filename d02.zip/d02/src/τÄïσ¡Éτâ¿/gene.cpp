#include "cstdio"
#include "algorithm"
using namespace std;
int n,m,f[1005][1005],v[1005][1005],ans;
char a[1005],b[1005];
int main(){
	freopen ("gene.in","r",stdin);
	freopen ("gene.out","w",stdout);
	v['A']['A']=v['C']['C']=v['G']['G']=v['T']['T']=5;
	v['C']['A']=v['A']['C']=v['A']['T']=v['T']['A']=v['T']['-']=v['-']['T']=-1;
	v['G']['C']=v['C']['G']=v['A']['-']=v['-']['A']=-3;
	v['A']['G']=v['G']['A']=v['T']['C']=v['C']['T']=v['T']['G']=v['G']['T']=v['-']['G']=v['G']['-']=-2;
	v['C']['-']=v['-']['C']=-4;
	scanf ("%d",&n);
	scanf ("%s",a+1);
	scanf ("%d",&m);
	scanf ("%s",b+1);
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			if (a[i]==b[j]) f[i][j]=f[i-1][j-1]+1,ans+=5;
			else{
				if (f[i-1][j]>f[i][j-1]){
					ans+=v[a[i-1]]['-'];
				}
				else{
					ans+=v[b[j-1]]['-'];
				}
				f[i][j]=max(f[i-1][j],f[i][j-1]);
			}
		}
	}
	printf ("%d\n",ans);
	return 0;
}
/*
	A	C	G	T	-
A	5	-1	-2	-1	-3
C	-1	5	-3	-2	-4
G	-2	-3	5	-2	-2
T	-1	-2	-2	5	-1
-	-3	-4	-2	-1	*
*/


