#include "cstdio"
#include "algorithm"
using namespace std;
int n,a[10005],b[10005],f[1000005];
int main(){
	freopen ("happy.in","r",stdin);
	freopen ("happy.out","w",stdout);
	scanf ("%d",&n);
	for (int i=1;i<=n;i++) scanf ("%d",&b[i]);
	for (int i=1;i<=n;i++) scanf ("%d",&a[i]);
	
	for (int i=1;i<=n;i++){
		for (int j=100;j>b[i];j--){
			f[j]=max(f[j],f[j-b[i]]+a[i]);
		}
	}
	printf ("%d",f[100]);
	return 0;
}
