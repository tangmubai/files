#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
bool t1[30],t2[30];char ans[30];string a;
int main(){
	int w=0;
	cin>>a;
	for(int i=0;i<a.size();++i) t1[a[i]-64]=1;
	cin>>a;
	for(int i=0;i<a.size();++i) t2[a[i]-64]=1;
	for(int i=1;i<=26;++i){
		if(t1[i]&&t2[i]) ans[++w]=i+64;
	}
	if(!w) puts("Unique");
	if(w==1){
		puts("Middling");
		printf("%c",ans[1]);puts("");
	}
	if(w>1){
		puts("Gloomy");
		sort(ans+1,ans+1+w);
		printf("%d",w);puts("");
		for(int i=1;i<w;++i){
			printf("%c",ans[i]);putchar('-');
		}
		printf("%c",ans[w]);puts("");
	}
	return 0;
}
