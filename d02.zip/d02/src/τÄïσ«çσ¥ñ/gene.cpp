#include<iostream>
#include<stdio.h>
using namespace std;
const int jy[10][10]={{5,-1,-2,-1,-3},{-1,5,-3,-2,-4},{-2,-3,5,-2,-2,},{-1,-2,-2,5,-1},{-3,-4,-2,-1,0}};
long long n,m,ans=-2147483647;
char a[105],b[105];
long long qread(){
	char c=getchar();
	while(c!='A'&&c!='C'&&c!='G'&&c!='T') c=getchar();
	return c;
}
void qs(long long h,long long i,long long w){
	if(w>n&&i==m){
		ans=max(ans,h);
		return;
	}
	qs(h+jy[a[i]-65][b[w]-65],i+1,w+1);
//	qs(h,i,w+1);
	return;
}
int main(){
	scanf("%lld",&n);
	for(long long i=1;i<=n;++i) a[i]=qread();
	scanf("%lld",&m);
	for(long long i=1;i<=m;++i) b[i]=qread();
	qs(0,1,1);
	printf("%lld",ans);puts("");
	return 0;
}
