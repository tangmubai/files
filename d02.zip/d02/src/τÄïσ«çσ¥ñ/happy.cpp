#include<iostream>
#include<stdio.h>
using namespace std;
long long n,ans;
long long tl[205],hp[205];
long long qread(){
	long long a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
void qs(long long i,long long h,long long now){
	if(i>n){
		ans=max(ans,h);
		return;
	}
	if(now>tl[i]) qs(i+1,h+hp[i],now-tl[i]);
	qs(i+1,h,now);
	return;
}
int main(){
	freopen("happy.in","r",stdin);freopen("happy.out","w",stdout);
	n=qread();
	for(long long i=1;i<=n;++i) tl[i]=qread();
	for(long long i=1;i<=n;++i) hp[i]=qread();
	qs(1,0,100);
	printf("%lld",ans);puts("");
	return 0;
}
