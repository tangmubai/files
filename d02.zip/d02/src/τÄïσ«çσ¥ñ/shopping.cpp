#include<iostream>
#include<stdio.h>
using namespace std;
long long mn[1005],bn[1005][2];bool sf[1005];
long long qread(){
	long long a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("shopping.in","r",stdin);freopen("shopping.out","w",stdout);
	long long n=qread(),m=qread(),ans=0;
	for(long long i=1;i<=n;++i) mn[i]=qread();
	for(long long i=1;i<=m;++i){
		bn[i][0]=qread();
		bn[i][1]=qread();
		sf[bn[i][0]]=1;
		sf[bn[i][1]]=1;
	}
	for(long long i=1;i<=n;++i){
		if(sf[i]==0) ans+=mn[i];
	}
	for(long long i=1;i<=m;++i) ans+=max(mn[bn[i][0]],mn[bn[i][1]]);
	printf("%lld",ans);puts("");
	return 0;
}
