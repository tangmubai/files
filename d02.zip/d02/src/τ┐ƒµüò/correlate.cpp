#include <cstdio>
#include <cstring>
using namespace std;
int n1,n2,i,t[258],tt[258],s,x; char a[258],b[258];
int main () {
	freopen ("correlate.in","r",stdin);
	freopen ("correlate.out","w",stdout);
	scanf ("%s%s",a+1,b+1);
	n1=strlen(a+1),n2=strlen(b+1);
	for (i=1;i<=n1;i++) t[a[i]]=1;
	for (i=1;i<=n2;i++) tt[b[i]]=1;
	for (i=1;i<=200;i++) if (t[i]==1&&tt[i]==1) s++,x=i;
	if (s==0) printf ("Unique");
	if (s==1) printf ("Middling");
	if (s>1) {
		printf ("Gloomy\n%d\n",s);
		for (i=1;i<=200;i++) if (t[i]==1&&tt[i]==1) {
			if (i<x) printf ("%c-",i);
			else printf ("%c",i);
		}
	}
	return 0;
}
