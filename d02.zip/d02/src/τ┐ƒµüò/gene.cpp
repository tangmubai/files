#include <cstdio>
using namespace std;
int n1,n2,i,j,s; char a1[101],a2[101];
int main () {
	//freopen ("gene.in","r",stdin);
	//freopen ("gene.out","w",stdout);
	scanf ("%d%s%d%s",&n1,a1+1,&n2,a2+1);
	
	return 0;
}
