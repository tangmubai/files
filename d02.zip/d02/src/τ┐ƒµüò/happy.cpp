#include <cstdio>
using namespace std;
int n,i,j,a[201],b[201],f[201][201],s;
int max (int a,int b) {return a>b?a:b;}
int main () {
	freopen ("happy.in","r",stdin);
	freopen ("happy.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) scanf ("%d",&a[i]);
	for (i=1;i<=n;i++) scanf ("%d",&b[i]);
	for (i=1;i<=n;i++) for (j=1;j<100;j++) {
		if (a[i]<j) f[i][j]=max(f[i-1][j],f[i-1][j-a[i]]+b[i]);
		else f[i][j]=f[i-1][j];
	}
	for (i=1;i<100;i++) if (s<f[n][i]) s=f[n][i];
	printf ("%d",s);
	return 0;
}
