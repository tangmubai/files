#include <cstdio>
using namespace std;

int main () {
	//freopen ("shopping.in","r",stdin);
	//freopen ("shopping.out","w",stdout);
	
	return 0;
}
