#include <stdio.h>
#include <time.h>
#include <stdlib.h> 
#include <iostream>
#include<cstring>
using namespace std;
int b[40000];
/*void getrand(int n)
{
    int i,k;
    srand((int)time(0));
    for (int i=0;i<=n;i++) b[i]=i;
    for(i=0;i<n-1;i++)
    {
        k=rand()%(n-i)+i;
        swap(b[i],b[k]); 
    }
	while(n--)
		printf("%d\n",b[n]);
}*/
int main(){
/*   freopen("zipper.bat","w",stdout);
    for (int i=0;i<10;i++)
        printf("zipper zipper%d.in zipper%d.out\n",i,i);
*/
    freopen("Zipper.in","r",stdin);  
    srand( unsigned ( time (NULL) ) );
    char fn[]="zipper .in";
    int p,k,t,u,v,j,a;
    char s[250],c;
    scanf("%d\n",&u);
    for (int i=0;i<9;i++){
        fn[6]=char (i+'0');
        freopen(fn,"w",stdout);
        a=rand()%14+1;
        printf("%d\n",a*3);
        a=a*3;j=0;
        while(a--){
          while((c=getchar())!='\n') 
             putchar(c);
        printf("\n");
        }
  }
   return 0;
}
