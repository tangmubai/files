#include <stdio.h>  
#include <string.h>  
#define N 202  
  
char s1[N], s2[N], s[N+N];  
  
int dfs(int x, int y)  
{  
    if (x == -1 && y == -1)  
        return 1;  
    if (x >= 0  && s1[x] == s[x + y + 1])  
        if (dfs(x - 1, y))  
            return 1;  
    if (y >= 0 && s2[y] == s[x + y + 1])  
        if (dfs(x, y - 1))  
            return 1;  
    return 0;  
}  
  
int main(void)  
{  
    int n, i;  
    scanf("%d", &n);  
    for (i = 1; i <= n; i++)  
    {  
        scanf("%s %s %s", s1, s2, s);  
        if ( dfs(strlen(s1)-1, strlen(s2)-1) )  
            printf("Data set %d: yes/n", i);  
        else  
            printf("Data set %d: no/n", i);  
    }  
    return 0;  
}  
