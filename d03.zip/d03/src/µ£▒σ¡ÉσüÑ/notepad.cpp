#include <iostream>
#include <string>
#include <map>
using namespace std;
map<string,int> t;
int trans[101];
void init(){
	trans['A']=trans['B']=trans['C']=2;
	trans['D']=trans['E']=trans['F']=3;
	trans['G']=trans['H']=trans['I']=4;
	trans['J']=trans['K']=trans['L']=5;
	trans['M']=trans['N']=trans['O']=6;
	trans['P']=trans['R']=trans['S']=7;
	trans['T']=trans['U']=trans['V']=8;
	trans['W']=trans['X']=trans['Y']=9;
}
int main(){
	freopen("notepad.in","r",stdin);freopen("notepad.out","w",stdout);
	init();
	int n;cin>>n;
	while(n--){
		string s,a="";cin>>s;
		for(int i=0;i<s.size();i++){
			if(s[i]>='A'&&s[i]<='Z'&&s[i]!='Q'&&s[i]!='Z') s[i]=trans[s[i]]+'0',a+=s[i];
			else if(s[i]!='-') a+=s[i];
		}
		++t[a];
	}
	bool ok=1;
	for(map<string,int>::iterator it=t.begin();it!=t.end();it++)
		if(it->second>1){
			for(int i=0;i<3;i++) cout<<it->first[i];
			cout<<'-';
			for(int i=3;i<it->first.size();i++) cout<<it->first[i];
			cout<<' '<<it->second<<'\n';
			ok=0;
		}
	if(ok) cout<<"No duplicates.\n";
	return 0;
}

