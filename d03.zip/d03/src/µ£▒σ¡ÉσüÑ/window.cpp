#include <cstdio>
#include <queue>
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
int n,k,a[1000003],mx[1000003],mn[1000003];
std::queue<int> maxq,minq;
int main(){
	freopen("window.in","r",stdin);freopen("window.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	maxq.push(a[1]);
	mx[k]=-(1<<30),mn[k]=1<<30;
	for(int i=2;i<=k;i++){
		while(maxq.front()<a[i]&&!maxq.empty()) maxq.pop();
		maxq.push(a[i]);
		while(minq.front()>a[i]&&!minq.empty()) minq.pop();
		minq.push(a[i]);
	}
	mx[k]=max(mx[k],maxq.front());
	mn[k]=min(mn[k],minq.front());
	for(int i=k+1;i<=n;i++){
		while(maxq.front()<a[i]&&!maxq.empty()) maxq.pop();
		maxq.push(a[i]);
		mx[i]=maxq.front();
		if(maxq.size()>k) maxq.pop();
		while(minq.front()>a[i]&&!minq.empty()) minq.pop();
		minq.push(a[i]);
		mn[i]=minq.front();
		if(minq.size()>k) minq.pop();
	}
	for(int i=k;i<=n;i++) printf("%d ",mn[i]);puts("");
	for(int i=k;i<=n;i++) printf("%d ",mx[i]);puts("");
	return 0;
}
//3 -1 -3
//-3
