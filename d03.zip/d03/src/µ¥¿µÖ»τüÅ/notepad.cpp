#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <map>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline void in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
		{
			x = EOF;
			return;
		}
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int to_num[30] = {2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 0, 7, 7, 8, 8, 8, 9, 9, 9};
map<string, int> t;

int main()
{
	freopen("notepad.in", "r", stdin);
	freopen("notepad.out", "w", stdout);
	
	ios::sync_with_stdio(0);
	
	
	int n;
	cin >> n;
	
	
	for(int i=1; i<=n; i++)
	{
		string s, ans;
		cin >> s;
		
		for(unsigned j=0; j<s.size(); j++)
		{
			if(isdigit(s[j]))
				ans.push_back(s[j]);
			if(isalpha(s[j]))
				ans.push_back(to_num[s[j] - 'A'] + '0');
		}
		
		t[ans]++;
	}
	
	
	bool flag = 1;
	
	for(map<string, int>::iterator it = t.begin(); it != t.end(); it++)
		if(it->second > 1)
			flag = 0, cout << it->first.substr(0, 3) << '-' << it->first.substr(3, 4) << ' ' << it->second << '\n';

	if(flag)
		puts("No duplicates.");
}

