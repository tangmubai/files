#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <deque>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline void in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
		{
			x = EOF;
			return;
		}
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


struct NODE
{
	int val, id;
	
	NODE(int a, int b)
	{
		val = a;
		id = b;
	}
};


deque<NODE> maxx, minn;
int ans_maxx[1000010], ans_minn[1000010];


int main()
{
	freopen("window.in", "r", stdin);
	freopen("window.out", "w", stdout);
	
	
	int n, k;
	in(n), in(k);
	

	for(int i=1; i<=n; i++)
	{
		int num;
		in(num);
		
		
		while(!maxx.empty() && maxx.front().id <= i-k)
			maxx.pop_front();
			
		while(!maxx.empty() && maxx.back().val < num)
			maxx.pop_back();
			
		maxx.push_back(NODE(num, i));
	
	
		while(!minn.empty() && minn.front().id <= i-k)
			minn.pop_front();
			
		while(!minn.empty() && minn.back().val > num)
			minn.pop_back();
			
		minn.push_back(NODE(num, i));
	

		ans_maxx[i] = maxx.front().val, ans_minn[i] = minn.front().val;
	}
	
	
	for(int i=k; i<=n; i++)
		out(ans_minn[i]), space;
	
	enter;
	
	for(int i=k; i<=n; i++)
		out(ans_maxx[i]), space;
}

