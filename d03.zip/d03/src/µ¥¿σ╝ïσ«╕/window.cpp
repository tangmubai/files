#include<iostream>
#include<queue>
using namespace std;
priority_queue<int>a;
priority_queue<int,vector<int>,greater<int> >b;
int main(){
//	freopen("window.in","r",stdin);
//	freopen("window.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n,k;
	cin>>n>>k;
	for;
	return 0;
}
