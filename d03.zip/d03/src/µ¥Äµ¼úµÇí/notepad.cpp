#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#include<map>
#define ll long long
using namespace std;
map<string,ll>mp;
map<string,ll>::iterator it;
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	ll n,x;string a;
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++){
		string ans;
		cin>>a;
		x=0;
		for(ll i=1;i<=a.size();i++){
			if(a[i]!='-'){
				if(a[i]>='0'&&a[i]<='9'){
					if(x==3)ans[++x]='-';
					ans[++x]=a[i];
					continue;
				}
				if(a[i]=='A'||a[i]=='B'||a[i]=='C'){
					if(x==3)ans[++x]='-';
					ans[++x]='2';
					continue;
				}
				if(a[i]=='D'||a[i]=='E'||a[i]=='F'){
					if(x==3)ans[++x]='-';
					ans[++x]='3';
					continue;
				}
				if(a[i]=='G'||a[i]=='H'||a[i]=='I'){
					if(x==3)ans[++x]='-';
					ans[++x]='4';
					continue;
				}
				if(a[i]=='J'||a[i]=='K'||a[i]=='L'){
					if(x==3)ans[++x]='-';
					ans[++x]='5';
					continue;
				}
				if(a[i]=='M'||a[i]=='N'||a[i]=='O'){
					if(x==3)ans[++x]='-';
					ans[++x]='6';
					continue;
				}
				if(a[i]=='P'||a[i]=='R'||a[i]=='S'){
					if(x==3)ans[++x]='-';
					ans[++x]='7';
					continue;
				}
				if(a[i]=='T'||a[i]=='U'||a[i]=='V'){
					if(x==3)ans[++x]='-';
					ans[++x]='8';
					continue;
				}
				if(a[i]=='W'||a[i]=='X'||a[i]=='Y'){
					if(x==3)ans[++x]='-';
					ans[++x]='9';
					continue;
				}
			}
		}
		mp[ans]++;
	}
	int f=0;
	for(it=mp.begin();it!=mp.end();it++)
		if(it->second>1){
			cout<<it->first<<' '<<it->second<<endl;
			f=1;
		}
	if(!f)printf("No duplicates.\n");
	return 0;
}

