#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#include<queue> 
#define ll long long
using namespace std;
priority_queue<ll>ma;
priority_queue<ll,vector<ll>,greater<ll> >mi;
ll a[1000005],maxx[1000005];
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	ll n,k;
	scanf("%lld%lld",&n,&k);
	for(ll i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(ll i=1;i<n-1;i++){
		for(ll j=i;j<i+k;j++){
			ma.push(a[j]);mi.push(a[j]);
		}
		printf("%lld ",mi.top());
		maxx[i]=ma.top();
		for(ll j=i;j<i+k;j++){
			ma.pop();mi.pop();
		}		
	}
	printf("\n");
	for(ll i=1;i<n-1;i++)printf("%lld ",maxx[i]);
	printf("\n");	
	return 0;
}

