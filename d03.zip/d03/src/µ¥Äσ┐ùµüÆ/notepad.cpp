#include<stdio.h>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
int f(char c){
	if(c=='A'||c=='B'||c=='C'){return 2;}
	if(c=='D'||c=='E'||c=='F'){return 3;}
	if(c=='G'||c=='H'||c=='I'){return 4;}
	if(c=='J'||c=='K'||c=='L'){return 5;}
	if(c=='M'||c=='N'||c=='O'){return 6;}
	if(c=='P'||c=='R'||c=='S'){return 7;}
	if(c=='T'||c=='U'||c=='V'){return 8;}
	if(c=='W'||c=='X'||c=='Y'){return 9;}
	return 0;
}
int g(char s[]){
	int num=0,len=0,i=0;
	while(i<=8){
		if(s[len]<='Z'&&s[len]>='A'){
			if(s[len]=='Q'||s[len]=='Z'){
				continue;
			}
			i++;
			num+=f(s[len]);
			num*10;
		}
		if(s[len]<='9'&&s[len]>='0'){
			i++;
			num+=s[len]-'0';
			num*10;
		}
		len++;
	}
	printf("%d\n",num);
	return num;
}
struct Node{
	int id,times;
}a[100050];
char str[100];
int main(){
	file("notepad");
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%s",str);
		int num=g(str);
		printf("%d\n",num);
	}
}

