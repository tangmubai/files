#include<stdio.h>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
int a[1000050];
int ans[1000050];
int main(){
	file("window");
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++){
		ans[i]=200000000;
	}
	for(int l=1;l+k-1<=n;l++){
		int r=l+k-1;
		if(ans[l-1]>=a[r]&&l-1){
			ans[l]=a[r];
		}else{
			for(int i=l;i<=r;i++){
				if(ans[l]>a[i]){
					ans[l]=a[i];
				}
			}
		}
	}
	for(int l=1;l+k-1<=n;l++){
		printf("%d ",ans[l]);
	}
	printf("\n");
	for(int i=1;i<=n;i++){
		ans[i]=-200000000;
	}
	for(int l=1;l+k-1<=n;l++){
		int r=l+k-1;
		if(ans[l-1]<=a[r]&&l-1){
			ans[l]=a[r];
		}else{
			for(int i=l;i<=r;i++){
				if(ans[l]<a[i]){
					ans[l]=a[i];
				}
			}
		}
	}
	for(int l=1;l+k-1<=n;l++){
		printf("%d ",ans[l]);
	}
	printf("\n");
}
