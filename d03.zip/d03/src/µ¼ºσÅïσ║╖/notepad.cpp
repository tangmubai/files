#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
bool flag;
char c[1010]; 
int n,i,j,s,len,s1,s2,t[10000010];
int list[30]={0,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,0,7,7,8,8,8,9,9,9,0};
int main () {
	freopen ("notepad.in","r",stdin);
	freopen ("notepad.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) {
		scanf ("%s",c+1);
		len=strlen (c+1);
		s=0;
		s1=0;
		j=1;
		while (s!=3) {
			if ((c[j]>='0'&&c[j]<='9')||(c[j]>='A'&&c[j]<='Z')) {
				if (c[j]>='0'&&c[j]<='9')
					s1=s1*10+(c[j]-'0');
				else 
					s1=s1*10+(list[c[j]-64]);
				s++;
			}
			j++;
		}
		s=0;
		s2=0;
		while (s!=4) {
			if ((c[j]>='0'&&c[j]<='9')||(c[j]>='A'&&c[j]<='Z')) {
				if (c[j]>='0'&&c[j]<='9')
					s2=s2*10+(c[j]-'0');
				else 
					s2=s2*10+(list[c[j]-64]);
				s++;
			}
			j++;
		}
		t[s1*10000+s2]++;
	}
	for (i=1;i<=9999999;i++) 
		if (t[i]>1) {
			flag=true;
			printf ("%d-%d %d\n",i/10000,i%10000,t[i]);
		}
	if (flag==false) 
		puts ("No duplicates.");
	return 0; 
} 
