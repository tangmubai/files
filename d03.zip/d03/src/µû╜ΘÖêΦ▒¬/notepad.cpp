#include<stdio.h>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<iostream>
#include<map>
using namespace std;
int a[30]={2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,0,7,7,8,8,8,9,9,9,0};
int hh[100005];
char ss[1005];
map<int,int>ok;
void out(int y){
	int x=y;
	int o[10],p=0;
	while(x){
		o[++p]=x%10;
		x/=10;
	}
	for(int i=7;i>=5;i--)printf("%d",o[i]);
	printf("-%d ",y%10000);
}
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int s=0;
		scanf("%s",ss+1);
		int l=strlen(ss+1);
		for(int j=1;j<=l;j++){
			if(ss[j]!='-'){
				if(ss[j]>='0'&&ss[j]<='9')s=s*10+ss[j]-'0';
				else s=s*10+a[ss[j]-'A'];
			}
		}
		hh[i]=s;
		ok[s]++;
	}
	sort(hh+1,hh+1+n);
	bool first=0;
	for(int i=1;i<=n;i++){
		if(ok[hh[i]]>=2){
			first=1;
			out(hh[i]);
			printf("%d\n",ok[hh[i]]);
			ok[hh[i]]=0;
		}
	}
	if(first==0){
		printf("No duplicates.");
	}
	return 0;
}
