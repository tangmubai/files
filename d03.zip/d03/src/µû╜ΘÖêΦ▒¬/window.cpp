#include<stdio.h>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<iostream>
#include<vector>
using namespace std;
int a[1000005];
int ans1[1000005];
int ans2[1000005];
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n-k+1;i++){
		int mi=(2147483647),ma=(-2147483647);
		for(int j=i,p=1;p<=k;j++,p++){
			mi=min(mi,a[j]);
			ma=max(ma,a[j]);
		}
		ans1[i]=mi;
		ans2[i]=ma;
	}
	for(int i=1;i<=n-k+1;i++)printf("%d ",ans1[i]);
	puts("");
	for(int i=1;i<=n-k+1;i++)printf("%d ",ans2[i]);
	return 0;
}
