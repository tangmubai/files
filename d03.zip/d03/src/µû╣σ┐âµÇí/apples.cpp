#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;
struct Node{
	int x,y,t;
}a[5010];
int n,s,ans;
bool cmp(Node p,Node q){
	return p.t<q.t;
}
double d(int x1,int y1,int x2,int y2){
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
void dfs(int i,int s,int nx,int ny,int nt){
	if(i>n){
		if(s>ans)ans=s;
		return;
	}
	if(s*(a[i].t-nt)>=d(a[i].x,a[i].y,nx,ny))dfs(i+1,s+1,a[i].x,a[i].y,nt+(d(a[i].x,a[i].y,nx,ny)+s-1)/s);
	dfs(i+1,s,nx,ny,nt);
	return;
}
int main(){
	freopen("apples.in","r",stdin);
	freopen("apples.out","w",stdout);
	scanf("%d%d",&n,&s);
	for(int i=1;i<=n;i++)
		scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].t);
	sort(a+1,a+1+n,cmp);
	dfs(1,0,0,0,0);
	printf("%d\n",ans);
	return 0;
}
