#include <cstdio>
#include <algorithm>
using namespace std;
int a[100010];
struct Node{
	int ans,num;
}b[100010];
bool cmp(Node p,Node q){
	return p.ans<q.ans;
}
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	int n,len=0;scanf("%d\n",&n);
	char c;
	for(int i=1;i<=n;i++){
		while(1){
			c=getchar();
			if(c=='\n')break;
			if(c=='-')continue;
			if(c>='0'&&c<='9')a[i]=a[i]*10+c-'0';
			if(c>='A'&&c<='Z'){
				if(c=='A'||c=='B'||c=='C')a[i]=a[i]*10+2;
				if(c=='D'||c=='E'||c=='F')a[i]=a[i]*10+3;
				if(c=='G'||c=='H'||c=='I')a[i]=a[i]*10+4;
				if(c=='J'||c=='K'||c=='L')a[i]=a[i]*10+5;
				if(c=='M'||c=='N'||c=='O')a[i]=a[i]*10+6;
				if(c=='P'||c=='R'||c=='S')a[i]=a[i]*10+7;
				if(c=='T'||c=='U'||c=='V')a[i]=a[i]*10+8;
				if(c=='W'||c=='X'||c=='Y')a[i]=a[i]*10+9;
			}
		}
	}
	sort(a+1,a+1+n);
	int now=a[1],s=1,ans1,ans2;
	for(int i=2;i<=n;i++)
		if(a[i]==now)s++;
		else{
			if(s>1){
				len++;
				b[len].ans=now;
				b[len].num=s;
			}
			s=1;now=a[i];
		}
	if(s>1){
		len++;
		b[len].ans=now;
		b[len].num=s;
	}
	sort(b+1,b+1+len,cmp);
	if(len==0){
		puts("No duplicates.");
		return 0;
	}
	for(int i=1;i<len;i++)
		printf("%03d-%04d %d\n",b[i].ans/10000,b[i].ans%10000,b[i].num);
	printf("%03d-%04d %d\n",b[len].ans/10000,b[len].ans%10000,b[len].num);
	return 0;
}
