#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;
int a[1000010],f[1000010][30],g[1000010][30];
int mn(int x,int y){
	return x<y?x:y;
}
int mx(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	int n,k;scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		f[i][0]=g[i][0]=a[i];
	}
	for(int j=1;j<=20;j++)
		for(int i=1;i<=n&&i+(1<<j)-1<=n;i++){
			f[i][j]=mn(f[i][j-1],f[i+(1<<(j-1))][j-1]);
			g[i][j]=mx(g[i][j-1],g[i+(1<<(j-1))][j-1]);
		}
	for(int i=1;i<=n-k+1;i++){
		int l=i,r=i+k-1;
		int tmp=log(r-l)/log(2);
		printf("%d ",mn(f[l][tmp],f[r-(1<<(tmp-1))][tmp]));
	}
	printf("\n");
	for(int i=1;i<=n-k+1;i++){
		int l=i,r=i+k-1;
		int tmp=log(r-l)/log(2);
		printf("%d ",mx(g[l][tmp],g[r-(1<<(tmp-1))][tmp]));
	}
	return 0;
}
