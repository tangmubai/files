#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

struct Node{
	double x,y;
	int time;
}a[5005];

bool operator<(const Node &a,const Node &b){
	return a.time<b.time;
}

int n,speed,ans;
int f[5005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

double dis(int i,int j){
	return sqrt((a[i].x-a[j].x)*(a[i].x-a[j].x)+(a[i].y-a[j].y)*(a[i].y-a[j].y));
}

int main(){
	freopen("apples.in","r",stdin);
	freopen("apples.out","w",stdout);
	n=read(),speed=read();
	for(int i=1;i<=n;++i){
		scanf("%lf%lf",&a[i].x,&a[i].y);
		a[i].time=read();
	}
	a[0].x=a[0].y=0.0;
	a[0].time=0;
	sort(a+1,a+n+1);
	for(int i=1;i<=n;++i){
		for(int j=i-1;j>-1;--j){
			if(a[i].time==a[j].time)continue;
			if(ceil(dis(i,j)/(1.0*speed))>a[i].time-a[j].time)continue;
			f[i]=max(f[i],f[j]+1);
		}
		ans=max(ans,f[i]);
	}
	printf("%d",ans);
	return 0;
}
