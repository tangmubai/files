#include <cstdio>
#include <map>
#include <string>
#include <iostream>
using namespace std;
map < string,int > mp;

int n;
string s,ss;

string work(){
	string ret="";
	for(int i=0;i<s.length();++i){
		if(ret.length()==3){
			ret+='-';
		}
		if(s[i]=='-' || s[i]=='Q' || s[i]=='Z')continue;
		if(s[i]>='0' && s[i]<='9'){
			ret+=s[i];
			continue;
		}
		switch (s[i]){
			case 'A':ret+='2';break;
			case 'B':ret+='2';break;
			case 'C':ret+='2';break;
			case 'D':ret+='3';break;
			case 'E':ret+='3';break;
			case 'F':ret+='3';break;
			case 'G':ret+='4';break;
			case 'H':ret+='4';break;
			case 'I':ret+='4';break;
			case 'J':ret+='5';break;
			case 'K':ret+='5';break;
			case 'L':ret+='5';break;
			case 'M':ret+='6';break;
			case 'N':ret+='6';break;
			case 'O':ret+='6';break;
			case 'P':ret+='7';break;
			case 'R':ret+='7';break;
			case 'S':ret+='7';break;
			case 'T':ret+='8';break;
			case 'U':ret+='8';break;
			case 'V':ret+='8';break;
			case 'W':ret+='9';break;
			case 'X':ret+='9';break;
			case 'Y':ret+='9';break;
		}
	}
	return ret;
}

int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		cin >> s;
		ss=work();
		++mp[ss];
	}
	bool ok=1;
	for(map < string,int >::iterator it=mp.begin();it!=mp.end();++it){
		if(it->second>1){
			cout << it->first << ' ' << it->second << endl;
			ok=0;
		}
	}
	if(ok){
		printf("No duplicates.");
	}
	return 0;
}
