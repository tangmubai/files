#include <cstdio>
#include <queue>
#include <iostream>
using namespace std;
deque < pair<int,int> > q;

int n,k;
int a[1000005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;++i){
		a[i]=read();
	}
	for(int i=1;i<=n;++i){
		while(!q.empty() && i-q.front().first>=k){
			q.pop_front();
		}
		while(!q.empty() && a[i]<=q.back().second){
			q.pop_back();
		}
		q.push_back(make_pair(i,a[i]));
		if(i>=k){
			printf("%d ",q.front().second);
		}
	}
	puts("");
	while(!q.empty()){
		q.pop_back();
	}
	for(int i=1;i<=n;++i){
		while(!q.empty() && i-q.front().first>=k){
			q.pop_front();
		}
		while(!q.empty() && a[i]>=q.back().second){
			q.pop_back();
		}
		q.push_back(make_pair(i,a[i]));
		if(i>=k){
			printf("%d ",q.front().second);
		}
	}
	return 0;
}
