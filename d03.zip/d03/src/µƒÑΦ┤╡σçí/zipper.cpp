#include <cstdio>
#include <cstring>

int test_num,n,m;
char a[205],b[205],c[405];
bool f[205][205];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("zipper.in","r",stdin);
	freopen("zipper.out","w",stdout);
	test_num=read();
	for(int test=1;test<=test_num;++test){
		scanf("%s%s%s",a+1,b+1,c+1);
		n=strlen(a+1);
		m=strlen(b+1);
		f[0][0]=1;
		for(int i=1;i<=n;++i){
			f[i][0]=f[i-1][0] | (a[i]==c[i]);
		}
		for(int j=1;j<=m;++j){
			f[0][j]=f[0][j-1] | (b[j]==c[j]);
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(a[i]==c[i+j] && b[j]==c[i+j]){
					f[i][j]=f[i-1][j] | f[i][j-1];
				}else if(a[i]==c[i+j]){
					f[i][j]=f[i-1][j];
				}else if(b[j]==c[i+j]){
					f[i][j]=f[i][j-1];
				}else {
					f[i][j]=0;
				}
			}
		}
		printf("Data set %d: %s\n",test,f[n][m]?"yes":"no");
	}
	return 0;
}
