#include<stdio.h>
#include<string>
#include<algorithm>
using namespace std;
int a[300];
string s[100005],ss;int n,len;
char A(){
	char c=getchar();
	while(!a[c])c=getchar();
	return a[c];
}
void print(string a){
	for(register int i=0;i<=2;++i)putchar(a[i]);
	putchar('-');
	for(register int i=3;i<=6;++i)putchar(a[i]);
	putchar(' ');
}
int main(){
	freopen("notepad.in","r",stdin);freopen("notepad.out","w",stdout);
	for(register int i='0';i<='9';++i)a[i]=i;
	a['A']=a['B']=a['C']='2';a['D']=a['E']=a['F']='3';a['G']=a['H']=a['I']='4';
	a['J']=a['K']=a['L']='5';a['M']=a['N']=a['O']='6';a['P']=a['R']=a['S']='7';
	a['T']=a['U']=a['V']='8';a['W']=a['X']=a['Y']='9';
	scanf("%d",&n);
	while(n--){
		ss="";
		for(register int i=1;i<=7;++i)
		ss+=A();
		s[++len]=ss;
	}
	sort(s+1,s+1+len);
	for(register int i=1,j=2;i<=len;i=j){
		while(s[i]==s[j]&&j<=len)++j;
		if(j-i>1)print(s[i]),printf("%d\n",j-i);
	}
}
