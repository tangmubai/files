#include<stdio.h>
int A(){
	char c=getchar();
	int k=1,s=0;
	while(c<'0'||c>'9'){
		c=='-'?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')s=s*10+c-'0',c=getchar();
	return s*k;
}
int a[1000005],q[1000005],front=1,rear,n,k;
int main(){
	n=A(),k=A();
	for(register int i=1;i<=n;++i)a[i]=A();
	for(register int i=1;i<=k;++i){
		while(a[q[front]]<a[i]&&front<=rear)++front;
		while(a[q[rear]]<a[i]&&front<=rear)--rear;
		q[++rear]=i;
	}
	printf("%d ",q[front]);
	for(register int i=k+1;i<=n;++i){
		while((a[q[front]]<a[i]||i-q[front]>k)&&front<rear)++front;
		while(a[q[rear]]<a[i]&&front<rear)--rear;
		q[++rear]=i;
		printf("%d ",q[front]);
	}
}
