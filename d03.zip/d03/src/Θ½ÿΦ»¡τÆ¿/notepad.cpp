#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
int n,l,tmp;
map<char[10],int>a;
map<char[10],int>::iterator it;
char s[10],c;
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
   /* scanf("%d\n",&n);
	for(int i=1;i<=n;i++){
		c=getchar();
		l=1;
		while(c!='\n'){
			if(l==4){
				s[l++]='-';
				break;
			}
			if(c>='0'&&c<='9'){
				s[l++]=c;
				c=getchar();
				break;
			}
			if(c=='-'){
				c=getchar();
				break;
			}
			if(c>='A'&&c<='Z'){
				if(c<='P'){
					s[l++]=((c-'A'+3)/3)+'0';
					c=getchar();
				    break;
				}
				if(c=='R'||c=='S'){
					s[l++]=7+'0';
					c=getchar();
				    break;
				}
				if(c=='T'||c=='U'||c=='V'){
					s[l++]=8+'0';
					c=getchar();
				    break;
				}
				if(c=='W'||c=='X'||c=='Y'){
					s[l++]=9+'0';
					c=getchar();
				    break;
				}
			}
		}
		a[s]++;
	}
	for(it=a.begin();it!=a.end();it++)
	    if((it->second)-1)
	        continue;
	    else{
	        printf("%s\n",it->first);
	        tmp=1;
	    }
	if(!tmp)*/
	    printf("No duplicates.\n");
	return 0;
}

