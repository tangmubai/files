#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;
int n,k,x,ans1[1000005],ans2[1000005];//ans1�����ֵ��ans2����Сֵ 
priority_queue<int>q1;//���ֵ
priority_queue<int,vector<int>,greater<int> >q2;//��Сֵ 
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		q1.push(a[i]);
		q2.push(a[i]);
		if(i>=k){
			if(q1.top()==a[i-k]&&i>k)q1.pop();
			if(q2.top()==a[i-k]&&i>k)q2.pop();
			ans1[i-k]=q1.top();
			ans2[i-k]=q2.top();
		}
	}
	for(int i=0;i+k<=n;i++)
	    printf("%d ",ans2[i]);
	printf("\n");
	for(int i=0;i+k<=n;i++)
	    printf("%d ",ans1[i]);
	printf("\n");
	return 0;
}
/*
8 3 
1 3 -1 -3 5 3 6 7

-1 -3 -3 -3 3 3 
3 3 5 5 6 7
*/
