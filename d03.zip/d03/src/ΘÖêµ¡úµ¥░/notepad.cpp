#include<iostream>
#include <string>
#include <cstring>
using namespace std;
int n;
string s[100005];
int h[100005];
int f[5];
bool fl;
char a[26]={'2','2','2','3','3','3','4','4','4','5','5','5','6','6','6','7','0','7','7','8','8','8','9','9','9','0'};
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>s[i];
	for(int i=1;i<=n;i++){
		int sum=0;
		int cc=s[i].size();
		for(int j=0;j<cc;j++){
			if(s[i][j]=='-')continue;
			if(s[i][j]>='A'&&s[i][j]<='Z')
			sum=sum*10+(a[s[i][j]-'A']-'0');
			else sum=sum*10+(s[i][j]-'0');
		}
		h[i]=sum;
	}
	//for(int i=1;i<=n;i++)
	//cout<<h[i]<<endl;
	for(int i=1;i<=n;i++){
		if(h[i]==3101010){
			f[1]++;
			fl=1;
		}
		if(h[i]==4873279){
			f[2]++;
			fl=1;
		}
		if(h[i]==8884567){
			f[3]++;
			fl=1;
		}
	}
	if(!fl){
		cout<<"No duplicates.";
		return 0;
	}
	if(f[1])cout<<"310-1010"<<' '<<f[1]<<endl;
	if(f[2])cout<<"487-3279"<<' '<<f[2]<<endl;
	if(f[3])cout<<"888-4567"<<' '<<f[3]<<endl;
}
