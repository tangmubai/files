#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n,m;
int a[1000005];
int q[1000005];
int mx(){
	memset(q,0,sizeof(q));
	int h=1,t=0;
	for(int i=1;i<=n;i++){
		while(h<=t&&q[h]+m<=i)h++;
		while(h<=t&&a[q[t]]<a[i])t--;
		q[++t]=i;
		if(i>=m)cout<<a[q[h]]<<' ';
	}
}
int mn(){
	memset(q,0,sizeof(q));
	int h=1,t=0;
	for(int i=1;i<=n;i++){
		while(h<=t&&q[h]+m<=i)h++;
		while(h<=t&&a[q[t]]>a[i])t--;
		q[++t]=i;
		if(i>=m)cout<<a[q[h]]<<' ';
	}
	cout<<endl;
}
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	mn();
	mx();
}
