#include<cstdio>
#include<iostream>
#include<string>
using namespace std;

int n,f[10000001];

int main(){
	freopen("notepad.in","r",stdin);freopen("notepad.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		string s;cin>>s;
		int tmp=0;
		for(int j=0;j<s.size();j++){
			char c=s[j];
			if(c=='-') continue;
			else if(c>='0'&&c<='9') tmp=tmp*10+c-'0';
			else{
				if(c<='C') tmp=tmp*10+2;
				else if(c<='F') tmp=tmp*10+3;
				else if(c<='I') tmp=tmp*10+4;
				else if(c<='L') tmp=tmp*10+5;
				else if(c<='O') tmp=tmp*10+6;
				else if(c<='S') tmp=tmp*10+7;
				else if(c<='V') tmp=tmp*10+8;
				else tmp=tmp*10+9; 
			}
		}
		f[tmp]++;
	}
	bool ok=false;
	for(int i=0;i<=10000000;i++)
		if(f[i]>1) ok=true,printf("%d-%d %d\n",i/10000,i%10000,f[i]);
	if(!ok) printf("No duplicates.\n");
	return 0;
}
