#include<cstdio>
#include<cstring>
using namespace std;

inline void in(int &x){
	x=0;register char c=getchar();register int f=1;
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
	x*=f;
}

int n,k,a[1000005],q[1000005],h,t;

int main(){
	freopen("window.in","r",stdin);freopen("window.out","w",stdout);
	in(n),in(k);
	for(int i=1;i<=n;i++) in(a[i]);
	memset(q,0,sizeof(q));
	h=1,t=0;
	for(int i=1;i<=n;i++){
		while(h<=t&&q[h]+k<=i) h++;
		while(h<=t&&a[q[t]]>a[i]) t--;
		q[++t]=i;
		if(i>=k) printf("%d ",a[q[h]]);
	}
	printf("\n");
	memset(q,0,sizeof(q));
	h=1,t=0;
	for(int i=1;i<=n;i++){
		while(h<=t&&q[h]+k<=i) h++;
		while(h<=t&&a[q[t]]<a[i]) t--;
		q[++t]=i;
		if(i>=k) printf("%d ",a[q[h]]);
	}
	printf("\n");
	return 0;
}
