#include<cstdio>
#include<cstring>
using namespace std;

char a[205],b[205],c[205];

int main(){
	freopen("zipper.in","r",stdin);freopen("zipper.out","w",stdout);
	int t;scanf("%d",&t);
	for(int kase=1;kase<=t;kase++){
		scanf("%s %s %s",a+1,b+1,c+1);
		int na=strlen(a+1),nb=strlen(b+1),nc=strlen(c+1);
		printf("Data set %d: ",kase);
		if(nc!=na+nb) printf("no\n");
		bool f[205][205]={0};
		for(int i=1;i<=na;i++)
			for(int j=1;j<=nb;j++)
				f[i][j]=(f[i-1][j]&&a[i]==c[i+j])||(f[i][j-1]&&b[j]==c[i+j]);
		if(f[na][nb]) printf("yes\n");
		else printf("no\n");
	}
	return 0;
}
