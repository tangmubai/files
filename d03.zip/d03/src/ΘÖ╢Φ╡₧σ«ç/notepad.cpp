#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<map>
#include<algorithm>
using namespace std;
const string val[]={"0","1","2","3","4","5","6","7","8","9"};
map<char,int> mp;
string a[100005];
char x[300005];
int n;
string tmp;
int cnt;
bool flag;
bool ok;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
inline bool cmp(string p,string q)
{
	return p<q;
}
int main()
{
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	mp['0']=0;mp['1']=1;
	mp['2']=mp['A']=mp['B']=mp['C']=2;
	mp['3']=mp['D']=mp['E']=mp['F']=3;
	mp['4']=mp['G']=mp['H']=mp['I']=4;
	mp['5']=mp['J']=mp['K']=mp['L']=5;
	mp['6']=mp['M']=mp['N']=mp['O']=6;
	mp['7']=mp['P']=mp['R']=mp['S']=7;
	mp['8']=mp['T']=mp['U']=mp['V']=8;
	mp['9']=mp['W']=mp['X']=mp['Y']=9;
	read(n);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",x);
		cnt=0;flag=true;
		for(int j=0;x[j];j++)
		{
			if(x[j]=='Q'||x[j]=='Z') continue;
			if(x[j]>='0'&&x[j]<='9') a[i]=a[i]+val[mp[x[j]]],cnt++;
			else 
			{
				if(x[j]>='A'&&x[j]<='Z') 
				{
					a[i]=a[i]+val[mp[x[j]]],cnt++;
				}
			}
			if(cnt==3&&flag) {
				a[i]=a[i]+"-";
				flag=false;
			}
		}	
	}
	sort(a+1,a+n+1,cmp);
	tmp=a[1];cnt=1;
	for(int i=2;i<=n;i++){
		if(tmp==a[i]) cnt++;
		else
		{
			if(cnt>1)
			{
				cout<<tmp;
				printf(" %d\n",cnt);
				ok=true;
			}
			cnt=1;
			tmp=a[i];
		}		
	}
	if(cnt>1) 
	{
		cout<<tmp;
		printf(" %d\n",cnt);
		ok=true;
	}
	if(!ok) puts("No duplicates.");
	return 0;
}
