#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<deque>
#include<algorithm>
using namespace std;
struct node
{
	int val;
	int id;
};
deque<node> Q1;
deque<node> Q2;
int n,k;
int a[1000005];
int Mn[1000005];
int Mx[1000005];
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
int main()
{
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	read(n);read(k);
	for(int i=1;i<=n;i++) read(a[i]);
	for(int i=1;i<=n;i++)
	{
		while(!Q1.empty()&&Q1.back().val<=a[i]) Q1.pop_back();
		while(!Q1.empty()&&i-Q1.front().id>=k) Q1.pop_front();
		while(!Q2.empty()&&Q2.back().val>=a[i]) Q2.pop_back();
		while(!Q2.empty()&&i-Q2.front().id>=k) Q2.pop_front();
		Q1.push_back((node){a[i],i});
		Q2.push_back((node){a[i],i});
		if(i>=k)
		{
			Mn[i]=Q2.front().val;
			Mx[i]=Q1.front().val;
		}
	}
	for(int i=k;i<=n;i++) printf("%d ",Mn[i]);puts("");
	for(int i=k;i<=n;i++) printf("%d ",Mx[i]);puts("");
	return 0;
}
