#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int t;
char a[205],b[205],c[205];
int lena,lenb,lenc;
bool f[205][205];
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
int main()
{
	freopen("zipper.in","r",stdin);
	freopen("zipper.out","w",stdout);
	read(t);
	for(int T=1;T<=t;T++)
	{
		scanf("%s",1+a);scanf("%s",1+b);scanf("%s",1+c);
		lena=strlen(1+a);lenb=strlen(1+b);lenc=strlen(1+c);
		if(lena+lenb!=lenc) 
		{
			printf("Data set %d: no\n",T);
			continue;
		}
		memset(f,false,sizeof(f));
		f[0][0]=true;
		for(int i=1;i<=lenb;i++) f[0][i]=f[0][i-1]&(b[i]==c[i]);
		for(int i=1;i<=lena;i++)
		{
			for(int j=i;j<=lenc;j++)
			{
				bool f1=(a[i]==c[j])&f[i-1][j-1];
				bool f2=(b[j-i]==c[j])&f[i][j-1];
				f[i][j]=f1|f2;
			}
		}
//		for(int i=1;i<=lena;i++)
//		{
//			for(int j=i;j<=lenc;j++)
//				printf("%d ",f[i][j]);
//			puts("");
//		}
		if(f[lena][lenc]) printf("Data set %d: yes\n",T);
		else printf("Data set %d: no\n",T);
	}
	return 0;
}
