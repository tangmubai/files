#include<stdio.h>
#include<string>
#include<map>
#include<iostream>
using namespace std;
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
map<string,int>a;
int jj[30]={0,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,0,7,7,8,8,8,9,9,9,0};
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++){
		string x,y;cin>>x;int js=0,jx=0;
		for(int j=0;j<x.size();j++){
			if(x[j]>='0'&&x[j]<='9')y+=x[j],js++;
			else if(x[j]!='-')y+=(jj[x[j]-'A'+1]+'0'),js++;
			if(js==3&&!jx)y+='-',jx=1;
		}
		a[y]++;
	}
	map<string,int>::iterator it=a.begin();int t=0;
	for(;it!=a.end();it++)
		if(it->second>1){cout<<it->first<<" "<<it->second<<endl;t=1;}
	if(!t)printf("No duplicates.");
	return 0;
}


