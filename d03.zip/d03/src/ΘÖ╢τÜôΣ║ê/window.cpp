#include<stdio.h>
#include<map>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[1000005],b[1000005],c[1000005];map<int,int>p;
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	int n=read(),k=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=k;i++)p[a[i]]++;
	map<int,int>::iterator t1=p.begin(),t2=p.end();
	t2--;int j1=0,j2=0;b[++j1]=t1->first;c[++j2]=t2->first;
	for(int i=k+1;i<=n;i++){
		p[a[i-k]]--;p[a[i]]++;
		if(p[a[i-k]]==0)p.erase(a[i-k]);
		t1=p.begin(),t2=p.end();t2--;b[++j1]=t1->first;c[++j2]=t2->first;
	}
	for(int i=1;i<=j1;i++)printf("%d ",b[i]);
	printf("\n");
	for(int i=1;i<=j2;i++)printf("%d ",c[i]);
	return 0;
}


