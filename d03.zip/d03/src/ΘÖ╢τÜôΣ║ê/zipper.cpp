#include<stdio.h>
#include<iostream>
#include<string>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
string a,b,c;
int main(){
	//freopen("zipper.in","r",stdin);
	//freopen("zipper.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++){
		int t=0;
		cin>>a>>b>>c;string t;
		if(a.size()<b.size())t=a,a=b,b=a;int k=0;
		for(int j=0;j<c.size(),j++){
			if(a[j])
		}
		printf("Data set %d: ",i);
		if(t)printf("yes\n");
		else printf("no\n");
	}
	return 0;
}



