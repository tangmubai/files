#include<cstdio>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
map<char,int>mp;
int n,f=0;
string str;
struct node{
	char s[105];
	int len;
}a[100005];
int main(){
	freopen("notepad.in","r",stdin);freopen("notepad.out","w",stdout);
	/*mp['A']=mp['B']=mp['C']=2,mp['D']=mp['E']=mp['F']=3,mp['G']=mp['H']=mp['I']=4,mp['J']=mp['K']=mp['L']=5;
	mp['M']=mp['N']=mp['O']=6,mp['P']=mp['R']=mp['E']=7,mp['T']=mp['U']=mp['V']=8,mp['W']=mp['X']=mp['Y']=9;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>str;
		a[i].len=0;
		for(int j=0;j<str.size();j++) if('A'<=str[j]<='Y') a[i].s[a[i].len++]=mp[str[j]];
	}
	for(int i=1;i<=n;i++){
		int ans=1,flag=1;
		for(int j=i+1;j<=n;j++){
			if(i==j) continue;
			for(int k=0;k<7;k++) if(a[i].s[k]!=a[j].s[k]){flag=0;break;} 
			if(flag) ans++;
		}
		if(ans>=2){
			for(int k=0;k<7;i++) {
				if(k==2) printf("%d-",a[i].s[k]);
				else printf("%d",a[i].s[k]);
			}
			printf("%d\n",ans);
			f=1;
		}
	}
	if(!f) */printf("No duplicates.\n");
	return 0;
}

