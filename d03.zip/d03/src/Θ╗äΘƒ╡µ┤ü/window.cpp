#include<cstdio>
#include<iostream>
#include<algorithm>
#include<set>
using namespace std;
#define ll long long
int n,k,a[100005],maxx=0,minn=0x7fffffff,mm[100005];
set<int>s;
set<int>::iterator it,ir;
int main(){
	freopen("window.in","r",stdin);freopen("window.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i+k-1<=n;i++){
		int j=i+k-1;
		if(j>n) break;
		for(int k=i;k<=j;k++) s.insert(a[k]);
		it=s.end();ir=s.begin();
		it--;
		if(*it>maxx) maxx=*it;
		if(*ir<minn) minn=*ir;
		printf("%d ",minn);
		mm[i]=maxx;
		s.clear();
	}
	printf("\n");
	for(int i=1;i+k-1<=n;i++) printf("%d ",mm[i]);
	printf("\n");
	return 0;
}

