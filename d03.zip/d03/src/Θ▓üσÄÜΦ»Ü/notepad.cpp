#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int n,ans,f;
char d[30]={'2','2','2','3','3','3','4','4','4','5','5','5','6','6','6','7','Q','7','7','8','8','8','9','9','9','Z'};
char b[100010][10];
string a[100010];
bool cmp(string x,string y){return x<y;}
int main()
{freopen("notepad.in","r",stdin);freopen("notepad.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++)
{cin>>b[i]+1;
 int m=strlen(b[i]+1);
 for(int j=1;j<=m;j++)
{if('0'<=b[i][j]&&b[i][j]<='9') a[i]+=b[i][j];
 else if('A'<=b[i][j]&&b[i][j]<='Z') a[i]+=d[b[i][j]-'A'];
}
}
 sort(a+1,a+n+1,cmp);ans=1;
 for(int i=2;i<=n;i++)
{if(a[i]!=a[i-1]&&ans>1)
{for(int j=0;j<7;j++)
{if(j==3) cout<<"-";
 cout<<a[i-1][j];
}
 cout<<" "<<ans<<endl;f=1;ans=0;
}
 else ans++;
}
 if(!f) cout<<"No duplicates."<<endl;
 return 0;
}
