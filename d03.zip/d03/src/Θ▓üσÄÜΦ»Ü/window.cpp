#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int n,k,a[1000010],mi,mx,h=1,t=1,b[1000010],c[1000010];
int main()
{freopen("window.in","r",stdin);freopen("window.out","w",stdout);
 cin>>n>>k;
 for(int i=1;i<=n;i++) cin>>a[i];
 mi=mx=a[1];
 for(int i=1;i<=n-k+1;i++)
{while(h<i) h++,mi=min(a[h],mi);mx=max(mx,a[h]);
 while(t-h+1<k){t++;mi=min(mi,a[t]);mx=max(mx,a[t]);}
 b[i]=mi;c[i]=mx;
}
 for(int i=1;i<=n-k+1;i++) cout<<b[i]<<" ";cout<<endl;
 for(int i=1;i<=n-k+1;i++) cout<<c[i]<<" ";cout<<endl;
 return 0;
}
