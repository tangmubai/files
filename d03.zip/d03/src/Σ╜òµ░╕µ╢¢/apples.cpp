#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int n,s,h,ans;
struct pg{
	int x,y,t;
}a[5005];
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
bool cmp(pg x,pg y){
	return x.t<y.t;
}
int main(){
	freopen("apples.in","r",stdin);
	freopen("apples.out","w",stdout);
	n=read();s=read();
	for(register int i=1;i<=n;i++){
		a[i].x=read();
		a[i].y=read();
		a[i].t=read();
	}
	sort(a+1,a+n+1,cmp);
	h=2;ans=1;
	while(h<=n){
		while(a[h].t==a[h-1].t&&h<=n) h++;
		if(h<=n) ans++,h++;
		else break;
	}
	printf("%d",ans);
	return 0;
}
