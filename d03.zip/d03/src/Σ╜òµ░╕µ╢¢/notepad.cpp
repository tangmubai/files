#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int n;char s[10005];
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;i++)
	scanf("%s",s);
	printf("No duplicates.");
	return 0;
}
