#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int a[1000005],b[1000005],c[1000005],n,k;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	n=read();k=read();
	for(register int i=1;i<=n;i++){
		a[i]=read();
		if(i==1){
			b[i]=a[i];c[i]=a[i];continue;
		}
		if(i<=k){
			b[i]=min(a[i],b[i-1]);
			c[i]=max(a[i],c[i-1]);
			continue;
		}
		if(a[i-k]==b[i-1]){
			b[i]=a[i];
			for(register int j=i-k+1;j<i;j++)
			b[i]=min(b[i],a[j]);
		}
		else if(a[i]<b[i-1]) b[i]=a[i];
		else b[i]=b[i-1];
		if(a[i-k]==c[i-1]){
			c[i]=a[i];
			for(register int j=i-k+1;j<i;j++)
			c[i]=max(c[i],a[j]);
		}
		else if(a[i]>c[i-1]) c[i]=a[i];
		else c[i]=c[i-1];
	}
	for(register int i=k;i<=n;i++)
	printf("%d ",b[i]);
	printf("\n");
	for(register int i=k;i<=n;i++)
	printf("%d ",c[i]);
	return 0;
}
