#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct q{
	char s1[50];
	char s2[50];
}a[100010];
bool cmp(q x,q y){
	for(int i=0;i<7;i++){
		if(x.s2[i]!=y.s2[i]) return x.s2[i]<y.s2[i];
	}
	return 1;
}
bool hrq2(int x,int y){
	for(int i=0;i<7;i++){
		if(a[x].s2[i]!=a[y].s2[i]) return 0;
	}
	return 1;
}
char hrq1(char c){
	if(c=='A'||c=='B'||c=='C') return '2';
	if(c=='D'||c=='E'||c=='F') return '3';
	if(c=='G'||c=='H'||c=='I') return '4';
	if(c=='J'||c=='K'||c=='L') return '5';
	if(c=='M'||c=='O'||c=='N') return '6';
	if(c=='P'||c=='R'||c=='S') return '7';
	if(c=='T'||c=='U'||c=='V') return '8';
	if(c=='W'||c=='X'||c=='Y') return '9';
}
void hrq(int x){
	int m=-1;
	for(int i=0;i<strlen(a[x].s1);i++){
		char c=a[x].s1[i];
		if(c<='9'&&c>='0'){
			if(m==2) a[x].s2[++m]='-';
			a[x].s2[++m]=a[x].s1[i];
		} 
		else if(c<='Z'&&c>='A'){
			if(m==2) a[x].s2[++m]='-';
			a[x].s2[++m]=hrq1(c);
		} 
	}
	return;
}
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%s",a[i].s1);
		for(int j=0;j<strlen(a[i].s1);j++)
			if(a[i].s1[j]>='a'&&a[i].s1[j]<='z') a[i].s1[j]=a[i].s1[j]-'a'+'A';
		hrq(i);
	}
	sort(a+1,a+1+n,cmp);
	int num=0;
	int cnt=1;
	for(int i=2;i<=n+1;i++){
	//	printf("%s %d\n",a[i-1].s2,cnt);
		if(hrq2(i-1,i)==1) cnt++;
		else{
			if(cnt!=1) printf("%s %d\n",a[i-1].s2,cnt);
			cnt=1;
			num++;
		}
	}
	if(num==n) printf("No duplicates\n");
	return 0;
}
