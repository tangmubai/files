#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
int a[1000010],minans[1000010],maxans[1000010];
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	int n,k;scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n-k+1;i++){
		minans[i]=1000010;
		for(int j=i;j<=i+k-1;j++){
			minans[i]=min(minans[i],a[j]);
			maxans[i]=max(maxans[i],a[j]);
		}
	}
	for(int i=1;i<=n-k+1;i++) printf("%d ",minans[i]);
	printf("\n");
	for(int i=1;i<=n-k+1;i++) printf("%d ",maxans[i]);
	return 0;
}
