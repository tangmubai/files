#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <map>
using namespace std;
const string val[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
map<char, int> mp;
int n, cnt;
bool ok;
string a[100005], tmp; 
char x[100005];
bool cmp(string a, string b)
{
	return a < b;
}
int main()
{
	freopen("notepad.in", "r", stdin);
	freopen("notepad.out", "w", stdout);
	mp['0'] = 0; mp['1'] = 1;
	mp['2'] = mp['A'] = mp['B'] = mp['C'] = 2;
	mp['3'] = mp['D'] = mp['E'] = mp['F'] = 3;
	mp['4'] = mp['G'] = mp['H'] = mp['I'] = 4;
	mp['5'] = mp['J'] = mp['K'] = mp['L'] = 5;
	mp['6'] = mp['M'] = mp['N'] = mp['O'] = 6;
	mp['7'] = mp['P'] = mp['R'] = mp['S'] = 7;
	mp['8'] = mp['T'] = mp['U'] = mp['V'] = 8;
	mp['9'] = mp['W'] = mp['X'] = mp['Y'] = 9;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		scanf("%s", x);
		cnt = 0;
		for (int j = 0; x[j]; j++)
		{
			if (x[j] == 'Q' || x[j] == 'Z') continue;
			if (x[j] >= '0' && x[j] <= '9') a[i] = a[i] + val[mp[x[j]]], cnt++;
			else
			{
				if (x[j] >= 'A' && x[j] <= 'Z')
				{
					a[i] = a[i] + val[mp[x[j]]], cnt++;
				}
			}
		}
//		if (cnt == 3) a[i] = a[i] + '-';
//		cout << cnt << endl;
	}
	sort(a + 1, a + 1 + n, cmp);
	tmp = a[1]; 
	cnt = 1;
	for (int i = 2; i <= n; i++)
	{
		if (a[i] == tmp) cnt++;
		else
		{
			if (cnt > 1)
			{
				ok = true;
				for (int i = 0; i < 3; i++) cout << tmp[i];
				cout << '-';
				for (int i = 3; i < 7; i++) cout << tmp[i];
				printf(" %d\n", cnt);
			}
			cnt = 1;
			tmp = a[i];
		}
	}
	if (cnt > 1)
	{
		ok = true;
		cout << tmp;
		printf(" %d\n", cnt);
	}
	if (!ok) puts("No duplicates.");
	return 0;
}

