#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <queue>
using namespace std;
int n, k, a[100005], Mn[100005], Mx[100005];
struct Node
{
	int val, id;
};
deque<Node> Q1;
deque<Node> Q2;
void read(int &x)
{
	char c = getchar(); int f = 1;
	while (c < '0' || c > '9') { if (c == '-') f = -1; c = getchar(); }
	while (c >= '0' && c <= '9') { x = x * 10 + c - '0'; c = getchar(); }
	x *= f;
}
int main()
{
	freopen("window.in", "r", stdin);
	freopen("window.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
	for (int i = 1; i <= n; i++)
	{
		while(!Q1.empty() && Q1.back().val <= a[i]) Q1.pop_back();
		while(!Q2.empty() && i - Q1.front().id >= k) Q2.pop_front();
		while(!Q1.empty() && Q1.back().val >= a[i]) Q1.pop_back();
		while(!Q2.empty() && i - Q2.front().id >= k) Q2.pop_front();
		Q1.push_back((Node){a[i], i});
		Q2.push_back((Node){a[i], i});
		if (i >= k)
		{
			Mn[i] = Q2.front().val;
			Mx[i] = Q1.front().val;
		}
	}
	for (int i = k; i <= n; i++) printf("%d ", Mn[i]);
	puts("");
	for (int i = k; i <= n; i++) printf("%d ", Mx[i]);
	return 0;
}

