#include<map>
#include<stdio.h>
#include<iostream>
#include<algorithm>
const int N = 100000; 
using namespace std;

int n, num[N + 5];
char s[N + 5][50]; 
map<int, int> mp; 

struct Node{
	int tp;
	int cnt;
}a[N + 5];
int tot;

bool cmp(Node p, Node q) {
	return p.tp < q.tp;
}

int Get(char x) {
	if (x >= '0' && x <= '9')
		return x - '0';
	if (x == 'A' || x == 'B' || x == 'C')
		return 2;
	if (x == 'D' || x == 'E' || x == 'F')
		return 3;
	if (x == 'G' || x == 'H' || x == 'I')
		return 4;
	if (x == 'J' || x == 'K' || x == 'L')
		return 5;
	if (x == 'M' || x == 'N' || x == 'Q')
		return 6;
	if (x == 'P' || x == 'R' || x == 'S')
		return 7;
	if (x == 'T' || x == 'U' || x == 'V')
		return 8;
	if (x == 'W' || x == 'X' || x == 'Y')
		return 9;							
}

void Print(int x, int p) {
	if (p == 3)
		printf("-");
	Print(x / 10, p + 1);
	printf("%d", x % 10);	
}  

int main() {
	freopen("notepad.in", "r", stdin);
	freopen("notepad.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i) {
		scanf("%s", s[i] + 1);
		num[i] = 0;
		for(int j = 0; s[j]; ++j)
			if (s[i][j] != '-') 
				num[i] = num[i] * 10 + Get(s[i][j]);
		mp[num[i]]++;		
	}
	for(int i = 1; i <= n; ++i) {
		if (mp[num[i]]) {
			a[++tot].tp = num[i];
			a[++tot].cnt = mp[num[i]];
			mp[num[i]] = 0; 
		}
	}
	if (tot == 0) {
		puts("No duplicates.");
		return 0;
	}
	sort(a + 1,a + tot + 1, cmp);
	for(int i = 1; i <= tot; ++i) {
		Print(a[i].tp, 1);
		printf(" %d\n", a[i].cnt);
	}
	return 0;
}
