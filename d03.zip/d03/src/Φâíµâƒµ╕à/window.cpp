#include<stdio.h>
#include<string.h>
const int N = 1000000, LogN = 20;

int n, m, a[N + 5], f[N + 5][LogN];
int log[N + 5];

void read(int &x) {
	x = 0; char c = getchar();int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x =  x * 10 + c - '0';
	x *= w;	  		
}

int max(int x, int y) {
	if (x > y)
		return x;
	else return y;	
}
int min(int x, int y) {
	if (x < y)
		return x;
	else return y;	
}

int main() {
	freopen("window.in", "r", stdin);
	freopen("window.out", "w", stdout);
	memset(f, 0x3f, sizeof(f));
	read(n);read(m);
	log[0] = -1;
	for(int i = 1; i <= n; ++i) {
		read(a[i]);
		log[i] = log[i / 2] + 1;
		f[i][0] = a[i];
	}
	for(int j = 1; j <= log[n] + 1; ++j)
		for(int i = 1; i <= n; ++i)
			f[i][j] = min(f[i][j - 1], f[i + (1 << (j - 1))][j - 1]);
 	
	for(int i = 1; i <= n - m + 1; ++i) {
		int x = i, y = i + m - 1;
		int l = log[y - x + 1];
		printf("%d ", min(f[x][l], f[y - (1 << l) + 1][l])); 
	}			
	puts("");
	memset(f, -0x3f, sizeof(f));
	for(int i = 1; i <= n; ++i)
		f[i][0] = a[i];
	for(int j = 1; j <= log[n] + 1; ++j)
		for(int i = 1; i <= n; ++i)
			f[i][j] = max(f[i][j - 1], f[i + (1 << (j - 1))][j - 1]);
 	
	for(int i = 1; i <= n - m + 1; ++i) {
		int x = i, y = i + m - 1;
		int l = log[y - x + 1];
		printf("%d ", max(f[x][l], f[y - (1 << l) + 1][l])); 
	}
	return 0;	
}
