#include <stdio.h>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
int n,x[100005][15],y[100005],ans;
char a[100005][15];
map <int, int>mp,vis;
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>a[i];
		int len=strlen(a[i]);
		for(int j=0;j<=len-1;j++){
			if(a[i][j]>='0'&&a[i][j]<='9')
				x[i][++x[i][0]]=a[i][j]-'0';
			if(a[i][j]>='A'&&a[i][j]<='C')
				x[i][++x[i][0]]=2;
			if(a[i][j]>='D'&&a[i][j]<='F')
				x[i][++x[i][0]]=3;
			if(a[i][j]>='G'&&a[i][j]<='I')
				x[i][++x[i][0]]=4;
			if(a[i][j]>='J'&&a[i][j]<='L')
				x[i][++x[i][0]]=5;
			if(a[i][j]>='M'&&a[i][j]<='O')
				x[i][++x[i][0]]=6;
			if(a[i][j]=='P'||a[i][j]=='R'||a[i][j]=='S')
				x[i][++x[i][0]]=7;
			if(a[i][j]>='T'&&a[i][j]<='V')
				x[i][++x[i][0]]=8;
			if(a[i][j]>='W'&&a[i][j]<='Y')
				x[i][++x[i][0]]=9;
		}
	}
	for(int i=1;i<=n;i++){
		int tmp=0;
		for(int j=1;j<=x[i][0];j++)
			tmp=tmp*10+x[i][j];	
		mp[tmp]++;
		y[++ans]=tmp;
	}
	sort(y+1,y+1+ans);
	bool flag=0;
	for(int i=1;i<=ans;i++)
		if(mp[y[i]]>1&&!vis[y[i]]){
			flag=1;
			vis[y[i]]=1;
			printf("%d-%d %d\n",y[i]/10000,y[i]%10000,mp[y[i]]);
		}
	if(flag==0)printf("No duplicates.");
	return 0;
}
