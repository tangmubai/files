#include <stdio.h>
int n,k,a[1000005],mx[1000005],mn[1000005];
int Max(int a,int b){
	if(a>b)return a;
	else return b;
}
int Min(int a,int b){
	if(a<b)return a;
	else return b;
}
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		mx[i]=-99999999,mn[i]=99999999;
		for(int j=i;j<=i+k-1;j++){
			mx[i]=Max(mx[i],a[j]);
			mn[i]=Min(mn[i],a[j]);
		}
	}
	for(int i=1;i<=n-k+1;i++)
		printf("%d ",mn[i]);
	printf("\n");
	for(int i=1;i<=n-k+1;i++)
		printf("%d ",mx[i]);
	return 0;
}
