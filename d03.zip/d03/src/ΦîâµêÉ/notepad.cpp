#include <map>
#include <cstdio>
#include <cctype>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
char str[258];
map<int,int> mp;
int a[255];
int main(){
    frin("notepad.in");frout("notepad.out");
    int n;scanf("%d",&n);
    int cnt=0;
    for(int i='A';i<='Z';++i){
    	if(i=='Q'||i=='Z') continue;
    	a[i]=cnt/3+2;
    	++cnt;
    }
    for(int i=1;i<=n;++i){
        scanf("%s",str);
        int x=0;
        for(int j=0;str[j];++j){
            if(str[j]=='-') continue;
            if(isdigit(str[j])) x=x*10+(str[j]-'0');
            else x=x*10+a[str[j]];
        }
        if(mp.count(x)==0) mp[x]=1;
        else ++mp[x];
    }
    bool flag=true;
    map<int,int>::iterator it=mp.begin();
    while(it!=mp.end()){
        if(it->second>1){
            printf("%d-%d %d\n",it->first/10000,it->first%10000,it->second);
            flag=false;
        }
        ++it;
    }
    if(flag) puts("No duplicates.");
    return 0;
}
