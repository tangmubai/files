#include <cstdio>
#include <queue>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
deque<int> q1,q2;
template<typename _tp>
inline void in(_tp &x){
    x=0;int w=0;char c=getchar();
    for(;c<'0'||c>'9';w|=c=='-',c=getchar());
    for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
    if(w) x=-x;
}
int a[1000005];
int main(){
    frin("window.in");frout("window.out");
    int n,k;in(n);in(k);
    for(int i=1;i<=n;++i) in(a[i]);
    for(int i=1;i<k;++i){
        while(!q1.empty()&&a[q1.back()]>=a[i]) q1.pop_back();
        q1.push_back(i);
        while(!q2.empty()&&a[q2.back()]<=a[i]) q2.pop_back();
        q2.push_back(i);
    }
    for(int i=k;i<=n;++i){
        while(!q1.empty()&&a[q1.back()]>=a[i]) q1.pop_back();
        q1.push_back(i);
        if(q1.front()<i-k+1) q1.pop_front();
        printf("%d ",a[q1.front()]);
    }
    puts("");
    for(int i=k;i<=n;++i){
        while(!q2.empty()&&a[q2.back()]<=a[i]) q2.pop_back();
        q2.push_back(i);
        if(q2.front()<i-k+1) q2.pop_front();
        printf("%d ",a[q2.front()]);
    }
    return 0;
}
