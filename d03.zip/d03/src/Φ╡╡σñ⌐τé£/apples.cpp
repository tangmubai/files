#include <cstdio>
#include <cmath>
#include <string>
#include <cstring>
#include <iostream>
#include <vector>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
double getdis (int x1, int x2, int y1, int y2) {
	return sqrt ((double)(x1 - x2) * (x1 - x2) + (double)(y1 - y2) * (y1 - y2));
}
int n, m;
int x[5005], y[5005], f[5005];
int mem[5005];
int search (int step, int tim) {
	if (mem[step] != -1)
		return mem[step];
	int res = 0;
	for (int i = 1; i <= n; i ++) {
		if (i != step && (f[i] - f[step]) * m >= ((int)getdis(x[step], x[i], y[step], y[i])) + 1) {
			res = max (res, search (i, f[i]) + 1);
		}
	}
	return mem[step] = res;
}
int main () {
	freopen ("apples.in", "r", stdin);
	freopen ("apples.out", "w", stdout);
	
	memset (mem, -1, sizeof(mem));
	n = read(), m = read();
	for (int i = 1; i <= n; i ++)
		x[i] = read(), y[i] = read(), f[i] = read();
	int ans = search (0, 0);
	printf ("%d", ans);
}

