#include <cstdio>
#include <cmath>
#include <string>
#include <algorithm>
#include <iostream>
#include <map>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
map <string, int> m;
int n;
char f[][4] = {
	{0, 0, 0},
	{0, 0, 0},
	{'A', 'B', 'C'},
	{'D', 'E', 'F'},
	{'G', 'H', 'I'},
	{'J', 'K', 'L'},
	{'M', 'N', 'O'},
	{'P', 'R', 'S'},
	{'T', 'U', 'V'},
	{'W', 'X', 'Y'}
};
string calc (string x) {
	string ans;
	string t;
	for (int i = 0; x[i]; i ++)
		if (x[i] != '-')
			t += x[i];
	x = t;
	for (int i = 0; i < 3; i ++) {
		if ('0' <= x[i] && x[i] <= '9')
			ans += x[i];
		else
		for (int j = 2; j <= 9; j ++) {
			for (int k = 0; k < 3; k ++)
				if (x[i] == f[j][k])
					ans += (j + '0');
		}
	}
	ans += '-';
	for (int i = 3; i < 7; i ++) {
		if ('0' <= x[i] && x[i] <= '9')
			ans += x[i];
		else
		for (int j = 2; j <= 9; j ++) {
			for (int k = 0; k < 3; k ++)
				if (x[i] == f[j][k])
					ans += (j + '0');
		}
	}
	return ans;		
}
string l[2580];
int cnt;
int main () {
	freopen ("notepad.in", "r", stdin);
	freopen ("notepad.out", "w", stdout);
	cin >> n;
	for (int i = 1; i <= n; i ++) {
		string q;
		cin >> q;
		string j = calc (q);
//		cout << '*' << j << '\n';
		if (++ m[j] == 2) {
			l[++ cnt] = j;
		}
	}
	sort (l + 1, l + cnt + 1);
	for (int i = 1; i <= cnt; i ++) {
		cout << l[i] << ' ' << m[l[i]] << '\n';
	}
}

