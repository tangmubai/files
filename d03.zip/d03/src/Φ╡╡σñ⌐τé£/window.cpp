#include <cstdio>
#include <cmath>
#include <deque>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
struct node {
	int id;
	int val;
};
deque <node> dq;
int n, m;
int a[1000005];
int main () {
	freopen ("window.in", "r", stdin);
	freopen ("window.out", "w", stdout);
	n = read(), m = read();
	for (int i = 1; i <= n; i ++)
		a[i] = read();
	for (int i = 1; i <= n; i ++) {
		while (!dq.empty() && dq.back().val >= a[i])
			dq.pop_back ();
		dq.push_back ((node){i, a[i]});
		if (i >= m)
			printf ("%d ", dq.front().val);
		while (dq.front().id <= i - m + 1)
			dq.pop_front ();
	}
	puts("");
	dq.clear()
;	for (int i = 1; i <= n; i ++) {
		while (!dq.empty() && dq.back().val <= a[i])
			dq.pop_back ();
		dq.push_back ((node){i, a[i]});
		if (i >= m)
			printf ("%d ", dq.front().val);
		while (dq.front().id <= i - m + 1)
			dq.pop_front ();
	}
}

