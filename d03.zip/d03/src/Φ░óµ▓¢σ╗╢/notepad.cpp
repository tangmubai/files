#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<map>
#include<algorithm>
#define ll register int

using namespace std;
int cha[200]={0};
string s[100005],c;
map<string,int>mp;
map<string,bool>vis;
bool cmp(string a,string b){
	for(ll i=0;i<=2;i++)if(a[i]!=b[i])return a[i]<b[i];
	for(ll i=4;i<=7;i++)if(a[i]!=b[i])return a[i]<b[i];
	return false;
}
int main(){freopen("notepad.in","r",stdin);freopen("notepad.out","w",stdout);
	ll n,j,p;
	cha['A']=cha['B']=cha['C']=2;
	cha['D']=cha['E']=cha['F']=3;
	cha['G']=cha['H']=cha['I']=4;
	cha['J']=cha['K']=cha['L']=5;
	cha['M']=cha['N']=cha['O']=6;
	cha['P']=cha['R']=cha['S']=7;
	cha['T']=cha['U']=cha['V']=8;
	cha['W']=cha['X']=cha['Y']=9;
	scanf("%d\n",&n);
	for(ll i=1;i<=n;i++){
		cin>>c;
		for(j=0,p=0;j<=c.length(),p!=3;j++){
			if(c[j]=='-')continue;
			if(c[j]>='0'&&c[j]<='9')s[i]+=c[j],p++;
			if(c[j]>='A'&&c[j]<='Y')s[i]+=cha[c[j]]+'0',p++;
		}s[i]+="-";
		for(ll p=0;j<=c.length(),p!=4;j++){
			if(c[j]=='-')continue;
			if(c[j]>='0'&&c[j]<='9')s[i]+=c[j],p++;
			if(c[j]>='A'&&c[j]<='Y')s[i]+=cha[c[j]]+'0',p++;
		}
		mp[s[i]]++;
		//cout<<s[i]<<endl; 
	}
	bool ok=0;
	sort(s+1,s+1+n,cmp);
	for(ll i=1;i<=n;i++){
		if(vis[s[i]]==0&&mp[s[i]]>=2){
			cout<<s[i]<<" "<<mp[s[i]]<<endl;
			vis[s[i]]=1;
			ok=1;
		}
	}
	if(!ok)printf("No duplicates.");
	return 0;
}
