#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#define ll register int

using namespace std;
int a[1000005]={0};
int front=1,rear=1;
int n,k;
struct node{
	int d,int num;
}aa[1000005];
int main(){//freopen("window.in","r",stdin);freopen("window.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(ll i=1;i<=n;i++)scnaf("%d",&a[i]);
	printf("%d ",a[1]);
	aa[front++]=a[1];
	for(ll i=2;i<=n;i++){
		while(front!=rear&&a[i]<=aa[front].num)front--;
		aa[front++].num=a[i],aa[front-1].d=i;
		while(front!=top&&aa[rear].d<i-k+1)rear++;
		printf("%d ",&aa[rear].num);
		
	}
	return 0;
}
