#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<map>
using namespace std;
int a[30]={2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,0,7,7,8,8,8,9,9,9};
char s[1000005];
map<int,int> b;
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	int n,i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%s",s);
		int k=0;
		for(j=0;s[j];j++){
			if((s[j]>='0'&&s[j]<='9')){
				k=k*10+s[j]-'0';
			}
			if(s[j]>='A'&&s[j]<='Z'){
				k=k*10+a[s[j]-'A'];
			}
		}
		b[k]++;
	}
	map<int,int>::iterator it;
	int flag=0;
	for(it=b.begin();it!=b.end();it++){
		if(it->second>1){
			int now=it->first,len=4;
			int s2[6]={0};
			for(j=1;j<=4;j++){
				s2[len--]=now%10;
				now/=10;
			}
			printf("%d-",now);
			for(j=1;j<=4;j++){
				printf("%d",s2[i]);
			}
			printf(" %d\n",it->second);
			flag=1;
		}
	}
	if(flag==0)printf("No duplicates.");
	return 0;
}
