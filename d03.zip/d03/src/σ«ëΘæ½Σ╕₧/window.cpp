#include<stdio.h>
#include<set>
using namespace std;
set<int> a;
int c[1000005],b[1000005];
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	int n,k,i;
	scanf("%d%d",&n,&k);
	for(i=1;i<k;i++){
		scanf("%d",&c[i]);
		a.insert(c[i]);
	}
	for(i=k;i<=n;i++){
		scanf("%d",&c[i]);
		a.insert(c[i]);
		set<int>::iterator it=a.begin();
		printf("%d ",*it);
		it=a.end();it--;
		b[i]=*it;
		a.erase(c[i-k+1]);
	}
	printf("\n");
	for(i=k;i<=n;i++){
		printf("%d ",b[i]);
	}
	return 0;
}
