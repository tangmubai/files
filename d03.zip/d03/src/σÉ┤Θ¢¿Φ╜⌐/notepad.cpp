#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
#include<map>
using namespace std;
map<char,int> w;
int n,a[100005],ans[100005];
int t[10000005],tt[10000005];
char s[1005];
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	w['A']=w['B']=w['C']=2;	w['D']=w['E']=w['F']=3;w['G']=w['H']=w['I']=4;w['J']=w['K']=w['L']=5;
	w['M']=w['N']=w['O']=6;	w['P']=w['R']=w['S']=7;w['T']=w['U']=w['V']=8;w['W']=w['X']=w['Y']=9;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%s",s);
		for(int j=strlen(s)-1,k=1;j>=0;j--){
			if(s[j]!='-'&&s[j]!='Q'&&s[j]!='Z'){
				if(s[j]>='A'&&s[j]<='Z')a[i]+=k*w[s[j]];
				else a[i]+=(s[j]-'0')*k;
				k*=10;
			}
		}
		t[a[i]]++;
	}
	sort(a+1,a+1+n);
	int ok=0;
	for(int i=1;i<=n;i++){
		if(t[a[i]]>1){
			ok=1;
			if(tt[a[i]]==0){
				tt[a[i]]=1;
				printf("%d-%d %d\n",a[i]/10000,a[i]%10000,t[a[i]]);
			}
		}
	}
	if(ok==0)printf("No duplicates.");
	return 0;
}
