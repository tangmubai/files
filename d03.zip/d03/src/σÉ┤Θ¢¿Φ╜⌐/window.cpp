#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
int n,k,a[1000005];
int maxa[1000005],mina[1000005],len;
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	int maxn,minn;
	for(int i=1;i<=n;i++){
		maxn=-1000001,minn=1000001;
		if(i+k-1>n)break;
		for(int j=i;j<=i+k-1;j++)
			maxn=max(maxn,a[j]),minn=min(minn,a[j]);
		maxa[++len]=maxn;mina[len]=minn;
	}
	for(int i=1;i<=len;i++)printf("%d ",mina[i]);
	printf("\n");
	for(int i=1;i<=len;i++)printf("%d ",maxa[i]);
	return 0;
}
