#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdio>
#define ll long long
using namespace std;

int main()
{
	freopen("apples.in","r",stdin);
	freopen("apples.out","w",stdout);
	ios::sync_with_stdio(false);
	return 0;
}

