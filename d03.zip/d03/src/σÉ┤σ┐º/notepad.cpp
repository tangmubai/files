#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdio>
#define ll long long
#include<map>
using namespace std;
string cl(string s)
{
	string ss="";
	int k=0,flag=0;
	for(int i=0;i<s.size();i++)
	{
		if(k==3 && flag==0)
		{
			ss+='-';
			flag=1;
		}
		if(s[i]=='A' || s[i]=='B' || s[i]=='C')
		{
			ss+=(char)(48+2);
			k++;
		}
		if(s[i]=='D' || s[i]=='E' || s[i]=='F')
		{
			ss+=(char)(48+3);
			k++;
		}
		if(s[i]=='G' || s[i]=='H' || s[i]=='I')
		{
			ss+=(char)(48+4);
			k++;
		}
		if(s[i]=='J' || s[i]=='K' || s[i]=='L')
		{
			ss+=(char)(48+5);
			k++;
		}
		if(s[i]=='M' || s[i]=='N' || s[i]=='O')
		{
			ss+=(char)(48+6);
			k++;
		}
		if(s[i]=='P' || s[i]=='R' || s[i]=='S')
		{
			ss+=(char)(48+7);
			k++;
		}
		if(s[i]=='T' || s[i]=='U' || s[i]=='V')
		{
			ss+=(char)(48+8);
			k++;
		}
		if(s[i]=='W' || s[i]=='X' || s[i]=='Y')
		{
			ss+=(char)(48+9);
			k++;
		}
		if(s[i]>='0' && s[i]<='9')
		{
			ss+=s[i];
			k++;
		}
	}
	return ss;
}
int n;
string s,ss;
map<string,int> mp;
map<string,int> ::iterator it;
int main()
{
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		ss=cl(s);
		mp[ss]++;
	}
	if(mp.size()==0)
	{
		printf("No duplicates.\n");
	}
	else
	{
		for(it=mp.begin();it!=mp.end();it++)
		{
			if((it->second)>1)
			cout<<(it->first)<<" "<<(it->second)<<endl;
		}
	}
	return 0;
}

