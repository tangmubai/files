#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdio>
#include<set>
#define ll long long
using namespace std;
inline int read()
{
	int s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
int n,a[11000000],k;
set<int> b;
set<int> ::iterator it;
int num[11000000],cnt;
int main()
{
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	ios::sync_with_stdio(false);
	n=read();
	k=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	for(int i=1;i<=k;i++)
	{
		b.insert(a[i]);
	}
	for(int i=k+1;i<=n+1;i++)
	{
		printf("%d ",*(b.begin()));
		it=b.end();
		it--;
		num[++cnt]=*(it);
		b.insert(a[i]);
		b.erase(a[i-k]);
	}
	printf("\n");
	for(int i=1;i<=cnt;i++)
	{
		printf("%d ",num[i]);
	}
	return 0;
}

