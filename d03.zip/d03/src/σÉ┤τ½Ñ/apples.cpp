#include<stdio.h>
#include<algorithm>
#define N 5001
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register bool t=0;register char c=nc();for(;c<'0'||'9'<c;t|=c=='-',c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());if(t)x=-x;
}
struct node
{
	int x,y,t;
	inline void in(){read(x);read(y);read(t);}
	inline bool operator<(const node&kkk)const{return t<kkk.t;}
}a[N];
int n,s,ans[N];
inline int dis(const int&x1,const int&y1,const int&x2,const int&y2)
	{return(x1<x2?x2-x1:x1-x2)+(y1<y2?y2-y1:y1-y2);}
main()
{
	freopen("apples.in","r",stdin);freopen("apples.out","w",stdout);
	register int n,s,maxn=0;
	read(n);read(s);for(register int i=1;i<=n;a[i++].in());
	std::sort(a+1,a+1+n);
	for(register int i=1;i<=n;++i)
	{
		ans[i]=-n;
		for(register int j=0;j<i;++j)
			if(ans[j]+1>ans[i]&&dis(a[i].x,a[i].y,a[j].x,a[j].y)<=(a[i].t-a[j].t)*s)
				ans[i]=ans[j]+1;
		if(ans[i]>maxn)maxn=ans[i];
	}
	printf("%d",maxn);
}
