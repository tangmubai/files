#include<stdio.h>
#include<map>
using std::map;
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
main()
{
	freopen("notepad.in","r",stdin);freopen("notepad.out","w",stdout);
	register int get[128]={},n,x;register char in;
	register bool ok=1;register map<int,int>mmp;
	get['0']=0;
	get['1']=1;
	get['2']=get['A']=get['B']=get['C']=2;
	get['3']=get['D']=get['E']=get['F']=3;
	get['4']=get['G']=get['H']=get['I']=4;
	get['5']=get['J']=get['K']=get['L']=5;
	get['6']=get['M']=get['N']=get['O']=6;
	get['7']=get['P']=get['R']=get['S']=7;
	get['8']=get['T']=get['U']=get['V']=8;
	get['9']=get['W']=get['X']=get['Y']=9;
	for(read(n);n--;++mmp[x])
	{
		x=0;
		for(register int i=7;i--;)
		{
			for(;in=nc(),(in<'0'||'9'<in)&&(in<'A'||'Z'<in););
			x=(x<<3)+(x<<1)+get[in];
		}
	}
 	for(register map<int,int>::iterator it=mmp.begin();it!=mmp.end();++it)
		if(it->second>1)
		{
			ok=0;
			printf("%03d-%04d %d\n",it->first/10000,it->first%10000,it->second);
		}
	if(ok)puts("No duplicates.");
}
