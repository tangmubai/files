#include<stdio.h>
#define N 1000000
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register bool t=0;register char c=nc();for(;c<'0'||'9'<c;t|=c=='-',c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());if(t)x=-x;
}
int n,k,a[N],q[N],l,r;
main()
{
	freopen("window.in","r",stdin);freopen("window.out","w",stdout);
	read(n);read(k);for(register int i=0;i<n;read(a[i++]));
	l=r=0;
	for(register int i=0;i<k-1;++i)
	{
		for(;l<r&&a[q[r-1]]>=a[i];--r);
		q[r++]=i;
	}
	for(register int i=k-1;i<n;++i)
	{
		if(q[l]+k==i)++l;
		for(;l<r&&a[q[r-1]]>=a[i];--r);
		q[r++]=i;
		printf("%d ",a[q[l]]);
	}
	putchar('\n');
	l=r=0;
	for(register int i=0;i<k-1;++i)
	{
		for(;l<r&&a[q[r-1]]<=a[i];--r);
		q[r++]=i;
	}
	for(register int i=k-1;i<n;++i)
	{
		if(q[l]+k==i)++l;
		for(;l<r&&a[q[r-1]]<=a[i];--r);
		q[r++]=i;
		printf("%d ",a[q[l]]);
	}
}
