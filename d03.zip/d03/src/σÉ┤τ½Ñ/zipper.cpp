#include<stdio.h>
#include<string.h>
#define N 222
char a[N],b[N],c[N<<1];bool ans[N][N];
main()
{
	freopen("zipper.in","r",stdin);freopen("zipper.out","w",stdout);
	register int t,n,m;
	scanf("%d",&t);
	for(register int cases=1;cases<=t;++cases)
	{
		printf("Data set %d: ",cases);
		scanf("%s%s%s",a+1,b+1,c+1);
		memset(ans,0,sizeof(ans));ans[0][0]=1;n=strlen(a);m=strlen(b);
		for(register int i=0;i<=n;++i)for(register int j=0;j<=m;++j)if(i||j)
		{
			if(i&&c[i+j]==a[i])ans[i][j]|=ans[i-1][j];
			if(j&&c[i+j]==b[j])ans[i][j]|=ans[i][j-1];
		}
		puts(ans[n][m]?"yes":"no");
	}
}
