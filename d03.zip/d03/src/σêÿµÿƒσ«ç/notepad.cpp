#include <cstdio>
#include <algorithm>
using namespace std;

char s[100005], map[105];
int t[10000000], a[100005], top;

void Y()
{
	map['A'] = map['B'] = map['C'] = 2;
	map['D'] = map['E'] = map['F'] = 3;
	map['G'] = map['H'] = map['I'] = 4;
	map['J'] = map['K'] = map['L'] = 5;
	map['M'] = map['N'] = map['O'] = 6;
	map['P'] = map['R'] = map['S'] = 7;
	map['T'] = map['U'] = map['V'] = 8;
	map['W'] = map['X'] = map['Y'] = 9;
}

int main()
{
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	int n;
	Y();
	scanf("%d", &n);
	for (int p = 1; p <= n; p++)
	{
		scanf("%s", s + 1);
		int k[8], tot = 0;
		for (int i = 1; s[i]; i++)
		{
			if (s[i] != '-' && s[i] != 'Q' && s[i] != 'Z')
			{
				if (s[i] >= 'A' && s[i] <= 'Z')
				{
					k[++tot] = map[s[i]];
//					printf("%d ", map[s[i]]);
//					printf("%d\n", k[tot]);
				}
				else
				{
					k[++tot] = s[i] - '0';
				}
			}
		}
		int num = 0;
		for (int i = 1; i <= 7; i++)
			num = num * 10 + k[i];
		if (!t[num])
			a[++top] = num;
		t[num]++;
	}
	sort(a + 1, a + 1 + top);
	bool ok = false;
	for (int i = 1; i <= top; i++)
	{
		if (t[a[i]] > 1)
		{
			ok = true;
			int o = a[i];
			int p = 0, ans[8];
			while (a[i] > 0)
			{
				ans[++p] = a[i] % 10;
				a[i] /= 10;
			}
			for (int j = 7; j >= 5; j--)
				printf("%d", ans[j]);
			printf("-");
			for (int j = 4; j >= 1; j--)
				printf("%d", ans[j]);
			printf(" %d", t[o]);
			printf("\n");
		}
	}
	if (ok == false)
		printf("No duplicates.\n");
	return 0;
}
