#include <stdio.h>
int main(void) {
	freopen("apples.in", "r", stdin);
	freopen("apples.out", "w", stdout);
	return 0;
}
