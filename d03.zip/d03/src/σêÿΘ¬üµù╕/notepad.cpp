#include <iostream>
#include <string>
const int w[] = {2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 0, 7, 7, 8, 8, 8, 9, 9, 9, 0};
using namespace std;
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 1; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w *= -1;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
}
int n;
//map<string, int>
int main(void) {
	freopen("notepad.in", "r", stdin);
	freopen("notepad.out", "w", stdout);
//	read(n);
//	string s;
//	for (int i = 1; i <= n; ++i) {
//		
//	}
	return 0;
}
