#include <stdio.h>
int n, k, a[1000005], maxans[1000005], minans[1000005];
int q[1000005], front, back;
int main(void) {
	freopen("window.in", "r", stdin);
	freopen("window.out", "w", stdout);
	scanf("%d %d", &n, &k);
	for (int i = 1; i <= n; ++i)
		scanf("%d", &a[i]);
	for (int i = k; i <= n; ++i) {
		maxans[i] = 0; minans[i] = 0x3f3f3f3f;
		for (int j = i - k + 1; j <= i; ++j) {
			maxans[i] = a[j] > maxans[i] ? a[j] : maxans[i];
			minans[i] = a[j] < minans[i] ? a[j] : minans[i];
		}
	}
	for (int i = k; i <= n; ++i)
		printf("%d ", minans[i]);
	puts("");
	for (int i = k; i <= n; ++i)
		printf("%d ", maxans[i]);
	puts("");
	return 0;
}
