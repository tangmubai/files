#include <stdio.h>
int main(void) {
	freopen("zipper.in", "r", stdin);
	freopen("zipper.out", "w", stdout);
	return 0;
}
