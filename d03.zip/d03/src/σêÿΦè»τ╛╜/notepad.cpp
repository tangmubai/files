#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
map<char,int> mp;
int main()
{
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	mp['A']=1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		cin>>a;
	}
}
