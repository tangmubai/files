#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e6+5;
int n,m;
int a[N],ans1[N],ans2[N];
int main()
{
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n-m+1;i++)
	{
		ans1[i]=ans2[i]=a[i];
		for(int j=1;j<m;j++)
		{
			ans1[i]=min(ans1[i],a[i+j]);
			ans2[i]=max(ans2[i],a[i+j]);
		}
	}
	for(int i=1;i<=n-m+1;i++)
	{
		printf("%d ",ans1[i]);
	}
	puts(" ");
	for(int i=1;i<=n-m+1;i++)
	{
		printf("%d ",ans2[i]);
	}
	return 0;
}

