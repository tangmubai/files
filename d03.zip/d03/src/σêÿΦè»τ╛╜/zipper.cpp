#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int t,m1,m2,m3,j,tmp;
char a[N],b[N],c[N];
int ok[N];
int main()
{
	freopen("zipper.in","r",stdin);
	freopen("zipper.out","w",stdout);
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		printf("Data set %d: ",i);
		scanf("%s",a+1);
		m1=strlen(a+1);
		scanf("%s",b+1);
		m2=strlen(b+1);
		scanf("%s",c+1);
		m3=strlen(c+1);
		if(m1+m2!=m3) 
		{
			printf("no");
			continue;
		}
		j=1;
		tmp=0;
		memset(ok,0,sizeof(ok));
		for(int k=1;k<=m3&&j<=m1;k++)
		{
			if(a[j]==c[k])
			{
				ok[k]=1;
				j++;
			}
		}
		j=1;
		for(int k=1;k<=m3&&j<=m2;k++)
		{
			if(b[j]!=c[k]&&!ok[k]) 
			{
				tmp=1;
				break;
			}
			else if(b[j]==c[k]&&!ok[k]) j++;
		}
		if(tmp==0) printf("yes");
		else
		{
			j=1;
			tmp=0;
			memset(ok,0,sizeof(ok));
			for(int k=1;k<=m3&&j<=m2;k++)
			{
				if(b[j]==c[k])
				{
					ok[k]=1;
					j++;
				}
			}
			j=1;
			for(int k=1;k<=m3&&j<=m1;k++)
			{
				if(a[j]!=c[k]&&!ok[k]) 
				{
					tmp=1;
					break;
				}
				else if(a[j]==c[k]&&!ok[k]) j++;
			}
			if(tmp==0) printf("yes");
			else printf("no");
		}
		puts(" ");
	}
	return 0;
}
