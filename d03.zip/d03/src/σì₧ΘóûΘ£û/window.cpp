#include<algorithm>
#include<iostream>
using namespace std;
int n,k,a[1000001],m[1000001];
int main(){
	freopen("window.in","r",stdin);freopen("window.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<k;i++)scanf("%d",&a[i]);
	for(int i=k;i<=n;i++){
		scanf("%d",&a[i]);
		m[i]=a[i];
		for(int j=i-k+1;j<i;j++)m[i]=min(m[i],a[j]);
		printf("%d ",m[i]);
		m[i]=a[i];
		for(int j=i-k+1;j<i;j++)m[i]=max(m[i],a[j]);
	}
	printf("\n");
	for(int i=k;i<=n;i++)printf("%d ",m[i]);
	return 0;
}
