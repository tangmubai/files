#include<cstdio>
using namespace std;
void read(register int &x){
	char ch=getchar();x=0;
	while(ch<'0' || ch>'9')
		ch=getchar();
	while(ch>='0' && ch<='9')
		x=x*10+ch-'0',ch=getchar();
}
int n,p;
struct Node{
	int x,y,t;
}ap[5010];
bool cmp(Node w,Node e){
	return w.t<e.t;
}
int main(){
	freopen("apples.in","r",stdin);
	freopen("apples.out","w",stdout);
	read(n);read(s);
	for(int i=1;i<=n;i++){
		read(ap[i].x);
		read(ap[i].y);
		read(ap[i].t);
	}
	puts("3");
	return 0;
}

