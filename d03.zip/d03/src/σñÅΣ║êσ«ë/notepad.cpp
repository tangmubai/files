#include<algorithm>
#include<cstdio>
using namespace std;
int n,a[100010];
struct Node{
	int num,ans;
}b[100010];
char x;
int s=1,len=0;
bool cmp(Node p,Node q){
	return p.ans<q.ans;
}
void read(register int &c) {
	char ch=getchar();
	c=0;
	while(ch<'0' || ch>'9')
		ch=getchar();
	while(ch>='0' && ch<='9')
		c=c*10+ch-'0',ch=getchar();
}
int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++){
		while(1){
			x=getchar();
			if(x=='\n') break;
			if(x=='-') continue;
			if(x>='0' && x<='9') a[i]=a[i]*10+x-'0';
			if(x>='A' && x<='Z'){
				if(x=='A' || x=='B' || x=='x') a[i]=a[i]*10+2;
				if(x=='D' || x=='E' || x=='F') a[i]=a[i]*10+3;
				if(x=='G' || x=='H' || x=='I') a[i]=a[i]*10+4;
				if(x=='J' || x=='K' || x=='L') a[i]=a[i]*10+5;
				if(x=='M' || x=='N' || x=='O') a[i]=a[i]*10+6;
				if(x=='P' || x=='R' || x=='S') a[i]=a[i]*10+7;
				if(x=='T' || x=='U' || x=='V') a[i]=a[i]*10+8;
				if(x=='W' || x=='X' || x=='Y') a[i]=a[i]*10+9;
			}
		}
	}
	sort(a+1,a+1+n);
	int now=a[1];
	for(int i=2;i<=n;i++){
		if(a[i]==now) s++;
		else {
			if(s>1){
				len++;
				b[len].ans=now;
				b[len].num=s;
			}
			s=1;
			now=a[i];
		}
	}
	if(s>1) {
		len++;
		b[len].ans=now;
		b[len].num=s;
	}
	if(len==0){
		puts("No duplicates.");
		return 0;
	}
	sort(b+1,b+1+len,cmp);
	for(int i=1;i<len;i++)
		printf("%03d-%04d %d\n",b[i].ans/10000,b[i].ans%10000,b[i].num);
	printf("%03d-%04d %d\n",b[len].ans/10000,b[len].ans%10000,b[len].num);
	return 0;
}
