#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio> 
#include<cmath>
#include<map>
#include<set>
using namespace std;
void read(register int &x) {
	char ch=getchar();x=0;
	while(ch<'0' || ch>'9')
		ch=getchar();
	while(ch>='0' && ch<='9')
		x=x*10+ch-'0',ch=getchar();
}
int main(){
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	
	return 0;
}
