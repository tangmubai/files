#include <algorithm>
#include <iostream>
#include <stdio.h>
#include <map>
using namespace std;
const int N = 1e5 + 5;
char z[30] = {'2', '2', '2', 
			  '3', '3', '3',
			  '4', '4', '4',
			  '5', '5', '5',
			  '6', '6', '6',
			  '7', '7', '7', ' 7',
			  '8', '8', '8',
			  '9', '9', '9','9'
};

map<string, int> mp;
int n;

int main() {
	ios :: sync_with_stdio(false);
//	freopen("notepad.in", "r", stdin);
//	freopen("notepad.out", "w", stdout);
	cin >> n;
	for (int i = 1; i <= n; i++) {
		string s,_;
		cin >> _;
		int cnt = 0;
		
		for (int j = 0; j < _.size(); j++) {
			if (_[j] == '-') continue;
			else if (!isdigit(_[j])) {
				s[++cnt] = z[_[j] - 65];
			}
			else s[++cnt] = _[j];
		}
		mp[s]++;
	}
//	map<string, int> :: iterator it;
//	for (it = mp.begin(); it != mp.end(); it++) {
//		if (it->second == 1) continue;
//		else {
//			for (int i = 0; i < 4; i++) {
//				cout << it->first[i];
//			}
//			cout << '-';
//			for (int i = 4; i < 8; i++) {
//				cout << it->first[i];
//			}
//			cout << '\n';
//		}
//	}
	return 0;
}

