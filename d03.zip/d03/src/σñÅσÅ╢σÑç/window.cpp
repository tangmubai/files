#include <algorithm>
#include <iostream>
#include <stdio.h>
#include <string>
#include <map>
using namespace std;
const int N = 1e5 + 5;

map<int, int> mp;
map<int, int> :: iterator it;
int a[N];
int mx[N];

int main() {
	ios :: sync_with_stdio(false);
//	freopen("window.in", "r", stdin);
//	freopen("window.out", "w", stdout);
	int n, k;
	cin >> n >> k;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i < k; i++) mp[a[i]]++;
	for (int i = 1; i <= n - k + 1; i++) {
		mp[a[i + k - 1]]++;
		mp[a[i - 1]]--;
		if (mp[a[i - 1]] <= 0)
		 	mp.erase(a[i - 1]);
		cout << mp.begin()->first << ' ';
		it = mp.end(), it--;
		mx[i] = it->first;
	}
	cout << '\n';
	for (int i = 1; i <= n - k + 1; i++)
		cout << mx[i] << ' ';
	cout << '\n';
	return 0;
}

