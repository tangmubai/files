#include <map>
#include <cstdio>
#include <string>

const int N = 5001;

struct Node {
    int px, py;
};

struct Apple {
    int tim;
    Node pos;
} apple[N];

int dp[N];

template <typename Tp>
inline void read(Tp &num) {
    Tp flag = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') flag = -1;
        ch = getchar();
    } 
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
    num *= flag;
}

inline int dis(const Node p1, const Node p2) { return (p1.px - p2.px) * (p1.px - p2.px) + (p1.py - p2.py) * (p1.py - p2.py) }

int main() {
    freopen("apples.in", "r", stdin);
    freopen("apples.out", "w", stdout);
    int n, speed;
    read(n); read(speed);
    for (int i = 1; i <= n; i++) {
        read(apple[i].pos.px); read(apple[i].pos.py); read(apple[i].tim);
        // dis <= t * s => dis * dis <= t * t * s * s
    } read(num[i]);
    workmin(); workmax();
    for (int i = m; i <= n; i++) printf("%d ", dpmin[i]);
    puts("");
    for (int i = m; i <= n; i++) printf("%d ", dpmax[i]);
    puts("");
    return 0;
}
