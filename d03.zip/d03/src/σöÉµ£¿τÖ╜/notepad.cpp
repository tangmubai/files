#include <map>
#include <cstdio>
#include <string>

const int N = 100005, M = 100;

int num[M];
std :: map <std :: string, int> mp;

inline void pre() {
    int now = 2, tot = 0;
    for (int i = 0; i < 25; i++) {
        if (i == 'Q' - 'A') continue;
        num[i] = now;
        tot++;
        if (tot % 3 == 0) now++;
    }
}

inline bool isalpha(const char ch) { return ch >= 'A' && ch <= 'Z'; }

inline bool isnum(const char ch) { return ch >= '0' && ch <= '9'; }

inline void get(std :: string &str) {
    char c = getchar();
    while (c != '-' && !isnum(c) && !isalpha(c)) c = getchar();
    for (str = ""; c == '-' || isnum(c) || isalpha(c); c = getchar()) str += c;
}

int main() {
    freopen("notepad.in", "r", stdin);
    freopen("notepad.out", "w", stdout);
    int n;
    scanf("%d", &n);
    pre();
    for (int i = 1; i <= n; i++) {
        int len;
        std :: string s, now;
        get(s);
        len = s.length();
        for (int i = 0; i < len; i++)
            if (isalpha(s[i])) now += (char) (num[s[i] - 'A'] + '0');
            else if (isnum(s[i])) now += s[i];
        mp[now]++;
    }
    if (mp.empty()) {
        puts("No duplicates.");
        return 0;
    }
    for (std :: map <std :: string, int> :: iterator it = mp.begin(); it != mp.end(); it++)
        if (it -> second > 1) {
            std :: string tmp = it -> first, out;
            out = tmp.substr(0, 3) + "-" + tmp.substr(3, 4);
            printf("%s %d\n", out.c_str(), it -> second);
        }
    return 0;

}
