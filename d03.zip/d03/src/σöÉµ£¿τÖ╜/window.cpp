#include <map>
#include <cstdio>
#include <string>

const int N = 1000001;

int q[N], id[N];
int n, m, num[N], dpmin[N], dpmax[N];

template <typename Tp>
inline void read(Tp &num) {
    Tp flag = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') flag = -1;
        ch = getchar();
    } 
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
    num *= flag;
}

inline void workmin() {
    int l = 1, r = 0;
    for (int i = 1; i <= n; i++) {
        while (id[l] < i - m + 1 && l <= r) l++;
        while (num[i] <= q[r] && l <= r) r--;
        id[++r] = i; q[r] = num[i];
        dpmin[i] = q[l];
    }
}

inline void workmax() {
    int l = 1, r = 0;
    for (int i = 1; i <= n; i++) {
        while (id[l] < i - m + 1 && l <= r) l++;
        while (num[i] >= q[r] && l <= r) r--;
        id[++r] = i; q[r] = num[i];
        dpmax[i] = q[l];
    }
}

int main() {
    freopen("window.in", "r", stdin);
    freopen("window.out", "w", stdout);
    read(n); read(m);
    for (int i = 1; i <= n; i++) read(num[i]);
    workmin(); workmax();
    for (int i = m; i <= n; i++) printf("%d ", dpmin[i]);
    puts("");
    for (int i = m; i <= n; i++) printf("%d ", dpmax[i]);
    puts("");
    return 0;
}
