#include <stdio.h>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(k1=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		a1=getchar();
	}
	return a1*k1;
}

int a[1000005];
int maxn[1000005];
int minn[1000005];
////priority_queue<int,vector<int>,greater<int> >Q;
main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	int n=re(),k=re(); //mx=-1,mn=0x3f3f3f;
	for(int i=1;i<=n;++i){
		a[i]=re();
	}
	for(int i=1;i<=n-k;++i){
		int mx=-1,mn=0x3f3f3f;
		for(int j=i;j<=i+k;++j){
			mx=a[j]>mx?a[j]:mx;
			mn=a[j]<mn?a[j]:mn;
		}
		maxn[i]=mx;minn[i]=mn;
	}
	for(int i=1;i<=n-k;++i)printf("%d ",maxn[i]);printf("\n");
	for(int i=1;i<=n-k;++i)printf("%d ",minn[i]);printf("\n");
}






