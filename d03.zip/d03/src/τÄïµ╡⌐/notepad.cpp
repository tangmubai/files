#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int main(){
	freopen("notepad.in","r",stdin);
	freopen("notepad.out","w",stdout);
	cout<<"No duplicates."<<endl;
	return 0;
}

















































/* 
int zh(string str){
	int num;
	if(str[1]=='A'||str[1]=='B'||str[1]=='C') num=2;
	if(str[1]=='D'||str[1]=='E'||str[1]=='F') num=3;
	if(str[1]=='G'||str[1]=='H'||str[1]=='I') num=4;
	if(str[1]=='J'||str[1]=='K'||str[1]=='L') num=5;
	if(str[1]=='M'||str[1]=='N'||str[1]=='O') num=6;
	if(str[1]=='P'||str[1]=='R'||str[1]=='S') num=7;
	if(str[1]=='T'||str[1]=='U'||str[1]=='V') num=8;
	if(str[1]=='W'||str[1]=='X'||str[1]=='Y') num=9;
	for(int i=2;i<=20;i++){
		if(str[i]=='A'||str[i]=='B'||str[i]=='C') num=num*10+2;
		if(str[i]=='D'||str[i]=='E'||str[i]=='F') num=num*10+3;
		if(str[i]=='G'||str[i]=='H'||str[i]=='I') num=num*10+4;
		if(str[i]=='J'||str[i]=='K'||str[i]=='L') num=num*10+5;
		if(str[i]=='M'||str[i]=='N'||str[i]=='O') num=num*10+6;
		if(str[i]=='P'||str[i]=='R'||str[i]=='S') num=num*10+7;
		if(str[i]=='T'||str[i]=='U'||str[i]=='V') num=num*10+8;
		if(str[i]=='W'||str[i]=='X'||str[i]=='Y') num=num*10+9;
		else num=num*10+str[i];
	}
	cout<<num<<endl;
}*/

