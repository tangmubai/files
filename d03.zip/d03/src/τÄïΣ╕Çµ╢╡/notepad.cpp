#include <iostream>
#include <cstring>
#include <string>
#include <map>
#include <algorithm>

using namespace std;

map<char, int> mp;
map<string, int> mp1;

const int N = 100010;

int f[N];
string s[1000000];

bool cmp(string p, string q)
{
	return p < q;
}

int main()
{
	freopen("notepad.in", "r", stdin);
	freopen("notepad.out", "w", stdout);
	mp['A'] = mp['B'] = mp['C'] = '2';
	mp['D'] = mp['E'] = mp['F'] = '3';
	mp['G'] = mp['H'] = mp['I'] = '4';
	mp['J'] = mp['K'] = mp['L'] = '5';
	mp['M'] = mp['N'] = mp['O'] = '6';
	mp['P'] = mp['R'] = mp['S'] = '7';
	mp['T'] = mp['U'] = mp['V'] = '8';
	mp['W'] = mp['X'] = mp['Y'] = '9';
	mp['1'] = '1';
	mp['2'] = '2';
	mp['3'] = '3';
	mp['4'] = '4';
	mp['5'] = '5';
	mp['6'] = '6';
	mp['7'] = '7';
	mp['8'] = '8';
	mp['9'] = '9';
	mp['0'] = '0';
	
	
	int n;
	cin >> n;
	
	int cnt = 0;
	
	for (int i = 1; i <= n; i ++ )
	{
		string a;
		cin >> a;
		
		string cz;
		
		for (int i = 0; i < a.size(); i ++ )
		{
			if (a[i] == '-' || a[i] == 'Q' || a[i] == 'Z')	continue;
			cz += mp[a[i]];
		}
		
		mp1[cz] ++ ;
		s[ ++ cnt ] = cz;
	}
	
	sort(s + 1, s + cnt + 1, cmp);
	cnt = unique(s + 1, s + cnt + 1) - s;
	for (int i = 1; i <= cnt; i ++ )
	{
		if (mp1[s[i]] > 1)
		{
			for (int j = 0; j < 3; j ++ )	cout << s[i][j];
			cout << '-';
			for (int j = 3; j < 7; j ++ )	cout << s[i][j];
			cout << ' ' << mp1[s[i]] << endl;
			mp1[s[i]] = 1;
		}
//		cout << s[i] << ' ' << mp1[s[i]] << endl;
	}
	
	return 0;
}
