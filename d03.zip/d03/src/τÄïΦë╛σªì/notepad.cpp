#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
string s[100005],ss;
int a[145],n,b[10],len;
char c[105];
bool cc(char c){
	return (c>='0'&&c<='9')||(c>='A'&&c<='Y'&&c!='Q');
}
char A(){
	char c=getchar();
	while(!cc(c))c=getchar();
	return a[c];
}
void print(string a){
	for(int i=6;i>=4;i--)putchar(a[i]);
	printf("-");
	for(int i=3;i>=0;i--)putchar(a[i]);
	printf(" ");
}
int main(){
	//freopen("notepad.in","r",stdin);
	//freopen("notepad.out","w",stdout);
	a['A']=a['B']=a['C']='2';a['D']=a['E']=a['F']='3';a['G']=a['H']=a['I']='4';
	a['J']=a['K']=a['L']='5';a['M']=a['N']=a['O']='6';a['P']=a['R']=a['S']='7';
	a['T']=a['U']=a['V']='8';a['W']=a['X']=a['Y']='9';
	scanf("%d",&n);
	while(n--){
		ss='0';
		for(int i=1;i<=7;i++)
		    ss+=A();
		s[++len]=ss;
	}
	sort(s+1,s+1+n);
	for(int i=1,j=2;i<=len;i=j){
		while(s[i]==s[j])j++;
		if(j-i>1)printf("%d\n",j-i);
	}
	return 0;
}
