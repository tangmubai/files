#include<stdio.h>
#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;
int n,k;
int a[1000005];
int min_value[1000005],max_value[1000005];
int main(){
	freopen("window.in","r",stdin);
	freopen("window.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++){
		int min=a[i],max=a[i];
		for(int j=i+1;j<k+i;j++){
			if(a[j]<min)min=a[j];
			if(a[j]>max)max=a[j];
		}
		min_value[i]=min;
		max_value[i]=max;
	}
	for(int i=1;i<=n-k+1;i++)printf("%d ",min_value[i]);
	printf("\n");
	for(int i=1;i<=n-k+1;i++)printf("%d ",max_value[i]);
	return 0;
}
