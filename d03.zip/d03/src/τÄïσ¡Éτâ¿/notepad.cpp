#include "cstdio"
#include "cstring"
using namespace std;
int map[10000005],n,a[1005];
char s[1005];
int main(){
	freopen ("notepad.in","r",stdin);
	freopen ("notepad.out","w",stdout);
	scanf ("%d",&n);
	for (int i=1;i<=n;i++){
		scanf ("%s",s+1);
		int t=0;
		for (int i=1;i<=strlen(s+1);i++){
			if (s[i]=='-') continue;
			if (s[i]>'9'||s[i]<'0'){
				if (s[i]=='A'||s[i]=='B'||s[i]=='C') a[++t]=2;
				if (s[i]=='D'||s[i]=='E'||s[i]=='F') a[++t]=3;
				if (s[i]=='G'||s[i]=='H'||s[i]=='I') a[++t]=4;
				if (s[i]=='J'||s[i]=='K'||s[i]=='L') a[++t]=5;
				if (s[i]=='M'||s[i]=='N'||s[i]=='O') a[++t]=6;
				if (s[i]=='P'||s[i]=='R'||s[i]=='S') a[++t]=7;
				if (s[i]=='T'||s[i]=='U'||s[i]=='V') a[++t]=8;
				if (s[i]=='W'||s[i]=='X'||s[i]=='Y') a[++t]=9;
			}
			else a[++t]=s[i]-'0';
		}
		int k=1,s=0;
		for (int i=t;i>=1;i--) s+=a[i]*k,k*=10;
		map[s]++;
	}
	int f=0;
	for (int i=1;i<=9999999;i++){
		if (map[i]>1){
			f=1;
			printf ("%03d-%04d ",i/10000,i%10000);
			printf ("%d\n",map[i]);
		}
	}
	if (f==0) printf ("No duplicates.\n");
	return 0;
}
