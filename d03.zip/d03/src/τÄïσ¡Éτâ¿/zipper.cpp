#include "cstdio"
#include "cstring"
using namespace std;
inline int max(int a,int b){
	return a>b?a:b;
}
int f[205][205],n;
char s1[205],s2[205],s3[205];
int main(){
	freopen ("zipper.in","r",stdin);
	freopen ("zipper.out","w",stdout);
	scanf ("%d",&n);
	for (int k=1;k<=n;k++){
		int ans=0;
		memset (f,0,sizeof f);
		scanf ("%s",s1+1);
		scanf ("%s",s2+1);
		scanf ("%s",s3+1);
		int n1=strlen(s1+1),n2=strlen(s2+1),n3=strlen(s3+1);
		for (int i=1;i<=n1;i++){
			for (int j=1;j<=n3;j++){
				if (s1[i]==s3[j]) f[i][j]=f[i-1][j-1]+1;
				else f[i][j]=max(f[i-1][j],f[i][j-1]);
			}
		}
		ans+=f[n1][n3];
		memset (f,0,sizeof f);
		for (int i=1;i<=n2;i++){
			for (int j=1;j<=n3;j++){
				if (s2[i]==s3[j]) f[i][j]=f[i-1][j-1]+1;
				else f[i][j]=max(f[i-1][j],f[i][j-1]);
			}
		}
		ans+=f[n2][n3];
		if (ans==n3) printf ("Data set %d: yes\n",k);
		else printf ("Data set %d: no\n",k);
	}
	return 0;
}
