#include<iostream>
#include<stdio.h>
using namespace std;
int need[1000005],minn[1000005],maxn[1000005];
int qread(){
	int a=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a*f;
}
int main(){
	freopen("window.in","r",stdin);freopen("window.out","w",stdout);
	int n=qread(),k=qread();
	for(int i=1;i<=n;++i) need[i]=qread();
	for(int i=1;i<=n-k+1;++i){
		maxn[i]=-2147483600;
		minn[i]=2147483647;
		for(int j=0;j<k;++j){
			maxn[i]=max(maxn[i],need[i+j]);
			minn[i]=min(minn[i],need[i+j]);
		}
	}
	for(int i=1;i<=n-k+1;++i) printf("%d ",minn[i]);
	printf("\n");
	for(int i=1;i<=n-k+1;++i) printf("%d ",maxn[i]);
	printf("\n");
	return 0;
}
