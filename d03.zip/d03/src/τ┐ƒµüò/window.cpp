#include <cstdio>
using namespace std;
int n,k,i,j,d[1000001],a[1000001],b[1000001];
int main () {
	freopen ("window.in","r",stdin);
	freopen ("window.out","w",stdout);
	scanf ("%d%d",&n,&k);
	for (i=1;i<=n;i++) scanf ("%d",&d[i]);
	for (i=1;i<=n;i++) a[i]=-1000000,b[i]=1000000;
	for (i=1;i<=n-k+1;i++) for (j=i;j<=i+k-1;j++) {
		if (a[i]<d[j]) a[i]=d[j];
		if (b[i]>d[j]) b[i]=d[j];
	}
	for (i=1;i<=n-k+1;i++) printf ("%d ",b[i]);
	printf ("\n");
	for (i=1;i<=n-k+1;i++) printf ("%d ",a[i]);
	return 0;
}
