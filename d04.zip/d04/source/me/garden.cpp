#include <cstdio>

const int N = 100001, M = 10;

int n, dp[N][M], val[N][M];

template <typename Tp>
inline Tp max(const Tp num1, const Tp num2) { return num1 > num2 ? num1 : num2; }

inline void read() {}
template <typename Tp1, typename ...Tp2>
inline void read(Tp1 &num, Tp2 &...rest) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 1) + (num << 3) + (ch ^ '0');
    read(rest...);
}

inline void work() {
    for (int i = 2; i <= n; i++) {
        dp[i][1] = max(dp[i - 1][2], dp[i - 1][4]) + val[i][1];
        dp[i][2] = dp[i - 1][1] + val[i][2];
        dp[i][3] = dp[i - 1][4] + val[i][2];
        dp[i][4] = max(dp[i - 1][1], dp[i - 1][3]) + val[i][3];
    }
}

int main() {
    freopen("garden.in", "r", stdin);
    freopen("garden.out", "w", stdout);
    int ans = 0;
    read(n);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= 3; j++)
            read(val[i][j]);
    dp[1][1] = val[1][1];
    work();
    if (dp[n][2] > ans) ans = dp[n][2];
    if (dp[n][4] > ans) ans = dp[n][4];
    dp[1][1] = 0;
    dp[1][2] = dp[1][3] = val[1][2];
    work();
    if (dp[n][1] > ans) ans = dp[n][1];
    if (dp[n][4] > ans) ans = dp[n][4];
    dp[1][2] = dp[1][3] = 0;
    dp[1][4] = val[1][3];
    work();
    if (dp[n][1] > ans) ans = dp[n][1];
    if (dp[n][3] > ans) ans = dp[n][3];
    printf("%d\n", ans);
    return 0;
}
