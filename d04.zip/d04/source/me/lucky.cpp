#include <cstdio>

const int N = 101;

int tot[N];

inline void read() {}
template <typename Tp1, typename ...Tp2>
inline void read(Tp1 &num, Tp2 &...rest) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 1) + (num << 3) + (ch ^ '0');
    read(rest...);
}

int main() {
    freopen("lucky.in", "r", stdin);
    freopen("lucky.out", "w", stdout);
    int n, mod, ans = 0, sum = 0;
    tot[0] = 1;
    for (read(n, mod); n; n--) {
        int num;
        read(num);
        sum = (sum + num) % mod;
        ans += tot[sum];
        tot[sum]++;
    }
    printf("%d\n", ans);
    return 0;
}
