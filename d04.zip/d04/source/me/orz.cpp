#include <cstdio>
#include <cstring>

const int N = 2501;

int dp[N], sum1[N], sum2[N];

template <typename Tp>
inline Tp abs(const Tp num) { return num < 0 ? -num : num; }

inline void read() {}
template <typename Tp1, typename ...Tp2>
inline void read(Tp1 &num, Tp2 &...rest) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 1) + (num << 3) + (ch ^ '0');
    read(rest...);
}

int main() {
    freopen("orz.in", "r", stdin);
    freopen("orz.out", "w", stdout);
    int n, m;
    read(n, m);
    memset(dp, 0x7f, sizeof dp);
    dp[0] = 0;
    for (int i = 1; i <= n; i++) {
        int opt;
        read(opt);
        sum1[i] = sum1[i - 1]; sum2[i] = sum2[i - 1];
        if (opt == 1) sum1[i]++;
        else sum2[i]++;
        for (int j = 0; j < n; j++) {
            int tmp1 = sum1[i] - sum1[j], tmp2 = sum2[i] - sum2[j];
            if (abs(tmp1 - tmp2) <= m || tmp1 == 0 || tmp2 == 0) {
                int tmp = dp[j] + 1;
                if (tmp < dp[i]) dp[i] = tmp;
            }
        }
    }
    printf("%d\n", dp[n]);
    return 0;
}
