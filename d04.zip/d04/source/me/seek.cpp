#include <cstdio>
#include <vector>
#include <cstring>

const int N = 101;

bool vis[N];
int m, val[N], dp[N][N];
std :: vector <int> edge[N];

inline void read() {}
template <typename Tp1, typename ...Tp2>
inline void read(Tp1 &num, Tp2 &...rest) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 1) + (num << 3) + (ch ^ '0');
    read(rest...);
}

inline void work(const int id) {
    int tmp[N];
    memset(tmp, -1, sizeof tmp);
    tmp[0] = 0; vis[id] = true;
    for (const auto nxt : edge[id]) {
        if (vis[nxt]) continue;
        work(nxt);
        for (int i = 1; i <= m; i++)
            if (dp[nxt][i] > dp[id][i])
                dp[id][i] = dp[nxt][i];
        for (int i = m; i >= 0; i--) {
            if (tmp[i] < 0) continue;
            for (int j = 1; j <= m - i; j++)
                if (tmp[i] + dp[nxt][j] > tmp[i + j])
                    tmp[i + j] = tmp[i] + dp[nxt][j];
        }
    }
    for (int i = 1; i <= m; i++)
        if (tmp[i - 1] + val[id] > dp[id][i])
            dp[id][i] = tmp[i - 1] + val[id];
}

int main() {
    freopen("seek.in", "r", stdin);
    freopen("seek.out", "w", stdout);
    int n, ans = 0;
    read(n, m);
    for (int i = 1; i <= n; i++) read(val[i]);
    for (int i = 1; i < n; i++) {
        int u1, u2;
        read(u1, u2);
        edge[u1].push_back(u2); edge[u2].push_back(u1);
    }
    work(1);
    for (int i = 1; i <= m; i++)
        if (dp[1][i] > ans)
            ans = dp[1][i];
    printf("%d\n", ans);
    return 0;
}
