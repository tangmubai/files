#include <cstdio>
#include <vector>
#include <cstring>

const int N = 101, M = 10001; 

bool dp[M];
int w[N];

inline void read(int &num) {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	for (num = 0; c >= '0' && c <= '9'; c = getchar()) num = (num << 1) + (num << 3) + (c ^ '0');
}

int main() {
	freopen("blocks.in", "r", stdin);
	freopen("blocks.out", "w", stdout);
	int t;
	for (read(t); t; t--) {
		int n, tot = 0, ans = 0, sum = 0;
		read(n);
		memset(dp, false, sizeof dp);
		for (int i = 1; i <= n; i++) {
			int a, b;
			read(a); read(b);
			if (a == 2) ans += b;
			else w[++tot] = b;
		}
		dp[0] = true;
		for (int i = 1; i <= tot; i++) {
			for (int j = sum; j >= 0; j--)
				if (dp[j] == true)
					dp[j + w[i]] = true;
			sum += w[i];
		}
		for (int i = sum / 2; i >= 0; i--)
			if (dp[i] == true) {
				ans += sum - i;
				break;
			}
		printf("%d\n", ans);
	}
	return 0;
}

