#include <cstdio>
#include <vector>
#include <cstring>

const int N = 100001; 

struct Edge {
	int nxt, val;
};

bool vis[N];
int n, ans, dp1[N], dp2[N];
std :: vector <Edge> edge[N];

inline void read(int &num) {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	for (num = 0; c >= '0' && c <= '9'; c = getchar()) num = (num << 1) + (num << 3) + (c ^ '0');
}

inline void clear() {
	memset(dp1, 0, sizeof dp1);
	memset(dp2, 0, sizeof dp2);
	memset(vis, false, sizeof vis);
	for (int i = 1; i <= n; i++) edge[i].clear();
}

inline void find(const int id) {
	vis[id] = true;
	for (auto it : edge[id]) {
		int nxt = it.nxt, tmp;
		if (vis[nxt]) continue;
		find(nxt);
		tmp = dp1[nxt] + it.val;
		if (tmp > dp1[id]) {
			dp2[id] = dp1[id];
			dp1[id] = tmp;
		} else if (tmp > dp2[id]) dp2[id] = tmp;
	}
	if (dp1[id] + dp2[id] > ans) ans = dp1[id] + dp2[id];
}

int main() {
	freopen("diameter.in", "r", stdin);
	freopen("diameter.out", "w", stdout);
	int t;
	for (read(t); t; t--) {
		read(n);
		clear();
		for (int i = 1; i < n; i++) {
			int p1, p2, v;
			read(p1); read(p2); read(v);
			edge[p1].push_back((Edge) {p2, v});
			edge[p2].push_back((Edge) {p1, v});
		}
		ans = -1;
		find(1);
		printf("%d\n", ans);
	}
	return 0;
}

