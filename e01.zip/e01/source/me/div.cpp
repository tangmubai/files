#include <cstdio>

const int N = 100;

int ans[N];

inline void read(int &num) {
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	for (num = 0; c >= '0' && c <= '9'; c = getchar()) num = (num << 1) + (num << 3) + (c ^ '0');
}

int main() {
	freopen("div.in", "r", stdin);
	freopen("div.out", "w", stdout);
	int t;
	for (read(t); t; t--) {
		int n, k, tot = 0;
		read(n); read(k);
		for (int i = 2; i <= n / i && k > 0; )
			if (n % i == 0) ans[++tot] = i, n /= i, k--;
			else i++;
		if (k == 0) ans[tot] *= n;
		else if (k == 1 && n > 1) ans[++tot] = n, k--;
		if (k >= 1) printf("No answer!");
		else for (int i = 1; i <= tot; i++) printf("%d ", ans[i]);
		putchar('\n');
	}
	return 0;
}

