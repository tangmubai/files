#include <queue>
#include <cstdio>
#include <algorithm>

const int N = 25000;

struct Game {
    int t, d;
} game[N];

inline void read() {}
template <typename Tp1, typename ...Tp2>
inline void read(Tp1 &num, Tp2 &...rest) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 1) + (num << 3) + (ch ^ '0');
    read(rest...);
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int t;
	for (read(t); t; t--) {
		int n, k, tot = 0, sum = 0;
        std :: priority_queue <int> q;
		read(n, k);
        for (int i = 1; i <= n; i++) read(game[i].t, game[i].d);
        std :: sort(game + 1, game + 1 + n, [](const Game tmp1, const Game tmp2) {
            return tmp1.d < tmp2.d;
        });
        for (int i = 1; i <= n; i++) {
            sum += game[i].t;
            q.push(game[i].t);
            while (sum > game[i].d) {
                tot++;
                sum -= q.top();
                q.pop();
            }
        }
        if (tot >= k) puts("-1");
        else printf("%d\n", tot);
	}
	return 0;
}
