	freopen("diameter.in", "r", stdin);
	freopen("diameter.out", "w", stdout);