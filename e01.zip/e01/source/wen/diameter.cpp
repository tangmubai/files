#include <cstdio>
#include <cstring>
const int N=100005;
struct Head{    
    int first, TMax, SMax; 
}head[N]; //smax��ʾ���tmax��ʾ�δ�
struct Edge{    
    int c, val, next;
}edge[2*N];
int ans, v[N], now;
void ins(int x, int y, int val){
    edge[now].c = y; edge[now].val = val;
    edge[now].next = head[x].first;
    head[x].first = now++;
} //��ʽǰ���� 
void in(int &x){
	char c=getchar();
	while (c<'0' || c>'9') c=getchar();
	for (x=0; c>='0' && c<='9'; c=getchar())
		x=x*10+c-'0';
} 
void dfs(int i){
    v[i]=1;    
	int m1=0, m2=0;
    for (int k=head[i].first; k; k=edge[k].next)
        if (!v[edge[k].c]){
            int w=edge[k].val;     
            dfs(edge[k].c);  
            int x=w+head[edge[k].c].SMax;
            if (x>m1){ m2=m1; m1=x;}   
            else if (x>m2) m2=x;   
        }
    head[i].SMax=m1; head[i].TMax=m2;             
    if (ans<m1+m2) ans=m1+m2;
}
int main(){
    freopen("diameter.in","r",stdin);
    freopen("diameter.out","w",stdout);
    int t, n;
    scanf("%d", &t);
    while (t--){
		scanf("%d", &n);
        memset(v, 0, sizeof(v));
        memset(head, 0, sizeof(head));
        now=1; ans=-1;
        int x, y, w;
        for (int i=1; i<n; i++){
        	in(x), in(y), in(w);
            //scanf("%d %d %d", &x, &y, &w);
            ins(x, y, w); ins(y, x, w);
        }
        dfs(1);
        printf("%d\n", ans);
    }
    return 0;
}
