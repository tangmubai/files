#include <cstdio>
unsigned a[40];
void out(unsigned c){
    for (int i=0; i<=c; i++)
        printf("%u ", a[i]);
    printf("\n");
}
int main(){
    freopen("div.in", "r", stdin);
    freopen("div.out", "w",stdout);
    int t;
    scanf("%d", &t);
    while (t--){
        unsigned n, k, j=0;
        scanf("%u %u", &n, &k);
        for (unsigned i=2; i*i<=n && j<k-1;){
			//ʹ��unsigned��Ϊ��i*i<=n����ж���������n�ﵽ(1<<31)-1ʱ���������� 
            if (n%i==0){
                n/=i; a[j++]=i;
            }            
            else 
                i++;
        }
        if (n>1 && j==k-1) {
            a[j]=n; out(j);
        }
        else 
            printf("No answer!\n");
    }
    return 0;
}
