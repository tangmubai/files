#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;
typedef long long ll;
bool jud(ll m){//�ж�m���ÿ��������ֻ��1�� 
	for (ll i=2; i*i<=m; i++){
		int s=0;
		while (m%i==0){
			s++, m/=i;
			if (s>1) return 0; 
		}
	}
	return 1;
}
ll cal(ll n){
	if (n<=4) return 4-n;
	ll x=sqrt(n*1.0)+.5, ans;
	for (ll m=x; ; m++){//�ڱ�x��������� 
		if (m*m>=n && jud(m)){
			ans=abs(m*m-n);
			break;
		}
	}
	for (ll m=x; ; m--){//�ڱ�xС�������� 
		if (n-m*m>ans) break;
		if (jud(m)) ans=min(ans, abs(m*m-n));
	} 
	return ans;
}
int main(){
	freopen("close.in", "r", stdin);
	freopen("close.out", "w", stdout);
	int t; ll n;
	scanf("%d", &t);
	while (t--){
		scanf("%lld", &n);
		printf("%lld\n", cal(n));
	}
	return 0;
} 
