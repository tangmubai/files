#include <cstdio>
const int N=100005;
const int pw[4][4]={{1,1,1,1},{1,2,4,3},{1,3,4,2},{1,4,1,4}};
char s[N];

int main(){
    freopen("maths.in", "r", stdin);
    freopen("maths.out", "w", stdout);
    int t;
    scanf("%d\n", &t);
    while (t--){
    	scanf("%s", s);
    	int sum=0, ans=0;
    	for (int i=0; s[i]; i++)
    		sum = (sum*10+s[i]-'0')%4;
    	for (int i=1; i<5; i++)
    	    ans += pw[i-1][sum];
    	printf("%d\n", ans%5);
	}
    return 0;
}

