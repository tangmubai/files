#include <cstdio>
#include <cmath>
#define Abs(x) ((x)<0?-(x):(x))
#define min(a,b) ((a)<(b)?(a):(b))
int t;
long long x;
bool check(long long y){
	for(long long i=2;i*i<=y;){
		if(!(y%i)){
			int s=0;
			while(!(y%i)) ++s,y/=i;
			if(s>1) return 0;
		}
		else ++i;
	}
	return 1;
}
int main(){
	freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&x);
		long long y=(int)(sqrt(x)),ans=-1;
		for(int r=0;;r++){
			long long y1=y-r,y2=y+r,ans1=-1,ans2=-1;
			if(check(y1)) ans1=Abs(y1*y1-x);
			if(check(y2)) ans2=Abs(y2*y2-x);
			if(ans1!=-1||ans2!=-1){
				if(ans1!=-1&&ans2!=-1) ans=min(ans1,ans2);
				else if(ans1!=-1) ans=ans1;
				else if(ans2!=-1) ans=ans2;
				break;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}

