#include <cstdio>
inline int read(){
	int x=0,w=0;char c=getchar();
	for(;c<'0'||c>'9';w^=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=getchar());
	return w?-x:x;
}
int t,l;
int main(){
	freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
	t=read();
	while(t--){
		l=read();
		printf("0\n");
	}
	return 0;
}

