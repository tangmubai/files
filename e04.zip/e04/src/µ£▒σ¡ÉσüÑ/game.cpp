#include <cstdio>
#include <algorithm>
int t,n,a[100003],b[100003],f[100003][5],ans;
int main(){
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=0;i<=100000;i++) b[i]=0;
		for(int i=1;i<=n;i++) scanf("%d",&a[i]),++b[a[i]];//f[i][1]=0;
		std::sort(a+1,a+1+n);
		ans=0;
		for(int i=n;i>=1;i--){
			if(!b[a[i]]) continue;
			ans+=a[i];
			b[a[i]-1]=b[a[i]+1]=0;
		}
		printf("%d\n",ans);
	}
	return 0;
}

