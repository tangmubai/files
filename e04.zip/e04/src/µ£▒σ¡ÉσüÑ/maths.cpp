#include <cstdio>
#include <cstring>
int t,ans;
const int two[4]={6,2,4,8},three[4]={1,3,9,7},four[4]={6,4,6,4};
char n[100003];
int main(){
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",n);
		ans=1;
		int x=(n[strlen(n)-1]-'0')+10*(n[strlen(n)-2]-'0');
		ans+=four[x%4]%5,ans+=three[x%4]%5;
		ans+=two[x%4]%5;
		printf("%d\n",ans%5);
	}
	return 0;
}

