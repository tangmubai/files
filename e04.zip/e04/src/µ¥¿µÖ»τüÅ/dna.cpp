#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline bool in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return 0;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int f[10000010], g[10000010], n2[10000010], a[20], maxx;

int main()
{
	freopen("dna.in", "r", stdin);
	freopen("dna.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	for(int ii=1; ii<=tt; ii++)
	{
		in(a[ii]);
		maxx = max(a[ii], maxx);
	}
	
	
	f[3] = g[3] = 1;
	n2[1] = 2, n2[2] = 4, n2[3] = 8;
	
	for(int i=4; i<=maxx; i++)
		f[i] = (f[i-1] * 2 % 10007 + (i - 2) % 10007) % 10007,
		g[i] = (g[i-1] * 2 % 10007 + (i - 1) % 10007) % 10007,
		n2[i] = n2[i-1] * 2 % 10007;
	
	
	for(int ii=1; ii<=tt; ii++)
		out((n2[a[ii]] - f[a[ii]] - g[a[ii]] + 10007 + 10007) % 10007), enter;
}

