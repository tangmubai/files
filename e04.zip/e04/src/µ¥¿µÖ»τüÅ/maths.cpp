#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline bool in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return 0;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int num[10][10] =
{{},
{1, 1, 1, 1},
{1, 2, 4, 3},
{1, 3, 4, 2},
{1, 4, 1, 4}
};

char s[100010];


int main()
{
	freopen("maths.in", "r", stdin);
	freopen("maths.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	for(int ii=1; ii<=tt; ii++)
	{
		scanf("%s", s);
		int len = strlen(s);
			
		int d = ((s[len - 2] - '0') * 10 + (s[len - 1] - '0')) % 4;
		
		
		out((num[1][d] + num[2][d] + num[3][d] + num[4][d]) % 5), enter;
	}
}

