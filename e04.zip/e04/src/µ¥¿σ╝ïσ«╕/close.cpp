#include<iostream>
#include<cmath>
using namespace std;
bool check(long long mid){
	int num=0;
	int k=sqrt(mid);
	for(long long i=2;i<=k;){
		if(mid%i==0){
			num++;
			mid/=i;
		}
		else{
			if(num!=1&&num!=0)return false;
			num=0;
			i++;
		}
	}
	return true;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		long long a;
		cin>>a;
		long long l=sqrt(a),r=sqrt(a)+1,s1=0,s2=0;
		while(1){
			if(check(l))s1=l*l;
			else l--;
			if(check(r))s2=r*r;
			else r++;
			if(s1!=0){
				if(s2==0){
					cout<<(long long)abs(s1-a)<<endl;
					break;
				}
				else{
					if(abs(s1-a)>=abs(s2-a)){
						cout<<(long long)abs(s2-a)<<endl;
						break;
					}
					else{
						cout<<(long long)abs(s1-a)<<endl;
						break;
					}
				}
			}
			if(s2!=0)if(s1==0){
				cout<<(long long)abs(s2-a)<<endl;
				break;
			}
		}
	}
	return 0;
}
