#include<iostream>
#include<cstring>
using namespace std;
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		char a[100005];
		cin>>a;
		int sum;
		int k=a[strlen(a)-1]-48+(a[strlen(a)-2]-48)*10;
		k%=4;
		if(k==1)sum=0;
		if(k==2)sum=2;
		if(k==3)sum=0;
		if(k==0)sum=4;
		cout<<sum<<endl;
	}
	return 0;
}
