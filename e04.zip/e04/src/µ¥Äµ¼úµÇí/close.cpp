#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#include<cmath>
#define ll long long
using namespace std;
ll min(ll p,ll q){
	return p>q?q:p;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	ll n,x,y,t,ans;
	scanf("%lld",&t);
	while(t--){
		scanf("%lld",&x);
		y=sqrt(x);
		//cout<<y<<endl;
		ans=min(abs(y*y-x),abs((y+1)*(y+1)-x));
		printf("%lld\n",ans);
	}
	return 0;
}


