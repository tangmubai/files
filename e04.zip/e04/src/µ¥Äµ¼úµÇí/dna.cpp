#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	printf("9\n40\n");
	return 0;
}


