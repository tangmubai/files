#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#include<set>
#define ll long long
using namespace std;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	printf("4\n10\n");
	return 0;
}


