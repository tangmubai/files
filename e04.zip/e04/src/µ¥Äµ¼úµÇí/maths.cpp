#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
char n[100005];
ll k;
int check(){
	int a=0,b=0;
	if(k>1)a=n[k-1]-'0',b=n[k-2]-'0';
	if(k==1) a=n[k-1]-'0';
	if((b*10+a)%4==0)return 1;
	return 0;
}
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	ll t;
	scanf("%lld",&t);
	while(t--){
		k=0;
		scanf("%s",n);
		k=strlen(n);
		if(check())printf("4\n");
		else printf("0\n");
	}
	return 0;
}

