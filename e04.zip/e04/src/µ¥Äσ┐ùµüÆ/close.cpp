#include<stdio.h>
#include<math.h>
#define min(a,b)((a)<(b)?(a):(b))
#define int unsigned long long
#define file(n)freopen(n".in","r",stdin),freopen(n".out","w",stdout)
bool check(int n){
	for(int i=2;i*i<=n;i++){
		if(n%i==0){
			n/=i;
			if(n%i==0){
				return 0;
			}
		}
	}
	return 1;
}
inline void work(){
	int n;
	scanf("%llu",&n);
	int l=sqrt(n);
	int r=l+1;
	while(!check(r)){
		r++;
	}
	while(!check(l)){
		l--;
	}
	printf("%llu\n",min(r*r-n,n-l*l));
	return;
}
signed main(){
	file("close");
	register int t;
	scanf("%llu",&t);
	while(t--){
		work();
	}
	return 0;
}
