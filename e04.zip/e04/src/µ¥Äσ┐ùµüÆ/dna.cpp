#include<stdio.h>
#define int long long
#define mod 10007
#define file(n)freopen(n".in","r",stdin),freopen(n".out","w",stdout)
int qpow(int n,int k){
	if(k<=1){
		return n;
	}
	if(k%2){
		return (qpow(n,k/2)*qpow(n,k/2)*n)%mod;
	}else{
		return (qpow(n,k/2)*qpow(n,k/2))%mod;
	}
}
inline void work(){
	int l;
	scanf("%lld",&l);
	int ans=qpow(2,l);
	int ans1=((l-2)*qpow(2,l-3))%mod;
	int ans2=((l-2)*qpow(2,l-3))%mod;
	printf("%lld\n",ans-ans1-ans2);
	return;
}
signed main(){
	file("dna");
	register int t;
	scanf("%lld",&t);
	while(t--){
		work();
	}
	return 0;
}
