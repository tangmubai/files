#include<stdio.h>
#define file(n)freopen(n".in","r",stdin),freopen(n".out","w",stdout)
inline void work(){
	return;
}
int main(){
	file("game");
	register int t;
	scanf("%d",&t);
	while(t--){
		work();
	}
	return 0;
}
