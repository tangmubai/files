#include<stdio.h>
#define file(n)freopen(n".in","r",stdin),freopen(n".out","w",stdout)
char s[100000];
inline void work(){
	scanf("%s",&s);
	int len=0;
	while(s[len]){
		len++;
	}
	int ans=s[len-2]-'0';
	ans*=10;
	ans+=s[len-1]-'0';
	if(ans%4){
		printf("0\n");
	}else{
		printf("4\n");
	}
	return;
}
int main(){
	file("maths");
	register int t;
	scanf("%d",&t);
	while(t--){
		work();
	}
	return 0;
}
