#include <math.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;
long long read () {
	long long k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}
bool flag;
long long t,x,i,n,j,k,s,p;
int main () {
	freopen ("close.in","r",stdin);
	freopen ("close.out","w",stdout);
	t=read ();
	while (t--) {
		x=read ();
		for (i=j=x;;i++,j--) {
			flag=true;
			n=i;
			k=2;
			while (1) {
				if (n==1) 
					break;	
				if (n%k==0) {
					s=0;
					while (n%k==0) {
						s++;
						n/=k;
						if (s>2) {
							s++;
							break;
						}
					}
					if (s!=2) {
						flag=false;
						break;
					}
				}
				if (flag==false) 
					break;
				k++;
			}
			if (flag==true) {
				printf ("%lld\n",abs (i-x));
				break;
			}
			flag=true;
			n=j;
			k=2;
			while (1) {
				if (n==1) 
					break;
				if (n%k==0) {
					s=0;
					while (n%k==0) {
						s++;
						n/=k;
						if (s>2) {
							s++;
							break;
						}
					}
					if (s!=2) {
						flag=false;
						break;
					}
				}
				k++;
				if (flag==false) 
					break;
			}
			if (flag==true) {
				printf ("%lld\n",abs (j-x));
				break;
			}
		}
	}
	return 0;
}
