#include <math.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;
long long read () {
	long long k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}
char a[100010];
long long t,s,i,ans,len;
int main () {
	freopen ("maths.in","r",stdin);
	freopen ("maths.out","w",stdout);
	t=read ();
	while (t--) {
		ans=0;
		for (i=1;i<=100000;i++)
			a[i]='0';
		scanf ("%s",a+1);
		len=strlen (a+1);
		s=(a[len]-'0'+(a[len-1]-'0')*10)%4;
		ans+=(pow (2,s));
		ans+=(pow (3,s));
		ans+=pow (4,s%2);
		ans++;
		ans%=5;
		printf ("%lld\n",ans);
	}
	return 0;
}
