#include<stdio.h>
#include<algorithm>
#include<cmath>
#include<iostream>
#include<cstring>
using namespace std;
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	int t;
	scanf("%d",&t);
	long long n;
	while(t--){
		scanf("%lld",&n);
		long long x=sqrt(n*1.0);
		if(x*x==n){
			printf("0\n");continue;
		}
		if(abs(x*x-n)<=abs(((x+1)*(x+1))-n)){
			printf("%d\n",abs(x*x-n));
		}else {
			printf("%d\n",abs(((x+1)*(x+1))-n));
		}
	}
	return 0;
}

