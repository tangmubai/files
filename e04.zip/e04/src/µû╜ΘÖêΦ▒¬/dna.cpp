#include<stdio.h>
#include<algorithm>
#include<cmath>
#include<iostream>
#include<cstring>
#define M 10007
#define MM 100007
using namespace std;
long long ksm(long long x,long long b,long long p){
	long long ans=1;
	while(b){
		if(b%2==1){
			ans=ans*x%p;
		}
		x=x*x%p;
		b/=2;
	}
	return ans%p;
}
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	int t;
	scanf("%lld",&t);
	long long n;
	while(t--){
		scanf("%lld",&n);
		long long ans1=ksm(2,n,MM);
		long long ans2=(2*(ksm(2,n-2,M)-1)+(n-3))%M;
		printf("%lld\n",(ans1-ans2)%M);
	}
	return 0;
}

