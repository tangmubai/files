#include<stdio.h>
#include<algorithm>
#include<cmath>
#include<iostream>
#include<cstring>
using namespace std;
int f[100005];
int hh[100005];
int a[100005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int t,n;
	scanf("%d",&t);
	while(t--){
		int ma=(-1);
		memset(f,0,sizeof(f));
		memset(hh,0,sizeof(hh));
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			f[a[i]]++;
			ma=max(ma,a[i]);
		}
		int last2=0,last1=0;
		for(int i=1;i<=ma;i++){
			if(f[i]){
				if(f[i-1])hh[i]=f[i]*i+hh[last2];
				else hh[i]=hh[last1]+f[i]*i;
				last2=last1;
				last1=i;
			}
		}
		int ans=(-1);
		for(int i=1;i<=ma;i++)ans=max(ans,hh[i]);
		printf("%d\n",ans);
	}
	return 0;
}

