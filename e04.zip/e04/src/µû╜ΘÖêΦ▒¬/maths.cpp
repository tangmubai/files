#include<stdio.h>
#include<algorithm>
#include<cmath>
#include<iostream>
#include<cstring>
using namespace std;
inline void in(int &x){
	x=0;
	int f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f=(-1);
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';c=getchar();
	}
	x*=f;
}
int a[5][5]={{},{1},{6,2,4,8},{1,3,9,7},{6,4}};
int f[5]={0,1,4,4,2};
int ans[10];
char s[100005];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		memset(ans,0,sizeof(ans));
		scanf("%s",s+1);
		int l=strlen(s+1);
		for(int i=1;i<=l;i++){
			for(int j=1;j<=4;j++){
				ans[j]=(ans[j]*10+(s[i]-'0'))%f[j];
			}
		}
		int hh=0;
		for(int i=1;i<=4;i++)hh=hh+(a[i][ans[i]]);
		printf("%d\n",hh%5);
	}
	return 0;
}
