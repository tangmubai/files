#include <cstdio>
#include <iostream>
using namespace std;
bool s[1000010];int a[1000010];
long long abss(long long x){
	if(x<0)return -x;
	return x;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	int t,len=0;scanf("%d",&t);
	for(int i=2;i<=1000000;i++)
		if(s[i]==0){
			a[++len]=i*i;
			for(int j=2;i*j<=1000000;j++)
				s[i*j]=1;
		}
	//printf("%d\n",len);
	while(t--){
		long long n,ans=999999999999999999,m,mm;
		scanf("%lld",&n);bool ok;
		for(long long i=0;;i++){
			m=mm=n+i;ok=1;
			for(long long j=2;ok&&j*j<=mm;j++){
				int s=0;
				while(m%j==0){
					m/=j;
					s++;
				}
				if(s!=0&&s!=2)ok=0;
			}
			if(m!=1)ok=0;
			if(ok){
				printf("%lld\n",i);
				break;
			}
			if(i>n)continue;
			m=mm=n-i;ok=1;
			for(long long j=2;ok&&j*j<=mm;j++){
				int s=0;
				while(m%j==0){
					m/=j;
					s++;
				}
				if(s!=0&&s!=2)ok=0;
			}
			if(m!=1)ok=0;
			if(ok){
				printf("%lld\n",i);
				break;
			}
		}
	}
	return 0;
}
