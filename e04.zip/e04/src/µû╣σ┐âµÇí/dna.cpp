#include <cstdio>
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		int n,ans;scanf("%d",&n);
		if(n==1){
			puts("2");
			continue;
		}
		if(n==2){
			puts("4");
			continue;
		}
		if(n==3){
			puts("6");
			continue;
		}
		if(n==4){
			puts("9");
			continue;
		}
//		int a=n,b=n-1,c=n-2;bool ok2=1,ok3=1;
//		if(ok2&&a%2==0){
//			a/=2;ok2=0;
//		}
//		if(ok2&&b%2==0){
//			b/=2;ok2=0;
//		}
//		if(ok2&&c%2==0){
//			c/=2;ok2=0;
//		}
//		if(ok3&&a%3==0){
//			a/=3;ok3=0;
//		}
//		if(ok3&&b%3==0){
//			b/=3;ok3=0;
//		}
//		if(ok3&&c%2==0){
//			c/=3;ok3=0;
//		}
//		ans=(int)((1ll*a*b%10007*c)%10007);
		int f1=1,f2=2,f3=2,f4=3,f5,g1=1,g2=2,g3=4,g4=6,g5;
		for(int i=1;i<=n-4;i++){
			g5=(f4+g4)%10007;f5=(f2+2*g2)%10007;
			f1=f2;f2=f3;f3=f4;f4=f5;
			g1=g2;g2=g3;g3=g4;g4=g5;
		}
		ans=(f5+g5)%10007;
		printf("%d\n",ans);
	}
	return 0;
}
