#include <cstdio>
#include <cstring>
using namespace std;
int a[100010];long long f[100010];
long long mx(long long x,long long y){
	return x>y?x:y;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		int n,x;scanf("%d",&n);memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++){
			scanf("%d",&x);
			a[x]++;
		}
		memset(f,0,sizeof(f));
		for(int i=1;i<=100000;i++)
			f[i]=mx(f[i-1],f[i-2]+a[i]*i);
		printf("%lld\n",f[100000]);
	}
	return 0;
}
