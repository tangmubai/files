#include <cstdio>
#include <cstring>
using namespace std;
char s[100010];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;scanf("%d\n",&t);
	while(t--){
		scanf("%s",s);
		int l=strlen(s);
		int n=(s[l-2]-'0')*10+(s[l-1]-'0'),ans;
		if(n%4==0)ans=4;
		else ans=0;
		printf("%d\n",ans);
	}
	return 0;
}
