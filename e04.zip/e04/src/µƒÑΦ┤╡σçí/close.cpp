#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

long long test_num,n,tmp,ans,prime_num;
long long prime[20005];
bool notp[40005];

inline long long read(){
	long long s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

void Ol_prime(long long n){
	notp[1]=1;
	for(long long i=2;i<=n;++i){
		if(!notp[i]){
			prime[++prime_num]=i;
		}
		for(long long j=1;j<=prime_num && i<=n/prime[j];++j){
			notp[i*prime[j]]=1;
			if(i%prime[j]==0){
				break;
			}
		}
	}
	return;
}

long long mabs(long long x){
	return x>=0?x:-x;
}

bool test(long long x){
	for(long long i=1;i<=prime_num && prime[i]<=n/2;++i){
		if(x%prime[i]==0 && x/prime[i]%prime[i]==0)return false;
//		if(x%prime[i]==0)printf("%lld ",prime[i]);
	}
//	printf("\n");
	return true;
}

int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	test_num=read();
	Ol_prime(40000);
	while(test_num--){
		n=read();
		ans=(1ll<<62)-1+(1ll<<62);
		tmp=(long long)(sqrt(n));
		for(long long i=tmp;i;--i){
			if(test(i)){
				ans=min(ans,mabs(i*i-n));
				break;
			}
		}
		for(long long i=tmp+1;i;++i){
			if(mabs(i*i-n)>=ans)break;
			if(test(i)){
				ans=min(ans,mabs(i*i-n));
				break;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
