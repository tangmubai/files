#include <cstdio>
#include <algorithm>
#define mod 10007
using namespace std;

int test_num,n,mx,sum;
int f[10][3],q[15],ans[15];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int find(int x){
	int l=1,r=test_num,mid;
	while(l<=r){
		mid=(l+r)>>1;
		if(q[mid]<=x){
			l=mid+1;
		}else {
			r=mid-1;
		}
	}
	if(q[r]==x){
		return r;
	}else {
		return -1;
	}
}

int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	test_num=read();
	for(int i=1;i<=test_num;++i){
		int x=read();
		q[i]=x;
		mx=max(mx,x);
	}
	sort(q+1,q+test_num+1);
	f[1][0]=1,f[1][1]=1;
	f[2][0]=2,f[2][1]=2;
	f[3][0]=4,f[3][1]=2;
	sum=6;
	for(register int i=4;i<=mx;++i){
		f[i%4][0]=sum;
		f[i%4][1]=(f[(i-2)%4][0]+f[(i-3)%4][0])%mod;
		sum=(sum+f[i%4][1])%mod;
		register int pos=find(i);
		if(pos!=-1){
			ans[pos]=(f[i%4][0]+f[i%4][1])%mod;
		}
	}
	for(int i=1;i<=test_num;++i){
		printf("%d\n",ans[i]);
	}
	return 0;
}
