#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

struct Node{
	int num,count;
}a[100005];

bool operator<(const Node &a,const Node &b){
	return a.num*a.count>b.num*b.count;
}

int test_num,n;
long long ans;
bool use[100005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	test_num=read();
	while(test_num--){
		n=read();
		ans=0;
		for(int i=1;i<=100000;++i){
			a[i].num=a[i].count=0;
		}
		for(int i=1;i<=n;++i){
			int x=read();
			a[x].num=x;
			++a[x].count;
		}
		sort(a+1,a+n+1);
		memset(use,0,sizeof(use));
		for(int i=1;i<=n;++i){
			if(!use[a[i].num]){
				ans+=1ll*a[i].num*a[i].count;
				use[a[i].num-1]=use[a[i].num+1]=1;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
