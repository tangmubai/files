#include <cstdio>
#include <cstring>

int test_num,n;
int a2[10]={1,2,4,3},a3[10]={1,3,4,2},a4[10]={1,4};
char s[100005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	test_num=read();
	while(test_num--){
		scanf("%s",s+1);
		n=strlen(s+1);
		for(int i=1;i<=n;++i){
			s[i]-='0';
		}
		int tmp=(s[n]+s[n-1]*10)%4,tmp2=s[n]%2;
		printf("%d\n",(1+a2[tmp]+a3[tmp]+a4[tmp2])%5);
	}
	return 0;
}
