#include<stdio.h>
#include<math.h>
long long x,y,z,minn;
int t;
bool check(long long n){
	for(register long long i=2,j=4;j<=n;++i,j+=(i<<1)-1){
		if(n%i==0){
			n/=i;
			if(n%i==0)return 0;
		}
	}
	return 1;
}
int main(){
	freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&x);
		y=sqrt(x);z=0;
		for(register long long i=y;i>=2;--i){
			if(check(i)){
				z=i;break;
			}
		}
		if(z)
		minn=x-z*z;z=0;
		for(register long long i=y+1;;++i){
			if(check(i)){
				z=i;break;
			}
		}
		if(z){
			z=z*z-x;
			if(minn>z)minn=z;
		}
		printf("%lld\n",minn);
	}
}
