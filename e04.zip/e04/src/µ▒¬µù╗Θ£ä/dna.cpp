#include<stdio.h>
int a[4000001],b[4000001],c[4000001],d[4000001],e[4000001],f[4000001];
int t,n,x;
int main(){
	freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
	a[1]=b[1]=c[1]=d[1]=e[1]=f[1]=1;
	for(register int i=2;i<=400000;++i){
		a[i]=a[i-1]+b[i-1]+c[i-1]+d[i-1]+e[i-1]+f[i-1];
		b[i]=a[i-1]+b[i-1]+e[i-1];
		c[i]=a[i-1]+b[i-1]+c[i-1]+d[i-1];
		d[i]=a[i-1]+b[i-1];
		e[i]=a[i-1]+b[i-1]+c[i-1]+d[i-1]+e[i-1]+f[i-1];
		f[i]=a[i-1]+b[i-1]+c[i-1]+d[i-1];
		a[i]%=10007;b[i]%=10007;c[i]%=10007;
		d[i]%=10007;e[i]%=10007;f[i]%=10007;
	}
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		x=n/3;
		if(n%3==0)
		printf("%d\n",(a[x]+b[x]+c[x]+d[x]+e[x]+f[x])%10007);
		else if(n%3==1)
		printf("%d\n",(a[x]*2+b[x]*2+c[x]+d[x]+e[x]*2+f[x])%10007);
		else printf("%d\n",(a[x]*4+b[x]*4+c[x]*2+d[x]*2+e[x]*2+f[x])%10007);
	}
}
