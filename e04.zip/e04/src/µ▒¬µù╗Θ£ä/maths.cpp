#include<stdio.h>
#include<string.h>
char c[100005];
int t,len,s;
int main(){
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",c+1);
		len=strlen(c+1);
		if((c[len]-'0')&1){
			printf("0\n");continue;
		}
		for(register int i=1;i<=len;++i){
			s=(s<<1)+(s<<3)+c[i]-'0';
			s&=3;
		}
		if(s)printf("0\n");
		else printf("4\n");
	}
}
