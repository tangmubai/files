#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include<algorithm>
using namespace std;
int t,n,ans;
void jw(bool s2,bool s1,int i){
	if(i>n){
		ans=(ans%10007+1)%10007;
	    return;
	}
	if(s2==1&&s1==0)
		jw(s1,0,i+1);
	else
	    if(s2==1&&s1==1)
	        jw(s1,0,i+1);
	    else{
	    	jw(s1,0,i+1);
	    	jw(s1,1,i+1);
	    }
}
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		ans=0;
		scanf("%d",&n);
		jw(0,0,1);
		printf("%d\n",ans);
	}
	return 0;
}
/*
3
55532
67037881
83112846

8748
7631
7603
*/
