#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include<algorithm>
using namespace std;
int t,s1,s2,s3,ans,l,b[100010];
//long long a;
char a[100010];
void js(){
	s1=s1*(2%5)%5;
	s2=s2*(3%5)%5;
	s3=s3*(4%5)%5;
}
void jf(char *a,int l){
	int i=l-1;
	b[i]=(a[i]-'0')-1;
	while(b[i]<=0&&i){
		b[i]+=9;
		b[i-1]=(a[i-1]-'0')-1;
	}
}
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		//scanf("%lld",&a);
		scanf("%s",a);
		l=strlen(a);
		l--;
		s1=1,s2=1,s3=1;
		while(b[0]!=0){
			js();
			//jf(a,l);
		}
		/*s1=1,s2=1,s3=1;
		while(a--){
			js();
		}*/
		ans=(s1+s2+s3+1)%5;
		printf("%d\n",ans);
	}
	return 0;
}
