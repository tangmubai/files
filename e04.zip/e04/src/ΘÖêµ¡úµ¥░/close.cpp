#include <iostream>
#include <cmath>
using namespace std;
typedef long long ll;
int t;
ll abbs(ll a,ll b){
	if(a-b)return a-b;
	else return b-a;
}
bool pd(ll x){
	for(ll i=2;i*i<=x;i++){
		if(x%i==0){
			x/=i;
			if(x%i==0)return 0;
		}
	}
	return 1;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	cin>>t;
	while(t--){
		ll x;
		cin>>x;
		ll ans;
		ll ls=(ll)(sqrt(x))+1;
		for(ll i=ls;;i++)
		if(pd(i)){
			ans=abbs(i*i,x);
			break;
		}
		for(ll i=ls-1;;i--){
			if(pd(i)&&i*i!=x){
				ans=min(ans,abbs(x,i*i));
				break;
			}
			if(abbs(x,i*i)>ans)break;
		}
		cout<<ans<<endl;
	}
}
