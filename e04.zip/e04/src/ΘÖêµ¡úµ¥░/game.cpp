#include <iostream>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <cstring>
using namespace std;
int t,n;
int a[100005];
int ans=-1;
void dfs(int num,int sum){
	if(!num){
		ans=max(ans,sum);
		return;
	}
	for(int i=1;i<=num;i++){
		vector<int>q;
		for(int j=1;j<=num;j++)
		q.push_back(a[j]);
		int t=0;
		for(int j=1;j<=num;j++)
		if(q[j]<a[i]-1||q[j]>a[i]+1||q[j]==a[i]&&i!=j)
		a[++t]=q[j];
		dfs(t,sum+a[i]);
		for(int j=1;j<=num;j++)
		a[j]=q[j];
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		ans=-1;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		dfs(n,0);
		cout<<ans;
	}
}
