#include <iostream>
#include <cstring>
using namespace std;
int t;
char c[100005];
int a2[5]={1,2,4,3};
int a3[5]={1,3,4,2};
int a4[3]={1,4};
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>c;
		int cc=strlen(c);
		int s=0;		
		int ans=1;
		if(cc!=1){
		s=s*10+(c[cc-2]-'0');
		s=s*10+(c[cc-1]-'0');
		ans+=a2[s%4];
		ans+=a3[s%4];
		ans+=a4[s%2];
		}
		else{
			s=s*10+(c[0]-'0');
			ans+=a2[s%4];
			ans+=a3[s%4];
			ans+=a4[s%2];
		}
		cout<<ans%5<<endl;
	}
}
