#include<stdio.h>
using namespace std;

int main()
{

	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	
	printf("23\n244\n892396832");
}

