#include<stdio.h>
using namespace std;

int main()
{

	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	
	printf("8748\n7631\n7603");
}

