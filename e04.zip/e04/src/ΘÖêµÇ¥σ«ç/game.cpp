#include<stdio.h>
using namespace std;
int a[100005];
int main()
{

	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	int n,t,i;
	
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(i=0;i<n;i++)scanf("%d",&a[i]);
		printf("%d\n",n+1);
		
		}
}

