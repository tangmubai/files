#include<stdio.h>
#include<string.h>
using namespace std;

char s[100005];
int  a[100005];
int main()
{
	
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	 int t,i,j;
	 scanf("%d",&t);
	 
	 while(t--)
	 {
	 	scanf("%s",s);
	 	int l=strlen(s)-1;
		 if((s[l]-'0')%2==1){
		 	printf("0\n");
		 	continue;
		 }	
		 
		 for(i=0;i<l;i++)a[i]=s[i]-'0';
		 
		 long long x=0;
		 for(i=0;i<l;i++)
		 {
		 	
		 	if(a[i]<4&&(x*10+a[i])<4)
		 	{
		 		x*=10+a[i];
		 		continue;
		 	}
		 	
			 if(a[i]<4&&(x*10+a[i])>4)
			 {
			 	x=x-(x*10+a[i])/4;
			 	continue;
			 }
		 	 
		 	x=x-(x*10+a[i])/4;
		 	
		 	
		 }
		 
		 if(x==0)printf("4\n");
		 else printf("0\n");
	 } 
	
}
