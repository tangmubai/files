#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
typedef long long ll;

bool check(ll x){
	for(ll i=2;i*i<=x;i++)
		if(x%i==0&&x%(i*i)==0) return false;
	return true;
}

int main(){
	freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		ll x;scanf("%lld",&x);
		ll rt=ll(sqrt(x)),i;
		for(i=rt;;i--)
			if(check(i)) break;
		ll ans=x-i*i;
		for(i=rt;;i++)
			if(check(i)) break;
		ans=min(ans,i*i-x);
		printf("%lld\n",ans);
	}
	return 0;
}
