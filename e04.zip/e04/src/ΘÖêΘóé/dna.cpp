#include<cstdio>
#include<cmath>
using namespace std;
typedef long long ll;

int main(){
	freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		ll len;scanf("%lld",&len);
		if(len==0) printf("1\n");
		else if(len==1) printf("2\n");
		else if(len==2) printf("4\n");
		else if(len==3) printf("6\n");
		else{
			ll ans=6;
			for(ll i=4;i<=len;i++){
				ll x=i-2;
				(ans+=x*(x+1)/2)%=10007;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
