#include<cstdio>
#include<cstring>
using namespace std;

int main(){
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		char n[100005];scanf("%s",n+1);
		int last=n[strlen(n+1)]-'0';
		int ans=0;
		//1^n
		ans++;
		//2^n
		if(last%4==0) ans+=1;
		if(last%4==1) ans+=2;
		if(last%4==2) ans+=4;
		if(last%4==3) ans+=3;
		//3^n;
		if(last%4==0) ans+=1;
		if(last%4==1) ans+=3;
		if(last%4==2) ans+=4;
		if(last%4==3) ans+=2;
		//4^n;
		if(last%2==0) ans+=1;
		if(last%2==1) ans+=4;
		ans%=5;
		printf("%d\n",ans);
	}
	return 0;
}
