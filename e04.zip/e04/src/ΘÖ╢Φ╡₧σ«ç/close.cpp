#include<iostream>
#include<cstdio>
#include<string>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
const ll oo=100000000000ll;
ll T,x;
ll yd;
ll ans;
ll l,r;
inline void read(ll &x)
{
	ll f=1;register char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline ll mn(ll _x,ll _y){
	return _x<_y?_x:_y;
}
inline bool check(ll v)
{
	ll k=2;
	int cnt;
	for(;k<=v/k;++k)
	{
		if(v%k==0)
		{
			v/=k;
			if(v%k==0) return false;
		}
	}
	return true;
}
int main()
{
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	read(T);
	while(T--)
	{
		read(x);
		yd=(ll)sqrt(x);
		ans=oo;	
		for(ll i=yd;i;--i){
			if(x-1ll*i*i>ans) break;;
			if(!check(i)) continue;
//			printf("%lld\n",i);
			ans=mn(ans,x-1ll*i*i);break;
		}
		for(ll i=yd+1;;++i)
		{
			if(1ll*i*i-x>ans) break;
			if(!check(i)) continue;
//			printf("%lld\n",i);
			ans=mn(ans,1ll*i*i-x);break;
		}
		printf("%lld\n",ans);
	}
	return 0;
}

