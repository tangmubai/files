#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
const int mod=10007;
int n;
int T;
int a[7000005],c[7000005],d[7000005];
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
int main()
{
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	read(T);
	a[1]=c[1]=1;
	a[2]/*=b[2]*/=c[2]=d[2]=1;
	for(register int i=3;i<=7000000;i++)
	{
		a[i]=(a[i-1]+d[i-1])%mod;
//		b[i]=c[i-1];
		c[i]=a[i-1];
		d[i]=(c[i-2]+c[i-1])%mod; 
	}
	while(T--){
		read(n);
		if(n==1) puts("2");
		else printf("%d\n",(a[n]+c[n-1]+c[n]+d[n])%mod);
	}
	return 0;
}

