#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
const int xh1[]={1,2,4,3};
const int xh2[]={1,3,4,2};
const int xh3[]={1,4};
char x[100005];
int a[100005];
int len;
int m1,m2; 
int T;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int div(int u)
{
	int r=0;
	for(int i=1;i<=len;i++)
	{
		r=r*10+a[i];
		r%=u;
	}
	return r;
}
int main()
{
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	read(T);
	while(T--){
		scanf("%s",1+x);
		len=strlen(1+x);
		memset(a,0,sizeof(a));
		for(int i=1;i<=len;i++)
			a[i]=x[i]-'0';
		m1=div(4);
		m2=div(2);
		printf("%d\n",(1+xh1[m1]+xh2[m1]+xh3[m2])%5); 
	}
	return 0;
}

