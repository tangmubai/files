#include<stdio.h>
#include<algorithm>
#include<cmath>
using namespace std;
inline long long read(){
	long long k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
long long aa(long long n){if(n<0)n=-n;return n;}
bool pz(long long n){
	for(long long i=2;i*i<=n;i++)if(n%i==0)return 0;
	return 1;
}
bool fj(long long ans){
	long long i=2;
	while(ans!=1){
		if(pz(ans))return 1;
		if(ans%i==0)ans/=i;
		if(ans%i==0)return 0;
		i++;
	}
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	long long t=read();
	while(t--){
		long long n=read();
		long long x=sqrt(n);long long i=0,ans=0;
		if(pz(x)){printf("%lld\n",aa(n-x*x));continue;}
		if(fj(x)){printf("%lld\n",aa(n-x*x));continue;}
		for(i=1;i<=x;i++){
			long long jx=x-i;bool jt=0;long long js=1000000000000000000,j;
			if(pz(jx)){jt=1;js=min(js,aa(n-jx*jx));}
			if(fj(jx)){jt=1;js=min(js,aa(n-jx*jx));}
			jx=x+i;
			if(fj(jx)){jt=1;js=min(js,aa(n-jx*jx));}
			if(jt==1){printf("%lld\n",js);break;}
		}
	}
	return 0;
}

