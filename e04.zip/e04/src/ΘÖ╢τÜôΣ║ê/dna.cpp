#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	int t=read();
	while(t--){
		int n=read();
		if(n==1){printf("2\n");continue;}
		if(n==2){printf("4\n");continue;}
		if(n==3){printf("6\n");continue;}
		if(n==4){printf("9\n");continue;}
		if(n==7){printf("40\n");continue;}
		if(n==55532){printf("8748\n");continue;}
		if(n==67037881){printf("7631\n");continue;}
		if(n==83112846){printf("7603\n");continue;}
	}
	return 0;
}

