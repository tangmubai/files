#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
struct pp{int jb,js;friend operator>(const pp &p1){return p1.js*1ll*p2.jb>js*1ll*jb;}};
map(pp);
int main(){
	//freopen("game.in","r",stdin);
	//freopen("game.out","w",stdout);
	return 0;
}

