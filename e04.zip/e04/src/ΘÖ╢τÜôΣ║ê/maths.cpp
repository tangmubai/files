#include<stdio.h>
#include<cstring>
#include<iostream>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
char a[100005];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t=read();
	for(int i=1;i<=t;i++){
		cin>>a;
		int j=strlen(a),x;j--;
		if(j==0)x=a[j]-'0';
		else x=(a[j]-'0')+(a[j-1]-'0')*10;
		if(x%4==0)printf("%d\n",4);
		else printf("%d\n",0);
	}
	return 0;
}

