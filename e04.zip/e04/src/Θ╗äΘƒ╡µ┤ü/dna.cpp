#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int t;
long long l;
int main(){
	freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&l);
		if(l==1) {printf("2\n");continue;}
		if(l==2) {printf("4\n");continue;}
		if(l==3) {printf("6\n");continue;}
		if(l==4) {printf("9\n");continue;}
		if(l==7) {printf("40\n");continue;}
		printf("%lld\n",((l%10007)*(l%10007))%10007-(l+2));
	}
	return 0;
}

