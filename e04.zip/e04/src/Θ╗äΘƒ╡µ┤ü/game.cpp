#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
int t,n,a[100005],ans=0;
bool v[100005]={0};
bool check(){
	for(int j=1;j<=n;j++) if(v[j]==0) return false;
	return true;
}
inline void dfs(int tot,int t){
	if(check()){
		ans=max(tot,ans);
		memset(v,0,sizeof(v));
		return;
	} 
	if(t==n&&!check()) return;
	for(int k=t+1;k<=n;k++){
		if(v[k]) continue;
		v[k]=1;
		for(int i=1;i<=n;i++) if(!v[i]) if(a[i]==a[k]-1 || a[i]==a[k]+1) v[i]=1;
		dfs(tot+a[k],k);
		v[k]=0;
	}
	return;
}
int main(){
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		dfs(0,0);
		printf("%d\n",ans);
	}
	return 0;
}
