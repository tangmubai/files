#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int t,ans,t2[4]={1,2,4,3},t3[4]={1,3,4,2},t4[2]={1,4};
char n[100005];
int main(){
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",n);
		ans=1;
		int len=strlen(n);
		int x=(n[len-1]-'0')+10*(n[len-2]-'0');
		ans=(t4[x%4]+ans)%5;
		ans=(t3[x%4]+ans)%5;
		ans=(t2[x%4]+ans)%5;
		printf("%d\n",ans);
	}
	return 0;
}

