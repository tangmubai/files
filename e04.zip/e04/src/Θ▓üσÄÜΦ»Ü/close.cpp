#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define ll long long
using namespace std;
int t,a[1000010];
ll n;
bool check(ll x)
{ll y=x;bool f=1;
 for(int i=2;i*i<=y;i++)
{if(y%i==0)
{y/=i;
 if(y%i==0)
{f=0;break;
}
}
}
 return f;
}
int main()
{freopen("close.in","r",stdin);freopen("close.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>n;
 ll q=sqrt(n);
 ll l=q,r=q;
 while(1)
{if(check(l)) break;
 l--;
}
  while(1)
{if(check(r)) break;
 r++;
}
 cout<<min(abs(n-l*l),abs(r*r-n))<<endl;
}
 return 0;
}
