#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int t,n,a[10000001];
int main()
{freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>n;
 memset(a,0,sizeof(a));
 a[1]=2;a[2]=4;a[3]=6;a[4]=9;
 for(int i=5;i<=n;i++)
 a[i]=a[i-1]+a[i-2]-1;
 cout<<a[n]<<endl;
}
 return 0;
}
