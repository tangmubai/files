#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int t,n,cnt,a[100010];
long long ans1,ans2;
bool cmp(int x,int y){return x<y;}
int main()
{freopen("game.in","r",stdin);freopen("game.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>n;ans1=ans2=cnt=0;
 for(int i=1;i<=n;i++) cin>>a[i];
 sort(a+1,a+n+1,cmp);a[0]=0;
 for(int i=1;i<=n;i++)
{if(a[i-1]+1==a[i]) cnt^=1;
 if(cnt==1) ans1+=a[i];
 else ans2+=a[i];
}
 cout<<max(ans1,ans2)<<endl;
}
 return 0;
}
