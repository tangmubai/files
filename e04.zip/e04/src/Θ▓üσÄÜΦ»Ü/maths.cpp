#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int t,cnt,n;
char a[100010];
int main()
{freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>a+1;cnt=1;
 int m=strlen(a+1);
 n=n+(a[m-1]-'0')*10+(a[m]-'0');n%=4;
 if(n==0) cout<<4<<endl;
 else cout<<0<<endl;
}
 return 0;
}
