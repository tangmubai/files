#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int t;long long n,m1,m2,ans;bool h1,h2;
bool ck(long long x){
	if(x==1) return 0;
	for(register long long i=2;i*i<=x;i++){
		if(x%(i*i)==0) return 0;
	}
	return 1;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&n);
		m1=(long long)(sqrt(n));
		m2=m1+1;ans=n;h1=h2=0;
		while(1){
			if(!h1&&ck(m1)&&ans>n-m1*m1){
				h1=1;ans=n-m1*m1;
			}
			if(!h2&&ck(m2)&&ans>m2*m2-n){
				h2=1;ans=m2*m2-n;
			}
			if(h1&&ans<=m2*m2-n) break;
			if(h2&&ans<=n-m1*m1) break;
			m1--;m2++;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
