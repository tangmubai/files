#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int t,n,x,mx;long long ans;
bool b[100005];
struct xl{
	long long sz,pb;int xh;
}a[100005];
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
bool cmp(xl x,xl y){
	if(x.sz==y.sz) return x.pb<y.pb;
	else return x.sz>y.sz;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	t=read();
	while(t--){
		n=read();mx=0;ans=0ll;
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		for(register int i=1;i<=n;i++){
			x=read();a[x].sz+=1ll*x;
			a[x].xh=x;
			a[x-1].pb+=1ll*x;
			a[x+1].pb+=1ll*x;
			mx=max(mx,x);
		}
		sort(a+1,a+mx+1,cmp);
		for(register int i=1;i<=mx;i++){
			if(b[a[i].xh]){
				continue;
			}
			if(a[i].sz==0) break;
			ans+=1ll*a[i].sz;
			b[a[i].xh-1]=1;
			b[a[i].xh+1]=1;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
