#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
char s[100005];int t,l,n;
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",s);
		l=strlen(s);
		if(l==1){
			n=s[l-1]-'0';
			switch(n%4){
				case 0:printf("4\n");break;
				case 1:printf("0\n");break;
				case 2:printf("0\n");break;
				case 3:printf("0\n");break;
			}
			continue;
		}
		n=(s[l-2]-'0')*10+(s[l-1]-'0');
		switch(n%4){
			case 0:printf("4\n");break;
			case 1:printf("0\n");break;
			case 2:printf("0\n");break;
			case 3:printf("0\n");break;
		}
	}
	return 0;
}
