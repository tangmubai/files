#include<cstdio>
using namespace std;
bool hrq(long long x){
	if(x%2==0){
		int num=0;
		while(x%2==0){
			num++;
			x/=2;
		}
		if(num!=2) return 0;
	}
	for(int i=3;i*i<=x;i+=2){
		if(x%i==0){
			int num=0;
			while(x%i==0){
				num++;
				x/=i;
			}
			if(num!=2) return 0;
		}
	}
	if(x!=1) return 0;
	return 1;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		long long x;scanf("%lld",&x);
		for(long long i=1;i<=x;i++){
			if(hrq(x-i)==1||hrq(x+i)==1){
				printf("%lld\n",i);
				break;
			}
		}
	}
	return 0;
}

