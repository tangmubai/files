#include<cstdio>
using namespace std;
int a[100000010];
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		int l;scanf("%d",&l);
		a[1]=2;
		a[2]=6;
		for(int i=3;i<=l;i++)
			a[l]=(a[l-1]+a[l-2])%10007;
		printf("%d\n",a[l]);
	}
	return 0;
}

