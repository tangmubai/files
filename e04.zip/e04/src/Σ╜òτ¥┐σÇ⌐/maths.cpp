#include<cstdio>
#include<cstring>
using namespace std;
char a[100010];
int hrq(){
	int x=0;
	int ans=0;
	for(int i=0;i<strlen(a);i++){
		int num=x*10+(a[i]-'0');
		ans=num%4;
		x=ans;
	}
	return ans;
}
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		memset(a,'\0',sizeof(a));
		scanf("%s",a);
		int ans=hrq();
		if(ans%4==0){
			printf("4\n");
		}
		else printf("0\n");
	}
	return 0;
}
