#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
typedef long long ll;
const ll INF = 1e18 + 5;
ll t, num, ans, x;
void read(ll &x)
{
	char c = getchar(); ll f = 1; x = 0;
	while (c < '0' || c > '9') { if (c == '-') f = -1; c = getchar(); }
	while (c >= '0' && c <= '9') { x = x * 10 + c - '0'; c = getchar(); }
	x *= f;
}
bool check(ll v)
{
	ll k = 2; int cnt;
	for (; k <= v / k; ++k)
	{
		if (v % k == 0)
		{
			v /= k;
			if (v % k == 0) return 0;
		}
	}
	return 1;
}
int main()
{
	freopen("close.in", "r", stdin);
	freopen("close.out", "w", stdout);
	read(t);
	while(t--)
	{
		read(x);
		num = (ll)sqrt(x); ans = INF;
		for (ll i = num + 1; ; i++)
		{
			if (1ll * i * i > ans) break;
			if (!check(i)) continue;
			ans = min(ans, 1ll * i * i - x); 
			break;
		}
		for (ll i = num;i; i--)
		{
			if (x - 1ll * i * i > ans) break;
			if (!check(i)) continue;
			ans = min(ans, x - 1ll * i * i); 
			break;
		}
		printf("%lld\n", ans);
	}
	return 0;
}

