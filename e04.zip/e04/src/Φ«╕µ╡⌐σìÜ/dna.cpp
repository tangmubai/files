#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int mod = 10007;
int n, t, a[7000005], b[7000005], c[7000005], d[7000005];
void read(int &x)
{
	char c = getchar(); int f = 1; x = 0;
	while (c < '0' || c > '9') { if (c == '-') f = -1; c = getchar(); }
	while (c >= '0' && c <= '9') { x = x * 10 + c - '0'; c = getchar(); }
	x *= f;
}
int main()
{
	freopen("dna.in", "r", stdin);
	freopen("dna.out", "w", stdout);
	read(t);
	a[2] = b[2] = c[2] = d[2] = 1;
	for (int i = 3; i < 7000005; i++)
	{
		a[i] = (a[i - 1] + d[i - 1]) % mod;
		b[i] = c[i - 1];
		c[i] = a[i - 1];
		d[i] = (b[i - 1] + c[i - 1]) % mod;
	}
	while(t--)
	{
		read(n);
		if (n == 1) puts("2");
		else printf("%d\n", (a[n] + b[n] + c[n] + d[n]) % mod);
	}
	return 0;
}
