#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	puts("355099");
	puts("4682676879");
	return 0;
}

