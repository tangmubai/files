#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int xh1[] = {1, 2, 4, 3};
const int xh2[] = {1, 3, 4, 2};
const int xh3[] = {1, 4};
int t, a[1000005], len, m1, m2; char x[1000005];
void read(int &x)
{
	char c = getchar(); int f = 1; x = 0;
	while (c < '0' || c > '9') { if (c == '-') f = -1; c = getchar(); }
	while (c >= '0' && c <= '9') { x = x * 10 + c - '0'; c = getchar(); }
	x *= f;
}
int div(int u)
{
	int r = 0;
	for (int i = 1; i <= len; i++)
	{
		r = r * 10 + a[i];
		r %= u;
	}
	return r;
}
int main()
{
	freopen("maths.in", "r", stdin);
	freopen("maths.out", "w", stdout);
	read(t);
	while(t--)
	{
		scanf("%s", x + 1);
		len = strlen(x + 1);
		memset(a, 0, sizeof(a));
		for (int i = 1; i <= len; i++)
			a[i] = x[i] - '0';
		m1 = div(4);
		m2 = div(2);
		printf("%d\n", (1 + xh1[m1] + xh2[m1] + xh3[m2]) % 5);
	}
	return 0;
}

