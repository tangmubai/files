#include<stdio.h>
#include<math.h>
#include<iostream>
const int N = 10000;
#define LL long long
using namespace std;

LL n;
int tot, p[N + 5], v[N + 5];
LL ans = 1;

void Prime() {
	for(int i = 2; i < N; ++i) {
		if (v[i] == 0)
			p[++tot] = i;
		else continue;
		for(int j = 2 * i;  j <= N; j += i)
			v[j] = 1;	
	}
}

LL abs(LL x) {
	if (x < 0)
		return -x;
	else return x;	
}

LL min(LL x, LL y) {
	if (x < y)
		return x;
	else return y;	
}

int main() {
	freopen("close.in", "r", stdin);
	freopen("close.out", "w", stdout);
	Prime();
	
	int t;
	scanf("%d", &t);
	while(t--) {
		scanf("%lld", &n);
		ans = 1e18;
		int x = sqrt(n);
		for(int i = x; i; --i) {
			LL tp = i, flag = 1, oes = i;
			for(int j = 1; j <= tot && p[j] * 1ll* p[j] <= tp; ++j)
				if (tp % p[j] == 0) {
					tp /= p[j];
					if (tp % p[j] == 0)
						flag = 0;
				}
			if (flag == 1) {
				ans = min(ans, abs(oes * oes - n));
				break;
			}
				
		}
		for(int i = x; i; ++i) {
			LL tp = i, flag = 1, oes = i;
			for(int j = 1; j <= tot && p[j] * 1ll * p[j] <= tp; ++j)
				if (tp % p[j] == 0) {
					tp /= p[j];
					if (tp % p[j] == 0)
						flag = 0;
				}
			if (flag == 1) {
				ans = min(ans, abs(oes * oes - n));
				break;
			}
				
		}
		cout <<ans << endl;
	}
	return 0;	
}
