#include<stdio.h>
const int Mod = 10007;
int t, n, f[5][2][2];
int main() {
	freopen("dna.in", "r", stdin);
	freopen("dna.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		f[0][1][1] = 1;
		
		for(int i = 1; i <= n; ++i) {
			f[i % 2][1] = (f[(i + 1) % 2][0] + f[(i + 1) % 2][1] ) % Mod;
			f[i % 2][0] = f[(i + 1) % 2][1]; 
		}
		int ans = 1;
		for(int i = 1; i <= n; ++i)
			ans = (ans * 2) % Mod;
		ans -= f[n % 2][1];
		while(ans < 0)
			ans += Mod;
		printf("%d\n", ans);
	}
	return 0;
}
