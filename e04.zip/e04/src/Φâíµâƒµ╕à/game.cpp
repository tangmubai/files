#include<stdio.h>
#include<iostream>
#include<algorithm>
#define LL long long
const int N = 1e5;
using namespace std;
int t, n, a[N + 5]; 
int main() {
//	freopen("game.in", "r", stdin);
//	freopen("game.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		for(int i = 1; i <= n; ++i)
			scanf("%d", a + i);
		sort(a + 1, a + n + 1);
		int bt = n;
		LL ans = 0;
		while(1) {
			ans += a[bt];
			int i;
			for(i = bt - 1; a[i] == a[bt] && i >= 1; --i)
				ans += a[i];
			for(; a[i] == a[bt] - 1 && i >= 1; --i);
			bt = i;
			if (bt < 1)
				break;
		}
		cout << ans << endl;	
	}
	return 0;
}
