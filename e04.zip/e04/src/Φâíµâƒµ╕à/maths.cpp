#include<stdio.h>
#include<iostream>
#include<string.h>
using namespace std;
int t;
char s[100005];

void read(int &x) {
	x = 0;char c = getchar(); int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;		
}

int main() {
	freopen("maths.in", "r", stdin);
	freopen("maths.out", "w", stdout);
	scanf("%d\n", &t);
	while(t--) {
		scanf("%s", s + 1);
		int l = strlen(s + 1), tp;
		if (l == 1)
			tp = (s[l] - '0') % 4;
		else tp = ((s[l - 1] - '0') * 10 + (s[l] - '0') )% 4;
		if (tp == 0)
			cout << 4 << endl;
		if (tp == 1)
			cout << 0 << endl;
		if (tp == 2)
			cout << 0 << endl;
		if (tp == 3)
			cout << 0 << endl;			
	}
	return 0;	 
}
