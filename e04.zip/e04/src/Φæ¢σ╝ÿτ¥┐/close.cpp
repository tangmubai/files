#include <stdio.h>
#include <cmath>
#define ll long long
ll t,n,prime[3500005],u,num;
ll Max(ll a,ll b){
	if(a>b)return a;
	else return b;
}
bool zs(ll a){
	for(int i=2;i<=sqrt(a);i++)	
		if(a%i==0)return 1;
	return 0;
}
void db(){
	for(int i=2;i<=u;i++){
		if(zs(i)){
			prime[++num]=i;
		}
	}
}
int main(){
//	freopen("close.in","r",stdin);
//	freopen("close.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		u=-1;num=0;
		scanf("%lld",&n);
		for(int i=2;i*i<=n;i++){
			while(n%i==0){
				n/=i;
			}
			u=Max(u,i);
		}
		u=Max(u,n);
		db();
		for(int i=1;i<=num;i++){	
			for(int j=1;j<=num;j++)	
				xuanhuobuxuanyou
			
		}
	}
	return 0;
}
