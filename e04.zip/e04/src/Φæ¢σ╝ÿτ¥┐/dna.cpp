#include <stdio.h>
int t;


int main(){
//	freopen("dna.in","r",stdin);
//	freopen("dna.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		
		
		
	
		
		
	}
	return 0;
}
