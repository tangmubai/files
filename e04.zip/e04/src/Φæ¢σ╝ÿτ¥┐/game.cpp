#include <stdio.h>
#include <cstring>
int k,n,a[100005],t[100005],ans=-1;
bool vis[100005];
bool check(){
	int s=0;
	for(int i=1;i<=n;i++)
		if(t[a[i]]==-1||vis[i]==1)s++;
	return s==n;
}
void dfs(int s){
	if(check()){
		if(s>ans)
			ans=s;
		return;
	}	
	for(int j=1;j<=n;j++){
		if(!vis[j]){
			vis[j]=1;
			if(t[a[j]]!=-1){
				t[a[j]-1]=-1;
				t[a[j]+1]=-1;
				dfs(s+a[j]);
				t[a[j]-1]=0;
				t[a[j]+1]=0;	
			}
			dfs(s);
		}
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&k);
	while(k--){
		ans=-1;
		memset(t,0,sizeof(t));
		memset(a,0,sizeof(a));
		memset(vis,0,sizeof(vis));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		dfs(0);
		printf("%d\n",ans);
	}	
	return 0;
}
