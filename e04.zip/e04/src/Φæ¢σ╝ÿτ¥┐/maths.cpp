#include <stdio.h>
#include <cstring>
#include <iostream>
using namespace std;
int t,len;
char a[100005];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		cin>>a;
		len=strlen(a);
		int tmp=((a[len-2]-'0')*10+(a[len-1]-'0'))%4;
		if(tmp==0){
			printf("4\n");
			continue;
		}
		if(tmp==1){
			printf("0\n");
			continue;
		}
		if(tmp==2){
			printf("0\n");
			continue;
		}
		if(tmp==3){
			printf("0\n");
			continue;
		}
	}
	return 0;
}
