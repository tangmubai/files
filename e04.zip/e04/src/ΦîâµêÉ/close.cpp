#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
typedef long long ll;
ll ab(ll n){
	return n<0?-n:n;
}
bool is(int n){
	for(int i=2;i*i<=n;++i){
		if(n%i==0){
			n/=i;
			if(n%i==0) return false;
		}
	}
	return true;
}
int main(){
	freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		ll x;scanf("%lld",&x);
		int y=sqrt(x);
		ll ans=1e17;
		while(y>1){
			if(is(y)){
				ans=min(ans,x-1LL*y*y);
				break;
			}
			--y;
		}
		y=sqrt(x);
		while(1){
			if(ab(1LL*y*y-x)>ans) break;
			if(is(y)){
				ans=min(ans,ab(x-1LL*y*y));
				break;
			}
			++y;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
