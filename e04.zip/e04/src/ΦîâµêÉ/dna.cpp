#include <cstdio>
#include <algorithm>
using namespace std;
const int mod=10007;
int dp[4];
struct qwq{
	int n,pos,ans;
}a[21];
bool cmp1(qwq x,qwq y){
	return x.n<y.n;
}
bool cmp2(qwq x,qwq y){
	return x.pos<y.pos;
}
int main(){
	freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;++i){
		scanf("%d",&a[i].n);
		a[i].pos=i;
	}
	sort(a+1,a+t+1,cmp1);
	dp[0]=dp[1]=dp[2]=dp[3]=1;
	int l=3;
	for(int i=1;i<=t;++i){
		if(a[i].n==1){
			a[i].ans=2;
			continue;
		}
		int n=a[i].n;
		for(;l<=n;++l){
			int a=dp[0],b=dp[1],c=dp[2],d=dp[3];
			dp[0]=dp[1]=dp[2]=dp[3]=0;
			dp[0]=(a+c)%mod;
			dp[1]=(a)%mod;
			dp[2]=(b+d)%mod;
			dp[3]=(b)%mod;
		}
		a[i].ans=(dp[0]+dp[1]+dp[2]+dp[3])%mod;
	}
	sort(a+1,a+t+1,cmp2);
	for(int i=1;i<=t;++i){
		printf("%d\n",a[i].ans);
	}
	return 0;
}
