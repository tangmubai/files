#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
template<typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
int a[100005];
struct qwq{
	int v;int n;
}b[100005];
long long dp[100005];
int main(){
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		int n;in(n);
		for(int i=1;i<=n;++i) in(a[i]);
		sort(a+1,a+n+1);
		long long ans=0;
		int tot=0;
		for(int i=1;i<=n;){
			b[++tot].v=a[i];
			int k=upper_bound(a+1,a+n+1,a[i])-a;
			b[tot].n=k-i;
			i=k;
		}
		b[0].v=-233;
		dp[0]=0;
		int now=0;
		for(int i=1;i<=n;++i){
			if(b[i].v==b[i-1].v+1){
				++now;
				dp[now]=max(dp[now-1],dp[now-2]+1LL*b[i].v*b[i].n);
			}
			else{
				ans+=dp[now];
				now=1;
				dp[now]=1LL*b[i].v*b[i].n;
			}
		}
		ans+=dp[now];
		printf("%lld\n",ans);
	}
	return 0;
}
