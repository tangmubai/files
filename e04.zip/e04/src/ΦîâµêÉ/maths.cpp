#include <cstdio>
#include <algorithm>
using namespace std;
char c[100005];
int a[5][5]={
	{0,0,0,0},
	{1,1,1,1},
	{1,2,4,3},
	{1,3,4,2},
	{1,4,1,4}
};
int main(){
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		scanf("%s",c+1);
		int x=0;
		for(int i=1;c[i];++i){
			x=x*10+(c[i]-'0');
			x%=4;
		}
		printf("%d\n",(a[1][x]+a[2][x]+a[3][x]+a[4][x])%5);
	}
	return 0;
}
