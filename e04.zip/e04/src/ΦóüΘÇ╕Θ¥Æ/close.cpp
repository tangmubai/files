#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
typedef long long ll;
const ll oo = 1e18;
inline ll read(ll &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline ll mn(ll x, ll y) {
	return x < y ? x : y;
}
inline ll check(ll x) {
	ll t = x;
	ll sum;
	for (register ll i = 2; i <= sqrt(x); i ++) {
		sum = 0;
		while (x % i == 0) sum ++, x /= i;
		if (sum > 1) return 0;
	}
	return t * t;
}
inline ll as(ll x, ll y) {
	ll z = x-y;
	return z > 0 ? z : -z;
}
main() {
	freopen ("close.in", "r", stdin);
	freopen ("close.out", "w", stdout);
	ll t;
	read(t);
	while (t --) {
		ll x, y = 0, ans = oo, now1, now2;
		read(x);
		ll sq = sqrt(x);
		for (register ll i = 0; i <=sq; i ++) {
			y = check(sq-i);
			now1 = as(y, x);
			ans = mn(ans, now1);
			y = check(sq+i);
			now2 = as(y, x);
			if (now1 > ans && now2 > ans) break;
			ans = mn(ans, now2);
		}
		
		printf ("%lld\n", ans);
	}
	return 0;
}
