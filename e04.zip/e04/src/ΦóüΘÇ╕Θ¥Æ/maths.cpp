#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
char n[100005];
main() {
	freopen ("maths.in", "r", stdin);
	freopen ("maths.out", "w", stdout);
	int t;
	read(t);
	while (t --) {
		scanf ("%s", &n);
		int len = strlen(n);
		if (len >= 2) {
			int sec = n[len-2] - 48;
			int lat = n[len-1] - 48;
			int a2, a3;
			int tot = sec * 10 + lat;
			if (tot % 4 == 1) a2 = 2, a3 = 3;
			else if (tot % 4 == 2) a2 = 4, a3 = 9;
			else if (tot % 4 == 3) a2 = 8, a3 = 7;
			else if (tot % 4 == 0) a2 = 6, a3 = 1;
			if (lat % 2) printf ("%d\n", (a2+a3) % 5);
			else printf ("%d\n", (a2+a3+7) % 5);
		}
		else {
			int x2 = 1, x3 = 1, x4 = 1;
			for (register int i = 1; i <= n[0]-48; i ++) {
				x2 *= 2;
				x3 *= 3;
				x4 *= 4;
			}
			printf ("%d\n", (x2+x3+x4+1) % 5);
		}
	}
	return 0;
}
