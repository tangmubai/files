#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
typedef long long ll;
int t;
ll n;
bool calc (ll x) {
	for (ll i = 2; i * i <= x; i ++) {
		int cnt = 0;
		while (x % i == 0) {
			x /= i;
			if (++ cnt > 2)
				return 0;
		}
		if (cnt && cnt != 2)
			return 0;
	}
	if (x > 1)
		return 0;
	return 1;
}
int main () {
	freopen ("close.in", "r", stdin);
	freopen ("close.out", "w", stdout);
	 
	scanf ("%d", &t);
	while (t --) {
		scanf ("%lld", &n);
		for (ll i = 0; ; i ++) {
			ll q1 = n - i, q2 = n + i;
			bool res = calc (q1) | calc (q2);
			if (res) {
				printf ("%lld\n", i);
				break;
			}
		}
	}
}	
/*
1112 = 2 ^ 3  
*/

