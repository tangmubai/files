#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int len, ans;
string str;
bool check (string str) {
	for (int i = 0; i + 2 < len; i ++)
		if (str[i] == str[i + 2] && str[i] == '1')
			return 0;
	return 1;
}
void search (int step, string str) {
	if (step == len + 1) {
		if (check(str))
			ans ++;
		return ;
	}
	search (step + 1, str + '0');
	search (step + 1, str + '1');
}
int f[2580][2];
int main () {
	freopen ("dna.in", "r", stdin);
	freopen ("dna.out", "w", stdout);
	
	scanf ("%d", &len);
	search (1, "");
	printf ("%d", ans % 10007);
	//
}
/*
L = 4
1010
1011
0101
1101
1110
0111
1111

L = 5
10100
10101
10110
10111

01010
01011
11010
11011

00101
01101
10101
11101

2 * 2 * 
*/

