#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <cstring>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int t;
char n[100005];
int main () {
	freopen ("maths.in", "r", stdin);
	freopen ("maths.out", "w", stdout);
	t = read();
	while (t --) {
		scanf ("%s", n + 1);
		n[0] = '0';
		int len = strlen (n + 1);
		int x = (n[len - 1] - '0') * 10 + n[len] - '0'; 
		printf ("%d\n", x % 4 == 0 ? 4 : 0);
	}
}
/*
1 1 1 1
2 4 3 1
3 4 2 1
4 1 4 1


*/

