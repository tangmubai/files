#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register long long
#define maxs 1000000000000000000ll

using namespace std;
long long work(ll root){
	ll ok=0;
	ll x=root;
	for(ll i=2;i*i<=root;i++){ok=0;
		while(root%i==0)ok++,root/=i;
		if(ok>1)return 0;
	}
	return x*x;
}
int main(){freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	ll t;
	ll x=0;
	ll n;
	ll result=maxs;
	scanf("%lld",&t);
	while(t--){
		result=maxs;
		scanf("%lld",&n);
		ll root=sqrt(n);
		for(ll i=0;i<=root;i++){
			x=work(root-i);
			if(x!=0ll)
				result=min(result,abs(x-n));
			x=work(root+i);
			if(x!=0ll)
				result=min(result,abs(x-n));
			if(result!=maxs)break;
		}
		printf("%lld\n",result);
	}
	return 0;
}


