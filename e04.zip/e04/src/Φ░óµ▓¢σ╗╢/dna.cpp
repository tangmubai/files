#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<string>
#define ll register int
#define mod 10007;

using namespace std;
int a[10000007],b[10000007],c[10000007],d[10000007];
int main(){freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
	ll n;
	a[2]=b[2]=c[2]=d[2]=1;
	for(ll i=2;i<=10000006;i++){
		b[i+1]+=a[i];
		c[i+1]+=a[i];
		d[i+1]+=b[i];
		b[i+1]+=c[i];
		a[i+1]+=d[i];
		d[i+1]+=d[i];
		a[i+1]%=mod;b[i+1]%=mod;c[i+1]%=mod;d[i+1]%=mod;
	}
	ll t,sum=0;
	scanf("%d",&t);
	for(ll i=1;i<=t;i++){
		scanf("%d",&n);
		sum=a[n]+b[n]+c[n]+d[n];
		sum%=mod;
		printf("%d\n",sum);
	}
	return 0;
}


