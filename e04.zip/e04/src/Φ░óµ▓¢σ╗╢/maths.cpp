#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<string>
#define ll register int
#define mod 5

using namespace std;
char c[100005]={0};
int a[6]={6,2,4,8,6};
int b[6]={1,3,9,7,1};
int main(){freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	ll t;
	ll res=0;
	ll sum=0;
	ll x=0;
	scanf("%d",&t);
	while(t--){x=0;
		scanf("%s",c+1);
		for(ll i=1;i<=strlen(c+1);i++){
			x*=10;
			x+=c[i]-'0';
			x%=4;
		}
		res=1+a[x]+b[x]+((c[strlen(c+1)]-'0')%2==1 ? 4 : 6);
		printf("%d\n",res%5);
	}
	return 0;
}

