#include<stdio.h>
#include<cmath>
using namespace std;
int check(long long n){
	long long i=2;
	while(n>1){
		if(i*i>n)return 1;
		int sum=0;
		while(n%i==0){
			n/=i;sum++;
			if(sum>1)return 0;
		}
		i++;
	}
	return 1;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		long long n,i;
		scanf("%lld",&n);
		long long m=sqrt(n);
		long long j=m,j1=m+1;
		while(check(j)==0)j--;
		long long sum=n-j*j,flag=1;
		if(sum<=j1*j1-n)flag=0;
		while(check(j1)==0&&flag){
			j1++;
			if(sum<=j1*j1-n||j1<0){
				flag=0;break;
			}
		}
		if(flag)printf("%lld\n",j1*j1-n);
		else printf("%lld\n",sum);
	}
	return 0;
}
