#include<stdio.h>
#include<algorithm>
using namespace std;
struct node{
	int k,bh;
}a[15];
int b[15];
bool cmp(node x,node y){
	return x.k<y.k;
}
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	int t,max=0,i,j;
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		scanf("%d",&a[i].k);
		a[i].bh=i;
		if(a[i].k>max)max=a[i].k;
	}
	sort(a+1,a+1+t,cmp);
	j=1;
	while(a[j].k==1){
		b[a[j].bh]=2;j++;
	}
	while(a[j].k==2){
		b[a[j].bh]=4;j++;
	}
	int l=2,l1=4,l2=0;
	for(i=3;i<=max;i++){
		l2=l+l1;
		if(i%4==0)l2--;
		if(i%4==2)l2++;
		l2%=10007;
		while(a[j].k==i){
			b[a[j].bh]=l2;j++;
		}
		l=l1;l1=l2;
	}
	for(i=1;i<=t;i++){
		for(j=1;j<=t;j++){
			if(a[j].bh==i){
				printf("%d\n",b[j]);break;
			}
		}
	}
	return 0;
}
