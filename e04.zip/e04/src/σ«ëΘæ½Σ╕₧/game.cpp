#include<stdio.h>
using namespace std;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	printf("355099\n4682676879");
	return 0;
}
