#include<stdio.h>
using namespace std;
char a[100005];
int b[6][6]={{0},{1,1,1,1},{6,2,4,8},{1,3,9,7},{6,4,6,4}};
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		scanf("%s",a);
		int n=0,i,j,sum=0;
		for(i=0;a[i];i++){
			n=n*10+a[i]-'0';
			n%=4;
		}
		for(i=1;i<=4;i++){
			sum+=b[i][n];
			sum%=5;
		}
		printf("%d\n",sum%5);
	}
	return 0;
}
