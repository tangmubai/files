#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int t;
long long x,ans=10000000000000000,a,b;
bool check(int x){
	if(x==2)return 1;
	if(x==1||x==0)return 0;
	for(int i=2;i*i<=x;i++)if(x%i==0)return 0;
	return 1;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&x);
		int ok=1;
		for(int i=1;i*i<=x;i++){
			if(check(i))
				if(abs(i*i-x)<ans)ans=abs(i*i-x),a=i;
			for(int j=i+1;j*j<=x;j++){
				if(check(i)&&check(j))
					if(abs(i*i*j*j-x)<ans)ans=abs(i*i*j*j-x),a=i,b=j;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
