#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int t,n,a[100005];
int vis[100005],f[100005],ans;
bool check(){
	for(int i=1;i<=n;i++)if(vis[a[i]]==0)return 0;
	return 1;
}
void dfs(int x,int y){
	if(check()){
		if(y>ans)ans=y;
		return;
	}	
	if(x>n)return;
	if(vis[x])return;
	dfs(x+1,y);
	for(int i=1;i<=n;i++)if(a[i]==a[x])vis[a[i]]=1;
	dfs(x+1,y+a[x]);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		memset(f,-1,sizeof(f));
		memset(vis,0,sizeof(vis));
		dfs(1,0);
		printf("%d\n",ans);
	}
	return 0;
}
