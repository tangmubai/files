#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int t;
char n[1000005];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",n);
		int x=(n[strlen(n)-1]-'0')+(n[strlen(n)-2]-'0')*10;
		if(x%4==0)printf("4\n");
		else printf("0\n");
	}
	return 0;
}
/*
  n=1  2  3   4    5    6      7      8
    1  1  1   1 ��
    2  4  8   16   32   64    128     256
    3  9  27  81   243  729   2187    6561 
    4  16 64  256 1024  4096  16384   65536
sum=10 30 100 354 1300  4890  18700   72354
ans=0  0   0   4   0     0     0       4
*/
