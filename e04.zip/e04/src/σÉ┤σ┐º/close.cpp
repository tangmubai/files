#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
long long n,ans;
int t;
bool pd(long long a)
{
	long long num=1;
	for(int i=2;i*i<=a;i++)
	{
		if(a%i==0)
		{
			long long j=i*i;
			if(a%j==0 && j!=a)
			{
				return 0;
			}
		}
	}
	return 1;
}
int main()
{
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		ans=100000000000000;
		cin>>n;
		long long i=sqrt(n);
		long long j=i+1;
		while(!pd(i))
		{
			i--;
		}
		while(!pd(j))
		{
			j++;
		}
		ans=min(abs(i*i-n),abs(j*j-n));
		cout<<ans<<endl;
	}
	return 0;
}
