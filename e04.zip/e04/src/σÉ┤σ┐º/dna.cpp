#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int f[1010000];
bool pd(int k)
{
	for(int i=1;i<=k-2;i++)
	{
		if((f[i]==1 && f[i+1]==0 && f[i+2]==1) || (f[i]==1 && f[i+1]==1 && f[i+2]==1))
		{
			return 0;
		}
	}
	return 1;
}
int n,ans;
void dfs(int i)
{
	if(i>n)
	{
		if(pd(n))
		{
			ans=(ans+1)%10007;
		}
		return ;
	}
	f[i]=1;
	dfs(i+1);
	f[i]=0;
	dfs(i+1);
}
int t;
int main()
{
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		ans=0;
		cin>>n;
		dfs(1);
		cout<<ans<<endl;
	}
	return 0;
}

