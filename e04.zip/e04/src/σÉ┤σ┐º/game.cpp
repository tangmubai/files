#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;

int main();
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);

	return 0;
}

