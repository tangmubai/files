#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int t;
string s;
int main()
{
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		cin>>s;
		int len=s.size();
		int num=0;
		if(len>1)
			num=(s[len-2]-'0')*10+(s[len-1]-'0');
		else
			num=(s[len-1]-'0');
		if(num%4==0)
		{
			cout<<4<<endl;
		}
		else
		{
			cout<<0<<endl;
		}
	}
	return 0;
}
