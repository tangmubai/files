#include<stdio.h>
#include<math.h>
#define min(x,y) ((x)<(y)?(x):(y))
#define abs(x) ((x)<0?-(x):(x))
inline bool jg(int x)
{
	if(!(x&1))
	{
		x>>=1;
		if(!(x&1))return 1;
	}
	for(register int i=3;i*i<=x;i+=2)if(!(x%i))
	{
		x/=i;
		if(!(x%i))return 1;
	}
	return 0;
}
main()
{
	freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	register int t,i,j;register long long n;
	for(scanf("%d",&t);t--;)
	{
		scanf("%lld",&n);
		for(i=sqrt(n);jg(i);++i);
		for(j=sqrt(n);jg(j);--j);
		printf("%lld\n",min(abs(1ll*i*i-n),abs(n-1ll*j*j)));
	}
}
