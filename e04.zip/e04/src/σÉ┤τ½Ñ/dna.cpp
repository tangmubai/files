#include<stdio.h>
#define mod 10007
struct matrix
{
	#define N 4
	int a[N][N];
	inline void operator*=(const matrix&kkk)
	{
		register int ans[N][N]={};
		for(register int i=0;i<N;++i)for(register int j=0;j<N;++j)if(a[i][j])
			for(register int k=0;k<N;++k)ans[i][k]+=a[i][j]*kkk.a[j][k];
		for(register int i=0;i<N;++i)for(register int j=0;j<N;++j)a[i][j]=ans[i][j]%mod;
	}
}a,ans;
main()
{
	freopen("dna.in","r",stdin);freopen("dna.out","w",stdout);
	register int t,n;
	for(scanf("%d",&t);t--;)
	{
		scanf("%d",&n);
		if(n==1){puts("2");continue;}
		ans.a[0][0]=1;ans.a[0][1]=1;ans.a[0][2]=1;ans.a[0][3]=1;
		ans.a[1][0]=0;ans.a[1][1]=0;ans.a[1][2]=0;ans.a[1][3]=0;
		ans.a[2][0]=0;ans.a[2][1]=0;ans.a[2][2]=0;ans.a[2][3]=0;
		ans.a[3][0]=0;ans.a[3][1]=0;ans.a[3][2]=0;ans.a[3][3]=0;
		a.a[0][0]=1;a.a[0][1]=1;a.a[0][2]=0;a.a[0][3]=0;
		a.a[1][0]=0;a.a[1][1]=0;a.a[1][2]=1;a.a[1][3]=1;
		a.a[2][0]=1;a.a[2][1]=0;a.a[2][2]=0;a.a[2][3]=0;
		a.a[3][0]=0;a.a[3][1]=0;a.a[3][2]=1;a.a[3][3]=0;
		for(n-=2;n;a*=a,n>>=1)
			if(n&1)ans*=a;
		printf("%d\n",(ans.a[0][0]+ans.a[0][1]+ans.a[0][2]+ans.a[0][3])%mod);
	}
}
/*     0,0 0,1 1,0 1,1
 * 0,0  1   1   0   0
 * 0,1  0   0   1   1
 * 1,0  1   0   0   0
 * 1,1  0   0   1   0
 */
