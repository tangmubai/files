#include<stdio.h>
#define N 100001
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
int a[N];long long ans1[N],ans2[N],ans3[N];
inline long long max(const long long&x,const long long&y){return x>y?x:y;}
/*ans1[i]:i is deleted by i-1
 *ans2[i]:i is deleted by i
 *ans3[i]:i is deleted by i+1
 */
main()
{
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	register int t,n;
	for(read(t);t--;)
	{
		read(n);
		for(register int i=1;i<N;++i)a[i]=0;
		for(register int x;n--;read(x),++a[x]);
		ans1[1]=-(1ll<<60);ans2[1]=a[1];ans3[1]=0;
		for(register int i=2;i<N;++i)
		{
			ans1[i]=ans2[i-1];//i-1 is deleted by i-1
			ans2[i]=ans3[i-1]+1ll*i*a[i];//i-1 is deleted by i
			ans3[i]=max(ans1[i-1],ans2[i-1]);
			//i-1 is deleted by i-2 or i-1,so that 1~i-1 are all deleted
		}
		printf("%lld\n",max(ans1[N-1],ans2[N-1]));
	}
}
