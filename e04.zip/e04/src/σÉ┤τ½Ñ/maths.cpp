#include<stdio.h>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=((x<<1)+(c^48))&3,c=nc());
}
main()
{
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	register int t,n;
	for(scanf("%d",&t);t--;read(n),puts(n?"0":"4"));
	/*1+2+3+4
	 *1+4+4+1
	 *1+3+2+4
	 *1+1+1+1
	 */
}
