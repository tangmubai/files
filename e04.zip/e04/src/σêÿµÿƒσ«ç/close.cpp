#include <cstdio>
#define ll unsigned long long

void in(int &x)
{
	int w = 0, f = 1;char c = getchar();
	while (c < '0' || c >'9'){if (c == '-')f = -1;c = getchar();}
	while (c >= '0' && c <= '9'){w = w * 10 + (c - '0');c =getchar();}
	x = w * f;
}

bool check(ll x)
{
	for (int i = 2; i * i <= x; i++)
	{
		int step = 0;
		while (x % i == 0)
		{
			step++;
			x /= i;
			if (step >= 2 && x % i == 0)
				return false;
		}
		if (step == 1)
			return false;
	}
	if (x > 1)
		return false;
	return true;
}

int main()
{
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	int t;
	in(t);
	while (t--)
	{
		ll n;
		scanf("%lld", &n);
		for (int i = 0; ; i++)
		{
			if (check(n + i) || (n - i > 0) && check(n - i))
			{
				printf("%d\n", i);
				break;
			}
		}
	}
	return 0;
}

