#include <cstdio>
#include <algorithm>
using namespace std;
int a[100005], t[100005];

void in(int &x)
{
	int w = 0, f = 1;char c = getchar();
	while (c < '0' || c >'9'){if (c == '-')f = -1;c = getchar();}
	while (c >= '0' && c <= '9'){w = w * 10 + (c - '0');c =getchar();}
	x = w * f;
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int m;
	in(m);
	while (m--)
	{
		int n;
		in(n);
		for (int i = 1; i <= n; i++)
			in(a[i]), t[a[i]]++;
		sort(a + 1, a + 1 + n);
		int s = n, ans = 0;
		while (s > 0)
		{
			int minn = 2147483647, ansi;
			for (int i = 1; i <= n; i++)
			{
				if (t[a[i]] <= 0)
					continue;
				int k = 0;
				k += t[a[i] - 1] * (a[i] - 1);
				k += t[a[i] + 1] * (a[i] + 1);
				if (k == minn)
				{
					int c1 = a[i] * t[a[i]];
					int c2 = a[ansi] * t[a[ansi]];
					if (c1 > c2)
					{
						minn = k;
						ansi = i;
						continue;
					} 
				}
				if (k < minn && t[a[i]] > 0)
				{
					ansi = i;
					minn = k;
				}
			}
			ans += a[ansi];
			s -= t[a[ansi] - 1] + t[a[ansi] + 1] + 1;
			t[a[ansi]]--;
			t[a[ansi] - 1] = t[a[ansi] + 1] = 0;
		}
		printf("%d\n", ans);
	}
	return 0;
}

