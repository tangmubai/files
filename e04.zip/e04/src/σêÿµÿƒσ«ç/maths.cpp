#include <cstdio>
#include <cstring>
//#include <>
using namespace std;

void in(int &x)
{
	int w = 0, f = 1;char c = getchar();
	while (c < '0' || c >'9'){if (c == '-')f = -1;c = getchar();}
	while (c >= '0' && c <= '9'){w = w * 10 + (c - '0');c =getchar();}
	x = w * f;
}

int main()
{
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;
	scanf("%d", &t);
	while (t--)
	{
		char s[100005];
		scanf("%s", s + 1);
		int sum = 0;
		int len = strlen(s + 1);
		for (int i  = 1; s[i]; i++)
			sum += s[i] - '0';
		if (sum % 3 == 0)
			printf("%d\n", (1 + 8 + 7 + 4) % 5);
		else if (((s[len - 1] - '0') * 10 + s[len] - '0') % 4 == 0)
			printf("%d\n", (1 + 6 + 1 + 6) % 5);
		else if ((s[len] - '0') % 2 == 0)
			printf("%d\n", (1 + 4 + 9 + 6) % 5);
		else 
			printf("%d\n", (1 + 2 + 4 + 3) % 5);
	}
	return 0;
}

