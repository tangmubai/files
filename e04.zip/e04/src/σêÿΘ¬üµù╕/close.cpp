#include <stdio.h>
typedef long long qaq;
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 1; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w *= -1;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x *= w;
}
qaq x;
inline bool ok(qaq n) {
	if (n < 0)
		return false;
	int cnt;
	for (qaq i = 2; i * i <= n; ++i) {
		cnt = 0;
		while (n % i == 0) {
			++cnt;
			n /= i;
		}
		if (cnt != 2)
			return false;
	}
	return n == 1;
}
int main(void) {
	freopen("close.in", "r", stdin);
	freopen("close.out", "w", stdout);
	int t;
	for (read(t); t--; ) {
		read(x);
		for (qaq i = 1; ; ++i)
			if (ok(x - i) || ok(x + i)) {
				printf("%lld\n", i);
				break;
			}
	}
	return 0;
}
