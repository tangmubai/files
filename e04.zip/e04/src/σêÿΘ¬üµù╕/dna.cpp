#include <stdio.h>
#include <map>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 1; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w *= -1;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x *= w;
}
int L, f[5][2], q[15], maxq;
std:: map<int, bool> mp;
int main(void) {
	freopen("dna.in", "r", stdin);
	freopen("dna.out", "w", stdout);
	int t;
	read(t);
	for (int i = 1; i <= t; ++i) {
		read(q[i]);
		maxq = q[i] > maxq ? q[i] : maxq;
		mp[q[i]] = true;
	}
	f[1][0] = f[1][1] = 1;
	f[2][0] = f[2][1] = 2;
	f[3][0] = 4, f[3][1] = 2;
	for (int i = 4; i <= maxq; ++i) {
		f[i % 4][0] = (f[(i - 1) % 4][0] + f[(i - 1) % 4][1]) % 10007;
		f[i % 4][1] = (f[(i - 2) % 4][0] + f[(i - 3) % 4][0]) % 10007;
		if (mp.count(true))
			mp[i] = f[i % 4][0] + f[i % 4][1] > 0;
	}
	for (int i = 1; i <= t; ++i)
		printf("%d\n", f[q[i] % 4][0] + f[q[i] % 4][1]);
	return 0;
}
