#include <stdio.h>
#include <algorithm>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 1; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w *= -1;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x *= w;
}
int n, mx, a[100005];
inline bool cmp(int p, int q) {
	return p > q;
}
int main(void) {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int t;
	for (read(t); t--; ) {
		read(n);
		for (int i = 1, x; i <= n; ++i) {
			read(x);
			mx = x > mx ? x : mx;
			++a[x];
		}
		std:: sort(a + 1, a + 1 + mx);
		int ans = 0;
		for (int i = mx; i >= 1; --i)
			ans += a[i];
		printf("%d\n", ans);
	}
	return 0;
}
