#include <stdio.h>
#include <string.h>
char str[100005];
int lens;
int main(void) {
	freopen("maths.in", "r", stdin);
	freopen("maths.out", "w", stdout);
	int t;
	for (scanf("%d", &t); t--; ) {
		scanf("%s", str + 1);
		lens = strlen(str + 1);
		int a = (str[lens - 1] * 10 + str[lens]) % 4, b = (str[lens] - '0') & 1, aa, bb, cc;
		switch (a) {
			case 0: aa = 1, bb = 1; break;
			case 1: aa = 2, bb = 3; break;
			case 2: aa = 4, bb = 4; break;
			case 3: aa = 3, bb = 2; break;
		}
		if (b)
			cc = 4;
		else
			cc = 1;
		printf("%d\n", (1 + aa + bb + cc) % 5);
	}
	return 0;
}
