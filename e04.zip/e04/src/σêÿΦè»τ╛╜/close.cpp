#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
#define ll long long
#define min(x,y) (x)<(y)?(x):(y)
using namespace std;
ll t,n,x,ok,ans,s;
inline ll ab(ll x,ll y)
{
	return (x-y)<0?y-x:x-y;
}
int main()
{
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	scanf("%lld",&t);
	while(t--)
	{
		scanf("%lld",&n);
		x=sqrt(n*1.0);
		ok=1;
		for(s=x;s&&ok;s++)
		{
			ll j=s,i=2;
			ok=0;
			while(i*i<=j)
			{
				if(j%(i*i)==0)
				{
					ok=1;
					break;
				}
				i++;
			}
		}
		s--;
		ans=ab(s*s,n);
		ok=1;
		for(s=x;s&&ok;s--)
		{
			ll j=s,i=2;
			ok=0;
			while(i*i<=j)
			{
				if(j%(i*i)==0)
				{
					ok=1;
					break;
				}
				i++;
			}
		}
		s++;
		ans=min(ans,ab(s*s,n));
		printf("%lld\n",ans);
	}
}
