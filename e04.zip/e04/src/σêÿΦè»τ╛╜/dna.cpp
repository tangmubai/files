#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
#define ll long long
#define min(x,y) (x)<(y)?(x):(y)
using namespace std;
const int mod=10007;
int t,n,ans;
inline void dfs(int i,int l1,int l2)
{
	if(i>n)
	{
		ans=(ans+1)%mod;
		return;
	}
	if(l1==1)
	{
		dfs(i+1,l2,0);
	}
	else
	{
		dfs(i+1,l2,0);
		dfs(i+1,l2,1);
	}
}
int main()
{
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		ans=0;
		dfs(1,0,0);
		printf("%d\n",ans);
	}
	return 0;
}
