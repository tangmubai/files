#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e5+5;
const int mod=5;
int t,n,a,ans;
char s[N];
inline int p(int x,int y)
{
	int sum=1;
	for(int i=1;i<=y;i++)
	{
		sum=sum*x%mod;
	}
	return sum;
}
int main()
{
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		ans=0;
		scanf("%s",s+1);
		n=strlen(s+1);
		if(n==1&&s[1]=='1')
		{
			printf("0\n");
			continue;
		}
		a=(s[n-1]-'0')*10+s[n]-'0';
		a=a%4+4;
		for(int i=1;i<=4;i++)
		{
			ans+=p(i,a);
		}
		printf("%d\n",ans%mod);
	}
	return 0;
}
