#include<stdio.h>
#include<iostream>
using namespace std;
long long ans;
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%d",&ans);ans%=4;
		if(ans==0)cout<<"4"<<endl;
		else cout<<"0"<<endl;
	}
	return 0;
}

