#include<stdio.h>
#include<math.h>
using namespace std;
int t;long long x,q;
int pd(long long n){
	if(n==2)return 1;
	for(int i=2;i*i<=n;i++)if(n%i==0)return 0;
	return 1;
}
int main(){
	freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&x);
		q=sqrt(x);
		long long z=0;
		while(1){
			long long q1=sqrt(x)+z,q2=sqrt(x)-z,f1=0,f2=0;
			if(pd(q1)){
				long long ans1=abs(x-q1*q1);
				printf("%lld\n",ans1);
				break;
			}
			if(pd(q2)){
				long long ans1=abs(x-q2*q2);
				printf("%lld\n",ans1);
				break;
			}
			for(int i=2;i*i<=q1;i++){
				if(q1%i==0&&pd(i)&&pd(q1/i)){
					f1=1;break;
				}
			}
			if(f1){
				long long ans1=abs(x-q1*q1);
				printf("%lld\n",ans1);
				break;
			}
			for(int i=2;i*i<=q1;i++){
				if(q2%i==0&&pd(i)&&pd(q2/i)){
					f2=1;break;
				}
			}
			if(f2){
				long long ans1=abs(x-q2*q2);
				printf("%lld\n",ans1);
				break;
			}
			z++;
		}
	}
	return 0;
}
