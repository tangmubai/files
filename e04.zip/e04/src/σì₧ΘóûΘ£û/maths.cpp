#include<stdio.h>
#include<string.h>
using namespace std;
int t;char q[100010];
int main(){
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",q);
		int l=strlen(q),w;
		if(l==1)w=(q[0]-'0')%4;
		else w=((q[l-1]-'0')+(q[l-2]-'0')*10)%4;
		if(w==0)printf("%d\n",(1+1+1+1)%5);
		if(w==1)printf("%d\n",(1+2+3+4)%5);
		if(w==2)printf("%d\n",(1+4+4+1)%5);
		if(w==3)printf("%d\n",(1+3+2+4)%5);
	}
	return 0;
}
