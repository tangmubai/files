#include<cstdio>
#include<iostream>
using namespace std;
int t;
long long abss(long long x){
	if(x<0) return -x;
	return x;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		long long n,ans=999999999999999999;
		scanf("%lld",&n);
		for(long long i=0;i>=0 && i*i*i*i>=0 && i*i*i*i<=n;i++)
			if(abss(n-i*i*i*i)<ans) ans=abss(n-i*i*i*i);
		cout<<ans<<endl;
	}
	return 0;
}
