#include<cstdio>
using namespace std;
int t;
int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		int n,ans=0;
		scanf("%d",&n);
		if(n==1){
			puts("2");
			continue;
		}
		if(n==2){
			puts("4");
			continue;
		}
		if(n==3){
			puts("6");
			continue;
		}
		if(n==4){
			puts("6");
			continue;
		}
		int f1=1,f2=2,f3=2,f4=3,f5;
		int g1=1,g2=2,g3=4,g4=6,g5;
		for(int i=1;i<=n-4;i++){
			g5=(f4+g4)%10007;
			f5=(f2+2*g2)%10007;
			f1=f2;f2=f3;f3=f4;f4=f5;
			g1=g2;g2=g3;g3=g4;g4=g5;
		}
		ans=(f5+g5)%10007;
		printf("%d\n",ans);
	}
	return 0;
}
