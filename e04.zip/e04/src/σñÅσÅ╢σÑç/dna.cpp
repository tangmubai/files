#include <stdio.h>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e8 + 5;
const int Mod = 10007;

int f1[N] = {0, 0, 1, 2, 2, 2};
int f[N] = { 0, 0, 0, 0, 0, 1};

void Dfs(int x) {
	if (x == 1) return;
	if (f[x] != 0) return;
	if (x % 2 == 1) {
		Dfs(x >> 1);
		f[x] = f[x >> 1] + f1[x >> 1] % Mod;
		f1[x] = f[x >> 1] % Mod;
	}else {
		Dfs(x + 1 >> 1);
		f[x] = (f[x + 1 >> 1] + f1[x + 1 >> 1] - 1) % Mod;
		f1[x] = f[x + 1>> 1] % Mod;
		f[x] = f[x >> 1] + f1[x >> 1] % Mod;
		f1[x] = f[x >> 1] % Mod;
	}
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	int t, n;
	cin >> t;
	while (t--) {
		cin >> n;
		Dfs(n);
		for (int x = 5; x <= n; x++) {
			if (x % 2 == 1) {
				f[x] += f[x >> 1] + f1[x >> 1] % Mod;
				f1[x] += f[x >> 1] % Mod;
			}else {
				f[x] += (f[x + 1 >> 1] + f1[x + 1 >> 1] - 1) % Mod;
				f1[x] += f[x + 1>> 1] % Mod;
				f[x] += f[x >> 1] + f1[x >> 1] % Mod;
				f1[x] += f[x >> 1] % Mod;
			}
		}
		cout << f[n] << '\n';
	}
	return 0;
}
/*
1	1
2	10
3	11
4	100
5	101
6	110
7	111
*/
