#include <stdio.h>
#include <string>
#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

template <typename Tp>
Tp Max(Tp x, Tp y) {
	if (x > y) return x;
	return y;
}

map<ll, ll> mp;
map<ll, ll> ::iterator it;

int main() {
	ios :: sync_with_stdio(false);
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int t, n;
	cin >> t;
	while (t--) {
		cin >> n;
		int _;
		for (int i = 1; i <= n; i++) {
			cin >> _; mp[_]++;
		}
		ll ans= 0;
		while (!mp.empty()) {
			ll mx = 0, mxp = 0;
			for (it = mp.begin(); it != mp.end(); it++) {
			if (it->first * it->second > mx) {
				mx = it->first * it->second, mxp = it->first;
				}
			}
			ans += mx;
//			cout << "mx mxp " << mx / (mx / mxp) << ' ' << mxp<< '\n';
			mp.erase(mxp), mp.erase(mxp - 1), mp.erase(mxp + 1);
		}
		cout << ans << '\n';
	}
	return 0;
}
