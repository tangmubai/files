#include <stdio.h>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

const int _2[5] = {1, 2, 4, 3};
const int _3[5] = {1, 3, 4, 2};
const int _4[5] = {1, 4, 1, 4};

string s;

int main() {
	ios :: sync_with_stdio(false);
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	ll t, n;
	cin >> t;
	while (t--) {
		cin >> s;
		int l = s.size() - 1;
		cout << (1 + _2[(s[l] - 48) % 4] + _3[(s[l] - 48) % 4] + _4[(s[l] - 48) % 4]) % 5 << '\n';
	}
	return 0;
}
