#include <cmath>
#include <cstdio>

const long long INF = 1e18;

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

template <typename Tp>
inline Tp ans(const Tp num) {
    return num < 0 ? -num : num;
}

int main() {
    freopen("close.in", "r", stdin);
    freopen("close.out", "w", stdout);
    int T;
    for (scanf("%d", &T); T; T--) {
        long long num, minn = INF;
        read(num);
        bool ok = true;
        long long tmp = sqrt(num);
        for (long long i = 1; ; i++) {
            long long tmp1 = tmp + i;
            long long tmp2 = tmp - i;
            bool flag = true;
            if (fabs(num - tmp1 * tmp1) >= minn && fabs(num - tmp2 * tmp2) >= minn) break;
            for (long long t = 2; t * t <= tmp1; t++)
                if (tmp1 % t == 0) {
                    tmp1 /= t;
                    if (tmp1 % t == 0) {
                        flag = false;
                        break;
                    }
                }
            tmp1 = tmp + i;
            if (flag && fabs(num - tmp1 * tmp1) < minn) {
                minn = fabs(num - tmp1 * tmp1);
            }
            if (tmp2 < 0) continue;
            flag = true;
            for (long long t = 2; t * t <= tmp2; t++)
                if (tmp2 % t == 0) {
                    tmp2 /= t;
                    if (tmp2 % t == 0) {
                        flag = false;
                        break;
                    }
                }
            tmp2 = tmp - i;
            if (flag && fabs(num - tmp2 * tmp2) < minn) {
                minn = fabs(num - tmp2 * tmp2);
            }
        }
        printf("%lld\n", minn);
    }
    return 0;
}
