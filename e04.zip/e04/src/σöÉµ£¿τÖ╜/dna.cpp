#include <cstdio>
#include <cstring>

const int N = 1000001, Mod = 10007;

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

int dp[N][2], num[N];

int main() {
    freopen("dna.in", "r", stdin);
    freopen("dna.out", "w", stdout);
    int T, maxn = 1000000;
    read(T);
    dp[1][0] = 1; dp[1][1] = 1;
    dp[2][0] = 2; dp[2][1] = 2;
    dp[3][0] = 4; dp[3][1] = 2;
    for (int i = 4; i <= maxn; i++) {
        dp[i][0] = (dp[i - 1][0] + dp[i - 1][1]) % Mod;
        dp[i][1] = (dp[i - 3][0]  + dp[i - 3][1]) * 2 % Mod;
    }
    for (int i = 1; i <= T; i++) {
        read(num[i]);
        printf("%d\n", (dp[num[i]][0] + dp[num[i]][1]) % Mod);
    }
    return 0;
}
