#include <cstdio>
#include <cstring>
#include <algorithm>

const int N = 100001;

long long dp1[N], dp2[N][2], num[N], tmp[N], tim[N];

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

template <typename Tp>
inline Tp max(const Tp num1, const Tp num2) {
    return num1 > num2 ? num1 : num2;
}

int main() {
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    int T;
    for (scanf("%d", &T); T; T--) {
        int n, tot = 0;
        read(n);
        memset(dp1, 0, sizeof dp1);
        memset(dp2, 0, sizeof dp2);
        for (int i = 1; i <= n; i++) read(num[i]);
        std :: sort(num + 1, num + 1 + n);
        tim[++tot] = 1; tmp[tot] = num[1];
        for (int i = 2; i <= n; i++)
            if (num[i] == num[i - 1]) tim[tot]++;
            else {
                tmp[++tot] = num[i]; tim[tot] = 1;
            }
        dp1[1] = tim[1] * tmp[1];
        for (int i = 2; i <= tot; i++) {
            dp1[i] = max(dp1[i - 2], dp2[i - 2][0]) + tim[i] * tmp[i];
            dp2[i - 1][0] = dp1[i - 2];
            dp2[i - 1][1] = dp1[i];
        }
        dp2[tot][0] = dp1[tot - 1];
        printf("%lld\n", max(dp1[tot], dp2[tot][0]));
    }
    return 0;
}
