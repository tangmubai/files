#include <cstdio>
#include <cstring>

const int N = 100001;

char s[N];

inline void get(char *str) {
    int len = 0;
    char c = getchar();
    while (c < '0' || c > '9') c = getchar();
    for (; c >= '0' && c <= '9'; c = getchar()) str[len++] = c;
    str[len] = '\0';
}

int main() {
    freopen("maths.in", "r", stdin);
    freopen("maths.out", "w", stdout);
    int T;
    for (scanf("%d", &T); T; T--) {
        int len, num;
        get(s + 1);
        len = strlen(s + 1);
        if (len == 1) num = s[1] - '0';
        else num = (s[len - 1] - '0') * 10 + s[len] - '0';
        if (num % 4 == 0) puts("4");
        else puts("0");
    }
    return 0;
}
