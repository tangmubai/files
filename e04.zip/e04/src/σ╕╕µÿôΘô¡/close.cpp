#include <stdio.h>
#include <cmath>
#include <algorithm>
using namespace std;

bool check(long long x){
	int sb=0;
	for(long long i=2ll;i*i<=x;){
		if(x%i==0){
			x/=i;sb++;
			if(sb>1)return false;
		}
		else ++i,sb=0;
	}
	return true;
}
int main(){
	freopen("close.in","r",stdin);
	freopen("close.out","w",stdout);
	int t,sb1,sb2;
	long long n,x,x1,x2,b1,b2;scanf("%d",&t);
//	printf("%lld\n",123456789987654321);
	while(t--){
		scanf("%lld",&n);
		x=(long long)sqrt(n);
		sb1=sb2=0;
		for(long long i=x,j=x+1;!sb1||!sb2;--i,++j){
//			printf("check %d %d\n",check(i),check(j));
			if(check(i)&&!sb1){
				sb1=1;x1=i*i;
//				printf("%lld x1 %lld\n",i,x1);
			}
			if(check(j)&&!sb2){
				sb2=1;x2=j*j;
//				printf("%lld x2 %lld\n",j,x2);
			}
		}
//		a2=(x+1)*(x+1);
//		a3=(x+2)*(x+2);
//		printf("%lld %lld %lld\n",n,x1,x2);
		b1=n-x1;b2=x2-n;
//		printf("%lld %lld %lld\n",x,x1,x2);
//		printf("%d %d %d\n",b1,b2);
		printf("%lld\n",min(b1,b2));
		
//		if(n-a1<a2-n){
//			printf("%lld\n",n-a1);
//		}
//		else printf("%lld\n",a2-n);
	}
	return 0;
}

