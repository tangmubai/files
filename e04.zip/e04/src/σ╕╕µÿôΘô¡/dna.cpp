#include <stdio.h>
using namespace std;

int main(){
	freopen("dna.in","r",stdin);
	freopen("dna.out","w",stdout);
	
	return 0;
}

