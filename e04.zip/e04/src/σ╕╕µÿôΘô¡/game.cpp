#include <stdio.h>
using namespace std;

int f[100005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	return 0;
}

