#include <stdio.h>
#include <cstring>
using namespace std;

char a[100005];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t,n,x;scanf("%d",&t);
	while(t--){
		scanf("%s",a+1);
		x=(a[strlen(a+1)-1]-'0')*10+(a[strlen(a+1)]-'0');
//		printf("%d\n",x);
		if(x%4==0){
			printf("4\n");
		}
		else printf("0\n");
		memset(a,'0',sizeof a);
	}
	return 0;
}

/*

0  4
1  0
2  0
3  0


*/
