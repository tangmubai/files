/*#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long ll;
ll ab(ll p){if(p<0)return p*(-1);}
ll n;
bool check(ll m){
	ll p=1;
	int tot=0;
	for(ll i=2;i*i<=m;i++){
		if(m%i==0)p*=i,tot++;
		while(m%i==0)m/=i;
	}
	
}
int main(){
	freopen("close.in","r",stdin);
		freopen("close.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&n);
		ll l=1,r=1e18;
		while(l<=r){
			ll mid=(l+r)>>1;
			if(check(mid))l=mid+1;
			else r=mid-1;
		}
		printf("%lld\n",ab(l-n));
	}
	return 0;
}*/
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
typedef long long ll;
ll ab(ll p){if(p<0)return p*(-1);}
ll n;
int main(){
	freopen("close.in","r",stdin);
		freopen("close.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&n);
		ll l=sqrt(n);
		printf("%lld\n",ab(l*l-n));
	}
	return 0;
}
