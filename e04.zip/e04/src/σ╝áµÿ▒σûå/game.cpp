#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int t,f[100005],a[100005],ans,g[100005],n;
int main(){
		freopen("game.in","r",stdin);
		freopen("game.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		int maxn=-1;
		memset(f,0,sizeof(f));
		memset(g,0,sizeof(g));
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			f[a[i]]++;
			maxn=(maxn,a[i]);
		}
		int last=0,l=0;
		for(int i=1;i<=maxn;i++){
			if(f[i]){
				if(f[i-1])g[i]=f[i]*i+g[l];
				else g[i]=g[last]+f[i]*i;
				l=last;
				last=i;
			}
		}
		ans=-1;
		for(int i=1;i<=maxn;i++)ans=max(g[i],ans);
		printf("%d\n",ans);
	}
	return 0;
}
