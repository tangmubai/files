/*#include<cstdio>
using namespace std;
const int a[5][5]={{},{1},{6,2,4,8},{1,3,9,7},{6,4}};
int t,f[5]={0,1,4,4,2},tot[5];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","W",stdout);
	scanf("%d",&t);
	char s[100001];
	while(t--){
		scanf("%s",s+1);
		int len=strlen(l+1);
		for(int i=1;i<=4;i++)tot[i]=(s[1]-'0')%f[i];
		for(int i=2;i<=l;i++)
		for(int j=1;j<=4;j++){
			s[i]=s[i]
		}
	}	
}*/
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int t;
char s[100005];
int main(){
		freopen("maths.in","r",stdin);
		freopen("maths.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",s+1);
		int len=strlen(s+1);
		int x=(s[len]-'0')+(s[len-1]-'0')*10;
		/*if(x%5==0&&x<10){
			puts("0");
			continue;
		}*/
		int m=x%4;
		if(m==1)puts("0");
		if(m==2)puts("2");
		if(m==3)puts("0");
		if(m==0)puts("4");
	}
	return 0;
}

