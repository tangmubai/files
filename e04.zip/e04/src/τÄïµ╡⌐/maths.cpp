#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
char a[100005];
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;
	cin>>t;
	while(t--){
		scanf("%s",a+1);
		int len=strlen(a+1);
		a[0]='0';
		int x=(a[len-1]-'0')*10+a[len]-'0';
		if(x%4==0){
			cout<<"4"<<endl;
		}else{
			cout<<"0"<<endl;
		}
	}
	return 0;
}
