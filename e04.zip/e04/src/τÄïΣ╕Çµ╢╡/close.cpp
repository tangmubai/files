#include <cstring>
#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

typedef long long LL;

bool chk(LL x)
{
	for (LL i = 2; i * i <= x; i ++ )
	{
		if (x % i == 0)
			x /= i;
		if (x % i == 0)
			return false;
	}
	
	return true;
}

LL mn(LL a, LL b)
{
	return a < b ? a : b;
}

LL ab(LL a)
{
	if (a < 0)
		return -a;
	return a;
}

int main()
{
	freopen("close.in", "r", stdin);
	freopen("close.out", "w",stdout);
	
	int t;
	scanf("%d", &t);
	while (t -- )
	{
		LL x;
		scanf("%lld", &x);
		
		LL q = (int) (sqrt(x * 1.0));
		LL p = q;
		
		for (; q; q -- )
			if (chk(q)) break;
		for (; p; p ++ )
			if (chk(p))	break;
		cout << mn(ab(x - (1ll * q * q)), ab((1ll * p * p) - x)) << endl; 
	}
	
	return 0;
}
