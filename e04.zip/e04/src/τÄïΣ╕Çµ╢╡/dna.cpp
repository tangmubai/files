#include <iostream>
//��һ������ͬ����-----------shiit 
using namespace std;

const int N = 100000010, Mod = 10007;

short g[N], f[N]; // g:���һλΪ1�� f:���һλΪ0 

int main()
{
	freopen("dna.in", "r", stdin);
	freopen("dna.out", "w", stdout);
	
	
	g[0] = 1;
	g[1] = 1;
	g[2] = 2;
	f[0] = 1;
	f[1] = 2;
	f[2] = 1;
	
	int t, mx = -1;
	cin >> t;
	
	while (t -- )
	{
		int x;
		cin >> x;
		
		if (x < mx)
		{
			cout << (f[x] + g[x]) % Mod << endl;
			continue;
		}
		
		for (int i = 3; i <= x; i ++ )
		{
			f[i] = (f[i - 1] + g[i - 1]) % Mod;
//			ff[i] = ff[i - 1];
			g[i] = (f[i - 1] - g[i - 2] + g[i - 1] - g[i - 2]) % Mod;
//			gg[i] = g[i - 1];

//			cout << f[i] << ' ' << g[i] << endl;
		}
		
		mx = x;
		
		cout << (f[x] + g[x]) % Mod << endl;
	}
	
	return 0;
}
