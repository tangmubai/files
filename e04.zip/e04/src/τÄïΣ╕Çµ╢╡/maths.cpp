#include <iostream>
#include <cstring>

using namespace std;

const int N = 100010;

char f[N];

int main()
{
	freopen("maths.in", "r", stdin);
	freopen("maths.out", "w", stdout);
	
	int t;
	cin >> t;
	while (t -- )
	{
		cin >> (f + 1);
		int L = strlen(f + 1);
		int x = ((f[L] - '0') + (f[L - 1] - '0') * 10) % 4;
		
		switch (x)
		{
			case 0: {
				cout << 4 << endl;
				break;
			}//cout << 4 << endl; break;
			case 1: {
				cout << 0 << endl;
				break;
			} //cout << 0 << endl; break;
			
			case 2: {
				cout << 0 << endl;
				break;
			}
			
			case 3: {
				cout << 0 << endl;
				break;
			}
		}
	}
	
	return 0;
}
