#include<stdio.h>
#include<math.h>
#define ll long long
using namespace std;
int t;
ll x,y;
bool pss(int x){
	for(int i=2;i*i<=x;i++){
		if(x%i==0)return 0;
	}
	return 1;
}
int main(){
	//freopen("close.in","r",stdin);
	//freopen("close.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld",&x);
		int a=sqrt(x);
		int ans,ans1;
		if(a%2==0){ans=a/2;ans1=2;}if(a%3==0){ans=a/3;ans1=3;}
		if(a%5==0){ans=a/5;ans1=5;}if(a%7==0){ans=a/7;ans1=7;}
		if(a%11==0){ans=a/11;ans1=11;}if(a%13==0){ans=a/13;ans1=13;}
		if(a%17==0){ans=a/17;ans1=15;}if(a%19==0){ans=a/19;ans1=19;}
		if(a%23==0){ans=a/23;ans1=23;}if(a%29==0){ans=a/29;ans1=29;}
		if(pss(ans)){
			printf("%d\n",(abs)(ans-ans1)+15);
		    continue;
		}
		int y1=a,y2=a;
		while(!pss(y))y1++;
		while(!pss(y))y2--;
		y=(y1<y2)?y1:y2;
		printf("%d\n",(abs)(y-x));
	}
	return 0;
}
