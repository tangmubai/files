#include<stdio.h>
int main(){
	freopen("maths.in","r",stdin);
	freopen("maths.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int n[100000],i=1,a=1,b=2,c=3,d=4,ans=0;
		for(i=1,a=1,b=2,c=3,d=4;i<=100000&&scanf("%d",&n[i]);i++,b*=2,c*=3,d*=4);
		ans=(a+b+c+d)%5;
		for(int j=1;j<=i;j++)ans=ans<<i;
		printf("%d\n",ans);
	}
	return 0;
}
