#include "cstdio"
#include "cmath"
#include "algorithm" 
using namespace std;
int t;
unsigned long long x;
inline int p(int n){
	if (n<=2) return 1;
	for (register int i=2;i*i<=n;i++) if (n%i==0) return 0;
	return 1;
}
inline int chk(int n){
	for (register int i=2;i*i<=n;i++){
		if (n%i==0) n/=i;
	}
	if (n==1) return 1;
	if (p(n)) return 1;
	if (n>1&&p(n)==0) return 0;
	return 1;
}
int main(){
	freopen ("close.in","r",stdin);
	freopen ("close.out","w",stdout);
	scanf ("%d",&t);
	while (t--){
		scanf ("%llu",&x);
		int k1=sqrt(x);
		int k2=k1+1;
		while (!chk(k1)) k1--;
		while (!chk(k2)) k2++;
		long long ans=min(x-1ll*k1*k1,1ll*k2*k2-x);
		printf ("%lld\n",ans);
	}
	return 0;
}
