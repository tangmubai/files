#include <stdio.h>
#include <cstring>
using namespace std;
int f[1005][3];
int t,l;
int main(){
	freopen ("dna.in","r",stdin);
	freopen ("dna.out","w",stdout);
	scanf ("%d",&t);
	while (t--){
		memset(f,0,sizeof f);
		scanf ("%d",&l);
		f[1][0]=f[1][1]=1; f[2][0]=f[2][1]=2;
		for (register int i=3;i<=l;++i){
			f[i%100][0]=(f[(i-2)%100][0]+f[(i-2)%100][1])*2%10007;
			f[i%100][1]=f[(i-2)%100][0]*2%10007;
		}
		printf ("%d\n",(f[l%100][1]+f[l%100][0])%10007);
	}
	return 0;
}
