#include "cstdio"
#include "cstring"
using namespace std;
char c[1000005];
int t;
int main(){
	freopen ("maths.in","r",stdin);
	freopen ("maths.out","w",stdout);
	scanf ("%d\n",&t);
	while (t--){
		scanf ("%s",c+1);
		int n=strlen(c+1);
		c[0]='0';
		int s=(c[n]-'0')+(c[n-1]-'0')*10;
		if (s%4==0) printf ("4\n");
		else printf ("0\n");
	}
	return 0;
}
