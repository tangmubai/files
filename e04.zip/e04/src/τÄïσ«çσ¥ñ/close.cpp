#include<iostream>
#include<stdio.h>
#include<math.h>
using namespace std;
long long qread(){
	long long a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
long long qabs(long long a){
	return a<0?-a:a;
}
bool qp(long long a){
	for(long long i=2,f;i*i<=a;++i){
		f=0;
		while(a%i==0){
			a/=i;
			++f;
		}
		if(f>1) return 0;
	}
	return a;
}
int main(){
	freopen("close.in","r",stdin);freopen("close.out","w",stdout);
	long long t=qread(),x,now,ans;bool f;
	while(t--){
		x=qread();
		ans=100000000000000000;
		for(now=0;now*now<=x;now+=1000);
		for(int i=now-1000;i<=now+5;++i){
			if(qp(i)) ans=min(ans,qabs(i*i-x));
		}
		printf("%lld\n",ans);
	}
	return 0;
}
