#include<iostream>
#include<stdio.h>
using namespace std;
string n;
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("maths.in","r",stdin);freopen("maths.out","w",stdout);
	int t=qread();
	while(t--){
		cin>>n;
		if((n[n.size()-1]^'0')%4==0) printf("4\n");
		else printf("0\n");
	}
	return 0;
}
