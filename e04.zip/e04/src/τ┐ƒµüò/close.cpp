#include <cstdio>
using namespace std;
long long t,n,x,y;
int zs (long long n) {
	for (long long i=2;i*i<=n;i++) if (n%i==0) return 0;
	return 1;
}
int fj (long long n) {
	for (long long i=2;;i++) {
		if (zs(i)==0) continue;
		if (i*i>n) return 0;
		if (i*i==n) return 1;
		if (n%(i*i)==0) n/=i*i;
	}
}
int main () {
	freopen ("close.in","r",stdin);
	freopen ("close.out","w",stdout);
	scanf ("%lld",&t);
	while (t--) {
		scanf ("%lld",&n);
		for (x=n,y=n;;x--,y++) {
			if (fj(x)==1) {printf ("%lld %lld\n",n-x,x); break;}
			if (fj(y)==1) {printf ("%lld %lld\n",y-n,y); break;}
		}
	}
	return 0;
}
