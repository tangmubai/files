#include <cstdio>
using namespace std;
int a[100001],t,n,i,f[10000001],f1[10000001],ans;
int main () {
	freopen ("dna.in","r",stdin);
	freopen ("dna.out","w",stdout);
	f[1]=2,f[2]=3; f1[1]=2;
	for (i=3;i<=10000000;i++) f[i]=(f[i-1]+f[i-2])%10007;
	for (i=2;i<=10000000;i++) f1[i]=(f[i-1]*f[i-1]+f1[i-1])%10007;
	scanf ("%d",&t);
	while (t--) {
		scanf ("%d",&n);
		if (n%2==0) printf ("%d\n",f[n/2]*f[n/2]%10007);
		else printf ("%d\n",f1[(n+1)/2]);
	}
	return 0;
}
