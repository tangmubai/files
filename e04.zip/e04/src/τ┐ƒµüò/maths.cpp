#include <cstdio>
#include <cstring>
using namespace std;
int t,x,n; char a[100001];
int main () {
	freopen ("maths.in","r",stdin);
	freopen ("maths.out","w",stdout);
	scanf ("%d",&t);
	while (t--) {
		scanf ("%s",a+1); n=strlen(a+1);
		x=(a[n-1]-48)*10+(a[n]-48);
		printf ("%d\n",x%4?0:4);
	}
	return 0;
}
