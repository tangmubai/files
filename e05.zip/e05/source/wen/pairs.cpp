#include <cstdio>
typedef long long ll;
int main(){
    freopen("pairs.in", "r", stdin);
    freopen("pairs.out", "w", stdout);
    int t, n, m;
    scanf("%d", &t);
    while (t--){
        scanf("%d %d", &n, &m);
        /*ll ans=0;
        for (int i=1; i<=n; i++)
            ans+=m/5+((m%5+i%5)>=5);
            //ans+=(i+m)/5-i/5;
        cout<<ans<<endl;*/
        
        ll x=n/5, y=m/5;
        int u=n%5, v=m%5;
        ll ans=x*y*5+u*y+v*x+((u+v)>4?u+v-4:0);
        printf("%lld\n", ans);
    }
    return 0;
}
