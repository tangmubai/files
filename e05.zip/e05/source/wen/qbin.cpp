#include <cstdio>
int main(){
	freopen("qbin.in", "r", stdin);
	freopen("qbin.out", "w", stdout);
	int d[10]={0, 1};
	for (int i=2; i<10; i++)
		d[i]=d[i-1]*10;
	int t, n;
	scanf("%d", &t);
	while (t--){
		scanf("%d", &n);
		int w, a[10]={0};
		for (w=0; n; n/=10)
			a[++w]=n%10;
		int k=0;
		int c[10]={0};
		for (int i=1; i<=w; i++){
			if (k<a[i]) k=a[i];
			for (int j=1; j<=a[i]; j++)
				c[j]+=d[i];
		}
		for (int i=k; i>0; i--)
			printf("%d ", c[i]);
		printf("\n");
	}
	return 0;
} 
