#include <cstdio>
inline bool btw(int a, int b, int c){
	return a>=b && a<=c;
}
int main(){
    freopen("square.in", "r", stdin);
    freopen("square.out", "w", stdout);
    int x, y, l, n;
    scanf("%d %d %d %d", &x, &y, &l, &n);
    int ans=0;
    while (n--){
		int u, v;
		scanf("%d %d", &u, &v);
		ans+= (btw(u, x, x+l) && btw(v, y, y+l));
	}
	printf("%d\n", ans);
    return 0;
}
