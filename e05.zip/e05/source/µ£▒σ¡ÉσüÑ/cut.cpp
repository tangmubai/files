#include <cstdio>
#include <cstring>
#define max(a,b) ((a)>(b)?(a):(b))
struct Edge{
	int to,next;
}e[200003];
int t,n,head[100003],len,size[100003],maxd[100003];
void add(int &u,int &v){
	e[++len].next=head[u],head[u]=len,e[len].to=v;
}
int dfs(int x,int fa){
	size[x]=1;
	for(int i=head[x];i;i=e[i].next){
		if(e[i].to!=fa){
			dfs(e[i].to,x);
			size[x]=max(size[x],size[e[i].to]);
		}
	}
	maxd[x]=n-size[x];
//	int s=1;
//	for(int i=head[x];i;i=e[i].next){
//		if(e[i].to!=fa) s+=dfs(e[i].to,x);
//	}
//	return s;
}
int main(){
	freopen("cut.in","r",stdin);freopen("cut.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		memset(e,0,sizeof e),memset(head,0,sizeof head),len=0,memset(size,0,sizeof size);
		for(int i=1;i<n;i++){
			int x,y;scanf("%d%d",&x,&y);
			add(x,y),add(y,x);
		}
		dfs(1,0);
		int mx=-(1<<30);
		for(int i=1;i<=n;i++) mx=max(mx,maxd[i]);
		for(int i=1;i<=n;i++) if(maxd[i]==mx) printf("%d ",i);
		puts("");
	}
	return 0;
}

