#include <cstdio>
int main(){
//	freopen("diff.in","r",stdin);freopen("diff.out","w",stdout);
	return 0;
}

