#include <cstdio>
long long n,m,a[5],b[5];
int main(){
	freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		scanf("%lld%lld",&n,&m);
		for(int i=0;i<5;i++) a[i]=n/5,b[i]=m/5;
		if(n%5){
			for(int i=1;i<5;i++) if(n%5>=i) ++a[i];
		}
		if(m%5){
			for(int i=1;i<5;i++) if(m%5>=i) ++b[i];
		}
		//for(int i=0;i<5;i++) printf("%lld %lld\n",a[i],b[i]);
		printf("%lld\n",a[0]*b[0]+a[1]*b[4]+a[2]*b[3]+a[3]*b[2]+a[4]*b[1]);
	}
	return 0;
}
/*
1 2 3 4 5 6
1 2 3 4 5 6 7 8 9 10 11 12
0 5
1 4
2 3
3 2
4 1

1 2
2 3
1 3
1 2
1 2

*/
