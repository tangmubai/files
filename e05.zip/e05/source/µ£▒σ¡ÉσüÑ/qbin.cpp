#include <cstdio>
#include <algorithm>
int t,n,bin[515],len,a[100003],lena;
int sw(int n){
	if(!n) return 1;
	int s=0;
	while(n) ++s,n/=10;
	return s;
}
void init(){
	for(int i=1;i<(1<<9);i++){
		++len;
//		int tmp=i,q=1;
//		while(tmp){
//			bin[len]=bin[len]*10+q*(tmp&1);
//			tmp>>=1,++q;
//		}
		int b[11]={0},tmp=i,lenb=0;
		while(tmp) b[++lenb]=(tmp&1),tmp>>=1;
		for(int i=lenb;i>=1;i--) bin[len]=bin[len]*10+b[lenb];
	}
}
bool cmp(int x,int y){
	return x<y;
}
int main(){
	freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
	init();
	//for(int i=1;i<=len;i++) printf("%d ",bin[i]);puts("");
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		lena=0;
		for(int i=(1<<sw(n))-1;i>=1;i--){
			if(n<10) for(int i=1;i<=n;i++) a[++lena]=bin[1];
			else if(n>=bin[i]){
				int s=1,lim=n/bin[i]-1;
				while(n>=bin[i]&&s<=lim) n-=bin[i],a[++lena]=bin[i],++s;
			}
		}
//		for(int i=(1<<sw(n))-1;i>=(1<<sw(n)-2)+1;i--){
//			
//		}
		std::sort(a+1,a+1+lena,cmp);
		for(int i=1;i<=lena;i++) printf("%d ",a[i]);
		puts("");
	}
	return 0;
}
/*
1 1
2 10
3 11
4 100
5 101
6 110
7 111
463=2,2,6,7,7,7

*/
