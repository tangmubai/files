#include <cstdio>
int x1,y1,l,n,ans,x2,y2;
int main(){
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&x1,&y1,&l,&n);
	x2=x1+l,y2=y1+l;
	while(n--){
		int a,b;scanf("%d%d",&a,&b);
		if(x1<=a&&a<=x2&&y1<=b&&b<=y2) ++ans;
	}
	printf("%d\n",ans);
	return 0;
}
