#include <cstdio>
#include <algorithm>
inline int read(){
	int x=0,w=0;char c=getchar();
	for(;c<'0'||c>'9';w^=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=getchar());
	return w?-x:x;
}
int n,n1,n2,a[3000003],max=-(1<<30),min=1<<30;
double s1,s2;
bool vis[3000003];
int main(){
	freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	n=read(),n1=read(),n2=read();
	for(int i=1;i<=n;i++) a[i]=read();
	std::sort(a+1,a+1+n);
	for(int i=1;i<=n2;i++) s2+=a[i];
	for(int i=n;i>=n-n1+1;i--) s1+=a[i];
	printf("%.3lf\n",s1/n1-s2/n2);
	return 0;
}
