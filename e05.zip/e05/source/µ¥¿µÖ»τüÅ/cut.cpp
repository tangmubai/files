#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<vector>
#include<queue>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &n)
{
	char ch = ' ';
	int num = 0, sign = 0;
	while(!isdigit(ch))
	{
		sign |= (ch == '-'), ch = getchar();
		if(ch == EOF)
			return -1;
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if(n < 0)
		n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


vector<int> edge[100010];
int f[100010], n;
priority_queue<int, vector<int>, greater<int> > ans;


int dfs(int r, int fa)
{
	if(f[r] != -1)
		return f[r];
	
	
	bool flag = 1;
	f[r] = 1;
	
	
	for(vector<int>::iterator it = edge[r].begin(); it < edge[r].end(); it++)
	{
		if(*it == fa)
			continue;
			
			
		int d = dfs(*it, r);
		
		if(d > n / 2)
			flag = 0;
		
		f[r] += d;
	}
	
	
	if(flag && n - f[r] <= n / 2)
		ans.push(r);
	
	return f[r];
}


int main()
{
	freopen("cut.in", "r", stdin);
	freopen("cut.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	
	for(int ii=1; ii<=tt; ii++)
	{
		in(n);
		
		
		for(int i=1; i<=n; i++)
			edge[i].clear();
			
		
		for(int i=1; i<n; i++)
		{
			int a, b;
			in(a), in(b);
			
			edge[a].push_back(b);
			edge[b].push_back(a);
		}
		
		
		memset(f, -1, sizeof(f));
		dfs(1, -1);
		
		
		if(ans.empty())
			printf("None");
		
		while(!ans.empty())
			out(ans.top()), space, ans.pop();
		
		enter;
	}
}

