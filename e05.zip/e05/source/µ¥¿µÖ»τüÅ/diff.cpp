#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &n)
{
	char ch = ' ';
	int num = 0, sign = 0;
	while(!isdigit(ch))
	{
		sign |= (ch == '-'), ch = getchar();
		if(ch == EOF)
			return -1;
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if(n < 0)
		n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int a[310], n;

bool check(int mid)
{
	int sum1 = 0, sum2 = 0;
	
	for(int i=1; i<=n; i++)
	{
		if(sum1 + a[i] - sum2 <= mid)
			sum1 += a[i];
		
		else
			sum2 += a[i];
	}
	
	
	return sum2 - sum1 <= mid && sum1 - sum2 <= mid;
}


int main()
{
	freopen("diff.in", "r", stdin);
	freopen("diff.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	
	for(int ii=1; ii<=tt; ii++)
	{
		in(n);
		
		
		register int left = 0, right = 0, mid;
		
		for(int i=1; i<=n; i++)
			in(a[i]), right += a[i];
		
		
		while(left < right)
		{
			mid = (left + right) >> 1;
			
			
			if(check(mid))
				right = mid - 1;
			
			else
				left = mid + 1;
		}
		
		
		out(left - 1), enter;
	}
}

