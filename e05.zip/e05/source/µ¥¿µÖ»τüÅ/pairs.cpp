#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline long long in(long long &n)
{
	char ch = ' ';
	long long num = 0, sign = 0;
	while(!isdigit(ch))
	{
		sign |= (ch == '-'), ch = getchar();
		if(ch == EOF)
			return -1;
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = sign ? -num : num;
	return 1;
}

inline void out(long long n)
{
	if(n < 0)
		n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


void MOD(long long n, long long a[])
{
	a[0] = a[1] = a[2] = a[3] = a[4] = n / 5;
	
	for(long long i=1; i<=n%5; i++)
		a[i]++;
}


int main()
{
	freopen("pairs.in", "r", stdin);
	freopen("pairs.out", "w", stdout);
	
	
	long long tt;
	in(tt);
	
	for(long long ii=1; ii<=tt; ii++)
	{
		long long n, m;
		in(n), in(m);
		
		
		long long b[10], g[10];
		MOD(n, b), MOD(m, g);
		
		
		out(b[0] * g[0] + b[1] * g[4] + b[2] * g[3] + b[3] * g[2] + b[4] * g[1]), \
		enter;
	}
}

