#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<vector>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &n)
{
	char ch = ' ';
	int num = 0, sign = 0;
	while(!isdigit(ch))
	{
		sign |= (ch == '-'), ch = getchar();
		if(ch == EOF)
			return -1;
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if(n < 0)
		n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


bool check(char n[], int len)
{
	for(int i=0; i<len; i++)
		if(n[i] != '0')
			return 1;
	
	return 0;
}


int main()
{
	freopen("qbin.in", "r", stdin);
	freopen("qbin.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	
	for(int ii=1; ii<=tt; ii++)
	{
		char n[20];
		scanf("%s", n);
		
		int len = strlen(n);
		
		
		vector<int> ans;
		
		while(check(n, len))
		{
			int num = 0;
		
			for(int i=0; i<len; i++)
			{
				if(n[i] != '0')
					n[i]--, num = num * 10 + 1;
				
				else
					num *= 10;
			}
			
			
			ans.push_back(num);
		}
		
		
		for(int i=ans.size()-1; i>=0; i--)
			out(ans[i]), space;
		
		enter;
	}
}

