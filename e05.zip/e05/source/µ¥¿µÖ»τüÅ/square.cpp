#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &n)
{
	char ch = ' ';
	int num = 0, sign = 0;
	while(!isdigit(ch))
	{
		sign |= (ch == '-'), ch = getchar();
		if(ch == EOF)
			return -1;
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if(n < 0)
		n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int main()
{
	freopen("square.in", "r", stdin);
	freopen("square.out", "w", stdout);
	
	
	int x1, y1, l, n;
	in(x1), in(y1), in(l), in(n);
	
	int x2 = x1 + l, y2 = y1 + l; 
	
	
	register int ans = 0;
	
	for(int i=1; i<=n; i++)
	{
		int x, y;
		in(x), in(y);
		
		
		if(x >= x1 && x <= x2 && y >= y1 && y <= y2)
			ans++;
	}
	
	
	out(ans);
}

