#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<queue>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &n)
{
	char ch = ' ';
	int num = 0, sign = 0;
	while(!isdigit(ch))
	{
		sign |= (ch == '-'), ch = getchar();
		if(ch == EOF)
			return -1;
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if(n < 0)
		n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int a[3000010];

int main()
{
	freopen("statistic.in", "r", stdin);
	freopen("statistic.out", "w", stdout);
	
	
	int n, n1, n2;
	in(n), in(n1), in(n2);
	
	for(register int i=0; i<n; i++)
		in(a[i]);
	
	sort(a, a+n);
	
	
	register long long sum1 = 0, sum2 = 0;
	
	for(register int i=n-1; n-i <= n1; i--)
		sum1 += a[i];
	
	for(register int i=0; i < n2; i++)
		sum2 += a[i];
	
	
	printf("%.3lf", 1. * sum1 / n1 - 1. * sum2 / n2);
}

