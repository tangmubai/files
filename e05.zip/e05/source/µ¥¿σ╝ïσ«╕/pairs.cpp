#include<iostream>
#include<cstring>
using namespace std;
long long a[5],b[5];
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		int n,m;
		unsigned long long ans=0;
		cin>>n>>m;
		for(int i=1;i<=n;i++)a[i%5]++;
		for(int i=1;i<=m;i++)b[i%5]++;
		for(int i=0;i<5;i++){
			if(i==0)ans+=a[i]*b[i];
			else ans+=a[i]*b[5-i];
		}
		cout<<ans<<endl;
	}
	return 0;
}
