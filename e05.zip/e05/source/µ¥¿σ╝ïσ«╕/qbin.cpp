#include<iostream>
#include<cstring>
#include<cmath>  
using namespace std;
int maxn;
int a[10],b[10];
void fj(int n){
	int maxnum=0,len=1;
	while(n){
		maxnum=max(maxnum,n%10);
		b[len]=n%10;
		len++;
		n/=10;
	}
	maxn=maxnum;
}
void work(int n){
	for(int i=1;i<=9;i++)for(int j=1;j<=b[i];j++)a[j]+=pow(10,i-1);
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		memset(a,0,sizeof(a));
		int n;
		cin>>n;
		fj(n);
		work(n);
		for(int i=maxn;i>=1;i--)cout<<a[i]<<" ";
		cout<<endl;
	}
	return 0;
}
