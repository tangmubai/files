#include<iostream>
using namespace std;
struct node{
	int x,y;
}a[10005];
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int x,y,l,n;
	cin>>x>>y>>l>>n;
	for(int i=1;i<=n;i++)cin>>a[i].x>>a[i].y;
	int ans=0;
	int x1=x+l,y1=y+l;
	for(int i=1;i<=n;i++)if(a[i].x>=x&&a[i].x<=x1&&a[i].y>=y&&a[i].y<=y1)ans++;
	cout<<ans;
	return 0;
}
