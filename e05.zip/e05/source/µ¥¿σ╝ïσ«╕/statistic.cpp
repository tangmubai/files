#include<algorithm>
#include<iostream>
#include<cstdio>
using namespace std;
long long a[3000005];
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n,n1,n2;
	cin>>n>>n1>>n2;
	for(int i=1;i<=n;i++)cin>>a[i];
	double s1=0,s2=0;
	sort(a+1,a+1+n);
	for(int i=1;i<=n1;i++)s1+=a[n-i+1];
	for(int i=1;i<=n2;i++)s2+=a[i];
	s1=s1/n1;
	s2=s2/n2;
	double ans=s1-s2;
	printf("%.3f",ans);
	return 0;
}
