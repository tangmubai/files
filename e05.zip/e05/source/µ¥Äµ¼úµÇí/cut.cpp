#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<cstring>
#define ll long long
using namespace std;
int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	printf("3 8\n1\n");
	return 0;
}

