#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<cstring>
#define ll long long
using namespace std;
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	ll n,m,t,k,ans;
	scanf("%lld",&t);
	while(t--){
		ans=0;
		scanf("%lld%lld",&n,&m);
		for(ll i=1;i<=n;i++){
			k=i%5;
			if(k==1){
				ans+=m/5;
				if(m%5!=0&&m-((m/5)*5)>=4)ans++; 
			}
			if(k==2){
				ans+=m/5;
				if(m%5!=0&&m-((m/5)*5)>=3)ans++; 
			}
			if(k==3){
				ans+=m/5;
				if(m%5!=0&&m-((m/5)*5)>=2)ans++; 
			}
			if(k==4){
				ans+=m/5;
				if(m%5!=0&&m-((m/5)*5)>=1)ans++; 
			}
			if(k==0)ans+=m/5;
		}
		printf("%lld\n",ans);
	}
	return 0;
}

