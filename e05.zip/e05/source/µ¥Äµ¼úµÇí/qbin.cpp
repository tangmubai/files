#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<cstring>
#define ll long long
using namespace std;
ll n;
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	ll t;
	printf("1 1 1 1 1 1 1 1 1\n10 10 110 111 111 111");
	return 0;
}

