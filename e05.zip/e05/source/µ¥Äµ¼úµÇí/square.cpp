#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<cstring>
#define ll long long
using namespace std;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	ll x,y,l,n,ans=0,a,b;
	scanf("%lld%lld%lld%lld",&x,&y,&l,&n);
	while(n--){
		scanf("%lld%lld",&a,&b);
		if(a>=x&&a<=x+l&&b>=y&&b<=y+l){
			ans++;
		}
	}
	printf("%lld\n",ans);
	return 0;
}
