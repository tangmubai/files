#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<cstring>
#define ll long long
using namespace std;
ll a[3000005],ans1,ans2;
inline int read(){
	register int x=0;
	register char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	ll n,n1,n2;
	scanf("%lld%lld%lld",&n,&n1,&n2);
	for(ll i=1;i<=n;i++)a[i]=read();
	sort(a+1,a+n+1);
	for(ll i=1;i<=n1;i++)ans1+=a[n-i+1];
	for(ll i=1;i<=n2;i++)ans2+=a[i];
	printf("%.3lf\n",double(ans1*1.0/n1)-double(ans2*1.0/n2));
	return 0;
}

