#include<stdio.h>
#define int long long
#define abs(a)((a)>0?(a):-(a))
#define min(a,b)((a)<(b)?(a):(b))
#define max(a,b)((a)>(b)?(a):(b))
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
int a[10];
void work(){
	int n,m;
	scanf("%lld%lld",&n,&m);
	int sum=0;
	for(int i=1;i<=5;i++){
		int tmp=5-i;
		if(tmp==0){
			tmp=5;
		}
		a[i]=(m-tmp)/5+1;
		sum+=a[i];
	}
	int ans=(n/5)*sum;
	for(int i=1;i<=n%5;i++){
		ans+=a[i];
	}
	printf("%lld\n",ans);
	return;
}
signed main(){
	file("pairs");
	int t;
	scanf("%lld",&t);
	while(t--){
		work();
	}
	return 0;
}
