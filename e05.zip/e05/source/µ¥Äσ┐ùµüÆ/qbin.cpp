#include<stdio.h>
#define abs(a)((a)>0?(a):-(a))
#define min(a,b)((a)<(b)?(a):(b))
#define max(a,b)((a)>(b)?(a):(b))
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
int a[120],ans[120];
void work(){
	int n;
	scanf("%d",&n);
	int len=0,maxn=0;
	while(n){
		a[++len]=n%10;
		n/=10;
		maxn+=a[len];
	}
	for(int i=1;i<=maxn;i++){
		ans[i]=0;
		for(int j=len;j>0;j--){
			ans[i]*=10;
			if(a[j]){
				ans[i]++;
				a[j]--;
			}
		}
	}
	for(int i=maxn;i>0;i--){
		if(ans[i]){
			printf("%d ",ans[i]);
		}
	}
	printf("\n");
	return;
}
int main(){
	file("qbin");
	int t;
	scanf("%d",&t);
	while(t--){
		work();
	}
	return 0;
}
