#include<stdio.h>
#define abs(a)((a)>0?(a):-(a))
#define min(a,b)((a)<(b)?(a):(b))
#define max(a,b)((a)>(b)?(a):(b))
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
int main(){
	file("square");
	int x,y,l,n;
	scanf("%d%d%d%d",&x,&y,&l,&n);
	int cnt=0;
	while(n--){
		int xi,yi;
		scanf("%d%d",&xi,&yi);
		if((xi>=x)&&(yi>=y)&&(xi<=x+l)&&(yi<=y+l)){
			cnt++;
		}
	}
	printf("%d",cnt);
	return 0;
}
