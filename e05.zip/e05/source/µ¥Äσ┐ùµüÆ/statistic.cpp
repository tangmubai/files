#include<stdio.h>
#include<algorithm>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
using std::sort;
inline int read(){
    register int s=0;
    register char c=getchar();
    for(;c<'0'||c>'9';c=getchar());
    for(;c>='0'&&c<='9';c=getchar())s=(s<<1)+(s<<3)+c-'0';
    return s;
}
int a[3000050];
int main(){
	file("statistic");
	register int n,n1,n2;
	n=read(),n1=read(),n2=read();
	for(register int i=1;i<=n;i++){
		a[i]=read();
	}
	sort(a+1,a+n+1);
	register double a1,a2;
	for(register int i=1;i<=n1;i++){
		a1+=a[n-i+1];
	}
	a1/=(double)n1;
	for(register int i=1;i<=n2;i++){
		a2+=a[i];
	}
	a2/=(double)n2;
	printf("%.3f",a1-a2);
	return 0;
}
