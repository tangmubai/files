#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

char s[20],k[20],T[20];

int t,n,len,p,ans[101010],i,j;

int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}

int main () {
	freopen ("cut.in","r",stdin);
	freopen ("cut.out","w",stdout);
	t=read ();
	while (t--) {
//		n=read ();//		j=n=0;
////		for (i=1;i<=len;i++)
//////			k[i]=1;
////		for (i=1;i<=len;i++) 
////			n=n*10+s[i]-'0';
////		while (n) {
////			p=0;
////			for (i=1;i<=len;i++)
////				p=p*10+k[i]-'0';
////			while (p<=n) {
////				n-=p;
////				ans[++j]=p;
////			}
////			
////		}
//		while (n--) 
//			printf ("1 ");
		puts ("None");
	}
	return 0;
}
