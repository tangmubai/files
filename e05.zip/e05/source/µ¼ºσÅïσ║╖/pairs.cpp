#include <cstdio>
#include <algorithm>

using namespace std;

long long t,n,m,ans,i,a[10],b[10];

long long read () {
	long long k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}

int main () {
	freopen ("pairs.in","r",stdin);
	freopen ("pairs.out","w",stdout);
	t=read ();
	while (t--) {
		for (i=0;i<5;i++)
			a[i]=b[i]=0;
		ans=0;
		n=read ();
		m=read ();
		a[0]=n/5;
		a[1]=n/5;
		a[2]=n/5;
		a[3]=n/5;
		a[4]=n/5;
		for (i=n/5*5;i<=n;i++) 
			if (i%5!=0) 
				a[i%5]++;
		b[0]=m/5;
		b[1]=m/5;
		b[2]=m/5;
		b[3]=m/5;
		b[4]=m/5;
		for (i=m/5*5;i<=m;i++) 
			if (i%5!=0) 
				b[i%5]++;
		printf ("%lld\n",a[0]*b[0]+a[1]*b[4]+a[2]*b[3]+a[3]*b[2]+a[4]*b[1]);
	}
	return 0;
} 
