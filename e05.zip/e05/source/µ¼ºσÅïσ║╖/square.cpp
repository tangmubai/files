#include <cstdio>
#include <algorithm>

using namespace std;

int X,Y,m,n,i,x,y,ans,A,B,C,D;

int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}

int main () {
	freopen ("square.in","r",stdin);
	freopen ("square.out","w",stdout);
	X=read ();
	Y=read ();
	m=read ();
	n=read ();
	A=X;
	B=X+m;
	C=Y;
	D=Y+m;
	for (i=1;i<=n;i++) {
		x=read ();
		y=read ();
		if (x>=A&&x<=B&&y>=C&&y<=D) 
			ans++;
	}
	printf ("%d\n",ans);
	return 0;
}
