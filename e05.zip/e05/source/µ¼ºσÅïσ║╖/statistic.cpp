#include <cstdio>
#include <algorithm>

using namespace std;

long long n,n1,n2,a[3000010],s1,s2,i;

long long read () {
	long long k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}

int main () {
	freopen ("statistic.in","r",stdin);
	freopen ("statistic.out","w",stdout);
	n=read ();
	n1=read ();
	n2=read ();
	for (i=1;i<=n;i++)
		a[i]=read ();
	s1=s2=0;
	sort (a+1,a+1+n);
	for (i=1;i<=n2;i++)
		s2+=a[i];
	for (i=n;i>n-n1;i--) 
		s1+=a[i];
	printf ("%.3lf\n",s1*1.0/n1-s2*1.0/n2);
	return 0;
}
