#include <cstdio>
#include <cstring>
using namespace std;
void in(int &x){
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	x=0;
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return;
} 
struct Edge{
	int x,y,next;
}e[100010];
int h[100010],tot,n,tmp,c[100010],u,w,mx,cnt[100010],mxcs;bool ok,flag,v[100010];
void add(int x,int y){
	tot++;
	e[tot].x=x;
	e[tot].y=y;
	e[tot].next=h[x];
	h[x]=tot;
	return;
}
void dfs1(int i,int cs){
	v[i]=1;c[i]=cs;
	for(int j=h[i];j;j=e[j].next){
		if(v[e[j].y])continue;
		dfs1(j,cs+1);
	}
	return;
}
int dfs(int now){
	int dt=1;
	for(int i=h[now];i;i=e[i].next){
		if(v[e[i].y])continue;
		v[e[i].y]=1;
		dt+=dfs(e[i].y);
		if(dt>mx)break;
	}
	return dt;
}
int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		tot=0;memset(h,0,sizeof(h));
		scanf("%d",&n);
		if(n&1)mx=(n-1)/2;
		else mx=n/2;
		for(int i=1;i<n;i++){
			in(u);in(w);
			add(u,w);add(w,u);
		}
		dfs1(1,1);
		for(int i=1;i<=mxcs;i++)
			cnt[i]+=cnt[i-1];
		ok=1;
		for(int i=1;i<=n;i++){
			if(c[i]>mx)continue;
			memset(v,0,sizeof(v));
			flag=1;
			v[i]=1;
			for(int j=1;flag&&j<=n;j++)
				if(!v[j]){
					v[j]=1;
					tmp=dfs(j);
					if(tmp>mx)flag=0;
				}
			if(flag){
				printf("%d ",i);
				ok=0;
			}
		}
		if(ok)puts("None");
		else printf("\n");
	}
	return 0;
}
