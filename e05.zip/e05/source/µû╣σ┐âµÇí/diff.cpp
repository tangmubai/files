#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;
int a[310],s[310],n;bool f[310][30010];
bool Isok(int d){
	for(int i=1;i<=n;i++){
		int j;
		for(j=0;j<=s[i]/2;j++){
			if(s[i]-j-j>d)continue;
			if(f[i][j])break;
		}
		if(j<=s[i]/2&&s[i]-j-j<=d&&f[i][j])continue;
		else return 0;
	}
	return 1;
}
bool Isok1(int d){
	int s1=0,s2=0;
	for(int i=1;i<=n;i++){
		if(s2+a[i]-s1<=d)s2+=a[i];
		else{
			s1+=a[i];
			if(abs(s1-s2)>d)return 0;
		}
		if(s1>s2){
			int tp=s1;s1=s2;s2=tp;
		}
	}
	return 1;
}
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		memset(s,0,sizeof(s));
		memset(f,0,sizeof(f));
		int sum=0;scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			sum+=a[i];
			s[i]=s[i-1]+a[i];
		}
		for(int i=0;i<=n;i++)
			f[i][0]=1;
		for(int i=1;i<=n;i++)
			for(int j=0;j<=sum;j++){
				f[i][j]=f[i-1][j];
				if(j>=a[i]&&f[i-1][j-a[i]])f[i][j]=1;
			}
//		for(int i=1;i<=n;i++){
//			for(int j=0;j<=sum;j++)
//				printf("%d ",f[i][j]);
//			printf("\n");
//		}
		int l=0,r=sum;
		while(l<=r){
			int mid=(l+r)>>1;
			if(Isok(mid))r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",l+1);
	}
	return 0;
}
