#include <cstdio>
void in(int &x){
	char c=getchar();int tmp=1;
	while(c<'0'||c>'9'){
		if(c=='-')tmp=-1;
		c=getchar();
	}
	x=0;
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	x*=tmp;
	return;
}
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int x1,y1,x2,y2,l,n,tx,ty,ans=0;scanf("%d%d%d%d",&x1,&y1,&l,&n);
	x2=x1+l;y2=y1+l;
	for(int i=1;i<=n;i++){
		scanf("%d%d",&tx,&ty);
		if(tx>=x1&&tx<=x2&&ty>=y1&&ty<=y2)ans++;
	}
	printf("%d\n",ans);
	return 0;
} 
