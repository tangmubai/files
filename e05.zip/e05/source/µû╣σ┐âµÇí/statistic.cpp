#include <cstdio>
#include <algorithm>
using namespace std;
int a[3000010];
void in(int &x){
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	x=0;
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return;
}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n,n1,n2;in(n);in(n1);in(n2);
	for(int i=1;i<=n;i++)
		in(a[i]);
	sort(a+1,a+1+n);
	//f(1,n);
	long long s1=0,s2=0;
	for(int i=n,cnt=1;cnt<=n1;i--,cnt++)
		s1+=a[i];
	for(int i=1;i<=n2;i++)
		s2+=a[i];
	double ans=1.0l*s1/n1-1.0l*s2/n2;
	printf("%.3f\n",ans);
	return 0;
}
