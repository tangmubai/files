#include <cstdio>
#include <cstring>

struct Edge{
	int to,nxt;
}a[200005];

int test_num,n,edge_num;
int head[100005],sum[100005],f[100005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

void add_edge(int x,int y){
	a[++edge_num].nxt=head[x];
	a[edge_num].to=y;
	head[x]=edge_num;
}

void dfs(int i,int fa){
	sum[i]=1;
	f[i]=fa;
	for(int j=head[i];j;j=a[j].nxt){
		if(a[j].to==fa)continue;
		dfs(a[j].to,i);
		sum[i]+=sum[a[j].to];
	}
	return;
}

int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	test_num=read();
	while(test_num--){
		n=read();
		edge_num=0;
		memset(sum,0,sizeof(sum));
		memset(head,0,sizeof(head));
		for(int i=1;i<n;++i){
			int x=read(),y=read();
			add_edge(x,y);
			add_edge(y,x);
		}
		dfs(1,n);
		bool ok=1;
		for(int i=1;i<=n;++i){
			bool flag=1;
			for(int j=head[i];j;j=a[j].nxt){
				if(a[j].to==f[i])continue;
				if(sum[a[j].to]>n/2){
					flag=0;
					break;
				}
			}
			if(flag && n-sum[i]<=n/2){
				printf("%d ",i);
				ok=0;
			}
		}
		if(ok){
			printf("None");
		}
		puts("");
	}
	return 0;
}
