#include <cstdio>
#include <cstring>

int test_num,n,sum,l,r,mid;
int a[305],bef[305];
bool f[305][30005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int mabs(int x){
	return x>=0?x:-x;
}

bool test(int x){
	memset(f,0,sizeof(f));
	f[0][0]=1;
	for(int i=1;i<=n;++i){
		for(int j=0;j<=bef[i];++j){
			if(mabs(bef[i]-j-j)<=x){
				if(j>=a[i]){
					f[i][j]|=f[i-1][j-a[i]];
				}
				f[i][j]|=f[i-1][j];
			}
		}
	}
	for(int j=0;j<bef[n];++j){
		if(f[n][j]){
			return true;
		}
	}
	return false;
}

int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	test_num=read();
	while(test_num--){
		n=read();
		sum=0;
		for(int i=1;i<=n;++i){
			a[i]=read();
			bef[i]=bef[i-1]+a[i];
			sum+=a[i];
		}
		l=0,r=sum;
		while(l<=r){
			mid=(l+r)>>1;
			if(test(mid)){
				r=mid-1;
			}else {
				l=mid+1;
			}
		}
		printf("%d\n",l);
	}
	return 0;
}
