#include <cstdio>
typedef long long ll;

ll test_num,n,m,ans0,ans1,ans2,ans3,ans4;

inline ll read(){
	ll s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	test_num=read();
	while(test_num--){
		n=read(),m=read();
		ans0=(n/5)*(m/5);
		ans1=((n/5)+(n%5>=1))*((m/5)+(m%5>=4));
		ans2=((n/5)+(n%5>=2))*((m/5)+(m%5>=3));
		ans3=((n/5)+(n%5>=3))*((m/5)+(m%5>=2));
		ans4=((n/5)+(n%5>=4))*((m/5)+(m%5>=1));
		printf("%lld\n",ans0+ans1+ans2+ans3+ans4);
	}
	return 0;
}
