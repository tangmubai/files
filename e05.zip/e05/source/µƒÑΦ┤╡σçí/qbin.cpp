#include <cstdio>

int test_num,n;

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

void work(int x){
	if(x==0){
		return;
	}
	if(x==1){
		printf("1 ");
		return;
	}
	int s=0,ss=0,tmp=x,tp=1;
	while(tmp){
		if(tmp%10>=1){
			s=(s<<3)+(s<<1)+1;
		}else {
			if(s==0)tp*=10;
			s=(s<<3)+(s<<1);
		}
		tmp/=10;
	}
	while(s){
		ss=(ss<<3)+(ss<<1)+s%10;
		s/=10;
	}
	ss*=tp;
	work(x-ss);
	printf("%d ",ss);
}

int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	test_num=read();
	while(test_num--){
		n=read();
		work(n);
		puts("");
	}
	return 0;
}
