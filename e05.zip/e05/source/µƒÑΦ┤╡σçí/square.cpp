#include <cstdio>

int x,y,xx,yy,len,n,ans;

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	x=read(),y=read(),len=read(),n=read();
	xx=x+len;
	yy=y+len;
	for(int i=1;i<=n;++i){
		int a=read(),b=read();
		if(a>=x && a<=xx && b>=y && b<=yy){
			++ans;
		}
	}
	printf("%d",ans);
	return 0;
}
