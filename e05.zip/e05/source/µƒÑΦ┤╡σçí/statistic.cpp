#include <cstdio>
#include <algorithm>
using namespace std;
typedef long long LL;

LL n,n1,n2,mid,i,j;
LL a[3000005];
double ans1,ans2;

inline LL read(){
	LL s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	n=read(),n1=read(),n2=read();
	for(i=1;i<=n;++i){
		a[i]=read();
	}
	sort(a+1,a+n+1);
	for(i=1;i<=n1;++i){
		ans1+=a[n-i+1];
	}
	for(i=1;i<=n2;++i){
		ans2+=a[i];
	}
	printf("%.3lf",ans1/n1-ans2/n2);
	return 0;
}
