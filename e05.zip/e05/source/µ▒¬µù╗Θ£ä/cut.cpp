#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
int f[100005],to[200005],head[200005],next[200005],num_edge;
void add(int x,int y){
	next[++num_edge]=head[x];
	to[num_edge]=y;
	head[x]=num_edge;
}
int A(){
	char c=getchar();
	int a=0,k=1;
	while(c>'9'||c<'0'){
		c=='-'?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int n,t,x,y,ans[5],len;
int max(int x,int y){
	return x>y?x:y;
}
void dfs(int x,int fa){
	int maxx=0;
	for(register int i=head[x];i;i=next[i]){
		int j=to[i];
		if(j!=fa){
			dfs(j,x);maxx=max(maxx,f[j]);
			f[x]+=f[j]+1;
		}
	}
	maxx=max(maxx,n-f[x]);
	if(maxx<=n/2)ans[++len]=x;
	return;
}
int main(){
	freopen("cut.in","r",stdin);freopen("cut.out","w",stdout);
	t=A();
	while(t--){
		memset(f,0,sizeof(f));memset(to,0,sizeof(to));
		memset(head,0,sizeof(head));memset(next,0,sizeof(next));
		n=A();len=0;
		for(register int i=1;i<n;++i){
			x=A(),y=A();
			add(x,y);add(y,x);
		}
		dfs(1,0);
		sort(ans+1,ans+1+len);
		for(register int i=1;i<=len;++i)
		printf("%d ",ans[i]);
		putchar('\n');
	}
}
