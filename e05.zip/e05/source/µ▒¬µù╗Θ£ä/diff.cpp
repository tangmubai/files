#include<stdio.h>
#include<iostream>
#include<string.h>
using namespace std;
int f[305][305],n,t,a[305],maxx,minn;
int abs(int x){
	return x<0?-x:x;
}
int main(){
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);maxx=0;memset(f,0x3f,sizeof(f));
		for(register int i=1;i<=n;++i)scanf("%d",&a[i]);
		for(register int i=1;i<=n;++i){
			f[i][0]=f[i-1][0]-a[i];
			for(register int j=0;j<=i;++j)
			if(abs(f[i][j-1]+a[i])<abs(f[i-1][j]-a[i]))
			f[i][j]=f[i][j-1]+a[i];
			else f[i][j]=f[i-1][j]-a[i];
			minn=abs(f[i][0]);
			for(register int j=1;j<=i;++j)
			minn=min(minn,abs(f[i][j]));
			maxx=max(maxx,minn);
		}
		printf("%d\n",maxx);
	}
}
