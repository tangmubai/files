#include<stdio.h>
long long n,m,s;
int t;
int getsum(int x,int y){
	if((x%5>=y)&&y)return x/5+1;
	return x/5;
}
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%lld%lld",&n,&m);
		s=0;
		for(register int i=0;i<5;++i)
		s+=getsum(n,i)*1ll*getsum(m,(5-i)%5);
		printf("%lld\n",s);
	}
}
