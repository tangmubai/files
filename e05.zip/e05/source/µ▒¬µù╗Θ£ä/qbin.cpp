#include<stdio.h>
#include<algorithm>
using namespace std;
int b[12],n,t,lenn,x;
struct stu{
	int a,id;
	friend bool operator<(stu x,stu y){
		return x.a>y.a;
	}
}ans[15];
int main(){
	freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
	b[1]=1;
	for(register int i=2;i<=10;++i)b[i]=b[i-1]*10;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);x=n;
		lenn=0;int maxx=0;
		while(x){
			++lenn;ans[lenn].id=lenn;
			ans[lenn].a=x%10;x/=10;
		}
		while(n){
			sort(ans+1,ans+1+lenn);
			maxx=ans[1].a;x=0;
			for(register int i=1;i<=lenn;++i)
			ans[i].a==maxx?x+=b[ans[i].id],--ans[i].a,n-=b[ans[i].id]:0;
			printf("%d ",x);
		}
		putchar('\n');
	}
}
