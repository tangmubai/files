#include<stdio.h>
int x1,y1,l,n,xx,yy,x2,y2,s;
int A(){
	char c=getchar();
	int a=0,k=1;
	while(c>'9'||c<'0'){
		c=='-'?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int main(){
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	x1=A(),y1=A(),l=A(),n=A();
	x2=x1+l,y2=y1+l;
	while(n--){
		xx=A(),yy=A();
		if(xx>=x1&&xx<=x2&&yy>=y1&&yy<=y2)++s;
	}
	printf("%d",s);
}
