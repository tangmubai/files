#include<algorithm>
#include<stdio.h>
using namespace std;
int a[3000005];
double s1,s2;
int A(){
	char c=getchar();
	int a=0,k=1;
	while(c>'9'||c<'0'){
		c=='-'?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int n,n1,n2,x,y,z;
int main(){
	freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	n=A();n1=A(),n2=A();
	for(register int i=1;i<=n;++i)
	a[i]=A();
	sort(a+1,a+1+n);
	for(register int i=1;i<=n2;++i)s2+=a[i];
	for(register int i=n,j=1;j<=n1;++j,--i)s1+=a[i];
	printf("%.3lf",s1/n1-s2/n2);
}
