#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include<algorithm>
using namespace std;
int t,n,a[350],sum;
bool check(int mid){
	int l,r;
	for(int i=1;i<=n;i++){
		if(l<r){
			if(r+a[i]-l<=mid)
			    r+=a[i];
			else
			    l+=a[i];   
		}
		else{
			if(l+a[i]-r<=mid)
			    l+=a[i];
			else
			    r+=a[i];   
		}
		if(abs(l-r)>mid)
		    return 0;
	}
	return 1;
}
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
		    scanf("%d",&a[i]);
		    sum+=a[i];
		}
		int l=a[1],r=sum,mid;
		while(l<r){
			mid=l+r>>1;
			if(check(mid)) l=mid;
			else r=mid;
		}
		printf("%d\n",l+1);
	}
	return 0;
}
/*
72
99
*/
/*
2
5
1 2 1 4 3
7	
4 5 6 1 1 3 4

2
5
*/
