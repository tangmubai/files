#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include<algorithm>
using namespace std;
int t,b,g,sum,tmp,k1,k2,k3,k4;
long long ans;
int maxn(int a,int b){
	return (a>b?a:b);
}
int minn(int a,int b){
	return (a<b?a:b);
}
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		ans=0;
		scanf("%d%d",&b,&g);
		sum=b+g;
		k1=maxn(b,g),k2=minn(b,g);
		tmp=(sum/5)*5;
		while(tmp){
			k3=maxn(tmp-k1,1);
			k4=minn(k2,tmp-1);
			ans+=(k4-k3+1);
		//	cout<<"*"<<tmp<<' '<<ans<<endl;
			tmp-=5;
		}
		printf("%lld\n",ans);
	}
	return 0;
}

