#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include<algorithm>
using namespace std;
#define ll long long
int t,n,tmp,a[20],k;
ll ans[200000];
int ws(int n){
	int u=0;
	while(n){
		a[u++]=n%10;//���λ->a[0]; 
		n/=10;
	}
	return u;
}
void cl(){
	ll sum=0,i=tmp-1;
	while(i>=0){
		if(a[i]){
			sum=sum*10+1;
			a[i]--;
		}
		else
			sum*=10;
		i--;
	}
	ans[k++]=sum;
}
bool pd(){
	int i=0;
	while(i<tmp){
		if(a[i])
			return 1;
		i++;
	}
	return 0;
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		k=0;
		scanf("%d",&n);
		tmp=ws(n);
		//cout<<tmp<<endl;
		while(pd())
			cl();
		for(int j=k-1;j>=0;j--)
			printf("%d ",ans[j]);
		printf("\n");
	}
	return 0;
}

