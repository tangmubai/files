#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include<algorithm>
using namespace std;
int x,y,x2,y2,l,n,ans,i,j;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&x,&y,&l,&n);
	x2=x+l,y2=y+l;
	while(n--){
		scanf("%d%d",&i,&j);
		if(i>=x&&i<=x2&&j>=y&&j<=y2)
			ans++;
	}
	printf("%d\n",ans);
	return 0;
}
