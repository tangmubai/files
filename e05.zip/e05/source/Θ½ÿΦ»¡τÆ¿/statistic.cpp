#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;
int n,n1,n2,x,a[3000050];
double s1,s2;
long long sum1,sum2;
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	scanf("%d%d%d",&n,&n1,&n2);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	for(int i=1;i<=n1;i++)
		sum1+=a[n-i+1];
	s1=(sum1*1.0/n1);
	for(int i=1;i<=n2;i++)
		sum2+=a[i];
	s2=(sum2*1.0/n2);
	printf("%.3lf\n",s1-s2);
	return 0;
}
