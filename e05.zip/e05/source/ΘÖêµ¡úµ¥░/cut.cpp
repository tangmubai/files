#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int t,n;
struct sj{
	int v,next;
}edge[200005];
int head[100005],tot;
void add(int u,int v){
	tot++;
	edge[tot].next=head[u];
	edge[tot].v=v;
	head[u]=tot;
}
int size[100005];
int f[100005];
void dfs(int u,int fa){
	size[u]=1;
	for(int i=head[u];i;i=edge[i].next){
		int v=edge[i].v;
		if(v==fa)continue;
		dfs(v,u);
		size[u]+=size[v];
		f[u]+=f[v]+size[u]-size[v];
	}
}
int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		memset(head,0,sizeof(head));
		tot=0;
		scanf("%d",&n);
		for(int i=1;i<n;i++){
			int x,y;
			scanf("%d %d",&x,&y);
			add(x,y);
			add(y,x);
		}
		dfs(1,0);
		//for(int i=1;i<=n;i++)
		//cout<<f[i]<<' ';cout<<endl;
		int mn=2147483647;
		for(int i=1;i<=n;i++)
		mn=min(mn,f[i]);
		for(int i=1;i<=n;i++)
		if(f[i]==mn)cout<<i<<' ';
		cout<<endl;
	}
}
