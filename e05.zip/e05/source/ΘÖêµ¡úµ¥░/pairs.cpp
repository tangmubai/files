#include <iostream>
#include <cstdio>
using namespace std;
typedef long long ll;
int t;
int n,m;
ll a[10];
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		ll ans=0;
		for(int i=1;i<=4;i++)
		a[i]=(m+i)/5+a[i-1];
		a[5]=m/5+a[4];
		ans=ans+n/5*a[5]+a[n%5];
		cout<<ans<<endl;
	}
}
