#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int a[525],tot;
void work(int now){
	if(now>1000000000)return;
	a[++tot]=now;
	work(now*10);
	work(now*10+1);
}
int t,n;
int h[10005],anst=2147483647;
int ls[10005];
void out(int tmp){
	if(tmp==anst){
		for(int i=1;i<=tmp;i++)
		if(ls[i]>h[i])return;
	}
	for(int i=1;i<=tmp;i++)
	h[i]=ls[i];
	anst=tmp;
}
void dfs(int x,int las,int num){
	if(!x){
		out(num-1);
		return;
	}
	if(num>anst)return;
	for(int i=las;i<=tot;i++){
		if(x>=a[i]){
			ls[num]=a[i];
			dfs(x-a[i],i,num+1);
		}
		else break;
	}
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	work(1);
	sort(a+1,a+1+tot);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		memset(ls,0,sizeof(ls));
		memset(h,0x7f,sizeof(h));
		anst=2147483647;
		dfs(n,1,1);
		for(int i=1;i<=anst;i++)
		printf("%d ",h[i]);
		printf("\n");
	}
}
