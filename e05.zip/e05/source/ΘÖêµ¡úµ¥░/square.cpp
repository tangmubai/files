#include <iostream>
#include <cstdio>
using namespace std;
int x,y,l,n;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d %d %d %d",&x,&y,&l,&n);
	int xx=x+l,yy=y+l;
	int ans=0;
	for(int i=1;i<=n;i++){
		int u,v;
		scanf("%d %d",&u,&v);
		if(u>=x&&u<=xx&&v>=y&&v<=yy)ans++;
	}
	cout<<ans;
}
