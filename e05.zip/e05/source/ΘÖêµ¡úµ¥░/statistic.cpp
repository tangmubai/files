#include <iostream>
#include <algorithm>
#include <cstdio>
#include <queue>
using namespace std;
typedef long long ll;
ll n,n1,n2;
ll a[3000005];
bool cmp(int a,int b){
	return a>b;
}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	scanf("%lld %lld %lld",&n,&n1,&n2);
	for(int i=1;i<=n;i++){
		ll x;
		scanf("%lld",&x);
		a[i]=x;
	}
	sort(a+1,a+1+n,cmp);
	ll s1=0,s2=0;
	for(int i=1;i<=n1;i++){
		s1+=a[i];
	}
	for(int i=n;i>=n-n2+1;i--)
	s2+=a[i];
	printf("%.3f",s1*1.0/n1-s2*1.0/n2);
}
