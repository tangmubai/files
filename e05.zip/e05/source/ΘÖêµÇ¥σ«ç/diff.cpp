#include<stdio.h>
#include<math.h>
#include<iostream>

using namespace std;

int a[305];
void in(int &x){
	char ch=getchar();int flag=0;x=0;
	while(ch<'0'||ch>'9')flag|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	if(flag)x=-x;
}
int main()
{

freopen("diff.in","r",stdin);
freopen("diff.out","w",stdout);
	int n,t,i,j;
	scanf("%d",&t);
	while(t--)
	{
		in(n);
		
		for(i=0;i<n;i++)scanf("%d",&a[i]);
	
		long long ans=0;
		
		for(i=0;i<n;i++)ans+=a[i];
		printf("%lld\n",ans/n);
	}

}

