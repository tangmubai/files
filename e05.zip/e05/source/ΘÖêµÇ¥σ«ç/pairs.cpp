#include<stdio.h>
#include<math.h>
#include<iostream>

using namespace std;
void in(int &x){
	char ch=getchar();int flag=0;x=0;
	while(ch<'0'||ch>'9')flag|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	if(flag)x=-x;
}
int main()
{

freopen("pairs.in","r",stdin);
freopen("pairs.out","w",stdout);

	long long  m,n;
	int t;
	in(t);
	
	while(t--)
	{
		scanf("%lld%lld",&n,&m);
		
		long long ans=0;
		
		ans=m*n/5;
		
		printf("%lld\n",ans);
	}
}
