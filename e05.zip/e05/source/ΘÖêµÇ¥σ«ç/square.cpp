#include<stdio.h>
#include<math.h>
#include<iostream>

using namespace std;

int xx[10005],yy[10005];
void in(int &x){
	char ch=getchar();int flag=0;x=0;
	while(ch<'0'||ch>'9')flag|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	if(flag)x=-x;
}
int main()
{

freopen("square.in","r",stdin);
freopen("square.out","w",stdout);
	
	int x,y,n,l,ans=0;
	int i,x1,x2,y1,y2;
	scanf("%d%d%d%d",&x,&y,&l,&n);
	
	x1=x,x2=x+l,y1=y,y2=y+n;
	for(i=0;i<n;i++){
	scanf("%d%d",&xx[i],&yy[i]);
	
	if(xx[i]>=x1&&xx[i]<=x2&&yy[i]>=y1&&yy[i]<=y2)ans++;
	}
	
	printf("%d",ans);
	
}
