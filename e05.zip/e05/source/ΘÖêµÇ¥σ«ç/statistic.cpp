#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<iostream>

using namespace std;

double a[3000005];

void in(int &x){
	char ch=getchar();int flag=0;x=0;
	while(ch<'0'||ch>'9')flag|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	if(flag)x=-x;
}
bool cmp(double a,double b)
{
	return a<b;
	}


int main()
{

freopen("statistic.in","r",stdin);
freopen("statistic.out","w",stdout);

int n,n1,n2,i;
	
	in(n);in(n1);in(n2);
	
	for(i=1;i<=n;i++)cin>>a[i];
	
	sort(a+1,a+n+1,cmp);
	
	double ans1=0.0,ans2=0.0;
	 
	for(i=1;i<=n1;i++)ans1+=a[n-i+1];
	ans1/=n1;
	for(i=1;i<=n2;i++)ans2+=a[i];
	ans2/=n2;
	double ans=ans1-ans2;
	printf("%.3f",ans);
}

