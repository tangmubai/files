#include<cstdio>
#include<cstring>
using namespace std;

inline void in(int &x){
	x=0;register char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
}

int n,head[100005],tot,size;
struct Edge{
	int v,next;
}edge[200005];

void add(int u,int v){
	edge[++tot].next=head[u];
	edge[tot].v=v;
	head[u]=tot;
}

void dfs(int u,int rt){
	size++;
	for(int i=head[u];i;i=edge[i].next){
		int v=edge[i].v;
		if(v==rt) continue;
		dfs(v,u);
	}
}

bool check(int x){
	for(int i=head[x];i;i=edge[i].next){
		int v=edge[i].v;
		size=0;
		dfs(v,x);
		if(size>n/2) return false;
	}
	return true;
}

int main(){
	freopen("cut.in","r",stdin);freopen("cut.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		memset(head,0,sizeof(head));
		tot=0;
		in(n);
		for(int i=1;i<n;i++){
			int u,v;in(u),in(v);
			add(u,v),add(v,u);
		}
		bool flag=false;
		for(int i=1;i<=n;i++)
			if(check(i)){
				flag=true;
				printf("%d ",i);
			}
		if(!flag) printf("None\n");
		else printf("\n");
	}
	return 0;
}

