#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;

int n,a[305];

bool check(int d){
	int x=0,y=0;
	int i=1;
	while(i<=n){
		if(x>y) swap(x,y);
		int tmp=i;
		while(abs(x+a[i]-y)<=d) x+=a[i],i++;
		if(tmp==i) return false;
	}
	return true;
}

int main(){
	freopen("diff.in","r",stdin);freopen("diff.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		int l=0,r=30000;
		while(l<=r){
			int mid=(l+r)>>1;
			if(check(mid)) r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",l);
	}
	return 0;
}
