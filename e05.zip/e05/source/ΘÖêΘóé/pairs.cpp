#include<cstdio>
using namespace std;
typedef long long ll;

int main(){
	freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		ll n,m;scanf("%lld %lld",&n,&m);
		ll n0=n/5,n1=n/5+(n%5>=1),n2=n/5+(n%5>=2),n3=n/5+(n%5>=3),n4=n/5+(n%5>=4);
		ll m0=m/5,m1=m/5+(m%5>=1),m2=m/5+(m%5>=2),m3=m/5+(m%5>=3),m4=m/5+(m%5>=4);
		printf("%lld\n",n0*m0+n1*m4+n2*m3+n3*m2+n4*m1);
	}
	return 0;
}
