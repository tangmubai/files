#include<cstdio>
#include<algorithm>
using namespace std;

void out(int x){
	if(!x) return;
	int tmp=x,Min=1e5,l=0;
	char num[15];
	while(tmp){
		if(tmp%10!=0) Min=min(Min,tmp%10);
		num[++l]=(tmp%10!=0)+'0';
		tmp/=10;
	}
	reverse(num+1,num+1+l);
	int k=0;
	for(int i=1;i<=l;i++) k=k*10+num[i]-'0';
	out(x-Min*k);
	for(int i=1;i<=Min;i++) printf("%d ",k);
}

int main(){
	freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		int n;scanf("%d",&n);
		out(n);printf("\n");
	}
	return 0;
}
