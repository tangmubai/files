#include<cstdio>
using namespace std;

int main(){
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	int x,y,l,n;scanf("%d %d %d %d",&x,&y,&l,&n);
	int ans=0,xx=x+l,yy=y+l;
	while(n--){
		int a,b;scanf("%d %d",&a,&b);
		if(a>=x&&b>=y&&a<=xx&&b<=yy) ans++;
	}
	printf("%d\n",ans);
	return 0;
}
