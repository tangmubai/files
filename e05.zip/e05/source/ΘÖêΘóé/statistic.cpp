#include<cstdio>
#include<algorithm>
using namespace std;

inline void in(int &x){
	x=0;register char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
}

int n,n1,n2,a[3000005];

int main(){
	freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	in(n),in(n1),in(n2);
	for(int i=1;i<=n;i++) in(a[i]);
	sort(a+1,a+1+n);
	double avg1=0.0,avg2=0.0;
	for(int i=n-n1+1;i<=n;i++) avg1+=a[i];
	for(int i=1;i<=n2;i++) avg2+=a[i];
	avg1/=n1,avg2/=n2;
	printf("%.3lf",avg1-avg2);
	return 0;
}
