#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
struct node
{
	int nxt;
	int p;
}e[200005];
int head[100005],tot;
int t;
int n;
int x,y;
int ans[100005],cnt;
int son[100005];
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;	
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;	
} 
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y; 
}
inline void add(int from,int to)
{
	e[++tot].p=to;
	e[tot].nxt=head[from];
	head[from]=tot;
}
inline void dfs1(int p,int fa)
{
	son[p]=1;
	for(int i=head[p];i;i=e[i].nxt)
	{
		int v=e[i].p;
		if(v==fa) continue;
		dfs1(v,p);
		son[p]+=son[v];
	}
	return ;
}
inline bool cmp(int p,int q)
{
	return p<q;
}
inline void dfs2(int p,int fa)
{
	bool flag=true;
	for(int i=head[p];i;i=e[i].nxt)
	{
		int v=e[i].p;
		if(v==fa)
		{
			if((son[1]-son[p])*2>n) 
			{
				flag=false;
				break;
			}
		}
		else
		{
			if(son[v]*2>n)
			{
				flag=false;
				break;
			}
		}
	}
	if(flag) ans[++cnt]=p;
	for(int i=head[p];i;i=e[i].nxt)
	{
		if(e[i].p!=fa) dfs2(e[i].p,p);
	}
	return ;
}
int main()
{
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	read(t);
	while(t--)
	{
		read(n);
		for(int i=1;i<n;i++)
		{
			read(x);read(y);
			add(x,y);
			add(y,x);
		}	
		dfs1(1,-1);
		bool flag=true;
		for(int i=head[1];i;i=e[i].nxt)
		{
//			printf("%d %d\n",e[i].p,son[e[i].p]);
			if(2*son[e[i].p]>n) 
			{
				flag=false;
				break;
			}
		}
		if(flag) 
		{
			ans[++cnt]=1;
//			puts("OH");
		}
		for(int i=head[1];i;i=e[i].nxt) dfs2(e[i].p,1);
		if(cnt==0) puts("None");
		else 
		{
			sort(ans+1,ans+cnt+1,cmp);
			for(int i=1;i<=cnt;i++) printf("%d ",ans[i]);
			puts("");
		}
		for(int i=1;i<=tot;i++) e[i].nxt=e[i].p=0;
		for(int i=1;i<=n;i++) head[i]=0;
		tot=cnt=0;
	} 
	return 0;
}
