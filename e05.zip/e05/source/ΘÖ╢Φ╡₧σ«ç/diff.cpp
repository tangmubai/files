#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
const int oo=1000000000;
int t,n;
int a[305],sum;
int f[305][30005];
bool g[30005];
int ans;
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;	
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;	
} 
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y; 
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
int main()
{
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	read(t);
	while(t--)
	{
		read(n);
		sum=0;
		memset(g,false,sizeof(g));
		g[0]=true;
		for(int i=1;i<=n;i++) 
		{
			read(a[i]);
			sum+=a[i];
		}
//		puts("E");
		for(int i=1;i<=n;i++)
			for(int j=0;j<=sum;j++)
				f[i][j]=oo;
		sum=0;
		for(int i=1;i<=n;i++)
		{
//			printf("%d\n",i);	
			for(int j=sum;j>=0;j--) g[j+a[i]]|=g[j];
			sum+=a[i];
			for(int j=0;j<=sum;j++)
			{
				if(g[j]) f[i][j]=mn(f[i][j],mx(f[i-1][j],ab(sum-j-j)));
				if(j>=a[i]&&g[j]&&g[j-a[i]]) f[i][j]=mn(f[i][j],mx(f[i-1][j-a[i]],ab(sum-j-j)));
			}
//			printf("%d\n",i);
		}
//		puts("E");
//		for(int i=1;i<=n;i++)
//		{	
//			for(int j=0;j<=sum;j++)
//			{
//				printf("%d ",f[i][j]);
//			}
//			puts("");
//		}
		ans=oo;
		for(int i=0;i<=sum;i++) if(g[i]) ans=mn(ans,f[n][i]);
		printf("%d\n",ans);
	} 
	return 0;
}
