#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
ll t,n,m;
ll ans;
inline int read(ll &x)
{
	ll f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;	
}
inline ll r0(ll x){return x/5;}
inline ll r1(ll x){return (x-1)/5+1;}
inline ll r2(ll x)
{
	if(x==1) return 0;
	return (x-2)/5+1;
}
inline ll r3(ll x)
{
	if(x<3) return 0;
	return (x-3)/5+1;
}
inline ll r4(ll x)
{
	if(x<4) return 0;
	return (x-4)/5+1;
}
int main()
{
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	read(t);
	while(t--)
	{
		read(n);read(m);
		ans=0;
		ans+=1ll*r0(n)*r0(m);
		ans+=1ll*r1(n)*r4(m);
		ans+=1ll*r2(n)*r3(m);
		ans+=1ll*r3(n)*r2(m);
		ans+=1ll*r4(n)*r1(m);
		printf("%lld\n",ans);
	}
	return 0;
}
