#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
ll ans[105],tot;
ll n,t;
ll x[105],w;
ll bin[105];
ll mnval,tmp;
inline int read(ll &x)
{
	ll f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;	
}
inline ll mn(ll _x,ll _y)
{
	return _x<_y?_x:_y; 
} 
/*
inline bool check()
{
	for(int i=1;i<=n;i++) 
		if(x[i]!=0) return false;
	return true;  
}
*/ 
inline bool cmp(ll p,ll q)
{
	return p<q;
}
int main()
{
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	bin[1]=1;
	for(int i=2;i<=10;i++) bin[i]=1ll*bin[i-1]*10;
	read(t);
	while(t--)
	{
		read(n);
		while(n)
		{
			x[++w]=n%10;
			n/=10;
		}
		while(233)
		{
			mnval=233;tmp=0;
			for(int i=1;i<=w;i++)
			{
				if(x[i]==0) continue;
				mnval=mn(mnval,x[i]);
			}
			if(mnval==233) break;
			for(int i=1;i<=w;i++)
				if(x[i]>=mnval) tmp+=bin[i];
			for(int i=1;i<=w;i++)
				if(x[i]>=mnval) x[i]-=mnval;
			for(int i=1;i<=mnval;i++) ans[++tot]=tmp;
		}
		sort(ans+1,ans+tot+1,cmp);
		for(int i=1;i<=tot;i++) printf("%lld ",ans[i]);
		puts("");
		memset(x,0,sizeof(x));
		memset(ans,0,sizeof(ans));
		tot=w=0;
	}
	return 0;
}
