#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int xl,yl,l,n;
int rx,ry;
int ans;
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;	
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;	
} 
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y; 
} 
int main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	read(xl);read(yl);read(l);read(n);
	while(n--)
	{
		read(rx);read(ry);
		if(xl<=rx&&rx<=xl+l&&yl<=ry&&ry<=yl+l) ans++; 
	}
	printf("%d\n",ans);
	return 0;
}
