#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<queue>
#include<algorithm>
using namespace std;
typedef long long ll;
ll a[3000005],b[3000005];
ll n1,n2;
ll tn;
ll n;
ll x;
ll s1,s2;
inline ll read(ll &x)
{
	register ll f=1;register char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;	
}
inline bool cmp(int p,int q)
{
	return p<q;
}
/*
inline void gb(int l,int r)
{
	if(l>=r) return ;
	int mid=l+r>>1;
	gb(l,mid);gb(mid+1,r);
	register int p1=l;register int p2=mid+1;
	register int p3=l;
	while(p1<=mid&&p2<=r)
	{
		if(a[p1]<a[p2])
		{
			b[p3++]=a[p1];
			p1++;
		}
		else
		{
			b[p3++]=a[p2];
			p2++;
		}
	}
	while(p1<=mid) b[p3++]=a[p1],p1++;
	while(p2<=r) b[p3++]=a[p2],p2++;
	for(register int i=l;i<=r;++i) a[i]=b[i];
	return ; 
}
*/ 
int main()
{
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	scanf("%lld %lld %lld",&n,&n1,&n2);
	for(int i=1;i<=n;i++) read(a[i]); 
//	gb(1,n);
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n2;i++) s2+=a[i];
	for(int i=0;i<n1;i++) s1+=a[n-i];
	printf("%.3lf\n",1.0*s1/n1-1.0*s2/n2);
	return 0;
}
