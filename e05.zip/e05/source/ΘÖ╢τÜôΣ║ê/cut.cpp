#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	printf("None");
	return 0;
}

