#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[305],n;
int aa(int n){if(n<0)n=-n;return n;}
bool cc(int mid){
	int j2=0,j1=0;
	for(int i=1;i<=n;i++)
		if(j1>j2){
			if(j1+a[i]-j2<=mid)j1+=a[i];
			else if(aa(j2+a[i]-j1)<=mid)j2+=a[i];
			else return 0;
		}
		else{
			if(j2+a[i]-j1<=mid)j2+=a[i];
			else if(aa(j1+a[i]-j2)<=mid)j1+=a[i];
			else return 0;
		}
	return 1;
}
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	int t=read();
	while(t--){
		n=read();int r=0,l=0;
		for(int i=1;i<=n;i++)a[i]=read(),r+=a[i];
		while(l<=r){
			int mid=(l+r)/2;
			if(cc(mid))r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",r+1);
	}
	return 0;
}

