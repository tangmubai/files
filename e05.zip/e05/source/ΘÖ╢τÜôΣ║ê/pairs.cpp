#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int min(int a,int b){return a<b?a:b;}
int a[10],b[10];
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	int t=read();
	while(t--){
		int x=read(),y=read(),jj1=x/5,jj2=y/5;
		a[0]=jj1;a[1]=jj1;a[2]=jj1;a[3]=jj1;a[4]=jj1;
		b[0]=jj2;b[1]=jj2;b[2]=jj2;b[3]=jj2;b[4]=jj2;
		for(int i=1;i<=x%5;i++)a[i]++;
		for(int i=1;i<=y%5;i++)b[i]++;
		long long ans=a[0]*1ll*b[0]+a[1]*1ll*b[4]+a[2]*1ll*b[3];
		ans+=a[3]*1ll*b[2]+a[4]*1ll*b[1];
		printf("%lld\n",ans);
	}
	return 0;
}

