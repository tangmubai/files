#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[15],b[205];
bool pd(int js){
	for(;js;js/=10)if(js%10>1){return 0;}
	return 1;
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	int t=read();
	while(t--){
		int n=read();
		if(n<10){for(int i=1;i<=n;i++)printf("1 ");printf("\n");continue;}
		int js=n,t=1;
		for(;js;js/=10)if(js%10>1){t=0;break;}
		if(t){printf("%d\n",n);continue;}
		js=n;int x=1,jj,jsum=1;
		for(;js;js/=10)a[x]+=js%10,x++,jsum*=10;
		jj=0;jsum/=10;
		for(int i=x-1;i>=1;i--,jsum/=10)
			while(a[i]){int ans=jsum,jjj=jsum/10;for(int j=i-1;j>=1;j--,jjj/=10)if(a[j])ans+=jjj,a[j]--;b[++jj]=ans;a[i]--;}
		for(int i=jj;i>=1;i--)printf("%d ",b[i]);
		printf("\n");
	}
	return 0;
}

