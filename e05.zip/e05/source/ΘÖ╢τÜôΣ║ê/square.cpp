#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int x=read(),y=read(),l=read(),n=read(),ans=0;
	for(int i=1;i<=n;i++){
		int a=read(),b=read();
		if(a<x||b<y)continue;
		if(a>x+l||b>y+l)continue;
		ans++;
	}
	printf("%d",ans);
	return 0;
}

