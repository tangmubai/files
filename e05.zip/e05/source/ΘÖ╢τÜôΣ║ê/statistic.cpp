#pragma GCC optimize(2)
#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[3000005];
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n=read(),n1=read(),n2=read();
	for(int i=1;i<=n;i++)a[i]=read();
	sort(a+1,a+1+n);double ans1=0,ans2=0;
	for(int i=1;i<=n2;i++)ans2+=a[i];
	for(int i=n;i>=n-n1+1;i--)ans1+=a[i];
	printf("%.3lf",ans1/n1-ans2/n2);
	return 0;
}

