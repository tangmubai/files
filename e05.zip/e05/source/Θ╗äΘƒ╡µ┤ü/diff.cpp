#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int t,n,a,ans=0;
int main(){
	freopen("diff.in","r",stdin);freopen("diff.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		ans=0;
		int s1=0,s2=0,ss1=0,ss2=0;
		for(int i=1;i<=n;i++){
			scanf("%d",&a);
			if(s1==0&&s2==0&&ss1==0&&ss2==0){
				s1=a,ss2=a;
				continue;
			} 
			if(s1>s2) s2+=a;
			else s1+=a;
			if(ss1>ss2) ss2+=a;
			else s1+=a;
		}
		ans=min(abs(s1-s2),abs(ss1-ss2));
		printf("%d\n",ans);
	}
	return 0;
}

