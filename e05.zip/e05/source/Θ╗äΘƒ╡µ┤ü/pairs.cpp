#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int t,n,m,a;
long long ans=0;
int main(){
	freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		ans=0;
		int ss0=0,ss1=0,ss2=0,ss3=0,ss4=0,s0=0,s1=0,s2=0,s3=0,s4=0;
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			a=i%5;
			if(a==0) ss0++;
			else if(a==1) ss1++;
			else if(a==2) ss2++;
			else if(a==3) ss3++;
			else if(a==4) ss4++;
		}  
		for(int i=1;i<=m;i++){
			a=i%5;
			if(a==0) s0++;
			else if(a==1) s1++;
			else if(a==2) s2++;
			else if(a==3) s3++;
			else if(a==4) s4++;
		}
		ans+=ss0*s0;
		ans+=ss1*s4;
		ans+=ss2*s3;
		ans+=ss3*s2;
		ans+=ss4*s1;
		printf("%lld\n",ans);
	}
	return 0;
}

