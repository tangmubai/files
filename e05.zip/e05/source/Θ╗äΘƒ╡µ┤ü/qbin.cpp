#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int t,n;
void n100(int x){
	if(!x) printf("0\n");
	else if(x<10){
		while(x){
			printf("1 ");
			x--;
		}
		printf("\n");
	}
	else if(x==10) printf("10\n");
	else {
		while(x%10!=0){
			printf("1 ");
			x--;
		}
		while(x){
			printf("10 ");
			x-=10;
		}
		printf("\n");
	}
}
void work(int x){
	while(x%10!=0){
		printf("1 ");
		x--;
	}
	while(x%100!=0){
		printf("10 ");
		x-=10;
	}
	if(x>=100){
		while(x%1000!=0){
			printf("100 ");
			x-=100;
		}
	}
	else if(x==0) printf("\n");
	else if(x>=1000){
		while(x%10000!=0){
			printf("1000 ");
			x-=1000;
		}
	}
	else if(x==0) printf("\n");
	else if(x>=10000){
		while(x%100000!=0){
			printf("10000 ");
			x-=10000;
		}
	}
	else if(x>=100000){
		while(x%1000000!=0){
			printf("100000 ");
			x-=100000;
		}
	}
	printf("\n");
}
int main(){
	freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		if(n>=0&&n<=99){
			n100(n);
			continue;
		}
		work(n);
	}
	return 0;
}

