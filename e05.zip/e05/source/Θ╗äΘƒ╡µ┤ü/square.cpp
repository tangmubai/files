#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int x,y,l,n,a,b,ans=0;
int main(){
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&x,&y,&l,&n);
	while(n--){
		scanf("%d%d",&a,&b);
		if(a>=x && a<=x+l && b>=y &&b<=y+l) ans++;
	} 
	printf("%d\n",ans);
	return 0;
}

