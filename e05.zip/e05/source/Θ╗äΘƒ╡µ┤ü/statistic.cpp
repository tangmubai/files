#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,n1,n2,a[3000005];
double s1=0,s2=0;
void in(int &n){
	n=0;int f=1;char c=getchar();
	while(c<'0'||'9'<c){if(c=='-') f*=-1;c=getchar();}
	while('0'<=c&&c<='9'){n=n*10+(c-'0');c=getchar();}
	n*=f;
}
int main(){
	freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	in(n),in(n1),in(n2);
	for(int i=1;i<=n;i++) in(a[i]);
	sort(a+1,a+n+1);
	for(int i=n;i>n-n1;i--) s1+=a[i];
	for(int i=1;i<=n2;i++) s2+=a[i];
	printf("%.3lf\n",s1/n1-s2/n2);
	return 0;
}

