#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int t,n;
int main()
{freopen("cut.in","r",stdin);freopen("cut.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>n;
 for(int i=1;i<=n;i++)
{int x,y;
 cin>>x>>y;
}
 cout<<"None"<<endl;
}
 return 0;
} 
