#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int t,n,a[310],f[310];
int main()
{freopen("diff.in","r",stdin);freopen("diff.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>n;
 int sum=0;
 for(int i=1;i<=n;i++)
 cin>>a[i],sum+=a[i];
 for(int i=1;i<=n;i++)
 for(int j=sum/2;j>=a[i];j--)
 f[j]=max(f[j],f[j-a[i]]+a[i]);
 cout<<abs((sum-f[sum/2])-f[sum/2])+1<<endl;
}
 return 0;
} 
