#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int t,n,m;
int main()
{freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>n>>m;
 if(n<=5&&m<=5)
{int ans=0;
 for(int i=1;i<=n;i++)
 for(int j=1;j<=m;j++)
 if((i+j)%5==0) ans++;
 cout<<ans<<endl;
 continue;
}
 int a[10],xx=max(n,m),yy=min(n,m);
 a[1]=(xx-3+4)/5;
 a[2]=(xx-2+4)/5;
 a[3]=(xx-1+4)/5;
 a[4]=(xx+4)/5;
 a[5]=xx/5;
 long long sum=a[1]+a[2]+a[3]+a[4]+a[5];
 int x=yy/5,y=yy%5;
 long long ans=sum*x;
 for(int i=1;i<=y;i++)
 ans+=a[i];
 cout<<ans<<endl;
}
 return 0;
} 
