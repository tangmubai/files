#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int t,n,cnt,a[10010],b[120];
int main()
{freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
 cin>>t;
 b[1]=1;
 for(int i=2;i<=9;i++)
 b[i]=b[i-1]*10;
 while(t--)
{cin>>n;
 cnt=0;
 for(int i=9;i>=1;i--)
 while(n>=b[i]&&n)
{int sum=0;
 int x=n,j=1;
 while(x)
{if(x%10!=0) sum+=b[j],j++;
 else j++;
 x/=10;
}
 a[++cnt]=sum;
 n-=sum;
}
 for(int j=cnt;j>=1;j--)
 cout<<a[j]<<" ";
 cout<<endl;
}
 return 0;
} 
