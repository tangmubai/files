#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int x,y,l,n,ans;
int main()
{freopen("square.in","r",stdin);freopen("square.out","w",stdout);
 cin>>x>>y>>l>>n;
 for(int i=1;i<=n;i++)
{int a,b;
 cin>>a>>b;
 if(x<=a&&a<=x+l&&y<=b&&b<=y+l) ans++;
}
 cout<<ans<<endl;
 return 0;
} 
