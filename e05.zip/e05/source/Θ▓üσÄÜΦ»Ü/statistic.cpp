#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,n1,n2,a[3000010];
long long sum,sum1;
bool cmp(int x,int y){return x<y;}
int main()
{freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
 scanf("%d %d %d",&n,&n1,&n2);
 for(int i=1;i<=n;i++)
 scanf("%d",&a[i]);
 sort(a+1,a+n+1,cmp);
 for(int i=1;i<=n1;i++) sum+=a[i];
 for(int i=n;i>=n-n2+1;i--) sum1+=a[i];
 double ans=sum1/n2-sum/n1;
 printf("%.3lf\n",ans);
 return 0;
} 
