#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int a[305],t,n,l,r,mid,sum;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
bool ck(int mid){
	int sum1=0,sum2=0;
	for(register int i=1;i<=n;i++){
		if(abs(sum1+a[i]-sum2)>mid&&abs(sum2+a[i]-sum1)>mid)
		return 0;
		if(abs(sum1+a[i]-sum2)>mid) sum2+=a[i];
		else if(abs(sum2+a[i]-sum1)>mid) sum1+=a[i];
		else if(sum1>=sum2) sum1+=a[i];
		else sum2+=a[i];
	}
	return 1;
}
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	t=read();
	while(t--){
		n=read();sum=0;
		for(register int i=1;i<=n;i++){
			a[i]=read();sum+=a[i];
		}
		l=1;r=sum;
		while(l<=r){
			mid=(l+r)>>1;
			if(ck(mid)) r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",l);
	}
	return 0;
}
