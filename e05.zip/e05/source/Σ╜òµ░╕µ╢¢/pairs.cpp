#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int a[7],b[7],t,n,m;long long ans;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	t=read();
	while(t--){
		n=read();m=read();ans=0ll;
		for(register int i=0;i<5;i++){
			a[i]=(n-i)/5+1;b[i]=(m-i)/5+1;
		}
		a[0]--;b[0]--;
		ans+=1ll*a[0]*b[0];
		ans+=1ll*a[1]*b[4];
		ans+=1ll*a[2]*b[3];
		ans+=1ll*a[3]*b[2];
		ans+=1ll*a[4]*b[1];
		printf("%lld\n",ans);
	}
	return 0;
}
