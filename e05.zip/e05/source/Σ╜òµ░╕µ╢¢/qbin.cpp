#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int a[10],t,n,h,x,mx;char s[10];
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",s);n=strlen(s);x=1;mx=0;
		memset(a,0,sizeof(a));
		for(register int i=n-1;i>=0;i--,x*=10){
			h=s[i]-'0';mx=max(mx,h);
			for(register int j=1;j<=h;j++)
			a[10-j]+=x;
		}
		for(register int i=10-mx;i<=9;i++)
		printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
