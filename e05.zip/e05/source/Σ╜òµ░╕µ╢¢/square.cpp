#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int n,l,a,b,c,d,x,y,ans;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	x=read();y=read();l=read();n=read();
	a=x;b=y;c=x+l;d=y+l;
	while(n--){
		x=read();y=read();
		if(x>=a&&x<=c&&y>=b&&y<=d) ans++;
	}
	printf("%d",ans);
	return 0;
}
