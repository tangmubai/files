#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int a[3000005],b[3000005],n,n1,n2;double ans1,ans2;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
//void merge(int l,int r){
//	if(l>=r) return;
//	int mid=(l+r)>>1;
//	merge(l,mid);merge(mid+1,r);
//	int i=l,j=mid+1,t=1;
//	while(i<=mid&&j<=r){
//		if(a[i]<=a[j]) b[t++]=a[i++];
//		else b[t++]=a[j++];
//	}
//	while(i<=mid) b[t++]=a[i++];
//	while(j<=r) b[t++]=a[j++];
//	for(register int k=1;k<=r-l+1;k++) a[l+k-1]=b[k];
//	return;
//}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	n=read();n1=read();n2=read();
	for(register int i=1;i<=n;i++) a[i]=read();
//	merge(1,n);
	sort(a+1,a+n+1);
	for(register int i=1;i<=n2;i++) ans1+=1.0*a[i];
	for(register int i=1;i<=n1;i++) ans2+=1.0*a[n-i+1];
	ans1/=1.0*n2;ans2/=1.0*n1;
	printf("%.3lf",ans2-ans1);
	return 0;
}
