#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int a[310],f[310][3];
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		memset(a,0,sizeof(a));
		memset(f,0,sizeof(f));
		int n;scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		f[0][0]=1000000;
		for(int i=1;i<=n;i++){
			f[i][0]=min(abs(f[i-1][1]+a[i]-f[i-1][2]),abs(f[i-1][2]+a[i]-f[i-1][1]));
			f[i][1]=f[i-1][1];
			f[i][2]=f[i-1][2];
			if(abs(f[i-1][1]+a[i]-f[i-1][2])<=abs(f[i-1][2]+a[i]-f[i-1][1])) f[i][1]=f[i-1][1]+a[i];
			else f[i][2]=f[i-1][2]+a[i];
		}
//		for(int i=1;i<=n;i++)
//			printf("%d ",f[i][0]);
//			printf("\n");
//		for(int i=1;i<=n;i++)
//			printf("%d ",f[i][1]);
//			printf("\n");
//			for(int i=1;i<=n;i++)
//			printf("%d ",f[i][2]);
//			printf("\n");
		int ans=0;
		for(int i=1;i<=n;i++) ans=max(f[i][0],ans);
		printf("%d\n",ans);
	}
	return 0;
}

