#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		long long n,m;scanf("%lld%lld",&n,&m);
		long long nnum=n/5,mnum=m/5;
		long long n1=0,n2=0,n3=0,n4=0;
		if(n%5==1) n1++;
		if(n%5==2) n1++,n2++;
		if(n%5==3) n1++,n2++,n3++;
		if(n%5==4) n1++,n2++,n3++,n4++;
		long long m1=0,m2=0,m3=0,m4=0;
		if(m%5==1) m1++;
		if(m%5==2) m1++,m2++;
		if(m%5==3) m1++,m2++,m3++;
		if(m%5==4) m1++,m2++,m3++,m4++;
		long long ans=0;
		ans+=(nnum+n1)*(mnum+m4)+(nnum+n2)*(mnum+m3)+(nnum+n3)*(mnum+m2)+(nnum+n4)*(mnum+m1)+nnum*mnum;
		printf("%lld\n",ans);
	}
	return 0;
}

