#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int x,y,l,n;scanf("%d%d%d%d",&x,&y,&l,&n);
	int ans=0;
	while(n--){
		int x1,y1;scanf("%d%d",&x1,&y1);
		if(x1>=x&&x1<=x+l&&y1>=y&&y1<=y+l) ans++;
	}
	printf("%d\n",ans);
	return 0;
}
