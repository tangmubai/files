#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int a[3000010],b[3000010];
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n,n1,n2;scanf("%d%d%d",&n,&n1,&n2);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	sort(a+1,a+1+n,cmp);
	sort(b+1,b+1+n);
	double n1ans=0,n2ans=0;
	for(int i=1;i<=n1;i++) n1ans+=a[i];
	for(int i=1;i<=n2;i++) n2ans+=b[i];
	n1ans/=n1;
	n2ans/=n2;
	printf("%.3lf\n",n1ans-n2ans);
	return 0;
}

