#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int t;
int main()
{
	freopen("cut.in", "r", stdin);
	freopen("cut.out", "w", stdout);
	scanf("%d", &t);
	while(t--) puts("None");
}
