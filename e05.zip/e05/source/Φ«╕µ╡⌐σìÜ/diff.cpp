#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int oo = 10000005;
int f[305][30005], t, n, a[305], sum; bool g[100005];
int main() {
	freopen("diff.in", "r", stdin);
	freopen("diff.out", "w", stdout);
	scanf("%d", &t);
	while(t--) 
	{
		sum = 0;
		scanf("%d", &n);
		memset(g, 0, sizeof(g));
		g[0] = 1;
		for (int i = 1; i <= n; i++) 
		{
			scanf("%d", &a[i]);
			sum += a[i];
		}
		memset(f, 0, sizeof(f));
		for (int i= 1; i <= n; i++)
			for (int j = 0; j <= sum; j++)
				f[i][j] = oo;
		for (int i = 1; i <= n; i++) {
			for (int j = sum; j >= 0; j--) g[j + a[i]] |= g[j];
			for (int j = 0; j <= sum; j++) {
				if (g[j]) f[i][j] = min(f[i][j], max(f[i - 1][j], abs(sum - j - j)));
				if (j >= a[i]&&g[i]&&g[j - a[i]]) f[i][j] = min(f[i][j], max(f[i - 1][j - a[i]], abs(sum - j - j)));
			}
		} 
		int ans = oo;
		for (int i = 0; i <= sum; i++) 
			if (g[i]) ans = min(ans, f[n][i]);
		printf("%d\n", ans);
	}
}
