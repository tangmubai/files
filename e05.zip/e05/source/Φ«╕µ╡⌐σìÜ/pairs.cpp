#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
typedef long long ll;
ll t, n, m, ans;
ll r0(ll x){ return x / 5; }
ll r1(ll x){ return (x - 1) / 5 + 1; }
ll r2(ll x)
{
	if (x == 1) return 0;
	return (x - 2) / 5 + 1;
}
ll r3(ll x)
{
	if (x < 3) return 0;
	return (x - 3) / 5 + 1;
}
ll r4(ll x)
{
	if (x < 4) return 0;
	return (x - 4) / 5 + 1;
}
int main()
{
	freopen("pairs.in", "r", stdin); freopen("pairs.out", "w", stdout);
	scanf("%lld", &t);
	while(t--)
	{
		scanf("%lld%lld", &n, &m); ans = 0;
		ans += 1ll * r0(n) * r0(m);
		ans += 1ll * r1(n) * r4(m);
		ans += 1ll * r2(n) * r3(m);
		ans += 1ll * r3(n) * r2(m);
		ans += 1ll * r4(n) * r1(m);
		printf("%lld\n", ans);
	}
}
