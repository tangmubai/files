#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
typedef long long ll;
ll t, ans[100005], tot, n, x[100005], w, bin[100005], mnval, tmp;
bool cmp(ll a, ll b)
{
	return a < b;
}
int main()
{
	freopen("qbin.in", "r", stdin);
	freopen("qbin.out", "w", stdout);
	bin[1] = 1;
	for (int i = 2; i <= 10; i++) bin[i] = 1ll * bin[i - 1] * 10;
	scanf("%lld", &t);
	while(t--)
	{
		scanf("%lld", &n);
		tot = 0, w = 0;
		memset(x, 0, sizeof(x)); memset(ans, 0, sizeof(ans));
		while(n)
		{
			x[++w] = n % 10;
			n /= 10;
		}
		while(233)
		{
			mnval = 233; tmp = 0;
			for (int i = 1; i <= w; i++)
			{
				if (x[i] == 0) continue;
				mnval = min(mnval, x[i]);
			}
			if (mnval == 233) break;
			for (int i = 1; i <= w; i++)
				if (x[i] >= mnval) tmp += bin[i];
			for (int i = 1; i <= w; i++)
				if (x[i] >= mnval) x[i] -= mnval; 
			for (int i = 1; i <= mnval; i++)
				ans[++tot] = tmp;
			
		}
		sort(ans + 1, ans + 1 + tot, cmp);
		for (int i = 1; i <= tot; i++) printf("%lld ", ans[i]);
		puts("");
	}
}
