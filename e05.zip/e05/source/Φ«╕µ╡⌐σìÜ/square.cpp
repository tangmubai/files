#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int x, y, l, n, ans;
int main()
{
	freopen("square.in", "r", stdin); freopen("square.out", "w", stdout);
	scanf("%d%d%d%d", &x, &y, &l, &n);
	for (int i = 1; i <= n; i++)
	{
		int xx, yy;
		scanf("%d%d", &xx, &yy);
		if (xx >= x && xx <= x + l && yy >= y && yy <= y + l) ans++;
	}
	printf("%d", ans);
}
