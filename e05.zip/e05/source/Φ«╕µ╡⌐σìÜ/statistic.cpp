#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
typedef unsigned long long ll;
ll n1, n2, n, a[10000005],s1, s2;
ll read()
{
	ll x = 0, f = 1; char c = getchar();
	while (c < '0' || c > '9')
	{
		if (c == '-') f = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') 
	{
		x = x * 10 + c - '0';
		c = getchar();
	}
	return x *= f;
}
int main()
{
	freopen("statistic.in", "r", stdin);
	freopen("statistic.out", "w", stdout);
	n = read(); n1 = read(); n2 = read();
	ll nn1 = n1, nn2 = n2;
	for (int i = 1; i <= n; i++) 
		a[i] = read();
	sort(a + 1, a + 1 + n, greater<int>());
	ll now = 1;
	while(n1) s1 += a[now], now++, n1--;
	now = n;
	while(n2) s2 += a[now], now--, n2--;
	printf("%.3lf", 1.0 * s1 / nn1 - 1.0 * s2 / nn2);
}
