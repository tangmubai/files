#include<stdio.h>
#include<vector>
#include<algorithm>
#include<string.h>
#include<iostream>
const int N = 1e5;
using namespace std;
int t, n, size[N + 5];
vector<int > edge[N + 5];
vector< int > ans;
void read(int &x) {
	x = 0; char c = getchar(); int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;			
}
void Get(int x, int fa) {
	size[x]	= 1;
	for(int i = 0; i < edge[x].size(); ++i) {
		int y = edge[x][i];
		if (y == fa)
			continue;
		Get(y, x);
		size[x] += size[y];
	}
}
void dfs(int x, int fa) {
	int flag = 1, sum = 1;
	for(int i = 0; i < edge[x].size(); ++i) {
		int y = edge[x][i];
		if (y == fa) continue;
		dfs(y, x);sum += size[y];
		if (size[y] > n / 2)
			flag = 0;
	}
	if (n - sum > n / 2)
		flag = 0;
	if (flag == 1)
		ans.push_back(x);
}
int main(){
	freopen("cnt.in", "r", stdin);
	freopen("cnt.out", "w", stdout);
	read(t);
	while(t--) {
		read(n);
		for(int i = 1; i <= n; ++i)
			edge[i].clear();
		ans.clear();	
		for(int i = 1; i < n; ++i) {
			int x, y;
			read(x);read(y);
			edge[x].push_back(y);
			edge[y].push_back(x);
		}
		Get(1, 0);
		dfs(1, 0);
		sort(ans.begin(), ans.end());
		for(int i = 0; i < ans.size(); ++i)
			printf("%d ", ans[i]);
		puts("");	
	}
	return 0;
}
