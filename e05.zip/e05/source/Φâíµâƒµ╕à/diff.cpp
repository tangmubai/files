#include<stdio.h>
#include<string.h>
#include<iostream>
const int N = 300, M = 300000;
using namespace std;
int t, n, a[N + 5], sum[N + 5], f[M + 5], ans;
void read(int &x) {
	x = 0; char c = getchar(); int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = -1;
	for(; c <= '9' && c >= '0'; c=  getchar())
		x = x * 10 + c - '0';
	x *= w;		
}
int max(int x, int y) {return x > y ? x: y;} 
int abs(int x) {return x < 0 ? -x : x;}
int min(int x, int y) {return x < y ? x : y;}
int main() {
	freopen("diff.in", "r", stdin);
	freopen("diff.out", "w", stdout);
	read(t);
	while(t--) {
		read(n);
		ans = 0x7fffffff;
		for(int i = 1; i <= n; ++i) {
			read(a[i]);
			sum[i] = sum[i - 1] + a[i];
		}
		for(int i = 0; i <= sum[n]; ++i)
			f[i] = 0;
		for(int i = 1; i <= n; ++i) {
			for(int j = sum[i]; j >= 0; --j) {
				f[j] = max(f[j], abs(j - sum[i] + j));
				if (j >= a[i])
					f[j] = min(f[j], max(f[j - a[i]], abs(j - sum[i] + j)));
			}
		}
		for(int i = 0; i <= sum[n]; ++i)
			ans = min(ans, f[i]);
		printf("%d\n", ans);
	}
		
	return 0;
}
