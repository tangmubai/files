#include<stdio.h>
#include<iostream>
#define LL long long
using namespace std;
int t, n, m;
void read(int &x) {
	x = 0;char c = getchar(); int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;		
}
int get(int n, int x) {
	if (x == 5) x = 0;
	if (x == 0) return n / 5;
	int ls = n / 5;
	if (n % 5 >= x)
		++ls;
	return ls;	 
}
int main() {
	freopen("pairs.in", "r", stdin);
	freopen("pairs.out", "w", stdout);
	read(t);
	while(t--) {
		read(n);read(m);
		LL ans = 0;
		for(int i = 0; i < 5; ++i) {
			LL x = get(n, i), y = get(m, 5 - i);
		//	cout << x << " " << y << endl;
			ans += x * y;
		}
		printf("%lld\n", ans);
//		cout << ans << endl;
	}
	return 0;
}
