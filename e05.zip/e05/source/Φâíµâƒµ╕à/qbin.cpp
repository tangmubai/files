#include<stdio.h>
#include<string.h>
int t, n, a[15], p[15][15], l, Maxx;
int max(int x, int y) {return x > y ? x: y;}
void Get(int x) {
	l = 0;Maxx = 0;
	while(x) {
		a[++l] = x % 10;
		Maxx = max(Maxx, x % 10);
		x /= 10;
	}
}
int main() {
	freopen("qbin.in", "r", stdin);
	freopen("qbin.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		memset(p, 0, sizeof(p));
		Get(n);int X = Maxx;Maxx = max(Maxx, l);
		for(int i = 1; i <= l; ++i) {
			int tp = a[i];
			for(int j = X - tp + 1; j <= X; ++j)	
				p[j][i] = 1;
		}
		
		for(int i = 1; i <= X; ++i) {
			int flag = 0;
			for(int j = Maxx; j >= 1; --j) {
				if (p[i][j] != 0) {printf("%d", p[i][j]);flag = 1;}
				if (p[i][j] == 0 && flag == 1) {printf("%d", p[i][j]); flag = 1;}
			}
			printf(" ");
		}
		puts("");
	}
	return 0;
}
