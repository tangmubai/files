#include<stdio.h>
#include<iostream>
#include<algorithm>
const int N = 1e5;
using namespace std;
int x, y, l, n, x1, x2, ans;
void read(int &x) {
	x = 0;char c = getchar(); int w = 1;
	for(; c < '0' || c > '9';c = getchar()) if (c == '-') w = -1;
	for(; c <= '9' && c >= '0'; c = getchar()) x = x * 10 + c - '0';
	x *= w;
}
int main() {
	freopen("square.in", "r", stdin);
	freopen("square.out", "w", stdout);
	read(x);read(y);read(l);read(n);
	x1 = x + l; x2 = y + l;
	for(int i = 1; i <= n; ++i) {
		int a, b;
		read(a);read(b);
		if (a <= x1 && a >= x && b <= x2 && b >= y)
			++ans;
	}
	cout << ans << endl;
	return 0;
} 
