#include<stdio.h>
#include<queue>
#include<string.h>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int n, n1,n2, x, Minx[25], Maxx[25]; 
int tp1, tp2;
void read(int &x) {
	x = 0;char c = getchar(); int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;		
}
int main() {
	freopen("statistic.in", "r", stdin);
	freopen("statistic.out", "w", stdout);
	memset(Minx, 0x3f, sizeof(Minx));
	memset(Maxx, -0x3f, sizeof(Maxx));
	read(n);read(n1);read(n2);
	for(int i = 1; i <= n; ++i)
	tp1 = 1; tp2 = 1;
	for(int i = 1;  i <= n; ++i) {
		read(x);
		if (x > Maxx[tp1]) {
		     Maxx[tp1] = x;
		     for(int j = 1; j <= n1; ++j)
		     	if (Maxx[j] < Maxx[tp1])
		     		tp1 = j;
		}
		if (x < Minx[tp2]) {
			Minx[tp2] = x;
			for(int j = 1; j <= n2; ++j)
				if (Minx[j] > Minx[tp2])
					tp2 = j;
		}
	}
	double s1 = 0.0, s2 = 0.0;
	for(int i = 1; i <= n1; ++i)
		s1 += Maxx[i];
	for(int i = 1; i <= n2; ++i)
		s2 += Minx[i];
	printf("%.3lf\n", s1 / n1 - s2 / n2);
	return 0;
}
