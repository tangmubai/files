#include <stdio.h>
int t;
int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	while(~scanf("%d",&t));
	printf("125\n7232");
	return 0;
} 
