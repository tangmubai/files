#include <stdio.h>
#include <cmath>
int t,a[305],n,s,ans;
bool flag;
void dfs(int mid,int i,int s1,int s2){
	if(i>n){
		if(abs((s-s2)-s2)<=mid)
			flag=1;
		return;
	}
	if(flag==1)return;
	if(s1+a[i]-s2<=mid)
		dfs(mid,i+1,s1+a[i],s2);
	if(s2+a[i]-s1<=mid)	
		dfs(mid,i+1,s1,s2+a[i]);
}
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		s=0;ans=99999999;
		scanf("%d",&n);	
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			s+=a[i];
		}
		int l=0,r=s+1;
		while(l<=r){
			flag=0;
			int mid=(l+r)>>1;		
			dfs(mid,1,0,0);
			if(flag==1){
				ans=mid;
				r=mid-1;
			}
			else l=mid+1;
		}
		printf("%d\n",ans);
	}
	return 0;
} 
