#include <stdio.h>
#define ll long long
ll t,ans,n,m;
bool flag;
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		ans=0;flag=0;
		scanf("%lld%lld",&n,&m);
		for(int i=0;i<=4;i++){
			if(flag==1)break;
			for(int j=0;j<=4;j++)
				if(n%5==i&&m%5==j){
					printf("%lld\n",(n/5)*(m/5)*5+i*(m/5)+j*(n/5));
					flag=1;
					break;
				}
		}
	}
	return 0;
} 
