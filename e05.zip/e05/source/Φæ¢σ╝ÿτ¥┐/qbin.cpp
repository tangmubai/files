#include <stdio.h>
#include <cstring>
#include <cmath>
#define ll long long
ll t,n,a[10],ans[1005];
void work(){
	int num=0,num2=0;
	bool flag=0;
	while(n){
		a[++num]=n%10;
		n/=10;
	}
	while(233){
		flag=0;
		++num2;
		for(int j=num;j>=1;j--){
			if(a[j]>0){
				ans[num2]=ans[num2]*10+1;
				a[j]--;
				flag=1;
			}
			else ans[num2]=ans[num2]*10;
		}
		if(flag==0)break;
	}
	for(int i=num2-1;i>=1;i--)
		printf("%lld ",ans[i]);
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		memset(a,0,sizeof(a));
		memset(ans,0,sizeof(ans));
		scanf("%lld",&n);
		work();	
		printf("\n");
	}
	return 0;
} 
