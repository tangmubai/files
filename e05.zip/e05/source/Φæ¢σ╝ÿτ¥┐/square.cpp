#include <stdio.h>
int x,y,l,n,x1[10005],y1[10005],ans;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&x,&y,&l,&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&x1[i],&y1[i]);	
	int x2=x+l,y2=y+l;
	for(int i=1;i<=n;i++)
		if(x1[i]>=x&&x1[i]<=x2&&y1[i]>=y&&y1[i]<=y2)
			ans++;
	printf("%d",ans);
	return 0;
} 
