#include <stdio.h>
#include <algorithm>
using namespace std;
int n,n1,n2,a[3000005];
double ans1,ans2;
int read(){
	int k=1,s=0;
	char c;
	c=getchar();
	while(c<'1'||c>'9'){
		if(c=='-')k=-1;
		c=getchar();
	}
	while(c>='1'&&c<='9'){
		s=s*10+c-'0';
		c=getchar();
	}
	return s*k;
}
bool cmp(int a,int b){
	return a>b;
}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	n=read();n1=read();n2=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n1;i++)
		ans1+=a[i];
	int k=n-n2+1;
	for(int i=n;i>=k;i--)
		ans2+=a[i];
	ans1/=n1;
	ans2/=n2;
	printf("%.3lf",ans1-ans2);
	return 0;
} 
