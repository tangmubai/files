#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
template <typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
const int N=1e5+5;
struct EDGE{
	int nxt,to;
}e[2*N];
int head[N],tot,son[N],ans[N],cnt;
void add(int from,int to){
	e[++tot].nxt=head[from];
	e[tot].to=to;
	head[from]=tot;
}
int n;
void dfs1(int u,int fa){
	son[u]=1;
	for(int i=head[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa) continue;
		dfs1(v,u);
		son[u]+=son[v];
	}
}
void dfs(int u,int fa){
	for(int i=head[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,u);
	}
}
void dfs2(int u,int fa){
	bool flag=true;
	for(int i=head[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa) continue;
		dfs2(v,u);
		if(son[v]>n/2) flag=false;
	}
	if(son[1]-son[u]>n/2) flag=false;
	if(flag) ans[++cnt]=u;
}
int main(){
	frin("cut.in");frout("cut.out");
	int t;in(t);
	while(t--){
		in(n);
		cnt=tot=0;
		memset(head,0,sizeof(head));
		memset(e,0,sizeof(e));
		for(int i=1;i<n;++i){
			int u,v;in(u),in(v);
			add(u,v),add(v,u);
		}
		dfs(1,0);
		dfs1(1,0);
		dfs2(1,0);
		if(cnt==0){
			puts("None");
			continue;
		}
		sort(ans+1,ans+cnt+1);
		for(int i=1;i<=cnt;++i){
			printf("%d ",ans[i]);
		}
		puts("");
	}
	return 0;
}
