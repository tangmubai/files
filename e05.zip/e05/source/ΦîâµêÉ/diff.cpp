#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
int a[305];
bool f[305][60005];
#define dp(a,b) f[a][(b)+30005]
int n;
int ab(int n){
	return n>=0?n:-n;
}
bool check(int x){
	memset(f,0,sizeof(f));
	dp(0,0)=1;
	for(int i=0;i<n;++i){
		for(int j=-x;j<=x;++j){
			if(ab(j+a[i])<=x){
				dp(i+1,j+a[i])|=dp(i,j);
			}
			if(ab(j-a[i])<=x){
				dp(i+1,j-a[i])|=dp(i,j);
			}
		}
	}
	bool flag=false;
	for(int i=-x;i<=x;++i){
		flag|=dp(n,i);
	}
	return flag;
}
int main(){
	frin("diff.in");frout("diff.out");
	int t;scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int l=0,r=0;
		for(int i=1;i<=n;++i){
			scanf("%d",a+i);
			r+=a[i];
		}
		while(l<=r){
			int mid=(l+r)>>1;
			if(check(mid)) r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",l);
	}
	return 0;
}
