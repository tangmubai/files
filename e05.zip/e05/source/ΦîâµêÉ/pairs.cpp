#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
typedef long long ll;
int main(){
	frin("pairs.in");frout("pairs.out");
	int t;scanf("%d",&t);
	while(t--){
		ll n,m;scanf("%lld%lld",&n,&m);
		ll ans=0;
		ans+=(n/5)*(m/5);
		for(int i=1;i<=4;++i){
			ans+=((n+i)/5)*((m+5-i)/5);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
