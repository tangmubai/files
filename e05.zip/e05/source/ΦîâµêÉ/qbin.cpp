#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
int a[20],tot;
int ans[20];
int main(){
	frin("qbin.in");frout("qbin.out");
	int t;scanf("%d",&t);
	while(t--){
		tot=0;
		int n;scanf("%d",&n);
		while(n){
			a[++tot]=n%10;
			n/=10;
		}
		memset(ans,0,sizeof(ans));
		int mx=0;
		for(int i=1;i<=tot;++i){
			mx=max(mx,a[i]);
		}
		for(int i=mx;i;--i){
			for(int j=tot;j;--j){
				ans[i]*=10;
				if(a[j]){
					--a[j];
					++ans[i];
				}
			}
		}
		for(int i=1;i<=mx;++i){
			printf("%d ",ans[i]);
		}
		puts("");
	}
	return 0;
}
