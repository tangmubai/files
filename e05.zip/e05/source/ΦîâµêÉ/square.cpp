#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
template <typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
struct qwq{
	int x,y;
}a[10005];
int main(){
	frin("square.in");frout("square.out");
	int x,y,l,n;in(x);in(y);in(l);in(n);
	for(int i=1;i<=n;++i) in(a[i].x),in(a[i].y);
	int ans=0;
	for(int i=1;i<=n;++i){
		if(a[i].x>=x&&a[i].x<=x+l&&a[i].y>=y&&a[i].y<=y+l) ++ans;
	}
	printf("%d\n",ans);
	return 0;
}
