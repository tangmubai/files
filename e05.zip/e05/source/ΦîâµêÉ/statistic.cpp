#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
template <typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
int a[3000005];
typedef long long ll;
int main(){
	frin("statistic.in");frout("statistic.out");
	int n,n1,n2;in(n);in(n1);in(n2);
	ll s1=0,s2=0;
	for(register int i=1;i<=n;++i){
		in(a[i]);
		s1+=a[i];
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n2;++i){
		s1-=a[i];
		s2+=a[i];
	}
	for(int i=n2+1;i<=n-n1;++i){
		s1-=a[i];
	}
	printf("%.3lf",1.0*s1/n1-1.0*s2/n2);
	return 0;
}
