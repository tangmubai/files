#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <map>
#include <iostream>
#include <string>
#include <string.h>
using namespace std;
inline long long read(long long &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
long long a[10];
main() {
	freopen("pairs.in", "r", stdin);
	freopen("pairs.out", "w", stdout);
	long long t;
	read(t);
	while (t --) {
	long long ans = 0;
		long long n, m;
		read(n);
		read(m);
		if (n > m) {
			long long a = n;
			n = m;
			m = a;
		}
		long long group = n / 5;
		long long more = n % 5;
		//cout << group << endl << more << endl;
		for (register int i = 1; i <= 5; i ++) {
		/*	a[i] = 1 + (m-5+i) / 5;
			ans += a[i] * group; */
			a[i] = 1;
			int now = 5-i;
			if (now == 0) now = 5;
			while (now + 5 <= m) {
				a[i] ++;
				now += 5;
			}
			ans += a[i] * group;
			//cout << a[i] << " " << group << " " << ans << endl;
		}
		for (register int i = 1; i <= more; i ++) ans += a[i];
		printf ("%lld\n", ans);
	}
	return 0;
}
