#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <map>
#include <iostream>
#include <string>
#include <string.h>
using namespace std;
/*inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}*/
int ans;
main() {
	freopen("square.in", "r", stdin);
	freopen("square.out", "w", stdout);
	int x1, y1, l, n;
	scanf ("%d %d %d %d", &x1, &y1, &l, &n);;
	while (n --) {
		int a, b;
		scanf ("%d %d", &a, &b);
		if (a >= x1 && a <= x1+l && b >= y1 && b <= y1+l) ans ++;
	}
	printf ("%d\n", ans);
	return 0;
}
