#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <queue>
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
int a[3000005];
double sum1, sum2;
main() {
	freopen("statistic.in", "r", stdin);
	freopen("statistic.out", "w", stdout);
	int n, n1, n2;
	read(n);
	read(n1);
	read(n2);
	for (register int i = 1; i <= n; i ++) read(a[i]);
	/*for (register int i = 1; i <= n; i ++) {
		int x;
		read(x);
		q1.push(x);
		q2.push(x);
	}
	for (register int i = 1; i <= n1; i ++) sum1 += q1.top(), q1.pop();
	for (register int i = 1; i <= n2; i ++) sum2 += q2.top(), q2.pop();*/
	std::sort (a+1, a+n+1);
	for (register int i = n; i >= n-n1+1; i --) sum1 += a[i];
	for (register int i = 1; i <= n2; i ++) sum2 += a[i];
	printf ("%.3lf\n", sum1 / n1 - sum2 / n2);
	return 0;
}
