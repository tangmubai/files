#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
int read() {
	int x = 0;
	char ch = getchar();
	int f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return x * f;
}
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
const int N = 1e5 + 5; 
int t, n;
int sz[N];
bool vis[N];
vector <int> edge[N];
void search (int step) {
	vis[step] = 1;
	sz[step] = 1;
	for (int i = 0; i < edge[step].size(); i ++) {
		if (!vis[edge[step][i]]) {
			search (edge[step][i]);
			sz[step] += sz[edge[step][i]];
		}
	}
	vis[step] = 0;
}

int main () {
	freopen ("cut.in", "r", stdin);
	freopen ("cut.out", "w", stdout);
	
	t = read();
	while (t --) {
		n = read();
		for (int i = 1; i <= n; i ++)
			edge[i].clear();
		for (int i = 1; i < n; i ++) {
			int u = read(), v = read();
			edge[u].push_back(v);
			edge[v].push_back(u);  
		}
		search (1);
		bool output = 0;
		for (int i = 1; i <= n; i ++) {
			bool ok = (n - sz[i]) <= n / 2;
			for (int j = 0; j < edge[i].size() && ok; j ++) {
				int to = edge[i][j];
				if (sz[to] <= sz[i] && sz[to] > n / 2)
					ok = 0;
			}
			if (ok)
				printf ("%d ", i), output = 1;
		}
		if (!output)
			printf ("None");
		puts("");
	}
}

