#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int read() {
	int x = 0;
	char ch = getchar();
	int f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return x * f;
}
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
const int N = 305;
int a[N];
int t, n;
int mem[N][205][2];
int mx, cnt;
int abs (int x) {
	return x > 0 ? x : -x;
}
bool check (int x, int c, int f) {
	if (abs(c) > f)
		return 0;
	if (x == n + 1)
		return 1;
	if (c >= 0) {
		if (mem[x][c][0] != -1 && mem[x][c][0] <= f)
			return 1;
	}
	else {
		if (mem[x][-c][1] != -1 && mem[x][-c][1] <= f)
			return 1;
	} 
	bool res = 0;
	res = check (x + 1, c + a[x], f) | check (x + 1, c - a[x], f);
	if (res)
		if (c >= 0) 
			mem[x][c][0] = f;
		else
			mem[x][-c][1] = f;
	return res;
}
int main () {
	freopen ("diff.in", "r", stdin);
	freopen ("diff.out", "w", stdout);
	t = read();
	while (t --) {
		memset (mem, -1, sizeof(mem));
		n = read();
		int l = 0, r = 200;
		for (int i = 1; i <= n; i ++) {
			a[i] = read();
		}
		int ans = -1;
		while (l <= r) {
			int mid = l + r >> 1;
			if (check (1, 0, mid)) {
				ans = mid;
				r = mid - 1;
			}
			else
				l = mid + 1;
		}
		printf ("%d\n", ans);
	}
}

