#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int read() {
	int x = 0;
	char ch = getchar();
	int f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return x * f;
}
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
typedef long long ll;
int t, n, m;
int main () {
	freopen ("pairs.in", "r", stdin);
	freopen ("pairs.out", "w", stdout);
	t = read();
	while (t --) {
		n = read(), m = read();
		ll q1[10] = {0}, q2[10] = {0};
		int y1 = n % 5, y2 = m % 5;
		n /= 5, m /= 5;
		ll ans = 0;
		for (int i = 0; i < 5; i ++)
			 q1[i] = n, q2[i] = m;
		for (int i = 1; i <= y1; i ++)
			q1[i] ++;
		for (int i = 1; i <= y2; i ++)
			q2[i] ++;
		for (int i = 1; i <= 4; i ++)
			ans += q1[i] * q2[5 - i] * 1ll;
		ans += q1[0] * q2[0] * 1ll;
		printf ("%lld\n", ans);
	}
}
/*
2
6 12
21 21

0 1 2 3 4


1 2 3 4 5 6
1 2 3 4 5 6 7 8 9 10 11 12

2 1 1 1 1
2 3 3 2 2

3+3+2+2+4

*/
