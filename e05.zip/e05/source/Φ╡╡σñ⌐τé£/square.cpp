#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int read() {
	int x = 0;
	char ch = getchar();
	int f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return x * f;
}
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int x, y, l, n, ans; 
int main () {
	freopen ("square.in", "r", stdin); 
	freopen ("square.out", "w", stdout); 
	x = read(), y = read(), l = read(), n = read();
	int x2 = x + l, y2 = y + l;
	printf ("%d %d %d %d\n", x, y, x2, y2);
	for (int i = 1; i <= n; i ++) {
		int ix = read(), iy = read();
		if (x <= ix && ix <= x2 && y <= iy && iy <= y2)
			ans ++;
	}
	printf ("%d", ans);
}

