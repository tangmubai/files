#include <cstdio>
#include <algorithm>
#include <queue>
using namespace std;
int read() {
	int x = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return x;
}
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int n, n1, n2;
const int N = 3e6 + 5;
typedef long long ll;
int a[N];
//vector <int> mn, mx;
int main () {
	freopen ("statistic.in", "r", stdin);
	freopen ("statistic.out", "w", stdout);
	
	n = read(), n1 = read(), n2 = read();
	ll s1, s2;
	s1 = s2 = 0;
	for (int i = 1; i <= n; i ++) {
		a[i] = read();
	} 
	sort (a + 1, a + n + 1);
	for (int i = 1; i <= n1; i ++)
		s1 += a[n - i + 1];
	for (int i = 1; i <= n2; i ++)
		s2 += a[i];
	printf ("%.3f", (double)s1 / (double)n1 - (double)s2 / (double)n2);
}

