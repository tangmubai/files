#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#define ll register int
#define mod 20070707
#define maxs 20070707

using namespace std;
int n,mid,l,r;
int a[305]={0};
bool chk(){
	ll c=0,h=a[1];
	if(abs(h-c)>mid)return false;
	for(ll i=2;i<=n;i++){
		ll x=abs(h+a[i]-c),y=abs(c+a[i]-h);
		if(x>mid&&y>mid)return false;
		if(x<=mid&&y>mid)h+=a[i];
		else if(x>mid&&y<=mid)c+=a[i];
		else if(x>y)h+=a[i];
		else c+=a[i];
		if(abs(h-c)>mid)return false;
	}
	return true;
}
int main(){freopen("diff.in","r",stdin);freopen("diff.out","w",stdout);
	ll t,ans=0;
	scanf("%d",&t);
	while(t--){l=r=0;
		scanf("%d",&n);
		for(ll i=1;i<=n;i++)scanf("%d",&a[i]),r+=a[i];
		while(l<=r){
			mid=(l+r)>>1;
			if(chk())ans=mid,r=mid-1;
			else l=mid+1;
			//printf("%dssssssssssss\n",mid);
		}
		printf("%d\n",ans);
	}
	return 0;
}

