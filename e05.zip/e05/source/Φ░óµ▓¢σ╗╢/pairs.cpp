#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#define ll register long long
#define mod 5
#define maxs 20070707

using namespace std;
long long b[10]={0};
long long g[10]={0};
int main(){freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
	ll t;
	ll n,m;
	ll ans=0;
	scanf("%lld",&t);
	while(t--){ans=0;
		scanf("%lld%lld",&n,&m);
		b[1]=b[2]=b[3]=b[4]=b[0]=n/5;
		g[1]=g[2]=g[3]=g[4]=g[0]=m/5;
		n%=5,m%=5;
		for(ll i=1;i<=n;i++)b[i]++;
		for(ll i=1;i<=m;i++)g[i]++;
		for(ll i=0;i<=4;i++)ans+=b[i]*g[4-i];
		printf("%lld\n",ans);
	};
	return 0;
}

