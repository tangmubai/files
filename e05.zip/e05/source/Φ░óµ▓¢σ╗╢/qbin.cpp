#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#define ll register int
#define mod 20070707
#define maxs 20070707

using namespace std;

int main(){//freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);

	return 0;
}

