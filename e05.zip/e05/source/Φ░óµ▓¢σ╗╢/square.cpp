#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#define ll register int
#define mod 20070707
#define maxs 20070707

using namespace std;

int main(){freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	ll x,y,l,n;
	ll a,b;
	ll ans=0;
	scanf("%d%d%d%d",&x,&y,&l,&n);
	for(ll i=1;i<=n;i++){
		scanf("%d%d",&a,&b);
		if(x+l>=a&&y+l>=b&&x<=a&&y<=b)ans++;
	}
	printf("%d",ans);
	return 0;
}

