#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#define ll register long long
#define mod 20070707
#define maxs 20070707

using namespace std;

long long a[3000006]={0};
int main(){freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	ll n,n1,n2;
	ll sum1=0,sum2=0;
	register double p1,p2;
	scanf("%lld%lld%lld",&n,&n1,&n2);
	for(ll i=1;i<=n;i++)scanf("%lld",&a[i]);
	sort(a+1,a+1+n);
	for(ll i=0;i<n1;i++)sum1+=a[n-i];
	for(ll i=1;i<=n2;i++)sum2+=a[i];
	p1=1.0*sum1/n1,p2=1.0*sum2/n2;
	printf("%.3f",p1-p2);
	return 0;
}

