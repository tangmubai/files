#include<stdio.h>
using namespace std;
struct node{
	int b;
	int next;
}a[200005];
int head[100005],sum=0;
void add(int x,int y){
	a[++sum].b=y;a[sum].next=head[x];head[x]=sum;
	return;
}
int find(int now,int last){
	int i,sum=1;
	for(i=head[now];i>0;i=a[i].next){
		if(a[i].b!=last)sum+=find(a[i].b,now);
	}
	return sum;
}
int check(int k,int n){
	int i;
	for(i=head[k];i>0;i=a[i].next){
		int h=find(a[i].b,k);
		//printf("%d %d\n",a[i].b,h);
		if(2*h>n)return 0;
	}
	return 1;
}
int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int n,i,x,y,f=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++){
			head[i]=0;
			//a[2*i].b=a[2*i].next=a[2*i-1].b=a[2*i-1].next=0;
		}
		for(i=1;i<n;i++){
			scanf("%d%d",&x,&y);
			add(x,y);
			add(y,x);
		}
		for(i=1;i<=n;i++){
			int flag=check(i,n);
			if(flag){
				printf("%d ",i);f=1;
			}
		}
		if(f==0)printf("None");
		printf("\n");
	}
	return 0;
} 
