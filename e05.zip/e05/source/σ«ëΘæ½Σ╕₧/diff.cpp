#include<stdio.h>
#include<iostream>
#include<cmath>
using namespace std;
int a[305],n;
int check(int k){
	int i,sum=0,sum1=0;
	for(i=1;i<=n;i++){
		sum+=a[i];
		if(sum-sum1>k){
			sum-=a[i];sum1+=a[i];
			if(sum1-sum>k)return 0;
		}
	}
	return 1;
}
int find(int l,int r){
	if(l>r)return -1;
	int mid=(l+r)/2;
	int flag=check(mid),flag1=check(mid-1);
	if(flag&&flag1==0)return mid;
	if(flag)return find(l,mid-1);
	else return find(mid+1,r);
}
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int i,sum=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++){
			scanf("%d",&a[i]);
			sum+=a[i];
		}
		int h=find(0,sum);
		printf("%d\n",h);
	}
	return 0;
} 
