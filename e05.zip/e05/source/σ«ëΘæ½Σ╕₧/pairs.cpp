#include<stdio.h>
using namespace std;
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		long long n,m,ans=0,i;
		scanf("%lld%lld",&n,&m);
		for(i=1;i<=5;i++){
			long long sum=(m+i)/5,sum1=(n+5-i)/5;
			if(i==5)sum--;
			ans=ans+sum*sum1;
		}
		printf("%lld\n",ans);
	}
	return 0;
} 
