#include<stdio.h>
#include<algorithm>
using namespace std;
int b[15];
struct node{
	int k,bh;
}a[15];
bool cmp(node x,node y){
	if(x.k!=y.k)return x.k>y.k;
	else return x.bh<y.bh;
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int n,sum=0,i,j;
		scanf("%d",&n);
		while(n){
			a[++sum].k=n%10;
			n/=10;
		}
		for(i=sum;i>0;i--){
			a[i].bh=sum-i+1;
			b[i]=0;
		}
		sort(a+1,a+1+sum,cmp);
		for(i=1;i<=sum;){
			b[a[i].bh]=1;
			while(i<=sum){
				i++;
				if(i==sum+1)break;
				if(a[i].k==a[i-1].k){
					b[a[i].bh]=1;
				}
				else break;
			}
			int k=a[i-1].k-a[i].k;
			int s=0;
			for(j=1;j<=sum;j++){
				s=s*10+b[j];
			}
			while(k--){
				printf("%d ",s);
			}
		}
		printf("\n");
	}
	return 0;
} 
