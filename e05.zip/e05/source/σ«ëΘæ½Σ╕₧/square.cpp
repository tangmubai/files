#include<stdio.h>
using namespace std;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int x,y,x2,y2,l,n,i,x1,y1;
	scanf("%d%d%d%d",&x,&y,&l,&n);
	x2=x+l;y2=y+l;
	int ans=0;
	for(i=1;i<=n;i++){
		scanf("%d%d",&x1,&y1);
		if(x1>=x&&y1>=y&&x1<=x2&&y1<=y2)ans++;
	}
	printf("%d",ans);
	return 0;
} 
