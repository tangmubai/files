#include<stdio.h>
#include<algorithm>
using namespace std;
int a[3000005];
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n,n1,n2,i,j;
	scanf("%d%d%d",&n,&n1,&n2);
	for(i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	/*double ans1=0,ans2=0;
	for(i=1;i<=n1;i++){
		double max=0;
		int bh=0;
		for(j=1;j<=n;j++){
			if(a[j]>max){
				max=a[j];bh=j;
			}
		}
		a[bh]=-1;
		ans1+=max;
	}
	for(i=1;i<=n2;i++){
		double max=2147483647;
		int bh=0;
		for(j=1;j<=n;j++){
			if(a[j]!=-1&&a[j]<max){
				max=a[j];bh=j;
			}
		}
		a[bh]=-1;
		ans2+=max;
	}*/
	sort(a+1,a+1+n);
	double ans=0,ans1=0;
	for(i=1;i<=n2;i++){
		ans+=a[i];
	}
	for(i=1;i<=n1;i++){
		ans1+=a[n-i+1];
	}
	ans1*=1.000000;ans*=1.000000;n2*=1.000000;n1*=1.000000;
	printf("%.3lf",(ans1/n1-ans/n2));
	return 0;
} 
