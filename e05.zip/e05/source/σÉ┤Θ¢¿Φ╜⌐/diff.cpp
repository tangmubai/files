#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
#define itn int
itn t,n,a[305],ans;
void dfs(int x,itn y,itn s1,itn s2){
	if(abs(s1-s2)>ans)return;
	if(x>n){
		if(y<ans)ans=y;
		return;
	}
	dfs(x+1,max(y,abs(s1-s2)),s1+a[x],s2);
	dfs(x+1,max(y,abs(s1-s2)),s1,s2+a[x]);
}
int main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		ans=30001;
		dfs(2,0,0,a[1]);
		dfs(2,0,a[1],0);
		printf("%d\n",ans);
	}
	return 0;
}
