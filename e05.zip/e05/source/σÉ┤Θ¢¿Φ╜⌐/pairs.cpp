#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
#define itn int
itn t,n,m;
long long a[10],ans,s;
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		s=ans=0;
		memset(a,0,sizeof(a));
		for(itn i=1;i<=5;i++){
			a[i]=(m-5+i)/5+1;
			if(i==5)a[i]--;
			s+=a[i];
		}
		ans=s*(n/5);
		for(int i=1;i<=n%5;i++)ans+=a[i];
		printf("%lld\n",ans);
	}
	return 0;
}
