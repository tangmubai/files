#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
#define itn int
int x,y,l,n,a,b,ans;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d %d %d %d",&x,&y,&l,&n);
	for(int i=1;i<=n;i++){
		scanf("%d %d",&a,&b);
		if(a>=x&&a<=x+n&&b>=y&&b<=y+n)ans++;
	}
	printf("%d",ans);
	return 0;
}
