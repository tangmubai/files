#include<stdio.h>
#include<algorithm>
using namespace std;
#define itn int
int n,n1,n2,a[3000005];
double s1,s2;
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	scanf("%d %d %d",&n,&n1,&n2);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	for(int i=n;i>n-n1;i--)s1+=a[i];
	for(int i=1;i<=n2;i++)s2+=a[i];
	s1=s1*1.0/n1;
	s2=s2*1.0/n2;
	printf("%.3lf",s1-s2);
	return 0;
}                    
