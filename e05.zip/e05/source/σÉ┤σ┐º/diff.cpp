#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,t,a[1100],ans=10000000,maxn;
void dfs(int i,int ja,int jo,int maxn)
{
	if(i>n)
	{
		ans=min(ans,maxn);
		return ;
	}
	dfs(i+1,ja+a[i],jo,max(maxn,abs(ja-jo)));
	dfs(i+1,ja,jo+a[i],max(maxn,abs(ja-jo)));
}
int main()
{
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		cin>>n;
		ans=100000000;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];		
		}
		dfs(1,0,0,-100000);
		printf("%d\n",ans);
	}
	return 0;
}

