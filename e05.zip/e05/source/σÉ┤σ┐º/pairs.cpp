#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
long long n,m,ans;
long long n1,n2,num;
int t;
int main()
{
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		ans=0;
		cin>>n>>m;
		num=m%5;
		m=(m+1)/5;
		n1=n%5;
		n2=n/5;
		ans=n2*(5*m+num);
		if(n1==1)
		{
			ans+=m;
		}
		if(n1==2)
		{
			ans+=2*m;
		}
		if(n1==3)
		{
			ans+=3*m;
		}
		if(n1==4)
		{
			ans+=4*m+1;
		}
		if(n1==5)
		{
			ans+=5*m+1;
		}
		cout<<ans<<endl;
	}
	return 0;
}
/*
5 20
1 4
1 9 
1 14
1 19
2 3
2 8
2 13
2 18
3 2
3 7
3 12
3 17
4 1
4 6
4 11
4 16

*/
