#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;

int main()
{
//	freopen("qbin.in","r",stdin);
//	freopen("qbin.out","w",stdout);
	ios::sync_with_stdio(false);
	
	return 0;
}

