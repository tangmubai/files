#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int x,y,l,n,a,b,xx,yy,ans;
int main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>x>>y>>l>>n;
	xx=x+l+1;
	yy=y+l+1;
	for(int i=1;i<=n;i++)
	{
		cin>>a>>b; 
		if((a>=x && b>=y) && (a<=xx && b<=yy))
		{
			ans++;
		}
	}
	cout<<ans<<endl;
	return 0;
} 
