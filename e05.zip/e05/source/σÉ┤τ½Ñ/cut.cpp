#include<stdio.h>
#define N 100000
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
struct edge{int to;edge*nxt;}*e[N];
int cnt[N],maxn[N];
inline void max(int&x,const int&y){if(x<y)x=y;}
inline void dfs(const int&i,const int&f)
{
	cnt[i]=1;maxn[i]=0;
	for(register edge*iee=e[i];iee;iee=iee->nxt)if(iee->to!=f)
	{
		dfs(iee->to,i);
		cnt[i]+=cnt[iee->to];
		max(maxn[i],cnt[iee->to]);
	}
}
main()
{
	freopen("cut.in","r",stdin);freopen("cut.out","w",stdout);
	register int t,n;register edge*tmp;register bool ok;
	for(read(t);t--;putchar('\n'))
	{
		read(n);
//		puts("qwq");
		for(register int i=n,u,v;--i;)
		{
			read(u);read(v);--u;--v;
			tmp=new edge;
			tmp->nxt=e[u];
			tmp->to=v;
			e[u]=tmp;
			tmp=new edge;
			tmp->nxt=e[v];
			tmp->to=u;
			e[v]=tmp;
		}
		dfs(0,-1);
		ok=1;
		for(register int i=0;i<n;e[i++]=0)
		{
			max(maxn[i],n-cnt[i]);
			if(maxn[i]<=(n>>1))printf("%d ",i+1),ok=0;
		}
		if(ok)putchar('N'),putchar('o'),putchar('n'),putchar('e');
	}
}
