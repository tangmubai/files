#include<stdio.h>
#define N 30001
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
int ans[N];
inline int min(const int&x,const int&y){return x<y?x:y;}
inline int max(const int&x,const int&y){return x>y?x:y;}
inline int abs(const int&x){return x<0?-x:x;}
main()
{
	freopen("diff.in","r",stdin);freopen("diff.out","w",stdout);
	register int t,n,a,s,minn;
	for(read(t);t--;)
	{
		for(register int i=1;i<N;ans[i++]=1<<30);ans[0]=0;s=0;
		for(read(n);n--;)
		{
			read(a);s+=a;
			for(register int i=s;i>=0;--i)ans[i]=max(min(ans[i],(i>=a?ans[i-a]:1<<30)),abs(s-i-i));
//			for(register int i=0;i<=s;printf("%d ",ans[i++]));printf("%d\n",s);
		}
		minn=s;
		for(register int i=0;i<=s;minn=min(minn,ans[i++]));
		printf("%d\n",minn);
	}
}
