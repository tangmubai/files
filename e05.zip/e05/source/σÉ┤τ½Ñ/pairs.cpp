#include<stdio.h>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
main()
{
	freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
	register int t,n,m,a[5],b[5];
	for(read(t);t--;)
	{
		read(n);read(m);
		a[0]=n/5;
		a[1]=n/5+(n%5>=1);
		a[2]=n/5+(n%5>=2);
		a[3]=n/5+(n%5>=3);
		a[4]=n/5+(n%5>=4);
		b[0]=m/5;
		b[1]=m/5+(m%5>=1);
		b[2]=m/5+(m%5>=2);
		b[3]=m/5+(m%5>=3);
		b[4]=m/5+(m%5>=4);
		printf("%lld\n",1ll*a[0]*b[0]+1ll*a[1]*b[4]+1ll*a[2]*b[3]+1ll*a[3]*b[2]+1ll*a[4]*b[1]);
	}
}
