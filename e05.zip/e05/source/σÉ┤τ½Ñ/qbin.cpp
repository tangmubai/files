#include<stdio.h>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
inline int cal(int&n)
{
	register int ans=0;
	for(register int i=1;i<=n;i=(i<<3)+(i<<1))if(n/i%10)n-=i,ans+=i;
	return ans;
}
main()
{
	freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
	register int t,n,ans[11],sz;
	for(read(t);t--;putchar('\n'))
	{
		read(n);sz=0;
		for(;n;ans[sz++]=cal(n));
		for(;sz--;printf("%d ",ans[sz]));
	}
}
