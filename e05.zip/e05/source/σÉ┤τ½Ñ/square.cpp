#include<stdio.h>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register bool t=0;register char c=nc();for(;c<'0'||'9'<c;t|=c=='-',c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());if(t)x=-x;
}
main()
{
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	register int x,y,l,n,a,b,ans=0;
	for(read(x),read(y),read(l),read(n);n--;read(a),read(b),ans+=x<=a&&a<=x+l&&y<=b&&b<=y+l);
	printf("%d",ans);
}
