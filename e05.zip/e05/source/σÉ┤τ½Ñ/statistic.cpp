#include<stdio.h>
#include<algorithm>
using namespace std;
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
int a[3000000];
main()
{
	freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	register int n,n1,n2;register long long ans1=0,ans2=0;
	read(n);read(n1);read(n2);
	for(register int i=0;i<n;read(a[i++]));
	nth_element(a,a+n2-1,a+n);
	for(register int i=0;i<n2;ans2+=a[i++]);
	nth_element(a,a+n-n1,a+n);
	for(register int i=n-n1;i<n;ans1+=a[i++]);
	printf("%.3lf",1.*ans1/n1-1.*ans2/n2);
}
