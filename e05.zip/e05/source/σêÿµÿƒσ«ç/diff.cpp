#include <cstdio>
#include <algorithm>
using namespace std;

const int N = 305;

int a[N];

void read(int &x)
{
	int f = 1; char c = getchar();
	while (c < '0' || c > '9')f = (c == '-' ? -1 : 1), c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
	if (f == -1) x = -x;
}

int main()
{
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	int t; read(t);
	while (t--)
	{
		int n; read(n);
		for (int i = 1; i <= n; i++) read(a[i]); 
		int jack = 0, john = 0, maxn = 0;
		for (int i = 1; i <= n; i++)
		{
			if (abs(jack + a[i] - john) < abs(john + a[i] - jack))
			{
				jack += a[i]; maxn = max(maxn, abs(jack + a[i] - john));
			}
			else
			{
				john += a[i]; maxn = max(maxn, abs(abs(john + a[i] - jack)));
			}
		}
		printf("%d\n", maxn);
	}
	return 0;
}

