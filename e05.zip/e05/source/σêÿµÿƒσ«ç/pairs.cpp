#include <cstdio>
#include <cstring>
#define ll long long
using namespace std;

int t1[6], t2[6];

void read(int &x)
{
	int f = 1; char c = getchar();
	while (c < '0' || c > '9')f = (c == '-' ? -1 : 1), c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
	if (f == -1) x = -x;
}

int main()
{
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	int t; read(t);
	while (t--)
	{
		memset(t1, 0, sizeof(t1));
		memset(t2, 0, sizeof(t2)); 
		ll ans = 0;
		int n, m; read(n), read(m);
		int k1 = n / 5, k2 = m / 5;
		for (int i = 0; i <= 4; i++) t1[i] += k1, t2[i] += k2;
		int q1 = n % 5, q2 = m % 5;
		for (int i = 1; i <= q1; i++) t1[i]++;
		for (int i = 1; i <= q2; i++) t2[i]++;
//		for (int i = 0; i <= 4; i++) printf("%d %d\n", t1[i], t2[i]);
		for (int i = 1; i <= 4; i++)
		{
			ans += 1ll * (1ll * t1[i] * t2[5 - i]);
		}
		ans += 1ll * t1[0] * t2[0];
		printf("%lld\n", ans);
	}
	return 0;
}

