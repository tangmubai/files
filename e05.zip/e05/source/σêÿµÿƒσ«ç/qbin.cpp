#include <cstdio>
#include <cstring>
using namespace std;

int a[105], ans[1005], len;
char s[105];

void read(int &x)
{
	int f = 1; char c = getchar();
	while (c < '0' || c > '9')f = (c == '-' ? -1 : 1), c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
	if (f == -1) x = -x;
}

bool check()
{
	for (int i = 1; i <= len; i++)
		if (a[i] != 0) return true;
	return false;
}

int main()
{
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	int t; read(t);
	while (t--)
	{
		memset(ans, 0, sizeof(ans));
		memset(a, 0, sizeof(a));
//		 len = 0; int k = 0;
		len = 0;
		scanf("%s", s + 1);
		for (int i = 1; s[i]; i++) a[i] = s[i] - '0', len++;
		int ans_i = 0;
		while (check())
		{
			int x = 0, i;
			for (i = 1; a[i] == 0; i++);
			for (; i <= len; i++)
			{
				if (a[i] >= 1) x = x * 10 + 1, a[i]--;
				else x = x * 10;
			}
			ans[++ans_i] = x;
		}
		for (int i = ans_i; i >= 1; i--) printf("%d ", ans[i]);
		printf("\n");
	}
	return 0;
}

