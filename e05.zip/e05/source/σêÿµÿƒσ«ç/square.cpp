#include <cstdio>

void read(int &x)
{
	int f = 1; char c = getchar();
	while (c < '0' || c > '9')f = (c == '-' ? -1 : 1), c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
	if (f == -1) x = -x; 
}

int main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int x, y, len, n;
	read(x), read(y), read(len), read(n);
//	x + len, y += len;
	int ans = 0;
	for (int i = 1; i <= n; i++)
	{
		int xx, yy; read(xx); read(yy); 
		if (xx <= x  + len && yy <= y  + len && xx >= x && yy >= y) ans++;
	}
	printf("%d\n", ans);
	return 0;
}
