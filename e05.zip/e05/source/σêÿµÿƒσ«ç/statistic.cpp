#include <cstdio>
#include <algorithm>
using namespace std;

int a[45];//�߽��С���� 
int minn[25], maxn[25], tot_min, tot_max;//minn����, maxn�ݼ� 

void read(int &x)
{
	int f = 1; char c = getchar();
	while (c < '0' || c > '9')f = (c == '-' ? -1 : 1), c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
	if (f == -1) x = -x;
}

int main()
{
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n, n1, n2; read(n), read(n1), read(n2);//n1���,n2��С 
	if (n <= n1 + n2)
	{
		for (int i = 1; i <= n; i++) read(a[i]);
		sort(a + 1, a + 1 + n);
		double x = 0.0, y = 0.0;
		for (int i = 1; i <= n2; i++) x += a[i];
		for (int i = n; i >= n - n1 + 1; i--) y += a[i];
		x /= n2; y /= n1;
		printf("%.3lf", y - x);
	}
	else
	{
		for (int i = 1; i <= n1 + n2; i++) read(a[i]);
		sort(a + 1, a + 1 + n1 + n2);
		for (int i = 1; i <= n2; i++) minn[++tot_min] = a[i];//Խ��Խ�� 
		for (int i = n1 + n2; i >= n1 + n2 - n1 + 1; i--) maxn[++tot_max] = a[i];//Խ��ԽС 
		minn[0] = 0, maxn[0] = 2147483647;
		for (int i = n1 + n2 + 1; i <= n; i++)
		{
//			bool ok = false;
			int x; read(x);
			if (x < minn[tot_min])
			{
				for (int j = tot_min - 1; j >= 0; j--)
				{
					if (minn[j] < x) minn[j + 1] = x;
				}
			}
			else if (x > maxn[tot_max])
			{
				for (int j = tot_max - 1; j >= 0; j--)
				{
					if (maxn[j] > x) maxn[j + 1] = x; 
				} 
			}
		}
		double x = 0.0, y = 0.0;//xСy��, y - x
		for (int i = 1; i <= tot_min; i++) x += minn[i];
		for (int i = 1; i <= tot_max; i++) y += maxn[i];
		x /= n2; y /= n1;
//		printf("%.3lf %3.lf", x, y);
		printf("%.3lf", y - x);
	}
	return 0;
}

