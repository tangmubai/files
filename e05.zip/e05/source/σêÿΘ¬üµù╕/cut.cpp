#include <stdio.h>
#include <vector>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n;
std:: vector<int> edge[100005];
inline int dfs(int u, int fa) {
	int node = 1;
	for (int i = 0; i < edge[u].size(); ++i) {
		int v = edge[u][i];
		if (v == fa) continue;
		node += dfs(v, u);
	}
	return node;
}
int main(void) {
	freopen("cut.in", "r", stdin);
	freopen("cut.out", "w", stdout);
	int t;
	for (read(t); t--; ) {
		read(n);
		for (int i = 1; i <= n; ++i)
			edge[i].clear();
		for (int i = 1, u, v; i < n; ++i) {
			read(u); read(v);
			edge[u].push_back(v);
			edge[v].push_back(u);
		}
		bool found = false;
		for (int i = 1; i <= n; ++i) {
			bool ok = true;
			for (int j = 0; j < edge[i].size(); ++j)
				if (dfs(edge[i][j], i) << 1 > n) {
					ok = false;
					break;
				}
			if (ok) {
				printf("%d ", i);
				found = true;
			}
		}
		if (found)
			puts("");
		else
			puts("None");
	}
	return 0;
}
