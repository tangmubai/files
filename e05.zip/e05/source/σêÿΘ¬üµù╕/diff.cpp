#include <stdio.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, a[305], f[2][305], ans[305];
inline int ab(int p) {
	return p > 0 ? p : -p;
}
int main(void) {
	int t;
	for (read(t); t--; ) {
		read(n);
		for (int i = 1; i <= n; ++i)
			read(a[i]);
		for (int i = 1; i <= n; ++i) {
			f[0][i] = f[0][i - 1] + a[i] - f[1][i - 1];
			f[1][i] = f[0][i - 1]
		}
	}
	return 0;
}
