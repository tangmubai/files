#include <stdio.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
long long n, m;
int main(void) {
	freopen("pairs.in", "r", stdin);
	freopen("pairs.out", "w", stdout);
	int t;
	for (read(t); t--; ) {
		read(n); read(m);
		printf("%lld\n", (n / 5) * (m / 5) * 5 + (n % 5) * (m / 5) + (n / 5) * (m % 5) + (n % 5 + m % 5) / 5);
	}
	return 0;
}
