#include <stdio.h>
#include <vector>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n;
std:: vector<int> dig[10];
inline int ksm(int a, int b) {
	int now = 1;
	while (b) {
		if (b & 1) now = now * a;
		a = a * a;
		b >>= 1;
	}
	return now;
}
int main(void) {
	freopen("qbin.in", "r", stdin);
	freopen("qbin.out", "w", stdout);
	int t;
	for (read(t); t--; ) {
		for (int i = 0; i <= 9; ++i)
			dig[i].clear();
		read(n);
		for (int i = 0; n; ++i) {
			dig[n % 10].push_back(ksm(10, i));
			n /= 10;
		}
		for (int i = 9; i >= 1; --i)
			if (dig[i].size() > 0) {
				int step = 0;
				for (int j = 0; j < dig[i].size(); ++j)
					step += dig[i][j];
				printf("%d ", step);
				dig[i - 1].push_back(step);
			}
		puts("");
	}
	return 0;
}
