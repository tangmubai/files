#include <stdio.h> 
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, x, y, l;
int main(void) {
	freopen("square.in", "r", stdin);
	freopen("square.out", "w", stdout);
	read(x); read(y); read(l); read(n);
	int ans = 0;
	for (int i = 1, u, v; i <= n; ++i) {
		read(u); read(v);
		ans += u >= x && u <= x + l && v >= y && v <= y + l;
	}
	printf("%d\n", ans);
	return 0;
}
