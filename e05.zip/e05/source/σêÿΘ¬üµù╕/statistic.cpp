#include <stdio.h>
#include <algorithm>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, n1, n2, a[3000005];
int main(void) {
	freopen("statistic.in", "r", stdin);
	freopen("statistic.out", "w", stdout);
	read(n); read(n1); read(n2);
	for (int i = 1; i <= n; ++i)
		read(a[i]);
	std:: sort(a + 1, a + 1 + n);
	int ans1 = 0, ans2 = 0;
	for (int i = n; i >= n - n1 + 1; --i)
		ans1 += a[i];
	for (int i = 1; i <= n2; ++i)
		ans2 += a[i];
	printf("%.3lf\n", 1.0 * ans1 / n1 - 1.0 * ans2 / n2);
	return 0;
}
