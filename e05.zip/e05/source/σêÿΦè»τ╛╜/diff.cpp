#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include<queue>
#define ll long long
using namespace std;
const int N=1e3+5;
int t,n,ans;
int a[N];
inline int read()
{
	int s=0,t=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			t=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*t;
}
inline void dfs(int i,int s1,int s2,int sum)
{
	if(i>n)
	{
		ans=min(ans,sum);
		return;
	}
	if(sum>ans) return;
	dfs(i+1,s1+a[i],s2,max(sum,abs(s1-s2)));
	dfs(i+1,s1,s2+a[i],max(sum,abs(s1-s2)));
	return;
}
int main()
{
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	t=read();
	while(t--)
	{
		n=read();
		for(int i=1;i<=n;i++)
		{
			a[i]=read();
		}
		ans=1<<30;
		dfs(1,0,0,0);
		printf("%d\n",ans);
	}
	return 0;
}
