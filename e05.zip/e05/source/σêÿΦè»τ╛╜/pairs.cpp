#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include<queue>
#define ll long long
using namespace std;
ll t,n,m,x,y,ans;
int main()
{
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%lld",&t);
	while(t--)
	{
		ans=0;
		scanf("%lld%lld",&n,&m);
		for(int i=1;i<=4;i++)
		{
			int j=5-i;
			x=n/5;
			y=m/5;
			if(x*5+i<=n) x++;
			if(y*5+j<=m) y++;
			ans+=x*y;
		}
		ans+=(n/5)*(m/5);
		printf("%lld\n",ans);
	}
	return 0;
}
