#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include<queue>
#define ll long long
using namespace std;
const int N=1e2+5;
int t,n,m,ok;
int a[N];
char s[N];
int main()
{
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%s",s+1);
		n=strlen(s+1);
		m=0;
		for(int i=1;i<=n;i++)
		{
			a[i]=s[i]-'0';
			m=max(m,a[i]);
		}
		for(int i=m;i;i--)
		{
			ok=0;
			for(int j=1;j<=n;j++)
			{
				if(a[j]<i&&ok)
				{
					printf("0");
				}
				if(a[j]>=i)
				{
					ok=1;
					printf("1");
				}
			}
			printf(" ");
		}
		puts(" ");
	}
	return 0;
}
