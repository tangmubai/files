#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include<queue>
using namespace std;
int x1,x2,y1,y2,l,n,x,y,ans;
inline int read()
{
	int s=0,t=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			t=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*t;
}
int main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	x1=read();
	y1=read();
	l=read();
	n=read();
	x2=x1+l;
	y2=y1+l;
	while(n--)
	{
		x=read();
		y=read();
		if(x1<=x&&x<=x2&&y1<=y&&y<=y2)
		{
			ans++;
		}
	}
	printf("%d",ans);
	return 0;
}
