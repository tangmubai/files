#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include<queue>
#define ll long long
using namespace std;
const int N=3e6+5;
int n,n1,n2;
int a[N];
double ans,sum;
inline int read()
{
	int s=0,t=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			t=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*t;
}
int main()
{
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	n=read();
	n1=read();
	n2=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n1;i++)
	{
		ans+=(double)a[n];
		n--;
	}
	ans/=(double)n1;
	for(int i=1;i<=n2;i++)
	{
		sum+=(double)a[i];
	}
	ans-=(double)sum/n2;
	printf("%.3lf",ans);
	return 0;
}
