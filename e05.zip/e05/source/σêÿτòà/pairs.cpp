#include<stdio.h>
long long ans=0,n,m;;
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	int t;scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%lld %lld",&n,&m);
		for(int i=1;i<=n;i++){for(int j=1;j<=m;j++){if((i+j)%5==0)ans++;}}  
	printf("%lld\n",ans);ans=0;
	}
}
