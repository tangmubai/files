#include<iostream>
#include<stdio.h>
using namespace std;
int main(){
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	int x,y,l,n,x1,y1;cin>>x>>y>>l>>n;int ans=0;
	for(int i=1;i<=n;i++){
		scanf("%d %d",&x1,&y1);
		if(x1>=x&&y1>=y&&x1<=(x+l)&&y1<=(y+l))ans++;
	}printf("%d",ans);
	return 0;
} 
