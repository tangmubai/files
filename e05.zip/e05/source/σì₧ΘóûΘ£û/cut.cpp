#include<stdio.h>
using namespace std;
int t,n,a,b;
int main(){
	freopen("cut.in","r",stdin);freopen("cut.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<n;i++)scanf("%d%d",&a,&b);
		printf("None\n");
	}
	return 0;
}
