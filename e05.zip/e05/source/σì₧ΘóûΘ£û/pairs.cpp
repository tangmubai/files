#include<stdio.h>
using namespace std;
long long t,a,b; 
int main(){
	freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		scanf("%lld%lld",&a,&b);
		long long a0=a/5,b0=b/5,a1=a/5,b1=b/5,a2=a/5,b2=b/5,a3=a/5,b3=b/5,a4=a/5,b4=b/5;
		if(a%5!=0){
			int e=a%5;if(e>=1)a1++;
			if(e>=2)a2++;if(e>=3)a3++;
			if(e>=4)a4++;
		}
		if(b%5!=0){
			int e=b%5;if(e>=1)b1++;
			if(e>=2)b2++;if(e>=3)b3++;
			if(e>=4)b4++;
		}
		printf("%lld\n",a0*b0+a1*b4+a2*b3+a3*b2+a4*b1);
	}
	return 0;
}
