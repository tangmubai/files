#include<stdio.h>
using namespace std;
int t,n;
int main(){
	freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		if(n<10){
			for(int i=1;i<=n;i++)printf("1 ");
			printf("\n");
			continue;
		}
		continue;
	}
	return 0;
}
