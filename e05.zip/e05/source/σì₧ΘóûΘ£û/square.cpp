#include<stdio.h>
using namespace std;
int x,y,l,n,a,b,p,q,s;
int main(){
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&x,&y,&l,&n);
	a=x+l;b=y+l;
	while(n--){
		scanf("%d%d",&p,&q);
		if((p<=a&&p>=x)&&(q<=b&&q>=y))s++;
	}
	printf("%d",s);
	return 0;
}
