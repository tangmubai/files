#include<stdio.h>
#include<algorithm>
using namespace std;
int n,a,b,s[3000001];
int main(){
	freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	for(int i=1;i<=n;i++)scanf("%d",&s[i]);
	sort(s+1,s+n+1);
	double n1=a,n2=b,s1=0,s2=0;
	for(int i=1;i<=n&&n2>0;i++,n2--)s2+=s[i];
	for(int i=n;i>=1&&n1>0;i--,n1--)s1+=s[i];
	printf("%.3lf",(s1/a)-(s2/b));
	return 0;
}
