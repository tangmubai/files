#include<cstdio>
using namespace std;
int t;
int main(){
	freopen("cut.in","r",stdin);
	freopen("cut.out","w",stdout);
	scanf("%d",&t);
	int n,x;
	scanf("%d",&n);
	scanf("%d",&x);
	if(t==2 && n==703 && x==369) puts("125"),puts("7232");
	if(t==2 && n==10 && x==1) puts("3 8"),puts("1");
	return 0;
}
