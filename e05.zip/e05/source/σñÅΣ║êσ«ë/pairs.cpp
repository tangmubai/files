#include<cstdio>
#include<iostream>
using namespace std;
int t;
int a[100000010],b[100000010];
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
		int tn=n/5,tm=m/5;
		for(int i=0;i<5;i++){
			a[i]=tn;
			b[i]=tm;
		}
		tn=5*tn+1;
		tm=5*tm+1;
		for(int i=tn;i<=n;i++)
			a[i%5]++;
		for(int i=tm;i<=m;i++)
			b[i%5]++;
		long long ans=1ll*a[0]*b[0]+1ll*a[1]*b[4]+1ll*a[2]*b[3]+1ll*a[3]*b[2]+1ll*a[4]*b[1];
		cout<<ans<<endl;
	}
	return 0;
}
