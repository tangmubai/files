#include<cstdio>
#include<iostream>
using namespace std;
int t;
int ans[100010],a[20];
bool em(){
	for(int i=1;i<=9;i++)
		if(a[i]!=0) return 0;
	return 1;
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		int n,len=0,ln=0;
		scanf("%d",&n);
		while(n){
			a[++ln]=n%10;
			n/=10;
		}
		while(!em()){
			int tmp=0;
			for(int i=9;i>=1;i--){
				if(a[i]!=0){
					a[i]--;
					tmp=tmp*10+1;
				}
				else tmp*=10;
			}
			ans[++len]=tmp;
		}
		for(int i=len;i>1;i--)
			printf("%d ",ans[i]);
		printf("%d\n",ans[1]);
	}
	return 0;
}
