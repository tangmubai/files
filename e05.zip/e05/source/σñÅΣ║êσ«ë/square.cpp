#include<cstdio> 
using namespace std;
int ans;
int x,y,l,n;
int a,b;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&x,&y,&l,&n);
	l+=x;n+=y;
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a,&b);
		if(a>=x&&a<=l && b>=y&&b<=n) ans++;
	}
	printf("%d\n",ans);
	return 0;
}
