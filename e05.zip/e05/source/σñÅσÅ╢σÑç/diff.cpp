#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
const int N = 3e2 + 5;

int Min(int x, int y) {
	if (x > y) return y;
	else return x;
}
int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}
int Abs(int x) {
	if (x < 0) return -x;
	else return x;
}

int t, n;
int a[N];

bool check(int x) {
	int ja = 0, jo = 0;
	for (int i = 1; i <= n; i++) {
//		if (Abs(ja - jo) + a[i] > x) {
//			if (ja > jo) jo += a[i];
//			else ja += a[i];
//		}else if (ja > jo) ja += a[i] ;
//		else jo += a[i];
		if (ja > jo and ja + a[i] - jo <= x) ja += a[i];
		else if (ja < jo and jo + a[i] - ja <= x) jo += a[i];
		else if (ja < jo) ja += a[i];
		else jo += a[i];
		if (Abs(ja - jo) > x) return false;
	}
	return true;
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("diff.in","r",stdin);
	//freopen("diff.out","w",stdout);
	cin >> t;
	while (t--)  {
		cin >> n;
		int l = 200, r = 0, mid;
		for (int i = 1; i <= n; i++) {
			cin >> a[i];
			l = Min(a[i], l);
			r = Max(a[i], r);
		}
		while (l < r) {
			mid = l + r >> 1;
			if (check(mid) == true) r = mid - 1;
			else l = mid;
		}
		cout << r + 1 << '\n';
		if (check(72) == true) cout << "!!!\n";
		else cout <<"false";
	}
	return 0;
}

