#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;

int main() {
	ios :: sync_with_stdio(false);
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	ll t, n, m, ans;
	cin >> t;
	while (t--) {
		ans = 0;
		cin >> n >> m;
		ans += (m / 5 * 5) * (n / 5);
		ans += (n % 5) * (m / 5);
		ans += (m % 5) * (n / 5);
		n %= 5, m %= 5;
		if (n + m < 5) {
			cout << ans << '\n';
			continue;
		}
		for (int i = 1; i <= n; i++) {
			if (5 - i < m) break;
			else ans++;
		}
		cout << ans << '\n';
	}
	return 0;
}
/*
1	2
1	2	3
*/
