#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;

int x, y, l, n;
int ans;

int main() {
	ios :: sync_with_stdio(false);
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	cin >> x >> y >> l >> n;
	int _x, _y;
	for (int i = 1; i <= n; i++)  {
		cin >> _x >> _y;
		if (_x >= x and _x <= l + x and _y >= y and _y <= y + l) ans++;
	}
	cout << ans << '\n';
	return 0;
}
