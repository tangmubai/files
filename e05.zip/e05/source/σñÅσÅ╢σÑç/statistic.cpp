#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
const int N = 3e6 + 5;

char buf[1 << 21], *p1, *p2;
int getc() {
	return p1 == p2 and (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1==p2)? EOF : *p1++;
}
inline int read(int &x) {
	char ch = getc();
	x = 0;
	bool f = false;
	while (!isdigit(ch)) {
		if (ch == '-') f = true;
		ch = getc();
	}
	while (isdigit(ch)) {
		x = x * 10 + ch - 48;
		ch = getc();
	}
	if (f == true) x = -x;
}

int a[N];

int main() {
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n, n1, n2;
	read(n), read(n1), read(n2);
	for (int i = 1; i <= n; i++) 
		read(a[i]);
	sort(a + 1, a + 1 + n);
	double sum1, sum2;
	for (int i = n; i > n - n1; i--)
		sum1 += a[i];
	sum1 /= (double)n1;
	for (int i = 1; i <= n2; i++)
		sum2 += a[i];
	sum2 /= (double)n2;
	printf ("%.3lf\n", sum1 - sum2);
	return 0;
}

