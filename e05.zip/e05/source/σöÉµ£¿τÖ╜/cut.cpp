#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>

const int N = 100001;

bool vis[N];
int ave, n, tot, deg[N], ans[N];
std :: vector <int> edge[N];

template <typename Tp>
inline void read(Tp &num) {
	char ch = getchar();
	while (ch < '0' || ch > '9') ch = getchar();
	for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

inline void work(const int id) {
	bool ok = true;
	deg[id] = 1; vis[id] = true;
	for (int i = 0; i < edge[id].size(); i++) {
		int nxt = edge[id][i];
		if (vis[nxt]) continue;
		work(nxt); deg[id] += deg[nxt];
		if (deg[nxt] > ave / 2) ok = false;
	}
	if (deg[id] < ave / 2) ok = false;
	if (ok) ans[++tot] = id;
}

int main() {
	freopen("cut.in", "r", stdin);
	freopen("cut.out", "w", stdout);
	int T;
	for (read(T); T; T--) {
		read(n);
		tot = 0; ave = n;
		if (n & 1) ave++;
		memset(deg, 0, sizeof deg);
		memset(vis, false, sizeof vis);
		for (int i = 1; i <= n; i++) edge[i].clear();
		for (int i = 1; i < n; i++) {
			int u1, u2;
			read(u1); read(u2);
			edge[u1].push_back(u2); edge[u2].push_back(u1);
		}
		work(1);
		if (tot == 0) {
			puts("None");
			continue;
		}
		std :: sort(ans + 1, ans + 1 + tot);
		for (int i = 1; i <= tot; i++) printf("%d ", ans[i]);
		puts("");
	}
	return 0;
}
