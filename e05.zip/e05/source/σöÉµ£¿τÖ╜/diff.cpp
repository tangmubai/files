#include <cstdio>
#include <cstring>

const int N = 301, M = 30001;

bool dp[2][M];
int n, val[N];

template <typename Tp>
inline void read(Tp &num) {
	char ch = getchar();
	while (ch < '0' || ch > '9') ch = getchar();
	for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

inline bool check(const int mx) {
	int sum = 0;
	memset(dp, false, sizeof dp);
	dp[0][0] = true;
	for (int i = 1; i <= n; i++) {
		bool nok = true;
		int now = i & 1, lst = (i - 1) & 1;
		for (int j = 0; j <= sum + val[i]; j++) dp[now][j] = false;
		for (int j = (sum + mx) / 2; j >= (sum - mx) / 2 && j >= 0; j--)
			if (dp[lst][j]) {
				dp[now][j] = true;
				dp[now][j + val[i]] = true;
			}
		sum += val[i];
		for (int j = (sum + mx) / 2; j >= (sum - mx) / 2 && j >= 0; j--)
			if (dp[now][j]) {
				nok = false;
				break;
			}
		if (nok) return false;
	}
	return true;
}

int main() {
	freopen("diff.in", "r", stdin);
	freopen("diff.out", "w", stdout);
	int T;
	for (read(T); T; T--) {
		int l = 0, r = 0, ans = -1;
		read(n);
		for (int i = 1; i <= n; i++) read(val[i]), r += val[i];
		while (l <= r) {
			int mid = (l + r) >> 1;
			if (check(mid)) r = mid - 1, ans = mid;
			else l = mid + 1;
		}
		printf("%d\n", ans);
	}
	return 0;
}
