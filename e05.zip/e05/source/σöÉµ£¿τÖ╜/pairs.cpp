#include <cstdio>

template <typename Tp>
inline void read(Tp &num) {
	char ch = getchar();
	while (ch < '0' || ch > '9') ch = getchar();
	for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

int main() {
	freopen("pairs.in", "r", stdin);
	freopen("pairs.out", "w", stdout);
	int T;
	for (read(T); T; T--) {
		long long n, m, ans = 0;
		long long tot1[10] = {0}, tot2[10] = {0};
		read(n); read(m);
		tot1[0] = tot1[1] = tot1[2] = tot1[3] = tot1[4] = n / 5;
		for (int i = 1; i <= n % 5; i++) tot1[i]++;
		tot2[0] = tot2[1] = tot2[2] = tot2[3] = tot2[4] = m / 5;
		for (int i = 1; i <= m % 5; i++) tot2[i]++;
		for (int i = 0; i <= 4; i++) ans += tot1[i] * tot2[(5 - i) % 5];
		printf("%lld\n", ans);
	}
	return 0;
}
