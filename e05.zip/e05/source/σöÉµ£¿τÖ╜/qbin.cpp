#include <cstdio>

const int N = 10001;

int tot, ans[N];

template <typename Tp>
inline void read(Tp &num) {
	char ch = getchar();
	while (ch < '0' || ch > '9') ch = getchar();
	for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

inline void make(const int num) {
	int pw = 1;
	ans[++tot] = 0;
	for (int t = num; t; t /= 10, pw *= 10) {
		int dig = t % 10;
		if (dig) ans[tot] += pw;
	}
}

int main() {
	freopen("qbin.in", "r", stdin);
	freopen("qbin.out", "w", stdout);
	int T;
	for (read(T); T; T--) {
		int n;
		read(n);
		tot = 0;
		while (n) {
			make(n);
			n -= ans[tot];
		}
		for (int i = tot; i; i--) printf("%d ", ans[i]);
		puts("");
	}
	return 0;
}
