#include <cstdio>

template <typename Tp>
inline void read(Tp &num) {
	Tp neg = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') neg = -1;
		ch = getchar();
	} 
	for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
	num *= neg;
}

int main() {
	freopen("square.in", "r", stdin);
	freopen("square.out", "w", stdout);
	int x, y, l, n, ans = 0;
	int x0, y0, x1, y1;
	read(x); read(y); read(l); read(n);
	x0 = x; y0 = y + l; x1 = x + l; y1 = y;
	for (int i = 1; i <= n; i++) {
		int tx, ty;
		read(tx); read(ty);
		if (tx >= x0 && tx <= x1 && ty >= y1 && ty <= y0) ans++;
	}
	printf("%d\n", ans);
	return 0;
}
