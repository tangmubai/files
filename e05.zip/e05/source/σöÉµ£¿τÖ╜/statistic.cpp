#include <cstdio>
#include <algorithm>

const int N = 3000001;

typedef long long ll;

ll num[N];

template <typename Tp>
inline void read(Tp &num) {
	char ch = getchar();
	while (ch < '0' || ch > '9') ch = getchar();
	for (num = 0; ch >= '0' && ch <= '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

int main() {
	freopen("statistic.in", "r", stdin);
	freopen("statistic.out", "w", stdout);
	int n, n1, n2;
	ll sum1 = 0, sum2 = 0;
	double t1, t2, tn1, tn2;
	read(n); read(n1); read(n2);//
	if (n1 > n2) n1 ^= n2 ^= n1 ^= n2;
	for (int i = 1; i <= n; i++) read(num[i]);
	std :: sort(num + 1, num + 1 + n);
	for (int i = 1; i <= n1; i++) sum1 += num[i];
	for (int i = 1; i <= n2; i++) sum2 += num[n - i + 1];
	t1 = sum1; t2 = sum2; tn1 = n1; tn2 = n2;
	printf("%.3lf\n", t2 / tn2 - t1 / tn1);
	return 0;
}
