#include <stdio.h>
using namespace std;

int n,ans;
int a[305];
inline int abs(int x){
	return x>0?x:-x;
}

inline int max(int x,int y){
	return x>y?x:y;
}

void dfs(int x,int y,int s1,int s2){
	if(abs(s1-s2)>ans)return ;
	if(x>n){
		if(y<ans)ans=y;return ;
	}
	dfs(x+1,max(y,abs(s1-s2)),s1+a[x],s2);
	dfs(x+1,max(y,abs(s1-s2)),s1,s2+a[x]);
}


main(){
	freopen("diff.in","r",stdin);
	freopen("diff.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		scanf("%d",&n);ans=1<<30;
		for(int i=1;i<=n;++i)scanf("%d",&a[i]);//printf("visit\n");
		dfs(2,0,0,a[1]);
//		printf("visit\n");
		dfs(2,0,a[1],0);
//		printf("visit\n");
		printf("%d\n",ans);
	} 
	return 0;
}

