#include <stdio.h>
#define ll long long
using namespace std;

ll a[6];
main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	int t,sb; ll n,m,ans=0,sum=0;
	scanf("%d",&t);
	while(t--){
		scanf("%lld %lld",&n,&m);ans=0;sum=0;
		for(ll i=1ll;i<5ll;++i){
			a[i]=(m+i)/5;sum+=a[i];//printf("%lld ",a[i]);
		}
		a[5]=m/5;sum+=a[5];//printf("%lld ",a[5]);
		ans=sum*(n/5);
		sb=n%5;//printf("%d\n",sb);
		for(int i=1;i<=sb;++i)ans+=a[i];
		printf("%lld\n",ans);
	}
	return 0;
}

