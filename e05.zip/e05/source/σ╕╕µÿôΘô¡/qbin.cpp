#include <stdio.h>
using namespace std;

int a[10];
char ans[10][10];
main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	int t,n,m;scanf("%d",&t);
	while(t--){
		scanf("%d",&n);m=n;int sb=0,ok=1,num=0;
		while(m){
			a[++sb]=m%10;m/=10;
		}
		while(ok){
			ok=0;++num;
			for(int i=1;i<=sb;++i){
//				int k=sb-i+1;
				if(a[i])ans[num][i]='1',ok=1,--a[i];
				else ans[num][i]='0';
			}
		}
		num--;
		for(int i=num;i;--i){
			ok=sb+1;
			while(ans[i][--ok]=='0');
			for(int j=ok;j;--j){
//				if(ans[i][j]=' ')printf("(%d,%d)\n",i,j);
				printf("%c",ans[i][j]);
			}
			printf(" ");
		}
		printf("\n");
	}
	return 0;
}

