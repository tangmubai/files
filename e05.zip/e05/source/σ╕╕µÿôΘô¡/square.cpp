#include <stdio.h>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}

main(){   
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int x=re(),y=re(),l=re(),n=re(),ans=0;//scanf("%d%d%d%d",&x,&y,&l,&n);
	int xe=x+l,ye=y+l,a,b;
	for(int i=1;i<=n;++i){
		scanf("%d%d",&a,&b);
//		a=re();b=re(); 
		if(a>=x&&a<=xe&&b>=y&&b<=ye)ans++;
	}
	printf("%d\n",ans);
	return 0;
} 

/*
0 0 5 5
1 2
3 4
6 7
5 3
2 8

3
*/
