#include <stdio.h>
#include <algorithm> 
using namespace std;

int re(){
	int a1=0;char ch=getchar();
	while(ch<'0'||ch>'9'){
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1;
}
int a[3000005];
double ans1,ans2,ans;
main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n=re(),n1=re(),n2=re();
	for(int i=1;i<=n;++i)//scanf("%d",&a[i]);
	a[i]=re();
	
	sort(a+1,a+1+n);
	for(int i=n,k=1;k<=n1;--i,++k)ans1+=a[i];
	for(int i=1;i<=n2;++i)ans2+=a[i];
	ans2=ans2*1.0/n2;ans1=ans1*1.0/n1;
	ans=ans1-ans2;
	printf("%.3lf",ans);
	return 0;
}

