#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int t,n,m;
long long a[10],b[10];
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		long long ans=0;
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)a[i%5]++;
		for(int i=1;i<=m;i++)b[i%5]++;
		for(int i=0;i<5;i++){
			if(i==0)ans+=a[i]*b[i];
			else ans+=a[i]*b[5-i];
		}
		printf("%lld\n",ans);
	}
	return 0;
}
