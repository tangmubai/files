#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int t,n,tot;
int a[11],b[11];
void nton(int x){
	int num=-1,len=1;
	while(x){
		b[len]++;
		++len;
		num=max(num,x%10);
		x/=10;
	}
	tot=num;
}
int main(){
	freopen("qbin.in","r",stdin);
	freopen("qbin.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		scanf("%d",&n);
		nton(n);
		for(int i=1;i<=9;i++)
		for(int j=1;j<=b[i];j++)a[j]+=pow(10,i-1);
		for(int i=tot;i>=1;i--)printf("%d ",a[i]);
		puts("");
	}
	return 0;
}
