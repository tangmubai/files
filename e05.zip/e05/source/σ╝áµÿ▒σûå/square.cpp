#include<cstdio>
#include<algorithm>
using namespace std;
int r,c,n,l,tot;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&r,&c,&l,&n);
	for(int t=1;t<=n;t++){
		int x,y;
		scanf("%d%d",&x,&y);
		if(x>=r&&y>=c&&x<=l+r&&y<=l+c)tot++;
	}
	printf("%d\n",tot);
	return 0;
}
