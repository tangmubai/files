#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,n1,n2,a[3000001];
inline int read(){
	char c=getchar();
	while(c<='0'||c>='9')c=getchar(); int p=0;
	while(c>='0'&&c<='9')p=p*10+(c-'0'),c=getchar();
	return p;
}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	//n=read(),n1=read(),n2=read();
	scanf("%d%d%d",&n,&n1,&n2);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	//a[i]=read();
	double s1=0,s2=0;
	sort(a+1,a+1+n);
	for(int i=1;i<=n1;i++)s1+=a[n-i+1];
	for(int i=1;i<=n2;i++)s2+=a[i];
	s1=s1/(n1*1.0);
	s2=s2/(n2*1.0);
	double ans=s1-s2;
	printf("%.3lf\n",ans);
	return 0;
}
