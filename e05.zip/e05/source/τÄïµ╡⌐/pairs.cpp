#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main() {
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	int t;
	cin>>t;
	while(t--) {
		int n,m;
		long long sum=0;
		cin>>n>>m;
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				if((i+j)%5==0) {
					sum++;
					sum+=((m-j)/5);
					break;
				}
			}
		}
		cout<<sum<<endl;
	}
	return 0;
}

