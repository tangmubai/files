#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main() {
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int x,y,l,n;
	cin>>x>>y>>l>>n;
	int fx=x+l;
	int fy=y+l;
	int sum=0;
	while(n--) {
		int a,b;
		cin>>a>>b;
		if(a<=fx&&b<=fy&&a>=x&&b>=y) {
			sum++;
		}
	}
	cout<<sum<<endl;
	return 0;
}
