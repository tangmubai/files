#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
inline int read (void) {
	register int x = 0, f = 1, ch = getchar();
	while(!isdigit(ch)) { if(ch == '-') f = -f; ch = getchar(); }
	while(isdigit(ch)) { x = x * 10 + ch - '0'; ch = getchar(); }
	return x * f;
}
double a[3000005];
int main() {
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	int n,n1,n2;
	n=read();n1=read();n2=read();
	for(int i=1; i<=n; i++) {
		a[i]=read();
	}
	sort(a+1,a+n+1);
	double sum1=0;
	for(int i=1; i<=n1; i++) {
		sum1+=a[i];
	}
	double sum2=0;
	for(int i=n; i>n2; i--) {
		sum2+=a[i];
	}
	double ans=sum2/n2-sum1/n1;
	printf("%.3lf",ans);
	return 0;
}
