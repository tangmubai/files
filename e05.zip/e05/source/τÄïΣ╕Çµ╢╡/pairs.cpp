#include <cstdio>
#include <cstring>
#include <cctype>
#include <algorithm>
using namespace std;
#define File(s) freopen(s".in", "r", stdin), freopen(s".out", "w", stdout)
typedef long long ll;
namespace io {
	const int SIZE = (1 << 21) + 1;
	char ibuf[SIZE], *iS, *iT, obuf[SIZE], *oS = obuf, *oT = oS + SIZE - 1, c, qu[55]; int f, qr;
	#define gc() (iS == iT ? (iT = (iS = ibuf) + fread (ibuf, 1, SIZE, stdin), (iS == iT ? EOF : *iS ++)) : *iS ++)
	inline void flush () {fwrite (obuf, 1, oS - obuf, stdout); oS = obuf;}
	inline void putc (char x) {*oS ++ = x; if (oS == oT) flush ();}
	template <class I> inline void gi (I &x) {for (f = 1, c = gc(); c < '0' || c > '9'; c = gc()) if (c == '-') f = -1;for (x = 0; c <= '9' && c >= '0'; c = gc()) x = x * 10 + (c & 15); x *= f;}
	template <class I> inline void print (I x) {if (!x) putc ('0'); if (x < 0) putc ('-'), x = -x;while (x) qu[++ qr] = x % 10 + '0',  x /= 10;while (qr) putc (qu[qr --]);}
	struct Flusher_ {~Flusher_(){flush();}}io_flusher_;
}
using io :: gi; using io :: putc; using io :: print;
ll a[10], b[10];
int main(){
    File("pairs");
	int t;
	gi(t);
	while (t -- )
	{
		ll n, m;
		gi(n), gi(m); 
		b[0] = b[1] = b[2] = b[3] = b[4] = (int)(m / 5);
		a[0] = a[1] = a[2] = a[3] = a[4] = (int)(n / 5);
		for (int i = 1; i <= n % 5; i ++ )	a[i] ++ ;
		for (int i = 1; i <= m % 5; i ++ )	b[i] ++ ;
		ll ans = 0;
		for (int i = 0; i < 5; i ++ )	ans += 1ll * a[i] * b[(5 - i) % 5];
		print(ans);
		putc('\n');
	}
	return 0;
}

