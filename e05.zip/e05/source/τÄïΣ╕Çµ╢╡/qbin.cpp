#include <iostream>
#include <cstdio>
#include <cstring>
#include <cctype>
#include <algorithm>
using namespace std;
#define File(s) freopen(s".in", "r", stdin), freopen(s".out", "w", stdout)
typedef long long ll;
namespace io {
	const int SIZE = (1 << 21) + 1;
	char ibuf[SIZE], *iS, *iT, obuf[SIZE], *oS = obuf, *oT = oS + SIZE - 1, c, qu[55]; int f, qr;
	#define gc() (iS == iT ? (iT = (iS = ibuf) + fread (ibuf, 1, SIZE, stdin), (iS == iT ? EOF : *iS ++)) : *iS ++)
	inline void flush () {fwrite (obuf, 1, oS - obuf, stdout); oS = obuf;}
	inline void putc (char x) {*oS ++ = x; if (oS == oT) flush ();}
	template <class I> inline void gi (I &x) {for (f = 1, c = gc(); c < '0' || c > '9'; c = gc()) if (c == '-') f = -1;for (x = 0; c <= '9' && c >= '0'; c = gc()) x = x * 10 + (c & 15); x *= f;}
	template <class I> inline void print (I x) {if (!x) putc ('0'); if (x < 0) putc ('-'), x = -x;while (x) qu[++ qr] = x % 10 + '0',  x /= 10;while (qr) putc (qu[qr --]);}
	struct Flusher_ {~Flusher_(){flush();}}io_flusher_;
}
using io :: gi; using io :: putc; using io :: print;
int nc(int x)
{
	int res = 0, r = 1;
	while (x % 10 == 0)
	{
		r *= 10;
		x /= 10;
	}
	while (x)
	{
//		cout << x % 10 << ' ';
		res = res * 10 + ((x % 10) > 0 ? 1 : 0);
		x /= 10;
	}
	int rres = 0;
	while (res)
	{
		rres = rres * 10 + res % 10;
		res /= 10;
	}
	return rres * r;
}
int nm(int x)
{
	int mn = 10000;
	while (x)
	{
		mn = min(mn, ((x % 10) > 0 ? x % 10 : 10));
		x /= 10;
	}
	return mn;
}
int cnt = 0;
int a[10000];
int main(){
    File("qbin");
	int t;
	gi(t);
	while (t -- )
	{
		cnt = 0;
		int n;
		gi(n);
		while (n)
		{
			int r = nc(n);
			int c = nm(n);
//			cout << c << ' ' << r << endl;
			n -= c * r;
//			cout << n << endl;
			for (int i = 1; i <= c; i ++ )	a[ ++ cnt] = r;
		}
		sort(a + 1, a + cnt + 1);
		for (int i = 1; i <= cnt; i ++ )
		{
			print(a[i]);
			putc(' ');
		}
		putc('\n');
	}
	return 0;
}

