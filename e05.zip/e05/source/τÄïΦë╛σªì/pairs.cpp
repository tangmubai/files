#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
using namespace std;
int t,m,n,ans=0;
int main(){
	freopen("pairs.in","r",stdin);
	freopen("pairs.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			int x=5-i%5;
			ans+=(m-x)/5+1;
		}
		printf("%d\n",abs(ans));
		ans=0;
	}
	return 0;
}
