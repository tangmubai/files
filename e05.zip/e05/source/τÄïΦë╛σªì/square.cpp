#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int x,y,l,n,x1,y1,ans=0;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d%d%d%d",&x,&y,&l,&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&x1,&y1);
		if(x1<=l+x&&y1<=l+x&&x1>=x&&y1>=y)ans++;
	}
	printf("%d\n",ans);
	return 0;
}
