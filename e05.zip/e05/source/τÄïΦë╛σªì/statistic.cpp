#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
const int MAXN=3*1e6;
int n,n1,n2,s1=0,s2=0;
int a[MAXN];
inline int read(){
	int s=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*f;
}
int main(){
	freopen("statistic.in","r",stdin);
	freopen("statistic.out","w",stdout);
	scanf("%d%d%d",&n,&n1,&n2);
	for(int i=1;i<=n;i++)a[i]=read();
	sort(a+1,a+1+n);
	for(int i=1;i<=n2;i++)s2+=a[i];
	for(int j=1;j<=n1;j++)s1+=a[j+n2];
	double ans=(s1/n1)-(s2/n2);
	printf("%.3lf\n",ans);
	return 0;
}
