#include "cstdio"
#include "cstring"
#include "algorithm"
using namespace std;
struct node{
	int from,to,next;
}e[1000005];
int t,n,ne,head[1000005],f[1000005],a[1000005],k,ans=2000000000;
void add(int from,int to){
	e[++ne].next=head[from];
	e[ne].to=to;
	head[from]=ne;
}
void dfs(int u,int fa){
	//f[u]=1;
	for (int i=head[u];i;i=e[i].next){
		int j=e[i].to;
		if (j!=fa){
			dfs(j,u);
			f[u]+=f[j];
		}
	}
	if (max(max(f[u],n-f[u]),min(f[u],n-f[u])+1)<ans) ans=max(f[u],n-f[u]);
}
int main(){
	//freopen ("cut.in","r",stdin);
	//freopen ("cut.out","w",stdout);
	scanf ("%d",&t);
	while (t--){
		memset (e,0,sizeof e);
		memset (f,0,sizeof f);
		memset (a,0,sizeof a);
		k=0;
		scanf ("%d",&n);
		int x,y;
		for (int i=1;i<=n-1;i++){
			scanf ("%d%d",&x,&y);
			add(x,y);
			add(y,x);
		}
		dfs(1,0);
		int fl=0;
		for (int i=1;i<=n;i++){
			if (max(f[i],n-f[i])==ans){
				printf ("%d ",i);
				fl=1;
			}
		}
		if (fl==0) printf ("None");
		printf ("\n");
	}
	return 0;
}
