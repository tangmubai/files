#include "cstdio"
int t,n,m,t1[105],t2[105];
long long ans;
int main(){
	freopen ("pairs.in","r",stdin);
	freopen ("pairs.out","w",stdout);
	scanf ("%d",&t);
	while (t--){
		ans=0;
		scanf ("%d%d",&n,&m);
		t1[1]=t1[2]=t1[3]=t1[4]=t1[0]=n/5;
		for (int i=n/5*5+1;i<=n;i++) t1[i%5]++;
		t2[1]=t2[2]=t2[3]=t2[4]=t2[0]=m/5;
		for (int i=m/5*5+1;i<=m;i++) t2[i%5]++;
		for (int i=0,j=5;i<=5&&j>=0;i++,j--){
			ans+=1ll*t1[i%5]*t2[j%5];
		}
		ans-=1ll*t1[0]*t2[0];
		printf ("%lld\n",ans);
	}
	return 0;
}
