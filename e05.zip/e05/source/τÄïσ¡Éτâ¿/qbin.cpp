#include "cstdio"
int a[100005],n,t;
int main(){
	freopen ("qbin.in","r",stdin);
	freopen ("qbin.out","w",stdout);
	scanf ("%d",&t);
	while (t--){
		scanf ("%d",&n);
		int k=n,i=0;
		while (k>0){
			a[++i]=k%10;
			k/=10;
		}
		for (int j=9;j>=1;j--){
			int f=0;
			for (int k=i;k>=1;k--){
				if (a[k]==j){
					f=1;
					a[k]--;
					printf ("1");
				}
				else if (f==1) printf ("0");
			}
			if (f==1) printf (" ");
		}
		printf ("\n");
	}
	return 0;
} 
