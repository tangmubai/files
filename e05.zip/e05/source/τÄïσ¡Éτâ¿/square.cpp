#include "cstdio"
int x,y,x1,y1,x2,y2,n,l,ans;
int main(){
	freopen ("square.in","r",stdin);
	freopen ("square.out","w",stdout);
	scanf ("%d%d%d%d",&x1,&y1,&l,&n);
	x2=x1+l;y2=y1+l;
	for (int i=1;i<=n;i++){
		scanf ("%d%d",&x,&y);
		if (x>=x1&&y>=y1&&x<=x2&&y<=y2) ans++;
	}
	printf ("%d\n",ans);
	return 0;
} 
