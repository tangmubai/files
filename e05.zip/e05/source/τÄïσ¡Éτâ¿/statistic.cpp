#include "cstdio"
#include "algorithm"
using namespace std;
int a[5000005];
int n,n1,n2;
inline int read(){
	int s=0;char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		s=s*10+c-'0';
		c=getchar();
	}
	return s;
} 
int main(){
	freopen ("statistic.in","r",stdin);
	freopen ("statistic.out","w",stdout);
	n=read();n1=read();n2=read();
	for (register int i=1;i<=n;i++) a[i]=read();
	sort (a+1,a+1+n);
	int s1=0,s2=0;
	for (int i=1;i<=n2;i++) s2+=a[i];
	for (int i=n;i>=n-n1+1;i--) s1+=a[i];
	printf ("%.3lf\n",1.0*s1/n1-1.0*s2/n2);
	return 0;
} 
