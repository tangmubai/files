#include<stdio.h>
using namespace std;
int a[10],b[10];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("pairs.in","r",stdin);freopen("pairs.out","w",stdout);
	int t=qread(),n,m;
	while(t--){
		n=qread();
		m=qread();
		a[0]=n/5;
		a[1]=a[0]+(int)(n%5>=1);
		a[2]=a[0]+(int)(n%5>=2);
		a[3]=a[0]+(int)(n%5>=3);
		a[4]=a[0]+(int)(n%5>=4);
		b[0]=m/5;
		b[1]=b[0]+(int)(m%5>=1);
		b[2]=b[0]+(int)(m%5>=2);
		b[3]=b[0]+(int)(m%5>=3);
		b[4]=b[0]+(int)(m%5>=4);
		printf("%lld\n",a[0]*(long long)b[0]+a[1]*(long long)b[4]+a[2]*(long long)b[3]+a[3]*(long long)b[2]+a[4]*(long long)b[1]);
	}
	return 0;
}
