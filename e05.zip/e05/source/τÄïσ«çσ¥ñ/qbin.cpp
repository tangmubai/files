#include<iostream>
#include<stdio.h>
using namespace std;
int f;
int zh[100000];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int make(int n){
	int a=0,w=0,b=0,c=0;
	while(n){
		++c;
		if(n%10) f=min(f,n%10);
		if(n%10==0) a=(a<<1)+(a<<3);
		else a=(a<<1)+(a<<3)+1;
		n/=10;
	}
	while(c--){
		b=(b<<1)+(b<<3)+a%10;
		if(a) a/=10;
	}
	return b;
}
int main(){
	freopen("qbin.in","r",stdin);freopen("qbin.out","w",stdout);
	int t=qread(),n,a,w;
	while(t--){
		n=qread();
		w=0;
		while(n){
			f=2147483647;
			a=make(n);
			for(int i=1;i<=f;++i){
				zh[++w]=a;
			}
			n-=f*a;
		}
		for(int i=w;i>=1;--i) printf("%d ",zh[i]);
		printf("\n");
	}
	return 0;
}
