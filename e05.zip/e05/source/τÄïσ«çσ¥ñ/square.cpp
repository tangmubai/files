#include<stdio.h>
using namespace std;
int qread(){
	int a=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a*f;
}
int main(){
	freopen("square.in","r",stdin);freopen("square.out","w",stdout);
	int x=qread(),y=qread(),l=qread(),n=qread(),ans=0,a,b,xi,yi;
	while(n--){
		a=qread();
		b=qread();
		if(a>=x&&a<=x+l&&b>=y&&b<=y+l) ++ans;
	}
	printf("%d\n",ans);
	return 0;
}
