#include<algorithm>
#include<stdio.h>
using namespace std;
int sz[3000005];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("statistic.in","r",stdin);freopen("statistic.out","w",stdout);
	int n=qread(),n1=qread(),n2=qread();long long h1=0,h2=0;
	for(int i=1;i<=n;++i) sz[i]=qread();
	sort(sz+1,sz+1+n);
	for(int i=1;i<=n1;++i) h1+=(long long)sz[n-i+1];
	for(int i=1;i<=n2;++i) h2+=(long long)sz[i];
	printf("%.3lf",h1*1.0/n1-h2*1.0/n2);
	return 0;
}
