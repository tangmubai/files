#include <cstdio>
using namespace std;
int t,n,i,a[301],ans;
int abs (int n) {return n<0?n*-1:n;}
void dfs (int i,int s1,int s2,int s) {
	int x=abs(s1-s2);
	if (x>ans) return; if (x>s) s=x;
	if (i>n) {if (s<ans) ans=s; return;}
	dfs (i+1,s1+a[i],s2,s);
	dfs (i+1,s1,s2+a[i],s);
}
int main () {
	freopen ("diff.in","r",stdin);
	freopen ("diff.out","w",stdout);
	scanf ("%d",&t);
	while (t--) {
		ans=1000000;
		scanf ("%d",&n);
		for (i=1;i<=n;i++) scanf ("%d",&a[i]);
		dfs (2,a[1],0,0);
		printf ("%d\n",ans);
	}
	return 0;
} 
