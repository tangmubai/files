#include <cstdio>
using namespace std;
long long t,n,m,i,s[5],ans;
int main () {
	freopen ("pairs.in","r",stdin);
	freopen ("pairs.out","w",stdout);
	scanf ("%lld",&t);
	while (t--) {
		scanf ("%lld%lld",&n,&m); 
		for (i=0;i<=4;i++) s[i]=(n/5);
		for (i=(n/5)*5+1;i<=n;i++) s[i%5]++;
		ans=(m/5)*s[0];
		for (i=1;i<=4;i++) ans+=(m/5)*s[5-(i%5)];
		for (i=(m/5)*5+1;i<=m;i++) ans+=(i%5==0?s[0]:s[5-(i%5)]);
		printf ("%lld\n",ans);
	}
	return 0;
} 
