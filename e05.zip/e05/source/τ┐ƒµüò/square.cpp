#include <cstdio>
using namespace std;
int x,y,l,n,xi,yi,i,ans;
int main () {
	freopen ("square.in","r",stdin);
	freopen ("square.out","w",stdout);
	scanf ("%d%d%d%d",&x,&y,&l,&n);
	for (i=1;i<=n;i++) {
		scanf ("%d%d",&xi,&yi);
		if (xi>=x&&xi<=x+l&&yi>=y&&yi<=y+l) ans++;
	}
	printf ("%d",ans);
	return 0;
} 
