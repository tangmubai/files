#include <cstdio>
#include <cstring>
using namespace std;
int n,a[3000001],n1,n2,i,j,k,x,y=100000000;
double s1,s2;
int main () {
	freopen ("statistic.in","r",stdin);
	freopen ("statistic.out","w",stdout);
	scanf ("%d%d%d",&n,&n1,&n2);
	for (i=1;i<=n;i++) scanf ("%d",&a[i]);
	for (k=1;k<=n1;k++) {
		for (i=1,x=0;i<=n;i++) 
			if (a[i]>x) x=a[i],j=i;
		a[j]=-1; s1+=x;
	}
	for (k=1;k<=n2;k++) {
		for (i=1,y=100000000;i<=n;i++)
			if (a[i]<y&&a[i]>0) y=a[i],j=i;
		a[j]=-1; s2+=y;
	}
	printf ("%.3lf",s1/n1-s2/n2);
	return 0;
} 
