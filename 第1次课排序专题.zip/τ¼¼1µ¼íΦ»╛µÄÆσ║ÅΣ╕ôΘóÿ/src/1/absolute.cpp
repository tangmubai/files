#include<iostream>
#include<algorithm>
#include <math.h>
using namespace std;

int ab[101];

bool cmp(int a,int b)
{
	return abs(a)>abs(b);
}
int main()
{
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
    int n;
   	while(cin>>n && n!=0)
    {
    	for(int i=0;i<n;i++)
    		cin>>ab[i];
    	sort(ab,ab+n,cmp);
    	for(int i=0;i<n;i++)
    	  cout<<ab[i]<<' ';
    	cout<<endl;
    }
  
    return 0;
}
