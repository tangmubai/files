#include<iostream>
#include<algorithm>
#include <math.h>
#include <string.h>
#include <string>
using namespace std;

struct ss{
	char name[101];
	int age;
	int score;
}ab[1001];

bool cmp(struct ss a,struct ss b)
{
	if(a.score!=b.score)
		return a.score<b.score;
	else
		{
		  if(strcmp(a.name,b.name)!=0)
		     return strcmp(a.name,b.name)<0;
		  else
		  	return a.age<b.age;
		}	
}


int main()
{
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
    int n;
    while(cin>>n)
    {
    	for(int i=0;i<n;i++)
    	{
    		scanf("%s %d %d",&ab[i].name,&ab[i].age,&ab[i].score);
    	}
    	sort(ab,ab+n,cmp);
       for(int s=0;s<n;s++)
         printf("%s %d %d\n",ab[s].name,ab[s].age,ab[s].score);
    }  
    return 0;
}
