#include <cstdio>
#include <algorithm>
bool cmp(int x,int y){
	return std::abs(x)>std::abs(y);
}
int n,a[103];
int main(){
	freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
	while(1){
		scanf("%d",&n);
		if(!n) break;
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		std::sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++) printf("%d ",a[i]);
		puts("");
	}
	return 0;
}
