#include <cstdio>
#include <algorithm>
struct date{
	int y,m,d,id;
}a[103];
bool cmp(date x,date y){
	if(x.y==y.y&&x.m==y.m&&x.d==y.d) return x.id<y.id;
	if(x.y==y.y&&x.m==y.m) return x.d<y.d;
	if(x.y==y.y) return x.m<y.m;
	return x.y<y.y;
}
int n;
char s[13];
int main(){
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	while(scanf("%s",s)!=EOF){
		a[++n].m=10*(s[0]-'0')+(s[1]-'0');
		a[n].d=10*(s[3]-'0')+(s[4]-'0');
		a[n].y=1000*(s[6]-'0')+100*(s[7]-'0')+10*(s[8]-'0')+(s[9]-'0');
		a[n].id=n;
	}
	std::sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++) printf("%02d/%02d/%d\n",a[i].m,a[i].d,a[i].y);
	return 0;
}
