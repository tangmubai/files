#include <cstdio>
#include <deque>
int n,a[11];
void sort1(){
	std::deque<int> q;
	q.push_back(a[1]);
	for(int i=2;i<=9;i++){
		if(a[i]<a[1]) q.push_front(a[i]);
		else q.push_back(a[i]);
	}
	while(!q.empty()){
		printf("%d ",q.front());
		q.pop_front();
	}
	puts("");
}
int main(){
	freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		for(int i=1;i<=9;i++) scanf("%d",&a[i]);
		sort1();
	}
	return 0;
}
