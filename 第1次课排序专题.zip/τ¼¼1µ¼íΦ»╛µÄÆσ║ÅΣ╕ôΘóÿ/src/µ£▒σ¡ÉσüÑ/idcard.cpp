#include <iostream>
#include <string>
#include <algorithm>
struct idcard{
	std::string date,id;
}a[100003];
bool cmp(idcard x,idcard y){
	if(x.date==y.date) return x.id>y.id;
	return x.date>y.date;
}
int main(){
	freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
	int n;std::cin>>n;
	for(int i=1;i<=n;i++){
		std::cin>>a[i].id;
		a[i].date="";
		for(int j=6;j<=13;j++) a[i].date+=a[i].id[j];
	}
	std::sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++) std::cout<<a[i].id<<'\n';
	return 0;
}
