#include <iostream>
#include <string>
#include <algorithm>
struct stu{
	std::string name;
	int age,score;
}a[1003];
bool cmp(stu x,stu y){
	if(x.score==y.score&&x.name==y.name) return x.age<y.age;
	if(x.score==y.score) return x.name<y.name;
	return x.score<y.score;
}
int main(){
	freopen("score.in","r",stdin);freopen("score.out","w",stdout);
	int n;
	while(std::cin>>n){
		for(int i=1;i<=n;i++) std::cin>>a[i].name>>a[i].age>>a[i].score;
		std::sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++) std::cout<<a[i].name<<' '<<a[i].age<<' '<<a[i].score<<'\n';
	}
	return 0;
}
