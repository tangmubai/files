#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
		ch = getchar(), flag |= (ch == '-');
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if(n < 0)
		putchar('-'), n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


inline bool cmp(int a, int b)
{
	return abs(a) > abs(b);
}


int a[110];

int main()
{
	freopen("absolute.in", "r", stdin);
	freopen("absolute.out", "w", stdout);
	
	
	int n;
	
	while(in(n), n)
	{
		for(int i=1; i<=n; i++)
			in(a[i]);
		
		
		sort(a+1, a+n+1, cmp);
		
		
		for(int i=1; i<=n; i++)
			out(a[i]), space;
		
		enter;
	}
}

