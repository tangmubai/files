#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
		ch = getchar(), flag |= (ch == '-');
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if(n < 0)
		putchar('-'), n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


struct DATE
{
	int year, month, day;
	
	bool operator<(const DATE &q) const
	{
		if(year != q.year)
			return year < q.year;
		if(month != q.month)
			return month < q.month;
		return day < q.day;
	}
} a[110];


int main()
{
	freopen("date.in", "r", stdin);
	freopen("date.out", "w", stdout);


	int len = 0;
	
	while(len++, ~scanf("%d/%d/%d", &a[len].month, &a[len].day, &a[len].year));
	len--;
	
	
	sort(a+1, a+len+1);
	
	
	for(int i=1; i<=len; i++)
		printf("%02d/%02d/%d\n", a[i].month, a[i].day, a[i].year);
}

