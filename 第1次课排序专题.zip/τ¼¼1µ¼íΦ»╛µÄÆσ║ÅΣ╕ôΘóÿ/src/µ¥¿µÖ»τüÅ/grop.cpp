#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
		ch = getchar(), flag |= (ch == '-');
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if(n < 0)
		putchar('-'), n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int a[20];

int main()
{
	freopen("grop.in", "r", stdin);
	freopen("grop.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	
	for(int ii=1; ii<=tt; ii++)
	{
		int n = 9;
		
		for(int i=1; i<=n; i++)
			in(a[i]);
		
		
		for(int i=n; i>1; i--)
			if(a[i] < a[1])
				out(a[i]), space;
		
		out(a[1]), space;
		
		for(int i=2; i<=n; i++)
			if(a[i] >= a[1])
				out(a[i]), space;
			
		enter;
	}
}

