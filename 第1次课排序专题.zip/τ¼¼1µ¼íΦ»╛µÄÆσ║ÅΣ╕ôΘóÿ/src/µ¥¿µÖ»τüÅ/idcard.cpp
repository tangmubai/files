#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
		ch = getchar(), flag |= (ch == '-');
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if(n < 0)
		putchar('-'), n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


string a[100010];

inline bool cmp(const string &a, const string &b)
{
	string suba = a.substr(6, 8), subb = b.substr(6, 8);
	
	if(suba != subb)
		return suba > subb;
	
	return a > b;
}

int main()
{
	freopen("idcard.in", "r", stdin);
	freopen("idcard.out", "w", stdout);
	
	ios::sync_with_stdio(0);
	
	
	int n;
	cin >> n;
	
	for(int i=1; i<=n; i++)
		cin >> a[i];
	
	
	sort(a+1, a+n+1, cmp);
	
	
	for(int i=1; i<=n; i++)
		cout << a[i] << '\n';
}

