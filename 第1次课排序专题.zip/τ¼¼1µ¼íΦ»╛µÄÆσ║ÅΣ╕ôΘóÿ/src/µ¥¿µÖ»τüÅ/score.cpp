#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
		ch = getchar(), flag |= (ch == '-');
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if(n < 0)
		putchar('-'), n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


struct STUDENT
{
	string name;
	int score, old;
	
	bool operator<(const STUDENT &q) const
	{
		if(score != q.score)
			return score < q.score;
		
		if(name != q.name)
			return name < q.name;
		
		return old < q.old;
	}
} a[1010];

int main()
{
	freopen("score.in", "r", stdin);
	freopen("score.out", "w", stdout);
	
	ios::sync_with_stdio(0);


	int n;
	
	while(cin >> n)
	{
		for(int i=1; i<=n; i++)
			cin >> a[i].name >> a[i].old >> a[i].score;
		
		
		sort(a+1, a+n+1);
		
		
		for(int i=1; i<=n; i++)
			cout << a[i].name << ' ' << a[i].old << ' ' << a[i].score << '\n';
	}
}

