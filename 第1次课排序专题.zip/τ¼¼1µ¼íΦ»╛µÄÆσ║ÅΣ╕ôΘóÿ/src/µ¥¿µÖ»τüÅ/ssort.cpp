#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
		ch = getchar(), flag |= (ch == '-');
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if(n < 0)
		putchar('-'), n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int a[110];

int main()
{
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	
	
	int n;
	
	while(~scanf("%d", &n))
	{
		for(int i=1; i<=n; i++)
			in(a[i]);
	
	
		sort(a+1, a+n+1);
	
	
		for(int i=1; i<=n; i++)
			out(a[i]), space;
		
		enter;
	}
}

