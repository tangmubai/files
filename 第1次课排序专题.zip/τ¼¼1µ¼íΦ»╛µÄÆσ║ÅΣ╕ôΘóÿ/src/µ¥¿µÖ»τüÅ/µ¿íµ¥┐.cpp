#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
		ch = getchar(), flag |= (ch == '-');
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if(n < 0)
		putchar('-'), n = -n;
	if(n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int main()
{
	freopen(".in", "r", stdin);
	freopen(".out", "w", stdout);
}
