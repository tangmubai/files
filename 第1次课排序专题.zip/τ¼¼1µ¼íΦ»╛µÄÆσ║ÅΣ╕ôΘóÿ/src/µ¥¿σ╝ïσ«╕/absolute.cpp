#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[105];
bool cmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(cin>>n){
		if(n==0)return 0;
		for(int i=1;i<=n;i++)cin>>a[i];
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)cout<<a[i]<<" ";
		cout<<endl;
	}
	return 0;
}
