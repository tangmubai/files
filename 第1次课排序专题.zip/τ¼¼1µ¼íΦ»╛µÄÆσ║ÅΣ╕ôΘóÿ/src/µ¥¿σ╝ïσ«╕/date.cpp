#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
struct node{
	int month,day,year;
	char ch[15];
};
node a[105];
bool cmp(node a,node b){
	if(a.year<b.year)return true;
	else if(a.year>b.year)return false;
	else{
		if(a.month<b.month)return true;
		else if(a.month>b.month)return false;
		else{
			if(a.day<=b.day)return true;
			else return false;
		}
	}
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int num=0;
	while(cin>>a[num+1].ch){
		a[num+1].month=(a[num+1].ch[0]-48)*10+a[num+1].ch[1]-48;
		a[num+1].day=(a[num+1].ch[3]-48)*10+a[num+1].ch[4]-48;
		a[num+1].year=(a[num+1].ch[6]-48)*1000+(a[num+1].ch[7]-48)*100+(a[num+1].ch[8]-48)*10+a[num+1].ch[9]-48;
		num++;
	}
	sort(a+1,a+1+num,cmp);
	for(int i=1;i<=num;i++){
		if(a[i].month<10)cout<<"0";
		cout<<a[i].month<<"/";
		if(a[i].day<10)cout<<"0";
		cout<<a[i].day<<"/"<<a[i].year<<endl;
	}
	return 0;
}
