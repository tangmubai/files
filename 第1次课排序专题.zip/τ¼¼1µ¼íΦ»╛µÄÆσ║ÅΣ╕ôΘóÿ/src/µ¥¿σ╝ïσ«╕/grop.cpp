#include<iostream>
#include<cstdio>
using namespace std;
int n,a[10];
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	cin>>n;
	while(n--){
		for(int i=1;i<=9;i++)cin>>a[i];
		int k1=a[1];
		for(int i=9;i>=2;i--)if(a[i]<k1)cout<<a[i]<<" ";
		cout<<k1<<" ";
		for(int i=2;i<=9;i++)if(a[i]>=k1)cout<<a[i]<<" ";
		cout<<endl;
	}
	return 0;
}
