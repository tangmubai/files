#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n;
struct node{
	int year,month,day;
	char ch[20];
};
bool cmp(node a,node b){
	if(a.year>b.year)return true;
	if(a.year<b.year)return false;
	if(a.year==b.year){
		if(a.month>b.month)return true;
		if(a.month<b.month)return false;
		if(a.month==b.month){
			if(a.day>=b.day)return true;
			else return false;
		}
	}
}
node a[100005];
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i].ch;
		a[i].year=(a[i].ch[6]-48)*1000+(a[i].ch[7]-48)*100+(a[i].ch[8]-48)*10+a[i].ch[9]-48;
		a[i].month=(a[i].ch[10]-48)*10+a[i].ch[11]-48;
		a[i].day=(a[i].ch[12]-48)*10+a[i].ch[13]-48;
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++)cout<<a[i].ch<<endl;
	return 0;
}
