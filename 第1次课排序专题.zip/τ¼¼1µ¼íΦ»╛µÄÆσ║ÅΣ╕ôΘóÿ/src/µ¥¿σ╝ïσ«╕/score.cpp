#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n;
struct node{
	string ch;
	int a,b;
};
node a[1005];
bool cmp(node a,node b){
	if(a.b<b.b)return true;
	if(a.b>b.b)return false;
	if(a.b==b.b){
		if(a.ch<b.ch)return true;
		if(a.ch>b.ch)return false;
		if(a.ch==b.ch){
			if(a.a<=b.a)return true;
			else return false;
		}
	}
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(cin>>n){
		for(int i=1;i<=n;i++)cin>>a[i].ch>>a[i].a>>a[i].b;
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)cout<<a[i].ch<<" "<<a[i].a<<" "<<a[i].b<<endl;
	}
	return 0;
}
