#include<iostream>
#include<stdio.h>
#include<algorithm>
#define ll long long
using namespace std;
ll n,x;
struct node{
	ll p,q;
}a[1000005];
bool cmp(node x,node y){
	return x.q>y.q;
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	scanf("%lld",&x);
	n=x;
	while(x!=0){
		for(ll i=1;i<=n;i++){
			scanf("%lld",&a[i].p);
			a[i].q=abs(a[i].p);
		}
		sort(a+1,a+n+1,cmp);
		for(ll i=1;i<n;i++)printf("%lld ",a[i].p);
		printf("%lld\n",a[n].p);
		scanf("%lld",&x);n=x;		
	}

	return 0;
}
