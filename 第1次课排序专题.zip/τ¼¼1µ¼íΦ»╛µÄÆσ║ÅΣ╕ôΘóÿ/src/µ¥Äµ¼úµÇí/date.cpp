#include<iostream>
#include<stdio.h>
#include<algorithm>
#define ll long long
using namespace std;
struct Node{
	int x,y,z;
}a[105];
bool cmp(Node p,Node q){
	if(p.z!=q.z)return p.z<q.z;
	if(p.x!=q.x)return p.x<q.x;
	return p.y<q.y;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	char s[10];ll n=1;
	while(scanf("%d/%d/%d",&a[n].x,&a[n].y,&a[n].z)!=EOF)n++;
	n--;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)printf("%02d/%02d/%04d\n",a[i].x,a[i].y,a[i].z);
	return 0;
}

