#include<iostream>
#include<stdio.h>
#include<algorithm>
#define ll long long
using namespace std;
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	ll n,ans,l,r;
	ll a[20],b[20];
	scanf("%lld",&n);
	while(n--){
		for(ll i=1;i<=9;i++)scanf("%lld",&a[i]);
		ans=a[1];b[10]=ans;l=10,r=10;
		for(ll i=2;i<=9;i++){
			if(a[i]<ans)b[--l]=a[i];
			else b[++r]=a[i];
		}
		for(ll i=l;i<r;i++)printf("%lld ",b[i]);
		printf("%lld\n",b[r]);
	}
	return 0;
}

