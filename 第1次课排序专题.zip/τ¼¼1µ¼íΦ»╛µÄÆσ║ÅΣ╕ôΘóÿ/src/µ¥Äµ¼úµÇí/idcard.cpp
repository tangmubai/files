#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<cstring>
#define ll long long
using namespace std;
struct Node{
	string s;
	ll x;
}a[100005];
bool cmp(Node p,Node q){
	if(p.x!=q.x)return p.x>q.x;
	return p.s>q.s;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	ll n;
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++){
		cin>>a[i].s;
		for(ll j=6;j<=13;j++)a[i].x=a[i].x*10+(a[i].s[j]-'0');
	}
	sort(a+1,a+n+1,cmp);
	for(ll i=1;i<=n;i++)cout<<a[i].s<<endl;
	return 0;
}

