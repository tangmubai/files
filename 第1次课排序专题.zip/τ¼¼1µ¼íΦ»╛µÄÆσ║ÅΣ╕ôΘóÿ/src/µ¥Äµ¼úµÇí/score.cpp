#include<iostream>
#include<stdio.h>
#include<algorithm>
#define ll long long
using namespace std;
struct Node{
	string s;
	ll age,point;
}a[1005];
bool cmp(Node x,Node y){
	if(x.point!=y.point)return x.point<y.point;
	if(x.s!=y.s)return x.s<y.s;
	return x.age<y.age;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	ll n;
	while(scanf("%lld",&n)!=EOF){
		for(ll i=1;i<=n;i++){
			cin>>a[i].s;
			scanf("%lld%lld",&a[i].age,&a[i].point);	
		}
		sort(a+1,a+n+1,cmp);
		for(ll i=1;i<=n;i++){
			cout<<a[i].s<<' ';
			printf("%lld %lld\n",a[i].age,a[i].point);
		}		
	}
	return 0;
}

