#include<iostream>
#include<stdio.h>
#include<algorithm>
#define ll long long
using namespace std;
ll n;
ll a[1000005];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while((scanf("%lld",&n))!=EOF){
	for(ll i=1;i<=n;i++)scanf("%lld",&a[i]);
	sort(a+1,a+n+1);
	for(ll i=1;i<n;i++)printf("%lld ",a[i]);
	printf("%lld\n",a[n]);	
	}
	return 0;
}
