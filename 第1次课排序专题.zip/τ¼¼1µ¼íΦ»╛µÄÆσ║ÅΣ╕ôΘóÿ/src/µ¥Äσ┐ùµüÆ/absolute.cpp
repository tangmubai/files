#include<stdio.h>
#include<math.h>
#include<algorithm>
using namespace std;
bool cmp(int a,int b){
	return abs(a)>abs(b);
}
int a[150];
void work(int n){
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		printf("%d ",a[i]);
	}
	printf("\n");
	return;
}

int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(1){
		int n;
		scanf("%d",&n);
		if(!n){
			return 0;
		}
		work(n);
	}
}
