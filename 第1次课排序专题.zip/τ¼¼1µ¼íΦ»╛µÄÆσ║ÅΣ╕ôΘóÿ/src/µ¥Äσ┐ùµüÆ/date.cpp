#include<stdio.h>
#include<algorithm>
using namespace std;
struct Node{
	int date,month,year;
}a[150];
bool cmp(Node a,Node b){
	if(a.year!=b.year){
		return a.year<b.year;
	}else{
		if(a.month!=b.month){
			return a.month<b.month;
		}
		return a.date<b.date;
	}
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int n=1;
	while((scanf("%d/%d/%d",&a[n].month,&a[n].date,&a[n].year))!=EOF)n++;
	n--;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		printf("%02d/%02d/%04d\n",a[i].month,a[i].date,a[i].year);
	}
}
