#include<stdio.h>
#include<algorithm>
using namespace std;
int a[150];
void work(){
	for(int i=1;i<10;i++){
		scanf("%d",&a[i]);
	}
	for(int i=9;i>=2;i--){
		if(a[i]<a[1]){
			printf("%d ",a[i]);
		}
	}
	printf("%d ",a[1]);
	for(int i=2;i<=9;i++){
		if(a[i]>=a[1]){
			printf("%d ",a[i]);
		}
	}
	printf("\n");
}
int main(){
	int t;
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		work();
	}
}
