#include<stdio.h>
#include<algorithm>
using namespace std;
long long a[150];
bool cmp(long long a,long long b){
	if((a/10000)%100000000==(b/10000)%100000000){
		return a>b;
	}
	return (a/10000)%100000000>(b/10000)%100000000;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		printf("%lld\n",a[i]);
	}
	return 0;
}
