#include<stdio.h>
#include<algorithm>
#include<cstring>
using namespace std;
struct Node{
	char name[150];
	int age,score;
}a[150];
bool cmp(Node a,Node b){
	if(a.score!=b.score){
		return a.score<b.score;
	}else{
		if(strcmp(a.name,b.name)!=0){
			return strcmp(a.name,b.name)<0;
		}
		return a.age<b.age;
	}
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	int n;
	while((scanf("%d",&n))!=EOF){
		for(int i=1;i<=n;i++){
			scanf("%s%d%d",&a[i].name,&a[i].age,&a[i].score);
		}
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++){
			printf("%s %d %d\n",a[i].name,a[i].age,a[i].score);
		}
	}
}
