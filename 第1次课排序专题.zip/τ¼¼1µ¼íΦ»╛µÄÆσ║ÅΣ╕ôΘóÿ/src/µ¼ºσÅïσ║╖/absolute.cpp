#include <cstdio>
#include <algorithm>
using namespace std;
struct Node {
	int a;
}a[1010];
int abs (int n) {
	return n > 0 ? n : -n;
}
bool operator < (const Node &a,const Node &b) {
	return abs (a.a)>abs (b.a);
}
int n,i;
int main () {
	freopen ("absolute.in","r",stdin);
	freopen ("absolute.out","w",stdout);
	while (1) {
		scanf ("%d",&n);
		if (n==0) 
			return 0;
		for (i=1;i<=n;i++)
			scanf ("%d",&a[i].a);
		sort (a+1,a+1+n);
		for (i=1;i<=n;i++)
			printf ("%d ",a[i].a);
		puts ("");
	}
	return 0;
}
