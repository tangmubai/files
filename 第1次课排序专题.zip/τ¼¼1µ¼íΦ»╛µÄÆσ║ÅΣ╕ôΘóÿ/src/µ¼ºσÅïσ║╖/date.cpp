#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
struct Node {
	int m;
	int d;
	int y;
}a[1010];
bool operator < (const Node &a,const Node &b) {
	if (a.y!=b.y)
		return a.y<b.y;
	if (a.m!=b.m)
		return a.m<b.m;
	if (a.d!=b.d)
		return a.d<b.d;
}
int n,i,len;
char s[110];
int main () {
	freopen ("date.in","r",stdin);
	freopen ("date.out","w",stdout);
	while (cin>>s+1) {
		a[++n].m=(s[1]-'0')*10+(s[2]-'0');
		a[n].d=(s[4]-'0')*10+(s[5]-'0');
		a[n].y=(s[7]-'0')*1000+(s[8]-'0')*100+(s[9]-'0')*10+(s[10]-'0');
	}
	sort (a+1,a+1+n);
	for (i=1;i<=n;i++) {
		if (a[i].m<10) 
			printf ("0");
		printf ("%d/",a[i].m);
		if (a[i].d<10) 
			printf ("0");
		printf ("%d/",a[i].d);
		if (a[i].y<1000) {
			printf ("0");
			if (a[i].y<100)
				printf ("0");
			if (a[i].y<10)
				printf ("0");
		}
		printf ("%d\n",a[i].y); 
	}
	return 0;
}
