#include <cstdio>
int n,i,a[20],j,b;
int main () {
	freopen ("grop.in","r",stdin);
	freopen ("grop.out","w",stdout);
	scanf ("%d",&n);
	while (n--) {
		for (i=1;i<=9;i++) 
			scanf ("%d",&a[i]);
		for (i=9;i>=2;i--) 
			if (a[i]<a[1]) {
				printf ("%d ",a[i]);
				a[i]=0x7fffffff-1;
			}
		printf ("%d ",a[1]);
		a[1]=0x7fffffff-1;
		for (i=1;i<=9;i++)
			if (a[i]!=0x7fffffff-1)
				printf ("%d ",a[i]);
		puts ("");
	}
	return 0;
}
