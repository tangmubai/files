#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
struct Node {
	int n;
	int y;
	int r;
	string s;
}a[1000010];
bool operator < (const Node &a,const Node &b) {
	if (a.n!=b.n) 
		return a.n>b.n;
	if (a.y!=b.y) 
		return a.y>b.y;
	if (a.r!=b.r) 
		return a.r>b.r;
	return a.s>b.s;
}
int n,i;
int main () {
	freopen ("idcard.in","r",stdin);
	freopen ("idcard.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) {
		cin>>a[i].s;
		a[i].n=(a[i].s[6]-'0')*1000+(a[i].s[7]-'0')*100+(a[i].s[8]-'0')*10+(a[i].s[9]-'0');
		a[i].y=(a[i].s[10]-'0')*10+(a[i].s[11]-'0');
		a[i].r=(a[i].s[12]-'0')*10+(a[i].s[13]-'0');
	}
	sort (a+1,a+1+n);
	for (i=1;i<=n;i++)
		cout<<a[i].s<<endl;
	return 0;
}
