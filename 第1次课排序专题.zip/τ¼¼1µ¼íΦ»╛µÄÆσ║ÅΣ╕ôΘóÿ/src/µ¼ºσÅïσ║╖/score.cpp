#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
struct Node {
	int a;
	int o;
	string s; 
}a[10010];
bool operator < (const Node &a,const Node &b) {
	if (a.a!=b.a) 
		return a.a<b.a;
	if (a.s!=b.s)
		return a.s<b.s;
	return a.o<b.o;
}
int n,i;
int main () {
	freopen ("score.in","r",stdin);
	freopen ("score.out","w",stdout);
	while (~scanf ("%d",&n)) {
		for (i=1;i<=n;i++) 
			cin>>a[i].s>>a[i].o>>a[i].a;
		sort (a+1,a+1+n);
		for (i=1;i<=n;i++) {
			cout<<a[i].s<<' ';
			printf ("%d %d\n",a[i].o,a[i].a);
		}
	}
	return 0;
} 
