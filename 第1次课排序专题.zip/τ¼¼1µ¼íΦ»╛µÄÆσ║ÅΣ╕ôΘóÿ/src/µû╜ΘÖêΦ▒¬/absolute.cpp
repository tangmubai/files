#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int a[1005],n;
bool cmp(int x,int y){
	return abs(x)>abs(y);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(1){
		scanf("%d",&n);
		if(n==0)return 0;
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}

