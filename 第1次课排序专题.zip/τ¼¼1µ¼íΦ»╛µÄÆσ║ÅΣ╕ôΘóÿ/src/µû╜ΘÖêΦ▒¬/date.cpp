#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
struct stu{
	char k[105];
	int a,b,c;
}s[105];
int top=1;
bool cmp(stu x,stu y){
	if(x.c!=y.c)return x.c<y.c;
	if(x.a!=y.a)return x.a<y.a;
	return x.b<y.b;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	while(scanf("%s",s[top].k+1)!=EOF){
		s[top].a=(s[top].k[1]-'0')*10+(s[top].k[2]-'0');
		s[top].b=(s[top].k[4]-'0')*10+(s[top].k[5]-'0');
		s[top].c=(s[top].k[7]-'0')*1000+(s[top].k[8]-'0')*100+(s[top].k[9]-'0')*10+(s[top].k[10]-'0');
		top++;
	}
	top--;
	sort(s+1,s+1+top,cmp);
	for(int i=1;i<=top;i++){
		printf("%s\n",s[i].k+1);
	}
	return 0;
}

