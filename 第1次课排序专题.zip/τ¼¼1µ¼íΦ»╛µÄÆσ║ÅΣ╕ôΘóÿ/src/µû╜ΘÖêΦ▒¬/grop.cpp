#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int a[1005];
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int n;
	scanf("%d",&n);
	while(n--){
		for(int i=1;i<=9;i++)scanf("%d",&a[i]);
		for(int i=9;i>=2;i--){
			if(a[i]<a[1])printf("%d ",a[i]);
		}
		printf("%d ",a[1]);
		for(int i=2;i<=9;i++){
			if(a[i]>=a[1])printf("%d ",a[i]);
		}printf("\n");
	}
	return 0;
}

