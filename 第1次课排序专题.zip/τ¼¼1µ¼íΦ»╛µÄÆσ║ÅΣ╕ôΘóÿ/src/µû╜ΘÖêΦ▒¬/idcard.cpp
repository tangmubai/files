#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;
int n;
struct stu{
	string k;
	int a,b,c;
}s[100005];
bool cmp(stu x,stu y){
	if(x.a!=y.a)return x.a>y.a;
	if(x.b!=y.b)return x.b>y.b;
	if(x.c!=y.c)return x.c>y.c;
	return x.k>y.k;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>s[i].k;
		s[i].a=(s[i].k[6]-'0')*1000+(s[i].k[7]-'0')*100+(s[i].k[8]-'0')*10+(s[i].k[9]-'0');
		s[i].b=(s[i].k[10]-'0')*10+(s[i].k[11]-'0');
		s[i].c=(s[i].k[12]-'0')*10+(s[i].k[13]-'0');
	}
	sort(s+1,s+1+n,cmp);
	for(int i=1;i<=n;i++){
		cout<<s[i].k<<endl;
	}
	return 0;
}

