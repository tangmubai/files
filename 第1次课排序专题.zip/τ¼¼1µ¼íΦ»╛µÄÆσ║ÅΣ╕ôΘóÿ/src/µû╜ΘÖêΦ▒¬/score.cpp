#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;
struct stu{
	string name;
	int year,score;
}s[5005];
bool cmp(stu x,stu y){
	if(x.score!=y.score)return x.score<y.score;
	if(x.name!=y.name)return x.name<y.name;
	return x.year<y.year;
}
int n;
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(cin>>n){
		for(int i=1;i<=n;i++){
			cin>>s[i].name;
			scanf("%d%d",&s[i].year,&s[i].score);
		}
		sort(s+1,s+1+n,cmp);
		for(int i=1;i<=n;i++){
			cout<<s[i].name;
			printf(" %d %d\n",s[i].year,s[i].score);
		}
	}
	return 0;
}

