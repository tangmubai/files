#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;
long long a[110];
long long abss(long long x){
	if(x<0)return -x;
	return x;
}
bool cmp(long long p,long long q){
	return abss(p)>abss(q);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int n;
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		for(int i=1;i<=n;i++)
			scanf("%lld",&a[i]);
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<n;i++)
			cout<<a[i]<<' ';
		cout<<a[n]<<endl;
	}
	return 0;
}

