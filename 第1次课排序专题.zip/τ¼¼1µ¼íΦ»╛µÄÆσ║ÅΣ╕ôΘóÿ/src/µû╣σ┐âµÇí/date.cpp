#include <cstdio>
#include <algorithm>
using namespace std;
struct Node{
	int m,d,y;
	char s[20];
}a[110];
bool cmp(Node p,Node q){
	if(p.y!=q.y)return p.y<q.y;
	if(p.m!=q.m)return p.m<q.m;
	return p.d<q.d;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int n=1;
	while(scanf("%s",a[n].s)!=EOF){
		a[n].m=(a[n].s[0]-'0')*10+a[n].s[1]-'0';
		a[n].d=(a[n].s[3]-'0')*10+a[n].s[4]-'0';
		a[n].y=(a[n].s[6]-'0')*1000+(a[n].s[7]-'0')*100+(a[n].s[8]-'0')*10+a[n].s[9]-'0';
		n++;
	}
	n--;
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++)
		printf("%s\n",a[i].s);
	return 0;
}
