#include <cstdio>
int a[20],b[20];
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int n;scanf("%d",&n);
	while(n--){
		for(int i=1;i<=9;i++)
			scanf("%d",&a[i]);
		int l=1,r=9;
		for(int i=9;i>=2;i--)
			if(a[i]<a[1]){
				b[l]=a[i];
				l++;
			}
			else{
				b[r]=a[i];
				r--;
			}
		b[l]=a[1];
		for(int i=1;i<9;i++)
			printf("%d ",b[i]);
		printf("%d\n",b[9]);
	}
	return 0;
}

