#include <cstdio>
#include <algorithm>
using namespace std;
struct Node{
	int b[20];
}a[100010];
char s[20];
bool cmp(Node p,Node q){
	int tmp=-1;
	for(int i=7;i<=14;i++)
		if(p.b[i]>q.b[i]){
			tmp=1;break;
		}
		else if(p.b[i]<q.b[i]){
			tmp=0;break;
		}
	if(tmp!=-1)return tmp;
	for(int i=1;i<=18;i++)
		if(p.b[i]>q.b[i]){
			tmp=1;break;
		}
		else if(p.b[i]<q.b[i]){
			tmp=0;break;
		}
	if(tmp!=-1)return tmp;
	return 0;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++){
		getchar();
		scanf("%s",s+1);
		for(int j=1;j<=18;j++)
			a[i].b[j]=s[j]-'0';
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=18;j++)
			printf("%d",a[i].b[j]);
		printf("\n");
	}
	return 0;
}

