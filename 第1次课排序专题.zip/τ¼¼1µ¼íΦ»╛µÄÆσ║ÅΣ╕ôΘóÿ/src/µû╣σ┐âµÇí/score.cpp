#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
struct Node{
	char name[110];
	int age,num;
}a[10010];
bool cmp(Node p,Node q){
	if(p.num!=q.num)return p.num<q.num;
	if(strcmp(p.name,q.name)!=0)return strcmp(p.name,q.name)<0;
	return p.age<q.age;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	int n;
	while((scanf("%d",&n))!=EOF){
		for(int i=1;i<=n;i++){
			scanf("\n%s %d %d",&a[i].name,&a[i].age,&a[i].num);
		}
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++){
			printf("%s %d %d \n",a[i].name,a[i].age,a[i].num);
		}
	}
	return 0;
}
