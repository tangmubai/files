#include <cstdio>
#include <algorithm>
using namespace std;

struct Node{
	int day,month,year;
}a[105];

bool operator<(const Node &a,const Node &b){
	if(a.year!=b.year){
		return a.year<b.year;
	}
	if(a.month!=b.month){
		return a.month<b.month;
	}
	return a.day<b.day;
}

int n;

void out(int x){
	if(x/10==0){
		printf("0%d/",x);
	}else {
		printf("%d/",x);
	}
	return;
}

int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	for(int i=1;;++i){
		if(scanf("%d",&a[i].month)==EOF){
			sort(a+1,a+i);
			for(int j=1;j<i;++j){
				out(a[j].month);
				out(a[j].day);
				printf("%d\n",a[j].year);
			}
			return 0;
		}else {
			scanf("/%d/%d",&a[i].day,&a[i].year);
		}
	}
	return 0;
}
