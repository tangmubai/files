#include <cstdio>
#include <algorithm>
using namespace std;

int test_num,n=9;
int a[15];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	test_num=read();
	while(test_num--){
		for(int i=1;i<=n;++i){
			a[i]=read();
		}
		for(int i=n;i>1;--i){
			if(a[i]<a[1]){
				printf("%d ",a[i]);
			}
		}
		for(int i=1;i<=n;++i){
			if(a[i]>=a[1]){
				printf("%d ",a[i]);
			}
		}
		puts("");
	}
	return 0;
}
