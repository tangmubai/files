#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;

int n;
string a[100005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

bool Cmp(string a,string b){
	if(a.substr(6,8)==b.substr(6,8)){
		return a>b;
	}else {
		return a.substr(6,8)>b.substr(6,8);
	}
}

int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i){
		cin >> a[i];
	}
	sort(a+1,a+n+1,Cmp);
	for(int i=1;i<=n;++i){
		cout << a[i] << endl;
	}
	return 0;
}
