#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;

struct Node{
	string name;
	int age,mark;
}a[1005];

int n;

bool operator<(const Node &a,const Node &b){
	if(a.mark!=b.mark){
		return a.mark<b.mark;
	}
	if(a.name!=b.name){
		return a.name<b.name;
	}
	return a.age<b.age;
}

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;++i){
			cin >> a[i].name;
			a[i].age=read();
			a[i].mark=read();
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=n;++i){
			cout << a[i].name;
			printf(" %d %d\n",a[i].age,a[i].mark);
		}
	}
	return 0;
}
