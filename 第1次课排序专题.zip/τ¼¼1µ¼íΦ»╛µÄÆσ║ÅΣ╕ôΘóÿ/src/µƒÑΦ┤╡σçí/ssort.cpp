#include <cstdio>
#include <algorithm>
using namespace std;

int n;
int a[105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;++i){
			a[i]=read();
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=n;++i){
			printf("%d ",a[i]);
		}
		printf("\n");
	}
	return 0;
}
