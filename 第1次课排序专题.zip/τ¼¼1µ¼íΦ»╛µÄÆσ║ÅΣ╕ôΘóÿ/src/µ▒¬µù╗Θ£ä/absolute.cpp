#include<stdio.h>
#include<algorithm>
using namespace std;
int A(){
	char c=getchar();
	int a=0,k=1;
	while(c<'0'||c>'9'){
		(c=='-')?k=-1:0;
		c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int n;
int a[105];
bool cmp(int x,int y){
	return abs(x)>abs(y);
}
int main(){
	freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
	while(n=A()){
		for(register int i=1;i<=n;++i)a[i]=A();
		sort(a+1,a+1+n,cmp);
		for(register int i=1;i<=n;++i)printf("%d ",a[i]);
		printf("\n");
	}
}
