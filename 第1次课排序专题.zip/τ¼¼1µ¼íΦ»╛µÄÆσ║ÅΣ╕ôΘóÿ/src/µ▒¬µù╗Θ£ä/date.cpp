#include<stdio.h>
#include<algorithm>
using namespace std;
struct stu{
	int a,b,c;
	bool friend operator <(stu x,stu y){
		if(x.c!=y.c)return x.c<y.c;
		if(x.a!=y.a)return x.a<y.a;
		return x.b<y.b;
	}
}s[105],x,y;
int i=1;
int main(){
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	while(scanf("%d/%d/%d",&s[i].a,&s[i].b,&s[i].c)!=EOF)++i;
	sort(s+1,s+i);
	for(register int j=1;j<i;++j)printf("%02d/%02d/%d\n",s[j].a,s[j].b,s[j].c);
}
