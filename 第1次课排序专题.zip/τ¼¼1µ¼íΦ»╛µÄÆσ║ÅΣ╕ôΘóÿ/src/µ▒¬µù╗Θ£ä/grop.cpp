#include<stdio.h>
#include<algorithm>
using namespace std;
int A(){
	char c=getchar();
	int a=0,k=1;
	while(c<'0'||c>'9'){
		(c=='-')?k=-1:0;
		c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int n,g;
int a[13];
int main(){
	freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
	n=A();
	while(n--){
		for(register int i=1;i<=9;++i)a[i]=A();
		for(register int i=9;i>=1;--i)(a[i]<a[1])?printf("%d ",a[i]),a[i]=0:0;
		for(register int i=1;i<=9;++i)(a[i])?printf("%d ",a[i]):0;
		printf("\n");
	}
}
