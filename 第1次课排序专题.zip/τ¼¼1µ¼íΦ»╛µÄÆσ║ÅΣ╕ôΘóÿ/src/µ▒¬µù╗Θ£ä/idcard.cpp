#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
int n,g;
struct stu{
	char c[25];
	int a;
	bool friend operator <(stu x,stu y){
		if(x.a!=y.a)return x.a>y.a;
		return strcmp(x.c+1,y.c+1)>0;
	}
}a[100005];
int main(){
	freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;++i){
		scanf("%s",a[i].c+1);g=0;
		for(register int j=7;j<=14;++j)g=(g<<1)+(g<<3)+a[i].c[j]-'0';
		a[i].a=g;
	}
	sort(a+1,a+1+n);
	for(register int i=1;i<=n;++i)printf("%s\n",a[i].c+1);
}
