#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
int n,g;
struct stu{
	char c[105];
	int a,b;
	bool friend operator <(stu x,stu y){
		if(x.a!=y.a)return x.a<y.a;
		if(strcmp(x.c+1,y.c+1))return strcmp(x.c+1,y.c+1)<0;
		return x.b<y.b;
	}
}a[1005];
int main(){
	freopen("score.in","r",stdin);freopen("score.out","w",stdout);
	while(~scanf("%d",&n)){
		for(register int i=1;i<=n;++i)
		scanf("%s%d%d",a[i].c+1,&a[i].b,&a[i].a);
		sort(a+1,a+1+n);
		for(register int i=1;i<=n;++i)printf("%s %d %d\n",a[i].c+1,a[i].b,a[i].a);
	}
}
