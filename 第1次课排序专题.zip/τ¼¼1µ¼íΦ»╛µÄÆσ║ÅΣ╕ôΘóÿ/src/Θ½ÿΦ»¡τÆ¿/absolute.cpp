#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
int n,a[150];
bool cmp(int x,int y){
	return abs(x)>abs(y);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
	    for(int i=0;i<n;i++)
	        scanf("%d",&a[i]);
	    sort(a,a+n,cmp);
	    for(int i=0;i<n;i++)
	        printf("%d ",a[i]);
	    puts("");
	}
}
