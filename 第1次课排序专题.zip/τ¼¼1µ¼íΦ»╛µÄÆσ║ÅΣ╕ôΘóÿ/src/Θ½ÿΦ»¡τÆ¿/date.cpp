#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
int n,i;
struct node{
	int y,m,d;
}a[150];
bool cmp(node a,node b){
	if(a.y==b.y)
		if(a.m==b.m)
			return a.d<b.d;
		else
		    return a.m<b.m;
	else
	    return a.y<b.y;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	while(scanf("%d/%d/%d",&a[i].m,&a[i].d,&a[i].y)!=EOF)
	    i++;
	sort(a,a+i,cmp);
	for(int j=0;j<i;j++)
	    printf("%02d/%02d/%d\n",a[j].m,a[j].d,a[j].y);
    puts("");
}
