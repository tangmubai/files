#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
int n,a[20],x;
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
    scanf("%d",&n);
    for(int k=0;k<n;k++){
	    for(int i=0;i<9;i++)
            scanf("%d",&a[i]);
        for(int i=8;i>0;i--)
         	 if(a[i]<a[0]){
         	    printf("%d ",a[i]);
         	    a[i]=-1;
           	 }
	    for(int i=0;i<9;i++)
	        if(a[i]!=-1)
	            printf("%d ",a[i]);
	    puts("");
	}
}
