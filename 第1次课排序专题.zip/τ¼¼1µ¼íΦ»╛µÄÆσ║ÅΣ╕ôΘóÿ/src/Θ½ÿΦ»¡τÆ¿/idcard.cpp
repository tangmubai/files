#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
int n;
struct node{
	char n[30];
	int d;
}a[100010];
bool cm(char *a,char *b){
	int i=0;
	if(strlen(a)!=strlen(b))
	    return strlen(a)<strlen(b);
	else{
		int n=strlen(a);
	    for(int i=0;i<n;i++)
	        if(a[i]==b[i])
	            continue;
	        else
	            return a[i]<b[i];
	}
	return 1;
}
bool cmp(node x,node y){
	if(x.d==y.d)
	    return cm(x.n,y.n);
	return x.d<y.d;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
    scanf("%d",&n);
	for(int i=0;i<n;i++){
	    scanf("%s",a[i].n);
	    int x=a[i].n[12]-'0',y=a[i].n[13]-'0';
	    a[i].d=x*10+y;
	}
	sort(a,a+n,cmp);
	for(int i=0;i<n;i++)
	    printf("%s\n",a[i].n);
}
