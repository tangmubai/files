#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
int n;
struct node{
	string name;
	int age,score;
}a[1010];
bool cmp(node x,node y){
	if(x.score==y.score)
	    if(x.name==y.name)
	        return x.age<y.age;
	    else
	        return x.name<y.name;
	return x.score<y.score;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
	    for(int i=0;i<n;i++)
	        cin>>a[i].name>>a[i].age>>a[i].score;
	    sort(a,a+n,cmp);
	    for(int i=0;i<n;i++)
	        cout<<a[i].name<<' '<<a[i].age<<' '<<a[i].score<<endl;
	}
}
