#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
int n,a[150];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
	    for(int i=0;i<n;i++)
	        scanf("%d",&a[i]);
	    sort(a,a+n);
	    for(int i=0;i<n;i++)
	        printf("%d ",a[i]);
	    puts("");
	}
}
