#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
int n;
struct sj{
	int n1,n2;
}a[105];
bool cmp(sj p,sj q){
	return p.n2>q.n2;
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(cin>>n){
		if(!n)return 0;
		for(int i=1;i<=n;i++){
			cin>>a[i].n1;
			a[i].n2=abs(a[i].n1);	
		}
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)
		cout<<a[i].n1<<' ';
		cout<<endl;
	}
}
