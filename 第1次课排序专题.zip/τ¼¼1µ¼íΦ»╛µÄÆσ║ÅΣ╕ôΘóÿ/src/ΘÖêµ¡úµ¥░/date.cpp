#include <iostream>
#include <algorithm>
#include <string>
#include <cstdio>
#include <cstring>
using namespace std;
struct sj{
	int nf,yf,rf;
}a[105];
bool cmp(sj p,sj q){
	if(p.nf!=q.nf)return p.nf<q.nf;
	else
	if(p.yf!=q.yf)return p.yf<q.yf;
	else
	return p.rf<q.rf; 
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int n=1;
	char ch;
	while(cin>>a[n].yf){
	cin>>ch>>a[n].rf>>ch>>a[n].nf;
		n++;
	}
	n--;
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++){
		if(a[i].yf<10)cout<<0;
		cout<<a[i].yf<<'/';
		if(a[i].rf<10)cout<<0;
		cout<<a[i].rf<<'/';
		cout<<a[i].nf<<endl;
	}
}
