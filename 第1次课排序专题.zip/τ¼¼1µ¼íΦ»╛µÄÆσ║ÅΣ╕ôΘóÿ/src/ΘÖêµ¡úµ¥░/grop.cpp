#include <iostream>
using namespace std;
int n;
int a[10];
int b[10],c[10],bt,ct;
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	cin>>n;
	while(n--){
		for(int i=1;i<=9;i++)
		cin>>a[i];
		bt=0;ct=0;
		for(int i=2;i<=9;i++){
			if(a[i]<a[1])b[++bt]=a[i];
			else c[++ct]=a[i];
		}
		for(int i=bt;i>=1;i--)
		cout<<b[i]<<' ';
		cout<<a[1]<<' ';
		for(int i=1;i<=ct;i++)
		cout<<c[i]<<' ';cout<<endl;
	}
}
