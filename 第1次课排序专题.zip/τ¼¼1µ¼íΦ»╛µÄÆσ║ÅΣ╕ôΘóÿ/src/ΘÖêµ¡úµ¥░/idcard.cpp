#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
struct sj{
	char num[20];
	char bir[10];
}a[100005];
bool cmp(sj p,sj q){
	if(!strcmp(p.bir,q.bir))return strcmp(p.num,q.num)>0;
	else return strcmp(p.bir,q.bir)>0;
}
int n;
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i].num;
		strncpy(a[i].bir,&a[i].num[6],8);
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++)
	cout<<a[i].num<<endl;
}
