#include <iostream>
#include <algorithm>
using namespace std;
int n;
struct sj{
	string c;
	int age,sco;
}a[1005];
bool cmp(sj p,sj q){
	if(p.sco==q.sco&&p.c==q.c)return p.age<q.age;
	else
	if(p.sco==q.sco)return p.c<q.c;
	else
	return p.sco<q.sco;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(cin>>n){
		for(int i=1;i<=n;i++)
		cin>>a[i].c>>a[i].age>>a[i].sco;
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)
		cout<<a[i].c<<' '<<a[i].age<<' '<<a[i].sco<<endl;
	}
}
