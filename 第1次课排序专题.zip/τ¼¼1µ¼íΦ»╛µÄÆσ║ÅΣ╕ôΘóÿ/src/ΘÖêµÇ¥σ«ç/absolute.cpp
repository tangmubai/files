#include<stdio.h>
#include<algorithm>
#include<cmath>

using namespace std;


int a[105];

bool cmp (int x ,int y )
{
	int  x1 =abs(x),y1 = abs(y);
	
//	printf("%d %d\n",x1,y1);

	if(x1 > y1)return 1;
	
	else  return  0;
}

void work()
{
	
	int n,i;
	
	while(scanf("%d",&n)!=EOF)
	{
		
		if(n==0) return ;
		
		for(i=0;i<n;i++)scanf("%d",&a[i]);
		
		sort(a,a+n,cmp);
		
		for(i=0;i<n;i++)printf("%d ",a[i]);
		
		puts("");
	}
	
}
int main()
{
	
	freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
	
	work();	
	
	return 0;
}
