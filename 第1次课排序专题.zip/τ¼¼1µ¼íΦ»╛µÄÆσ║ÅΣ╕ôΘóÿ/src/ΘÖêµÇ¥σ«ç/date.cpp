#include<stdio.h>
#include<algorithm>
#include<cstring>

using namespace std;

struct sj{
	
	int  year;
	int month;
	int day;
	
	} a[105];
	
	 

bool cmp (sj a, sj b){
	
	if(a.year>b.year)return 0;
	
	if(a.year<b.year)return 1;
	
	else {
		
		if(a.month >b.month ) return 0;
		
		if(a.month<b.month ) return 1;
		
		else{
			
			if( a.day> b.day)return 0;
			  
			  return 1;
		}
	}
	
}

void work(){
	
	int i=0;
	
	while (scanf("%d/%d/%d",&a[i].month,&a[i].day,&a[i].year)!=EOF)
	{
	i++;
	}

	
	sort(a,a+i,cmp);
	
	for(int j=0;j<i;j++)
	printf("%02d/%02d/%4d \n",a[j].month,a[j].day,a[j].year);
	
	return ;
}

int main()
{
	
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	
	work();
	
	return 0;
	
}
