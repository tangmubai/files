#include<stdio.h>
#include<algorithm>

using namespace std;

int a[105];


void work(){
	int n,i;
	
	while(scanf("%d",&n)!=EOF){
		
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	
	sort(a,a+n);
	
	for(i=0;i<n;i++)
	printf("%d ",a[i]);
	
	puts("");
	}
	
}

int main()
{
	int n,i,j;
	
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	
	work();
	return 0;
	
}
