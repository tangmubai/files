#include<cstdio>
#include<algorithm>
using namespace std;
struct Date{
	int year,month,day;
}a[105];
int n=1;
bool cmp(Date x,Date y){
	if(x.year==y.year)
		if(x.month==y.month) return x.day<y.day;
		else return x.month<y.month;
	else return x.year<y.year;
}
int main(){
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	while((scanf("%d/%d/%d",&a[n].month,&a[n].day,&a[n].year))!=EOF) n++;
	sort(a+1,a+n,cmp);
	for(int i=1;i<n;i++){
		if(a[i].month<10) printf("0");
		printf("%d/",a[i].month);
		if(a[i].day<10) printf("0");
		printf("%d/",a[i].day);
		printf("%d\n",a[i].year);
	}
	return 0;
}
