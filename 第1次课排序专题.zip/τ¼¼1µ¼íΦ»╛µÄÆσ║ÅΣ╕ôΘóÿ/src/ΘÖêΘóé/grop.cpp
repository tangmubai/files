#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
	freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
	int n;scanf("%d",&n);
	while(n--){
		int more[15]={0},less[15]={0},key;scanf("%d",&key);
		for(int i=1;i<=8;i++){
			int x;scanf("%d",&x);
			if(x>=key) more[++more[0]]=x;
			else less[++less[0]]=x;
		}
		for(int i=less[0];i>=1;i--) printf("%d ",less[i]);
		printf("%d ",key);
		for(int i=1;i<=more[0];i++) printf("%d ",more[i]);
		printf("\n");
	}
	return 0;
}
