#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n;
struct ID{
	char s[20];
	char birth[10];
}a[100005];
bool cmp(ID x,ID y){
	if(!strcmp(x.birth,y.birth)) return strcmp(x.s,y.s)>0;
	else return strcmp(x.birth,y.birth)>0;
}
int main(){
	freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%s",a[i].s);
	for(int i=1;i<=n;i++)
		for(int j=6;j<=13;j++) a[i].birth[j-6]=a[i].s[j];
	sort(a+1,a+1+n,cmp); 
	for(int i=1;i<=n;i++) printf("%s\n",a[i].s);
	return 0;
}
