#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
using namespace std;
struct Node{
	char name[105];
	int score,age;
}a[1005];
int n;
bool cmp(Node x,Node y){
	if(x.score==y.score)
		if(!strcmp(x.name,y.name)) return x.age<y.age;
		else return strcmp(x.name,y.name)<0;
	else return x.score<y.score;
}
int main(){
	freopen("score.in","r",stdin);freopen("score.out","w",stdout);
	while(cin>>n){
		for(int i=1;i<=n;i++) cin>>a[i].name>>a[i].age>>a[i].score;
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++) cout<<a[i].name<<a[i].age<<a[i].score;
	}
	return 0;
}
