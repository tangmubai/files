#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
struct node
{
	int mon;
	int day;
	int year;
}a[105];
int n;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline bool cmp(node p,node q)
{
	if(p.year!=q.year) return p.year<q.year;
	if(p.mon!=q.mon) return p.mon<q.mon;
	return p.day<q.day;
}
int main()
{
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	n=1;
	while(scanf("%d/%d/%d",&a[n].mon,&a[n].day,&a[n].year)!=EOF) n++;
	n--;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++) 	
		printf("%02d/%02d/%04d\n",a[i].mon,a[i].day,a[i].year);
 	return 0;
}

