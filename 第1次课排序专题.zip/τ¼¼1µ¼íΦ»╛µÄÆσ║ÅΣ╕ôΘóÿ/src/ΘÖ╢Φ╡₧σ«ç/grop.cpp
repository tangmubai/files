#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int t;
int a[15];
int b[15],c[15];
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
int main()
{
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	read(t);
	while(t--)
	{
		for(int i=1;i<=9;i++) read(a[i]);
		b[0]=c[0]=0;
		for(int i=2;i<=9;i++) 
		{
			if(a[i]<a[1]) b[++b[0]]=a[i];
			else c[++c[0]]=a[i];
		}
		for(int i=b[0];i>=1;i--) printf("%d ",b[i]);
		printf("%d ",a[1]);
		for(int i=1;i<=c[0];i++) printf("%d ",c[i]);
		puts("");
	}
	return 0;
}

