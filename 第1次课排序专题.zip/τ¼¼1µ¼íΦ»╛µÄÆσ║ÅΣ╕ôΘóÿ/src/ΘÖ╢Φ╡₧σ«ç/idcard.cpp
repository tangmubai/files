#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
struct node
{
	char x[25];
	int val;
}a[100005];
int n;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline bool cmp(node p,node q)
{
	if(p.val!=q.val) return p.val>q.val;
	for(int i=1;i<=18;i++)
	{
		if(p.x[i]!=q.x[i]) return (p.x[i]-'0')>(q.x[i]-'0');
	}
	return false;
}
int main()
{
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++) 
	{
		scanf("%s",1+a[i].x);
		for(int j=7;j<=14;j++) 
			a[i].val=a[i].val*10+(a[i].x[j]-'0');
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=18;j++) printf("%c",a[i].x[j]);
		puts("");
	}
	return 0;
}

