#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
struct node
{
	char s[105];
	int age;
	int sc;
}a[1005];
int n;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline bool cmp(node p,node q)
{
	if(p.sc!=q.sc) return p.sc<q.sc;
	if(strcmp(p.s,q.s)!=0) return strcmp(p.s,q.s)<0;
	return p.age<q.age;
}
int main()
{
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n)!=EOF)
	{
		for(int i=1;i<=n;i++)
		{
			scanf("%s",a[i].s);
			read(a[i].age);
			read(a[i].sc);
		}	
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++)
		{
			printf("%s %d %d\n",a[i].s,a[i].age,a[i].sc);
		}
	}
	return 0;
}

