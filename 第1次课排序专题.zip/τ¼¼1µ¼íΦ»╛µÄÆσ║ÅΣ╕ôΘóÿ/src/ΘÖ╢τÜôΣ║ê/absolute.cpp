#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[105];
int aa(int n){if(n<0)n=-n;return n;}
bool cmp(int p1,int p2){
	return aa(p1)>aa(p2);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int n=read();
	while(n){
		for(int i=1;i<=n;i++)a[i]=read();
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)printf("%d ",a[i]);
		printf("\n");n=read();
	}
	return 0;
}

