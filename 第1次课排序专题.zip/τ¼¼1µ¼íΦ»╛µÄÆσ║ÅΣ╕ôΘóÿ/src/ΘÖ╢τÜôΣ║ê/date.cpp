#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
struct pp{int day,month,year;}a[105];
bool cmp(const pp &p1,const pp &p2){
	if(p1.year!=p2.year)return p1.year<p2.year;
	if(p1.month!=p2.month)return p1.month<p2.month;
	return p1.day<p2.day;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int js=1;
	while(scanf("%d/%d/%d",&a[js].month,&a[js].day,&a[js].year)!=EOF)
		js++;
	js--;
	sort(a+1,a+1+js,cmp);
	for(int i=1;i<=js;i++){
		if(a[i].month<10)printf("0%d/",a[i].month);
		else printf("%d/",a[i].month);
		if(a[i].day<10)printf("0%d/",a[i].day);
		else printf("%d/",a[i].day);
		printf("%d\n",a[i].year);
	}
	return 0;
}

