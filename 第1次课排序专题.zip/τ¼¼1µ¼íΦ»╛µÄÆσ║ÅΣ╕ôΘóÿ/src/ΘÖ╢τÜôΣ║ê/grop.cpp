#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[15];
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int n=read();
	while(n--){
		for(int i=1;i<=9;i++)a[i]=read();
		for(int i=9;i>=1;i--)if(a[i]<a[1])printf("%d ",a[i]);
		printf("%d ",a[1]);
		for(int i=2;i<=9;i++)if(a[i]>=a[1])printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}

