#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
struct pp{char p[20];long long z;int age;}a[100005];
bool cmp(const pp &p1,const pp &p2){
	if(p1.age!=p2.age)return p1.age>p2.age;
	return p1.z>p2.z;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++){
		scanf("%s",a[i].p);a[i].z=0;a[i].age=0;
		for(int j=0;j<18;j++){
			if(j>=6&&j<=13)a[i].age=a[i].age*10+a[i].p[j]-'0';
			a[i].z=a[i].z*10+a[i].p[j]-'0';
		}
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++)printf("%lld\n",a[i].z);
	return 0;
}

