#include<stdio.h>
#include<cstring>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
struct pp{int age,s;char na[1005];}a[1005];
bool cmp(const pp &p1,const pp &p2){
	if(p1.s!=p2.s)return p1.s<p2.s;
	int s=strcmp(p1.na,p2.na);
	if(s)return s<0?1:0;
	return p1.age<p2.age;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;i++)scanf("%s %d %d",a[i].na,&a[i].age,&a[i].s);
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)printf("%s %d %d\n",a[i].na,a[i].age,a[i].s);
	}
	return 0;
}

