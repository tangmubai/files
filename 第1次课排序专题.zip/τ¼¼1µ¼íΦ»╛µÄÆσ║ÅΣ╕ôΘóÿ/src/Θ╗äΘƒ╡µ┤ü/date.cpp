#include<cstdio>
#include<algorithm>
using namespace std;
int n=1;
struct node{
	int x;
	int y;
	int z;
}a[105];
bool cmp(node c,node d){
	return c.z<d.z||c.z==d.z&&c.x<d.x||c.z==d.z&&c.x==d.x&&c.y<d.y;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	while(scanf("%d",&a[n].x)!=EOF){
		scanf("/%d/%d",&a[n].y,&a[n].z);
		n++;
	}
	n--;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		if(a[i].x>=1&&a[i].x<=9&&a[i].y>=1&&a[i].y<=9) printf("0%d/0%d/%d\n",a[i].x,a[i].y,a[i].z);
		else if(a[i].y>=1&&a[i].y<=9) printf("%d/0%d/%d\n",a[i].x,a[i].y,a[i].z);
		else if(a[i].x>=1&&a[i].x<=9) printf("0%d/%d/%d\n",a[i].x,a[i].y,a[i].z);
		else printf("%d/%d/%d\n",a[i].x,a[i].y,a[i].z);
	} 
	return 0;
}

