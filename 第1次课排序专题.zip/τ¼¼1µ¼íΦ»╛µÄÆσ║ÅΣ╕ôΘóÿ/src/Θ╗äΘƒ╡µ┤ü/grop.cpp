#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int n,a[15],ans[15],k;
bool v[15]={0};
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		k=1;
		memset(v,0,sizeof(v));
		for(int i=1;i<=9;i++) scanf("%d",&a[i]);
		for(int i=9;i>=2;i--){
			if(a[i]<a[1]){
				ans[k]=a[i];
				v[i]=1;
				k++;
			}
		}
		ans[k]=a[1];v[1]=1;
		k++;
		for(int i=2;i<=9;i++){
			if(!v[i]) ans[k]=a[i],k++;
		}
		for(int i=1;i<=9;i++) cout<<ans[i]<<" ";
		printf("\n");
	}
	return 0;
}

