#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	
	return 0;
}

