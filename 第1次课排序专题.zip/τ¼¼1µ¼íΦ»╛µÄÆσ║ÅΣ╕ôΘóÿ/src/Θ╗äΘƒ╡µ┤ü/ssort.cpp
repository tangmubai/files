#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,a[105];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(cin>>n){
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++) printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}

