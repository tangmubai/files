#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n;
struct node{int x,y;}a[200];
bool cmp(node x,node y){return x.y>y.y;}
int main()
{freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
 while(scanf("%d",&n)!=0)
{if(n==0) return 0;
 for(int i=1;i<=n;i++)
{cin>>a[i].x;
 a[i].y=abs(a[i].x);
}
 sort(a+1,a+n+1,cmp);
 for(int i=1;i<=n;i++)
 cout<<a[i].x<<" ";
 cout<<endl;
}
 return 0;
}
