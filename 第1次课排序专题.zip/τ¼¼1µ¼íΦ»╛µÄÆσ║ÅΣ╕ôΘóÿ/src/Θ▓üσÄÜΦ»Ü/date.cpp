#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
struct node{int y,m,d;}a[200];
int n,i=1;
bool cmp(node x,node y)
{if(x.y==y.y)
{if(x.m==y.m) return x.d<y.d;
 else return x.m<y.m;
}
 else return x.y<y.y;
}
int main()
{freopen("date.in","r",stdin);freopen("date.out","w",stdout);
 while(scanf("%d/%d/%d",&a[i].m,&a[i].d,&a[i].y)!=EOF) i++;
 n=i;
 sort(a+1,a+n+1,cmp);
 for(int i=1;i<=n;i++)
{if(a[i].m<10) cout<<0;
 cout<<a[i].m<<"/";
 if(a[i].d<10) cout<<0;
 cout<<a[i].d<<"/"<<a[i].y<<endl;
}
 return 0;
}
