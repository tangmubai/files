#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[100],l,r,b[100];
int main()
{freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++)
{for(int j=1;j<=9;j++) cin>>a[j];
 l=r=11;b[11]=a[1];
 for(int j=2;j<=9;j++)
 if(a[j]<a[1]) b[--l]=a[j];
 else b[++r]=a[j];
 for(int j=l;j<=r;j++)
 cout<<b[j]<<" ";
 cout<<endl;
}
 return 0;
}
