#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int x,n,m;
struct node{char a[20];long long b;}a[100010];
bool cmp(node x,node y)
{string xx,yy;
 for(int i=1;i<=18;i++)
 xx+=x.a[i],yy+=y.a[i];
 if(x.b==y.b) return xx>yy;
 else return x.b>y.b;
}
int main()
{freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++)
{for(int j=1;j<=18;j++)
{cin>>a[i].a[j];
 if(7<=j&&j<=14) a[i].b=a[i].b*10+(a[i].a[j]-'0');
}
}
 sort(a+1,a+n+1,cmp);
 for(int i=1;i<=n;i++)
{for(int j=1;j<=18;j++)
 cout<<a[i].a[j];
 cout<<endl;
}
 return 0;
}
