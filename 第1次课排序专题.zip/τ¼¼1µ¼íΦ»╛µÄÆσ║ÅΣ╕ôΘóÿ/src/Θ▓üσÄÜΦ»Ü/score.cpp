#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n;
struct node{string a;int b,c;}a[3000];
bool cmp(node x,node y)
{if(x.c==y.c)
{if(x.a==y.a) return x.b<y.b;
 else return x.a<y.a;
}
 else return x.c<y.c;
}
int main()
{freopen("score.in","r",stdin);freopen("score.out","w",stdout);
 while(scanf("%d",&n)!=EOF)
{for(int i=1;i<=n;i++)
 cin>>a[i].a>>a[i].b>>a[i].c;
 sort(a+1,a+n+1,cmp);
 for(int i=1;i<=n;i++)
{cout<<a[i].a<<" "<<a[i].b<<" "<<a[i].c;
 cout<<endl;
}
}
 return 0;
}
