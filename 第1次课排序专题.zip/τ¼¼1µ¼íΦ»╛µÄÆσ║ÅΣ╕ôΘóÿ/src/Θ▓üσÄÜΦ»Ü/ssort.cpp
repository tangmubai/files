#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[200];
int main()
{freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
 while(scanf("%d",&n)!=EOF)
{for(int i=1;i<=n;i++)
{cin>>a[i];
 a[i]+=1000000;
}
 sort(a+1,a+n+1);
 for(int i=1;i<=n;i++)
 cout<<a[i]-1000000<<" ";
 cout<<endl;
}
 return 0;
}
