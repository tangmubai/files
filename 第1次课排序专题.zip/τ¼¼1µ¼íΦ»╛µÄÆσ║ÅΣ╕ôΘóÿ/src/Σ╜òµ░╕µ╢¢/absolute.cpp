#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"vector"
#include"set"
#include"map"
#include"iostream"
#include"iomanip"
using namespace std;
int a[105],n;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
bool cmp(int x,int y){
	return abs(x)>abs(y);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	n=read();
	while(n){
		for(register int i=1;i<=n;i++) a[i]=read();
		sort(a+1,a+n+1,cmp);
		for(register int i=1;i<=n;i++) printf("%d ",a[i]);
		printf("\n");
		n=read();
	}
	return 0;
}
