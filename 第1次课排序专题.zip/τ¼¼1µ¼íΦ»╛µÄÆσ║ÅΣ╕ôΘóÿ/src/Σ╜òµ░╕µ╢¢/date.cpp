#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"vector"
#include"set"
#include"map"
#include"iostream"
#include"iomanip"
using namespace std;
int n;
struct rq{
	int m,d,y;
}a[105];
bool cmp(rq x,rq y){
	if(x.y==y.y){
		if(x.m==y.m) return x.d<y.d;
		else return x.m<y.m;
	}
	else return x.y<y.y;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	n=1;
	while(scanf("%d/%d/%d",&a[n].m,&a[n].d,&a[n].y)!=EOF) n++;
	n--;
	sort(a+1,a+n+1,cmp);
	for(register int i=1;i<=n;i++){
		if(a[i].m<10) printf("0%d/",a[i].m);
		else printf("%d/",a[i].m);
		if(a[i].d<10) printf("0%d/%d\n",a[i].d,a[i].y);
		else printf("%d/%d\n",a[i].d,a[i].y);
	}
	return 0;
}
