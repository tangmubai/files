#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"vector"
#include"set"
#include"map"
#include"iostream"
#include"iomanip"
using namespace std;
int a[15],b[15],c[15],n,t,l,r;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=9;j++){
			a[j]=read();b[j]=a[j];
		}
		t=a[1];sort(a+1,a+10);
		for(register int i=1;i<=9;i++){
			if(a[i]==t){t=i;break;}
		}
		c[t]=b[1];l=t-1;r=t+1;
		for(register int j=2;j<=9;j++){
			if(b[j]<b[1]) c[l--]=b[j];
			else c[r++]=b[j];
		}
		for(register int j=1;j<=9;j++) printf("%d ",c[j]);
		printf("\n");
	}
	return 0;
}
