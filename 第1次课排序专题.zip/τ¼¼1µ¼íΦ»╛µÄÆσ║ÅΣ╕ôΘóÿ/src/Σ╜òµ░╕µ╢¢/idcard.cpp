#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"vector"
#include"set"
#include"map"
#include"iostream"
#include"iomanip"
using namespace std;
int n;
struct sfz{
	string s;int cs;
}a[100005];
int sz(string s){
	int sum=0;
	for(register int i=6;i<=13;i++)
	sum=sum*10+(s[i]-'0');
	return sum;
}
bool cmp(sfz x,sfz y){
	if(x.cs==y.cs) return x.s>y.s;
	else return x.cs>y.cs;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;i++){
		cin>>a[i].s;
		a[i].cs=sz(a[i].s);
	}
	sort(a+1,a+n+1,cmp);
	for(register int i=1;i<=n;i++)
	cout<<a[i].s<<endl;
	return 0;
}
