#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"vector"
#include"set"
#include"map"
#include"iostream"
#include"iomanip"
using namespace std;
int n;
struct stu{
	string name;int age,score;
}a[1005];
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
bool cmp(stu x,stu y){
	if(x.score==y.score){
		if(x.name==y.name) return x.age<y.age;
		else return x.name<y.name;
	}
	else return x.score<y.score;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(register int i=1;i<=n;i++){
			cin>>a[i].name;a[i].age=read();a[i].score=read();
		}
		sort(a+1,a+n+1,cmp);
		for(register int i=1;i<=n;i++){
			cout<<a[i].name<<" ";
			printf("%d %d\n",a[i].age,a[i].score);
		}
	}
	return 0;
}
