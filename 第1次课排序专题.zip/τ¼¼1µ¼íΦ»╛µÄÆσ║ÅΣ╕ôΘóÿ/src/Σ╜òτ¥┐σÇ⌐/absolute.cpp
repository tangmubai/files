#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int a[110];
bool cmp(int x,int y){
	return abs(x)>abs(y);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int n;scanf("%d",&n);
	while(n!=0){
		memset(a,0,sizeof(a));
		for(int i=0;i<n;i++)scanf("%d",&a[i]);
		sort(a,a+n,cmp);
		for(int i=0;i<n;i++) printf("%d ",a[i]);
		printf("\n");
		scanf("%d",&n);
	}
	return 0;
}

