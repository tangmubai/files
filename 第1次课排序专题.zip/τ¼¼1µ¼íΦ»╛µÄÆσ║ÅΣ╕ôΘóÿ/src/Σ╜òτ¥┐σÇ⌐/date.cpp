#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
struct q{
	int y,m,d;
	char s[20];
}a[110];
bool cmp(q l,q r){
	if(l.y==r.y){
		if(l.m==r.m) return l.d<r.d;
		else return l.m<r.m;
	}
	else return l.y<r.y;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int n=0;
	while(scanf("%s",a[n+1].s)!=EOF){
		n++;
		if(a[n].s[0]=='0') a[n].m=a[n].s[1]-'0';
		else a[n].m=(a[n].s[0]-'0')*10+(a[n].s[1]-'0');
		if(a[n].s[3]=='0') a[n].d=a[n].s[4]-'0';
		else a[n].d=(a[n].s[3]-'0')*10+(a[n].s[4]-'0');
		a[n].y=(a[n].s[6]-'0')*1000+(a[n].s[7]-'0')*100+(a[n].s[8]-'0')*10+(a[n].s[9]-'0');
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++) printf("%s\n",a[i].s);
	return 0;
}

