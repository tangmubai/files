#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int a[20],b[20];
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		for(int i=1;i<=9;i++) scanf("%d",&a[i]);
		int m=0;
		for(int i=2;i<=9;i++){
			if(a[i]<a[1]){
				m++;
				b[m]=a[i];
				a[i]=-1;
			}
		}
		for(int i=m;i>=1;i--) printf("%d ",b[i]);
		for(int i=1;i<=9;i++){
			if(a[i]!=-1) printf("%d ",a[i]);
		}
		printf("\n");
	}
	return 0;
}

