#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
struct q{
	int y,m,d;
	char s[30];
}a[100010];
bool cmp1(q l,q r){
	for(int i=1;i<=18;i++){
		if(l.s[i]!=r.s[i]) return l.s[i]>r.s[i];
	}
}
bool cmp(q l,q r){
	if(l.y==r.y){
		if(l.m==r.m){
			if(l.d==r.d) return cmp1(l,r);
			else return l.d>r.d;
		}
		else return l.m>r.m;
	}
	else return l.y>r.y;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%s",a[i].s+1);
	for(int i=1;i<=n;i++){
		if(a[i].s[11]=='0') a[i].m=a[i].s[12]-'0';
		else a[i].m=(a[i].s[11]-'0')*10+(a[i].s[12]-'0');
		if(a[i].s[13]=='0') a[i].d=a[i].s[14]-'0';
		else a[i].d=(a[i].s[13]-'0')*10+(a[i].s[14]-'0');
		a[i].y=(a[i].s[7]-'0')*1000+(a[i].s[8]-'0')*100+(a[i].s[9]-'0')*10+(a[i].s[10]-'0');
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++) printf("%s\n",a[i].s+1);
	return 0;
}

