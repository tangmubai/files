#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int a[110];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		memset(a,0,sizeof(a));
		for(int i=0;i<n;i++) scanf("%d",&a[i]);
		sort(a,a+n);
		for(int i=0;i<n;i++) printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
