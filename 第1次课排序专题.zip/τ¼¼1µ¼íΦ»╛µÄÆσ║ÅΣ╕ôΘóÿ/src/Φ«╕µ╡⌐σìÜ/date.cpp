#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n;
struct Date
{
	int day, mon, year;
}a[100005];
bool cmp(Date a, Date b)
{
	if (a.year != b.year) return a.year < b.year;
	else if (a.mon != b.mon) return a.mon < b.mon;
	else return a.day < b.day;
}
int main()
{
	freopen("date.in", "r", stdin);
	freopen("date.out", "w", stdout);
	n=1;
	while(scanf("%d/%d/%d", &a[n].mon, &a[n].day, &a[n].year) != EOF) n++;
	n--;
	sort(a + 1, a + 1 + n, cmp);
	for (int i = 1; i <= n; i++)
		printf("%02d/%02d/%04d\n",a[i].mon, a[i].day, a[i].year);
}
