#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int t, n, a[1005], b[1005], c[1005];
int main()
{
	freopen("grop.in", "r", stdin);
	freopen("grop.out", "w", stdout);
	scanf("%d", &t);
	while(t--)
	{
		for (int i = 1; i <= 9; i++) scanf("%d", &a[i]);
		b[0] = c[0] = 0;
		for (int i = 2; i <= 9; i++)
		{
			if (a[i] < a[1]) b[++b[0]] = a[i];
			else c[++c[0]] = a[i];
		}
		for (int i = b[0]; i >= 1; i--) printf("%d ", b[i]);
		printf("%d ", a[1]);
		for (int i = 1; i <= c[0]; i++) printf("%d ", c[i]);
		puts("");
	}
}
