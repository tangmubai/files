#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n;
struct Node
{
	string id;
	long long num;
}ss[100005];
bool cmp(Node a, Node b)
{
	if (a.num != b.num) return a.num > b.num;
	else return a.id > b.id;
}
int main()
{
	freopen("idcard.in", "r", stdin);
	freopen("idcard.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		cin >> ss[i].id;
		long long d = 0;
		string str = ss[i].id;
		for (int j = 6; j <= 13; j++) d = d * 10 + str[j] - '0';
		ss[i].num = d;
	}
	sort(ss + 1, ss + n + 1, cmp);
	for (int i = 1; i <= n; i++)
		cout << ss[i].id << endl;
}
