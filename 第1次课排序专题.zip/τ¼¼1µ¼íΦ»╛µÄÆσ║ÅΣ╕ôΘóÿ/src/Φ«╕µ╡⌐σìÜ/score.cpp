#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n;
struct Node
{
	char name[1001];
	int age, score;
}a[1000005];
bool cmp(Node a, Node b)
{
	if(a.score != b.score) return a.score < b.score;
	else if (strcmp(a.name, b.name) != 0) return strcmp(a.name, b.name) < 0;
	else return a.age < b.age;
}
int main()
{
	freopen("score.in", "r", stdin);
	freopen("score.out", "w", stdout);
	while(~scanf("%d", &n))
	{
		for (int i = 1; i <= n; i++) scanf("%s%d%d",a[i].name, &a[i].age, &a[i].score);
		sort(a + 1, a + 1 + n, cmp);
		for (int i = 1; i <= n; i++) 
			printf("%s %d %d\n", a[i].name, a[i].age, a[i].score);
	}
}
