#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n, a[1000005];

int main()
{
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	while(~scanf("%d", &n)){
		for (int i = 1; i <= n; i++)
			scanf("%d", &a[i]);
		sort(a + 1, a + 1 + n);
		for (int i = 1; i <= n; i++)
			printf("%d ", a[i]);
		puts("");
	}
}
