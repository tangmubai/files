#include<stdio.h>
#include<algorithm>
const int N = 100;
using namespace std;

int n;
struct Node{
	int x, sp;
}a[N + 5];
void read(int &x) {
	x = 0;char c = getchar();int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;			
}

bool cmp(Node p, Node q) {
	return p.x > q.x;
}

int main() {
	freopen("absolute.in", "r", stdin);
	freopen("absolute.out", "w", stdout);
	while(scanf("%d", &n) != EOF) {
		if (n == 0)
			return 0;
		for(int i = 1; i <= n; ++i) {
			read(a[i].x);
			if (a[i].x >= 0)
				a[i].sp = 1;
			else {
				a[i].sp = -1;
				a[i].x = -a[i].x;	
			}
		}			
		sort(a + 1, a + n + 1, cmp);
		for(int i = 1; i <= n; ++i)
			printf("%d ", a[i].x * a[i].sp);
		printf("\n");		
	}
	return 0;
}
