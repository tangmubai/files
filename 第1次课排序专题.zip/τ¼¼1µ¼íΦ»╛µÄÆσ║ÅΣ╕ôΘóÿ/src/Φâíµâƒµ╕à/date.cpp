#include<stdio.h>
#include<algorithm>
const int N = 100;
using namespace std;

int n;
struct Node{
	int a, b, c;
}a[N + 5];
void read(int &x) {
	x = 0;char c = getchar();int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;			
}

bool cmp(Node p, Node q) {
	if (p.a != q.a)
		return p.a < q.a;
	else if (p.b != q.b)
		return p.b < q.b;
	else return p.c < q.c;		
}

void out1(int x, int now) {
	if (now == 0)
		return ;
	out1(x / 10, now - 1);
	printf("%d", x % 10);	
}

int main() {
	freopen("date.in", "r", stdin);
	freopen("date.out", "w", stdout);
	while(scanf("%d", &a[++n].b) != EOF) {
		read(a[n].c);
		read(a[n].a);
	}
	--n;
	sort(a + 1, a + n + 1, cmp);
	for(int i = 1; i <= n; ++i) {
		out1(a[i].b, 2);
		putchar('/');
		out1(a[i].c, 2);
		putchar('/');
		out1(a[i].a, 4);
		puts("");
	}
	return 0;
}
