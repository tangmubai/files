#include<stdio.h>

int Q, a[25];
int ans[25], tot;

int main() {
	freopen("grop.in", "r", stdin);
	freopen("grop.out", "w", stdout);
	scanf("%d", &Q);
	while(Q--) {
		tot = 0;
		for(int i = 1; i <= 9; ++i)
			scanf("%d", a + i);
		for(int i = 9; i >= 2; --i)
			if (a[i] < a[1])
					ans[++tot] = a[i];
		ans[++tot] = a[1];
		for(int i = 2; i <= 9; ++i)
			if (a[i] >= a[1])
				ans[++tot] = a[i];
		for(int i = 1; i <= 9; ++i)
			printf("%d ", ans[i]);
		puts("");						
	}
	return 0;
}
