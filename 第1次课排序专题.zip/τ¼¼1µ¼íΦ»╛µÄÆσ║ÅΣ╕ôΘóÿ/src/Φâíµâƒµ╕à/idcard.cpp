#include<stdio.h>
#include<string>
#include<iostream>
#include<algorithm>
const int N = 100000;
using namespace std;

int n;
struct Node{
	string s1, s2;
}a[N + 5];
void read(int &x) {
	x = 0;char c = getchar();int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;			
}



bool cmp(Node p, Node q) {
	if (p.s2 == q.s2)
		return p.s1 > q.s1;
	else return p.s2 > q.s2;	
}

int main() {
	freopen("idcard.in", "r", stdin);
	freopen("idcard.out", "w", stdout);
	read(n);
	for(int i = 1; i <= n; ++i) {
		cin >> a[i].s1;
		for(int j = 6; j < 14; ++j)
			a[i].s2 += a[i].s1[j];
	}
	sort(a + 1, a + n + 1, cmp);
	for(int i = 1; i <= n; ++i)
		cout << a[i].s1 << endl; 
	return 0;
}
