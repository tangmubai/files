#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
const int N = 1000;
using namespace std;
int n;
struct Node{
	char nm[105];
	int s, ol;
}a[N + 5];
void read(int &x) {
	x = 0;char c = getchar();int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;			
}

bool cmp(Node p, Node q) {
	if (p.s != q.s)
		return p.s < q.s;
	else if (strcmp(p.nm, q.nm))
		return strcmp(p.nm, q.nm) < 0;
	else return p.ol < q.ol;		
}

int main() {
	freopen("score.in", "r", stdin);
	freopen("score.out", "w", stdout);
	while(scanf("%d", &n) != EOF) {
		for(int i = 1; i <= n; ++i)
			scanf("%s %d %d", a[i].nm, &a[i].ol, &a[i].s);
		sort(a + 1, a + n + 1, cmp);
		for(int i = 1; i <= n; ++i)
			printf("%s %d %d\n", a[i].nm, a[i].ol, a[i].s);
	}
	return 0;
}
