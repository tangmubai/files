#include<stdio.h>
#include<algorithm>
const int N = 100;
using namespace std;

int n;
struct Node{
	int x;
}a[N + 5];
void read(int &x) {
	x = 0;char c = getchar();int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;			
}

bool cmp(Node p, Node q) {
	return p.x < q.x;
}

int main() {
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	while(scanf("%d", &n) != EOF) {
		for(int i = 1; i <= n; ++i)
			read(a[i].x);
		sort(a + 1, a + n + 1, cmp);
		for(int i = 1; i <= n; ++i)
			printf("%d ", a[i].x);
		printf("\n");		
	}
	return 0;
}
