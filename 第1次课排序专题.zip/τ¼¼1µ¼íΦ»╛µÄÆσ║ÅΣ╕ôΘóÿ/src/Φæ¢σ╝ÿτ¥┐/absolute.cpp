#include <stdio.h>
#include <algorithm>
#include <cmath>
#include <cstring>
using namespace std;
int n,a[1005],k;
struct Node{
	int num,num2;
}b[105];
bool cmp(Node a,Node b){
	return a.num>b.num;
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(~scanf("%d",&n)){
		k=0;
		memset(b,0,sizeof(b));
		memset(a,0,sizeof(a));
		if(n==0)
			break;
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		for(int i=1;i<=n;i++){
			bool flag=1;
			for(int j=1;j<=k;j++)
				if(a[i]==b[k].num2){
					flag=0;break;
				}
			if(flag==1){
				b[++k].num=abs(a[i]);
				b[k].num2=a[i];
			}
		}
		sort(b+1,b+1+k,cmp);
		for(int i=1;i<=n;i++)
			printf("%d ",b[i].num2);
		printf("\n");
	}
	return 0;
} 
