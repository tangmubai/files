#include <stdio.h>
#include <algorithm>
using namespace std;
int i=1;
struct Node{
	int n,y,r;
}a[105];
bool cmp(Node a,Node b){
	if(a.n==b.n)
		if(a.y==b.y)
			return a.r<b.r;
		else return a.y<b.y;
	else return a.n<b.n;
} 
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	while(~scanf("%d/%d/%d",&a[i].r,&a[i].y,&a[i].n))
		i++;		
	sort(a+1,a+i,cmp);
	for(int j=1;j<=i-1;j++)
		if(a[j].r/10==0&&a[j].y/10==0)
			printf("0%d/0%d/%d\n",a[j].r,a[j].y,a[j].n);
		else if(a[j].y/10==0)
			printf("%d/0%d/%d\n",a[j].r,a[j].y,a[j].n);
		else if(a[i].r/10==0)
			printf("0%d/%d/%d\n",a[j].r,a[j].y,a[j].n);
		else printf("%d/%d/%d\n",a[j].r,a[j].y,a[j].n);
	return 0;
} 
