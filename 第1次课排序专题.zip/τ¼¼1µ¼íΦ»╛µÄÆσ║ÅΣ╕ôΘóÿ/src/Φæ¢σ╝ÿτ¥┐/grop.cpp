#include <stdio.h>
int t,a[100];



int main(){
//	freopen("grop.in","r",stdin);
//	freopen("grop.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		for(int i=1;i<=9;i++)
			scanf("%d",&a[i]);
		for(int i=1;i<=9;i++){
			
			
			
			
		}
		
		
	}
	
	
	
	
	
	return 0;
} 
