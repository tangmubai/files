#include <stdio.h>
#include <cstring>
#include <algorithm>
#include <iostream>
using namespace std;
int n;
struct Node{
	string name;
	int n,s;
}a[1005];
bool cmp(Node a,Node b){
	if(a.s==b.s){
		if(a.name==b.name)
			return a.n<b.n;
		else return a.name<b.name;
	}
	else return a.s<b.s;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(~scanf("%d",&n)){
		for(int i=1;i<=n;i++)
			cin>>a[i].name>>a[i].n>>a[i].s;
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)
			cout<<a[i].name<<' '<<a[i].n<<' '<<a[i].s<<endl;
	}
	return 0;
} 
