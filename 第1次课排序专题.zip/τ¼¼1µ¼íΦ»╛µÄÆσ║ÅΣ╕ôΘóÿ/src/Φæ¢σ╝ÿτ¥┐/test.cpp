#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
int n,len;
struct Node{
	char s[105];
	int num,num2,num3;
}a[100005];
bool cmp(Node a,Node b){
	if(a.num==b.num){
		return strcmp(a.s,b.s)>0;
	}
	else return a.num>b.num;
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>a[i].s;
		a[i].num=0;
		a[i].num2=0;
		a[i].num3=0;
		len=strlen(a[i].s);
		for(int j=0;j<=len-1;j++){
			if(j<6)a[i].num2=a[i].num2*10+a[i].s[j]-'0';
			if(j>=6&&j<=13)
				a[i].num=a[i].num*10+a[i].s[j]-'0';
			if(j>13)a[i].num3=a[i].num3*10+a[i].s[j]-'0';
		}
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++)
		printf("%s\n",a[i].s);
	return 0;
} 
