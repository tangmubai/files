#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
int a[105];
int ab(int n){
	return n>=0?n:-n;
}
bool cmp(int a,int b){
	return ab(a)>ab(b);
}
int main(){
	frin("absolute.in");frout("absolute.out");
	int n;
	while(scanf("%d",&n)==1&&n!=0){
		for(int i=1;i<=n;++i) scanf("%d",a+i);
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;++i){
			printf("%d ",a[i]);
		}
		puts("");
	}
	return 0;
}
