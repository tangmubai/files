#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
struct qwq{
	int d,m,y;
}a[105];
bool operator <(qwq x,qwq y){
	if(x.y!=y.y) return x.y<y.y;
	if(x.m!=y.m) return x.m<y.m;
	return x.d<y.d;
}
int main(){
	frin("date.in");frout("date.out");
	int n=0;
	int x,y,z;
	while(scanf("%d/%d/%d",&x,&y,&z)==3){
		a[++n].d=y;a[n].m=x;a[n].y=z;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;++i){
		printf("%02d/%02d/%d\n",a[i].m,a[i].d,a[i].y);
	}
	return 0;
}
