#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
template<typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
int a[15];
int main(){
	frin("grop.in");frout("grop.out");
	int n;in(n);
	while(n--){
		for(int i=1;i<=9;++i) in(a[i]);
		int x=a[1];
		int cnt=0;
		for(int i=9;i>1;--i){
			if(a[i]<x) printf("%d ",a[i]);
		}
		printf("%d ",x);
		for(int i=2;i<=9;++i){
			if(a[i]>=x) printf("%d ",a[i]);
		}
		puts("");
	}
	return 0;
}
