#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
struct qwq{
	string id;
}a[100005];
bool operator <(qwq x,qwq y){
	string s1=x.id.substr(6,8),s2=y.id.substr(6,8);
	if(s1!=s2) return s1>s2;
	else return x.id>y.id;
}
int main(){
	frin("idcard.in");frout("idcard.out");
	ios::sync_with_stdio(false);
	int n;cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i].id;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;++i){
		cout<<a[i].id<<endl;
	}
	return 0;
}

