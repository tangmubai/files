#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
struct qwq{
	string name;
	int age;
	double score;
}a[1005];
bool operator <(qwq x,qwq y){
	if(x.score!=y.score) return x.score<y.score;
	if(x.name!=y.name) return x.name<y.name;
	return x.age<y.age;
}
int main(){
	frin("score.in");frout("score.out");
	ios::sync_with_stdio(false);
	int n;
	while(cin>>n){
		for(int i=1;i<=n;++i){
			cin>>a[i].name>>a[i].age>>a[i].score;
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=n;++i){
			cout<<a[i].name<<' '<<a[i].age<<' '<<a[i].score<<endl;
		}
	}
	return 0;
}

