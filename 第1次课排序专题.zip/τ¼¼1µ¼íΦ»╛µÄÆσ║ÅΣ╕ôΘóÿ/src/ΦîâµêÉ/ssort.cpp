#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
int a[258];
int main(){
	frin("ssort.in");frout("ssort.out");
	int n;
	while(scanf("%d",&n)==1){
		for(int i=1;i<=n;++i) scanf("%d",a+i);
		sort(a+1,a+n+1);
		for(int i=1;i<=n;++i){
			printf("%d ",a[i]);
		}
		puts("");
	}
	return 0;
}
