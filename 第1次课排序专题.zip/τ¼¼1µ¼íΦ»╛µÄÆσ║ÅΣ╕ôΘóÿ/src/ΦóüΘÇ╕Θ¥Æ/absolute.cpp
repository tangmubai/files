#include <stdio.h>
#include <string.h>
#include <math.h>
#include <algorithm>
using namespace std;
struct ac {
	int n;
	bool f;
} a[105];
inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline bool cmp(ac x, ac y) {
	return x.n > y.n;
}
main() {
	//freopen ("absolute.in", "r", stdin);
	//freopen ("absolute.out", "w", stdout);
	int n = read();
	while (n != 0) {
		for (register int i = 1; i <= n; i ++) {
			a[i].n = read();
			if (a[i].n < 0) a[i].f = 1;
			a[i].n = abs(a[i].n);
		}
		sort (a+1, a+n+1, cmp);
		for (register int i = 1; i <= n; i ++) {
			if (a[i].f) printf ("%d ", a[i].n * -1);
			else printf ("%d ", a[i].n);
			
		}
		puts ("");
		n = read();
	}
	return 0;
}
