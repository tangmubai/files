#include <stdio.h>
#include <string.h>
#include <math.h>
#include <algorithm>
#include <iostream>
using namespace std;
struct ac {
	int year, month, day;
} a[105];
int t = 1;
inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline bool cmp(ac x, ac y) {
	if (x.year == y.year) {
		if (x.month == y.month) {
			return x.day < y.day;
		}
		return x.month < y.month;
	}
	return x.year < y.year;
}
main() {
	freopen ("date.in", "r", stdin);
	freopen ("date.out", "w", stdout);
	while (scanf ("%d %d %d", &a[t].month, &a[t].day, &a[t].year) != EOF) t ++;
	sort (a+1, a+t+1, cmp);
	for (register int i = 2; i <= t; i ++) printf ("%02d/%02d/%4d\n", a[i].month, a[i].day, a[i].year);
	return 0;
}
