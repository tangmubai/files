#include <stdio.h>
#include <string.h>
#include <math.h>
#include <algorithm>
#include <iostream>
using namespace std;
struct ac {
	string name;
	int age, mark;
} a[105];
int t = 1;
inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline bool cmp(ac x, ac y) {
	if (x.mark == y.mark) {
		if (x.name == y.name)
			return x.age < y.age;
		return x.name < y.name;
	}
	return x.mark < y.mark;
}
main() {
	freopen ("score.in", "r", stdin);
	freopen ("score.out", "w", stdout);
	int n;
	while (cin >> n) {
		for (register int i = 1; i <= n; i ++) {
			cin >> a[i].name;
			a[i].age = read();
			a[i].mark = read();
		}
		sort (a+1, a+n+1, cmp);
		for (register int i = 1; i <= n; i ++) {
			cout << a[i].name;
			printf (" %d %d\n", a[i].age, a[i].mark);
		}
	}
	return 0;
}
