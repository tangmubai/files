#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <iostream>
using namespace std;
int a[105];
inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
main() {
	freopen ("ssort.in", "r", stdin);
	freopen ("ssort.out", "w", stdout);
	int n;
	while (cin >> n) {
		for (register int i = 1; i <= n; i ++) a[i] = read();
		sort (a+1, a+n+1);
		for (register int i = 1; i <= n; i ++) printf ("%d ", a[i]);
		puts ("");
	}
	return 0;
}
