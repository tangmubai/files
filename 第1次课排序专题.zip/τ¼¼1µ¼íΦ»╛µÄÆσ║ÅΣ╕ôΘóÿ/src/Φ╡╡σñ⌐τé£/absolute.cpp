#include <cstdio>
#include <algorithm>
using namespace std;
const int N = 105;
int n;
struct node {
	bool f;
	int val;
} a[N];
bool cmp (node x, node y) {
	return x.val > y.val;
}
int main () {
	freopen("absolute.in", "r", stdin);
	freopen("absolute.out", "w", stdout);
	while (1) {
		scanf ("%d", &n);
		if (n == 0)
			return 0;
		for (int i = 1; i <= n; i ++) {
			scanf ("%d", &a[i].val);
			if (a[i].val < 0)
				a[i].val = -a[i].val, a[i].f = 1;
			else
				a[i].f = 0;
		}
		sort (a + 1, a + n + 1, cmp);
		for (int i = 1; i <= n; i ++) {
			if (a[i].f)
				putchar('-');
			printf ("%d ", a[i].val);
		}
		putchar('\n');
	}
}
