#include <cstdio>
#include <algorithm>
using namespace std;
const int N = 105;
struct node {
	int yea, mon, day;
} a[N];
int n = 1;
char x;
bool cmp (node x, node y) {
	if (x.yea == y.yea) {
		if (x.mon == y.mon)
			return x.day < y.day;
		return x.mon < y.mon;
	}
	return x.yea < y.yea;
}
void print (int x) {
	if (x < 10)
		putchar('0');
	printf ("%d", x);
}
int main () {
	freopen("date.in", "r", stdin);
	freopen("date.out", "w", stdout);
	while (scanf ("%d", &a[n].mon) != EOF) {
		getchar();
		scanf ("%d", &a[n].day);
		scanf ("%c", &x);
		scanf ("%d", &a[n].yea);
		n ++;
	} 
	n --;
	sort (a + 1, a + n + 1, cmp);
	for (int i = 1; i <= n; i ++) {
		print(a[i].mon);
		putchar(x);
		print(a[i].day);
		putchar(x);
		print(a[i].yea);
		putchar('\n');
	}
}
