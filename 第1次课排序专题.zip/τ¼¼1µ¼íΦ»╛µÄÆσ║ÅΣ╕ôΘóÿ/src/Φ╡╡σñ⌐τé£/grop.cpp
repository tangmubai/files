#include <cstdio>
const int N = 1005;
int a[N];
int ans[N];
int n, t;
int main () {
	freopen("grop.in", "r", stdin);
	freopen("grop.out", "w", stdout);
	scanf ("%d", &t);
	while (t --) {
		n = 9;
		for (int i = 1; i <= n; i ++)
			scanf ("%d", &a[i]);
		ans[a[1]] = a[1];
		int j = n;
		for (int i = 1; i < a[1]; i ++) {
			for (; j >= 1; j --)
				if (a[j] < a[1]) {
					ans[i] = a[j];
					j --;
					break;
				}
		}
		j = 1;
		for (int i = a[1] + 1; i <= n; i ++) {
			for (; j <= n; j ++)
				if (a[j] >= a[1]) {
					ans[i] = a[j];
					j ++;
					break;
				}
		}
		for (int i = 1; i <= n; i ++)
			printf ("%d ", ans[i]);
		puts("");
		
	}
}
