#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;
const int N = 100005;
struct node {
	int day;
	int mon;
	int yea;
	char fr[20], bk[20];
} a[N];
bool cmp (node x, node y) {
	if (x.yea == y.yea) {
		if (x.mon == y.mon)
			return x.day > y.day;
		return x.mon > y.mon;
	}
	return x.yea > y.yea;
}

void print (int x) {
	if (x < 10)
		putchar('0');
	printf ("%d", x);
}
int n;
int main () {
	freopen("idcard.in", "r", stdin);
	freopen("idcard.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i ++) {
		for (int j = 1; j <= 6; j ++)
			cin >> a[i].fr[j];
		scanf ("%4d%2d%2d", &a[i].yea, &a[i].mon, &a[i].day);
		for (int j = 1; j <= 4; j ++)
			cin >>a[i].bk[j];
	}
	sort (a + 1, a + n + 1, cmp);
	for (int i = 1; i <= n; i ++) {
		printf ("%s%d", a[i].fr + 1, a[i].yea);
		print (a[i].mon);
		print (a[i].day);
		printf ("%s\n", a[i].bk + 1);
	}
}
