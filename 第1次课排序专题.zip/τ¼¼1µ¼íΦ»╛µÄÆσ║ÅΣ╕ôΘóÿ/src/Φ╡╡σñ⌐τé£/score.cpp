#include <cstdio>
#include <algorithm>
#include <iostream>
#include <string>
using namespace std;
const int N = 1005;
struct node {
	string nam;
	int yea;
	int cj;
} a[N];
int n;
bool cmp (node x, node y) {
	if (x.cj == y.cj) {
		if (x.nam == y.nam)
			return x.yea < y.yea;
		return x.nam < y.nam;
	}
	return x.cj < y.cj;
}
int main () {
	freopen("score.in", "r", stdin);
	freopen("score.out", "w", stdout);
	
	while (scanf ("%d", &n) != EOF) {
		for (int i = 1; i <= n; i ++)
			cin >> a[i].nam >> a[i].yea >> a[i].cj;
		sort (a + 1, a + n + 1, cmp);
		for (int i = 1; i <= n; i ++) {
			cout << a[i].nam << ' ' << a[i].yea << ' ' << a[i].cj << '\n';	 
		}
	}
}
