#include <cstdio>
#include <algorithm>
using namespace std;
const int N = 105;
int a[N];
int n;
int main () {
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	while (scanf ("%d", &n) != EOF) {
		for (int i = 1; i <= n; i ++)
			scanf ("%d", &a[i]);
		sort (a + 1, a + n + 1);
		for (int i = 1; i <= n; i ++)
			printf ("%d ", a[i]);
		puts("");
	}
}
