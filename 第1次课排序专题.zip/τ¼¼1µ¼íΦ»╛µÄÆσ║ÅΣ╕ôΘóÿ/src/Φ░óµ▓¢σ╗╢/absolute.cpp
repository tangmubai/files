#include<map>
#include<set>
#include<cmath>
#include<math.h>
#include<vector>
#include<cstdio>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
int a[105]={0};
bool cmp(int a,int b){return abs(a)>abs(b);}
int main(){freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
	ll n;scanf("%d",&n);
	while(n!=0){
		for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+1+n,cmp);
		for(ll i=1;i<=n;i++)printf("%d ",a[i]);
		puts("");
		scanf("%d",&n);
	}
	return 0;
}

