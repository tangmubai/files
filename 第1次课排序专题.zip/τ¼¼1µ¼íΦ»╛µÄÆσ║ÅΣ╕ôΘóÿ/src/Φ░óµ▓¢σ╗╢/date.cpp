#include<map>
#include<set>
#include<cmath>
#include<math.h>
#include<vector>
#include<cstdio>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
struct node{int y,m,d;}f[105];
bool cmp(node a,node b){if(a.y==b.y)if(a.m==b.m)return a.d<b.d;else return a.m<b.m;else return a.y<b.y;}
int main(){freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	ll n=0;
	ll a,b,c;
	while(scanf("%d/%d/%d",&a,&b,&c)!=EOF)f[++n].y=c,f[n].m=a,f[n].d=b;
	sort(f+1,f+1+n,cmp);
	for(ll i=1;i<=n;i++){
		if(f[i].m<=9)printf("0%d/",f[i].m);else printf("%d/",f[i].m);
		if(f[i].d<=9)printf("0%d/",f[i].d);else printf("%d/",f[i].d);
		if(f[i].y<=9)printf("0%d",f[i].y);else printf("%d",f[i].y);
		puts("");
	}
	return 0;
}

