#include<map>
#include<set>
#include<cmath>
#include<math.h>
#include<vector>
#include<cstdio>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
int a[10]={0};
int main(){freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
	ll n,flag;
	scanf("%d",&n);
	while(n--){
		for(ll i=1;i<=9;i++)scanf("%d",&a[i]);flag=a[1];
		for(ll i=9;i>=1;i--)if(a[i]<flag)printf("%d ",a[i]);
		printf("%d ",flag);
		for(ll i=2;i<=9;i++)if(a[i]>=flag)printf("%d ",a[i]);
		puts("");
	}
	return 0;
}

