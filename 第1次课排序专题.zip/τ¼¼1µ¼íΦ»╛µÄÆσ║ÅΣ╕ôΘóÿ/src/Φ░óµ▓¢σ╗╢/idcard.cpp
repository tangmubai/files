#include<map>
#include<set>
#include<cmath>
#include<math.h>
#include<vector>
#include<cstdio>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
string c[100005];
bool cmp(string s1,string s2){
	for(ll i=6;i<14;i++)if(s1[i]!=s2[i])return s1[i]>s2[i];
	for(ll i=0;i<18;i++)if(s1[i]!=s2[i])return s1[i]>s2[i];
	return true;
}
int main(){freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
	ll n;
	scanf("%d",&n);
	for(ll i=1;i<=n;i++)cin>>c[i];
	sort(c+1,c+1+n,cmp);
	for(ll i=1;i<=n;i++)cout<<c[i]<<endl;
	return 0;
}

