#include<map>
#include<set>
#include<cmath>
#include<math.h>
#include<vector>
#include<cstdio>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
struct node{char name[105];int age,score;}f[1005];
bool cmp(node a,node b){
	if(a.score==b.score){
		if(strcmp(a.name+1,b.name+1)==0)return a.age<b.age;
		else if(strcmp(a.name+1,b.name+1)==-1)return true;
		else return false;
	}
	return a.score<b.score;
}
int main(){freopen("score.in","r",stdin);freopen("score.out","w",stdout);
	ll n;
	while(~scanf("%d",&n)){
		for(ll i=1;i<=n;i++)scanf("%s %d %d\n",f[i].name+1,&f[i].age,&f[i].score);
		sort(f+1,f+1+n,cmp);
		for(ll i=1;i<=n;i++)printf("%s %d %d\n",f[i].name+1,f[i].age,f[i].score); 
	}
	return 0;
}

