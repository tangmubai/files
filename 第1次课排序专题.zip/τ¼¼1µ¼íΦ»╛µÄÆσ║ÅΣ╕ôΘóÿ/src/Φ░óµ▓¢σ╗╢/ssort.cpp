#include<map>
#include<set>
#include<cmath>
#include<math.h>
#include<vector>
#include<cstdio>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
int a[105]={0};
int main(){freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	ll n;
	while(~scanf("%d",&n)){
		for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+1+n);for(ll i=1;i<=n;i++)printf("%d ",a[i]);
		puts("");
	}
	return 0;
}

