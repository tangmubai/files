#include<stdio.h>
#include<algorithm>
using namespace std;
char a[40];
struct node{
	int y,m,d;
}b[105];
int now=0;
int read(){
	int s=0;
	while(a[now]<'0'||a[now]>'9')now++;
	while(a[now]>='0'&&a[now]<='9'){
		s=s*10+a[now]-'0';now++;
	}
	return s;
}
bool cmp(node x,node z){
	if(x.y!=z.y)return x.y<z.y;
	else if(x.m!=z.m)return x.m<z.m;
	else if(x.d!=z.d)return x.d<z.d;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int sum=0,i;
	while(~scanf("%s",a)){
		int len=0;
		for(len=0;a[len];len++);
		a[len]='a';
		now=0;
		b[++sum].m=read();
		b[sum].d=read();
		b[sum].y=read();
	}
	sort(b+1,b+1+sum,cmp);
	for(i=1;i<=sum;i++){
		if(b[i].m<10)printf("0");
		printf("%d/",b[i].m);
		if(b[i].d<10)printf("0");
		printf("%d/",b[i].d);
		printf("%d\n",b[i].y);
	}
	return 0;
}
