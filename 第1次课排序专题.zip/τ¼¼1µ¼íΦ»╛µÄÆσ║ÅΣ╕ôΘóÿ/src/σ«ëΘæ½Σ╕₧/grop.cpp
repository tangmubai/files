#include<stdio.h>
#include<algorithm>
using namespace std;
int a[15],b[15];
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int i,k,k1,len=0,len1=0;
		scanf("%d",&k);
		for(i=2;i<=9;i++){
			scanf("%d",&k1);
			if(k1<k)a[++len]=k1;
			else b[++len1]=k1;
		}
		for(i=len;i>0;i--){
			printf("%d ",a[i]);a[i]=0;
		}
		printf("%d ",k);
		for(i=1;i<=len1;i++){
			printf("%d ",b[i]);b[i]=0;
		}
		printf("\n");
	}
	return 0;
}
