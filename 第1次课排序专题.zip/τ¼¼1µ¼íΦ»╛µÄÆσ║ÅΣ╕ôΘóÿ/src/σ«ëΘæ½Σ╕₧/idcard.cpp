#include<stdio.h>
#include<algorithm>
using namespace std;
struct node{
	char s[25];
	int k;
}a[100005];
bool cmp(node x,node y){
	if(x.k!=y.k)return x.k>y.k;
	else{
		int flag=1,i;
		for(i=0;i<18;i++){
			if(x.s[i]<y.s[i]){
				flag=0;break;
			}
			if(x.s[i]>y.s[i]){
				flag=1;break;
			}
		}
		return flag;
	}
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n,i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%s",a[i].s);
		a[i].k=0;
		for(j=6;j<14;j++){
			a[i].k=a[i].k*10+a[i].s[j]-'0';
		}
	}
	sort(a+1,a+1+n,cmp);
	for(i=1;i<=n;i++){
		for(j=0;j<18;j++){
			printf("%c",a[i].s[j]);
		}
		printf("\n");
	}
	return 0;
}
