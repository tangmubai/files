#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
struct node{
	char c[105];
	int age,s;
}a[1005];
bool cmp(node x,node y){
	if(x.s!=y.s)return x.s<y.s;
	else{
		int flag=0,i;
		for(i=0;x.c[i]||y.c[i];i++){
			if(x.c[i]>y.c[i]){
				flag=2;break;
			}
			if(x.c[i]<y.c[i]){
				flag=1;break;
			}
		}
		if(flag==2)return 0; 
		if(flag==1)return 1;
		if(flag==0){
			return x.age<y.age;
		}
	}
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	int n;
	while(~scanf("%d",&n)){
		int i,j;
		for(i=1;i<=n;i++){
			scanf("%s%d%d",a[i].c,&a[i].age,&a[i].s);
		}
		sort(a+1,a+1+n,cmp);
		for(i=1;i<=n;i++){
			printf("%s %d %d\n",a[i].c,a[i].age,a[i].s);
		}
	}
	return 0;
}
