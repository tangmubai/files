#include<stdio.h>
#include<cstring>
#include<algorithm>
using namespace std;
char a[105],b[105];
int main(){
	scanf("%s%s",a,b);
	printf("%d",strcmp(a,b));
	return 0;
}
