#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<string.h>
using namespace std;
int n=1;
char s[105];
struct Node{
	int y,m,d;
}a[105];
bool cmp(Node xx,Node yy){
	if(xx.y==yy.y){
		if(xx.m==yy.m)return xx.d<yy.d;
		else return xx.m<yy.m;
	}
	else return xx.y<yy.y;
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	while(scanf("%d/%d/%d",&a[n].m,&a[n].d,&a[n].y)!=EOF)n++;
	n--;
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++)printf("%02d/%02d/%4d\n",a[i].m,a[i].d,a[i].y);
	return 0;
}
/*
m    d     y
01 / 02 / 1999
01 2 34 5 6789
*/
