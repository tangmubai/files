#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<string.h>
using namespace std;
int n,a[15],ans[15],l,r;
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		for(int i=1;i<=9;i++)scanf("%d",&a[i]);
		int x=a[1];
		for(int i=9;i>=2;i--)if(a[i]<x)printf("%d ",a[i]);
		printf("%d ",x);
		for(int i=2;i<=9;i++)if(a[i]>=x)printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
