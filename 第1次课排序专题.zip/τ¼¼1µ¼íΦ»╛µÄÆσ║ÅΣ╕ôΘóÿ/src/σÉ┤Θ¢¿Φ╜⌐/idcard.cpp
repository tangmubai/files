#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<string.h>
using namespace std;
int n;
char s[105];
struct Node{
	int y,m,d,l,r;
}a[100005];
bool cmp(Node xx,Node yy){
	if(xx.y==yy.y){
		if(xx.m==yy.m){
			if(xx.d==yy.d){
				if(xx.l==yy.l)return xx.r>yy.r;
				else return xx.l>yy.l;
			}
			else return xx.d>yy.d;
		}
		else return xx.m>yy.m;
	}
	else return xx.y>yy.y;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%s",s+1);
		for(int j=6,k=1;j>=1;j--,k*=10)a[i].l+=(s[j]-'0')*k;
		for(int j=10,k=1;j>=7;j--,k*=10)a[i].y+=(s[j]-'0')*k;
		for(int j=12,k=1;j>=11;j--,k*=10)a[i].m+=(s[j]-'0')*k;
		for(int j=14,k=1;j>=13;j--,k*=10)a[i].d+=(s[j]-'0')*k;
		for(int j=18,k=1;j>=15;j--,k*=10)a[i].r+=(s[j]-'0')*k;
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++){
		printf("%d",a[i].l);
		printf("%d",a[i].y);
		if(a[i].m<10)printf("0");
		printf("%d",a[i].m);
		if(a[i].d<10)printf("0");
		printf("%d",a[i].d);
		printf("%d\n",a[i].r);
	}
	return 0;
}
