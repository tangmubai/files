#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<string.h>
using namespace std;
int n;
struct Node{
	char na[105];
	int ag;
	int sc;
}a[1005];
bool cmp(Node xx,Node yy){
	if(xx.sc==yy.sc){
		if(strcmp(xx.na,yy.na)==0)return xx.ag<yy.ag;
		return strcmp(xx.na,yy.na)<0;
	}
	return xx.sc<yy.sc;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;i++)scanf("%s%d%d",&a[i].na,&a[i].ag,&a[i].sc);
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)printf("%s %d %d\n",a[i].na,a[i].ag,a[i].sc);
	}
	return 0;
}
