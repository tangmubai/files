#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<set>
#include<map>
using namespace std;
int n,a[10100];
bool cmp(int a,int b)
{
	return abs(a)>abs(b);
}
int main()
{
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(1)
	{
		scanf("%d",&n);
		if(n==0)
		{
			return 0;
		}
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<n;i++)
		{
			printf("%d ",a[i]);
		}
		printf("%d\n",a[n]);
	}
	return 0;
}

