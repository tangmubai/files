#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<set>
#include<map>
using namespace std;
int n=1;
struct node
{
	string d,m,y;
}a[11000];
bool cmp(node a,node b)
{
	if(a.y!=b.y) return a.y<b.y;
	if(a.m!=b.m) return a.m<b.m;
	return a.d<b.d;
}
string s;
int main()
{
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	while(cin>>s)
	{
		int j=0;
		while(j<2)
		{
			a[n].m+=s[j];//ע������ 
			j++;
		}
		j++;
		while(j<=4)
		{
			a[n].d+=s[j];
			j++;
		}
		j++;
		while(j<s.size())
		{
			a[n].y+=s[j];
			j++;
		}
		n++;
	}
	sort(a+1,a+n,cmp);
	for(int i=1;i<n-1;i++)
	{
		cout<<a[i].m<<"/"<<a[i].d<<"/"<<a[i].y<<endl;
	}
	cout<<a[n-1].m<<"/"<<a[n-1].d<<"/"<<a[n-1].y;
	return 0;
}

