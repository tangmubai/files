#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<set>
#include<map>
using namespace std;
int n,a[10010],b[10010];
int main()
{
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=9;j++)
		{
			scanf("%d",&a[j]);
		}
		int k=1;
		b[1]=a[1];
		for(int j=2;j<=9;j++)
		{
			if(a[j]<a[1])
			{
				for(int l=k;l>=1;l--)
				{
					b[l+1]=b[l];
				}
				b[1]=a[j];
				k++;
			}
			else
			{
				b[++k]=a[j];
			}
		}
		for(int j=1;j<=k;j++)
		{
			printf("%d ",b[j]);
		}
		printf("\n");
	}
	return 0;
}

