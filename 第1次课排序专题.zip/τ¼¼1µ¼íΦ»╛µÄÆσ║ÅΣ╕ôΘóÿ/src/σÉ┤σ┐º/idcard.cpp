#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<set>
#include<map>
using namespace std;
struct node
{
	string id,da;
}a[101000];
int n;
bool cmp(node a,node b)
{
	if(a.da != b.da) return a.da>b.da;
	else return a.id>b.id;
}
string s;
int main()
{
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		a[i].id=s;
		for(int j=6;j<14;j++)
		{
			a[i].da+=s[j];
		}
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		cout<<a[i].id<<endl;
	}
	return 0;
}

