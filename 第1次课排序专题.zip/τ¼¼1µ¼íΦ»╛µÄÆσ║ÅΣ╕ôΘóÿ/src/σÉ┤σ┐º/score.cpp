#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<set>
#include<map>
using namespace std;
struct node
{
	string name;
	int age,se;
}a[10100];
bool cmp(node a,node b)
{
	if(a.se!=b.se) return a.se<b.se;
	if(a.name!=b.name) return a.name<b.name;
	return a.age<b.age;
}
int n;
int main()
{
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n)!=EOF)
	{
		for(int i=1;i<=n;i++)
		{
			cin>>a[i].name>>a[i].age>>a[i].se;
		}
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++)
		{
			cout<<a[i].name<<" "<<a[i].age<<" "<<a[i].se<<endl;
		}
	}
	return 0;
}

