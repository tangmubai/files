#include<stdio.h>
#include<algorithm>
#define abs(x) ((x)<0?-(x):(x))
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register bool t=0;register char c=nc();for(;c<'0'||'9'<c;t|=c=='-',c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());if(t)x=-x;
}
struct node
{
	int x;
	inline void in(){read(x);}
	inline void ou()const{printf("%d ",x);}
	inline bool operator<(const node&kkk)const{return abs(x)>abs(kkk.x);}
}a[100];
main()
{
	freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
	register int n;
	for(;read(n),n;putchar('\n'))
	{
		for(register int i=0;i<n;++i)a[i].in();
		std::sort(a,a+n);
		for(register int i=0;i<n;++i)a[i].ou();
	}
}
