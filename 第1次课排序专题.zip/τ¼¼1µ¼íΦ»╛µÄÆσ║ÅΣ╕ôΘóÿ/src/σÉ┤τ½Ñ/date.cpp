#include<stdio.h>
#include<algorithm>
struct node
{
	int x,y,z;
	inline bool in(){return scanf("%d/%d/%d",&x,&y,&z)!=EOF;}
	inline void ou()const{printf("%02d/%02d/%04d\n",x,y,z);}
	inline bool operator<(const node&kkk)const
	{
		if(z!=kkk.z)return z<kkk.z;
		if(x!=kkk.x)return x<kkk.x;
		return y<kkk.y;
	}
}a[100];
main()
{
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	register int n=0;
	for(;a[n].in();++n);
	std::sort(a,a+n);
	for(register int i=0;i<n;++i)a[i].ou();
}
