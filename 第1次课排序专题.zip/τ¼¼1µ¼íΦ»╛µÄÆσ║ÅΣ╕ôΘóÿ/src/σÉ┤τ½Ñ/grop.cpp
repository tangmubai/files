#include<stdio.h>
#include<algorithm>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
main()
{
	freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
	register int n,a[9];
	for(read(n);n--;putchar('\n'))
	{
		for(register int i=0;i<9;++i)read(a[i]);
		for(register int i=8;i>=0;--i)if(a[i]<a[0])printf("%d ",a[i]);
		for(register int i=0;i<9;++i)if(a[i]>=a[0])printf("%d ",a[i]);
	}
}
