#include<stdio.h>
#include<algorithm>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(long long&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
struct node
{
	long long x,y;
	inline void in(){read(x);y=x/10000%100000000;}
	inline void ou()const{printf("%lld\n",x);}
	inline bool operator<(const node&kkk)const
	{
		if(y!=kkk.y)return y>kkk.y;
		return x>kkk.x;
	}
}a[100000];
main()
{
	freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
	register long long n;read(n);
	for(register int i=0;i<n;++i)a[i].in();
	std::sort(a,a+n);
	for(register int i=0;i<n;++i)a[i].ou();
}
