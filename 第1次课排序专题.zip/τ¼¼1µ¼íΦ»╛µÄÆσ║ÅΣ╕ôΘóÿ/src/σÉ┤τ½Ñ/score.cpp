#include<stdio.h>
#include<algorithm>
inline void read(int&x)
{
	register char c=getchar();for(;c<'0'||'9'<c;c=getchar());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=getchar());
}
struct node
{
	char name[111];int age,sco;
	inline void in(){scanf("%s",name);read(age);read(sco);}
	inline void ou()const{printf("%s %d %d\n",name,age,sco);}
	inline bool operator<(const node&kkk)const
	{
		if(sco!=kkk.sco)return sco<kkk.sco;
		for(register int i=0;i<100&&(name[i]||kkk.name[i]);++i)
			if(name[i]!=kkk.name[i])return name[i]<kkk.name[i];
		return age<kkk.age;
	}
}a[1000];
main()
{
	freopen("score.in","r",stdin);freopen("score.out","w",stdout);
	register int n;
	for(;scanf("%d",&n)!=EOF;)
	{
		for(register int i=0;i<n;++i)a[i].in();
		std::sort(a,a+n);
		for(register int i=0;i<n;++i)a[i].ou();
	}
}
