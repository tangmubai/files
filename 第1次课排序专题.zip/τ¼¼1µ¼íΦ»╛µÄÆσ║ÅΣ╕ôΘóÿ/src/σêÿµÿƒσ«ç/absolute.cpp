#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;

pair<int, int> a[10005];

bool cmp(pair <int,int> a, pair<int,int> b)
{
	return a.first * a.second > b.first * b.second;
}

int main()
{
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int n;
	while (true)
	{
		scanf("%d", &n);
		if (n == 0)
			return 0;
		for (int i = 1; i <= n; i++)
			scanf("%d", &a[i].first), a[i].second = a[i].first >= 0 ? 1 : -1;
		sort(a + 1, a + 1+ n, cmp);
		for (int i = 1; i <= n; i++)
			printf("%d ", a[i].first);
		printf("\n");
	}
	return 0;
}
