#include <cstdio>
#include <string>
#include <algorithm>
#include <iostream>
using namespace std;

struct NODE
{
	int year, month, day;
} a[1005];

bool cmp(NODE x, NODE b)
{
	if (x.year != b.year)
		return x.year < b.year;
	if (x.month != b.month)
		return x.month < b.month;
	if (x.day != b.day)
		return x.day < b.day;
}

int main()
{
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int tot = 0;
	char s[10005];
	while(scanf("%s", s + 1) != EOF)
	{
		tot++;
		int i;
		for (i = 1; s[i] != '/'; i++)
			a[tot].month = a[tot].month * 10 + s[i] - '0';
		i++;
		for (; s[i] != '/'; i++)
			a[tot].day = a[tot].day * 10 + s[i] - '0';
		
		i++;
		for (; s[i]; i++)
			a[tot].year = a[tot].year * 10 + s[i] - '0';
		
	}
	sort(a + 1, a + 1 + tot, cmp);
	for (int i =1; i <= tot; i++)
	{
		if (a[i].month < 10)
			printf("0%d/", a[i].month);
		else
			printf("%d/", a[i].month);
		if (a[i].day < 10)
			printf("0%d/", a[i].day);
		else
			printf("%d/", a[i].day);
		printf("%d\n", a[i].year);
	}
	return 0;
}
