#include <cstdio>

int front[10005], back[10005], totf, totb;

int main()
{
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int t;
	scanf("%d", &t);
	while (t--)
	{
		int k1;
		totf = totb = 0;
		scanf("%d", &k1);
		for (int i = 2; i <= 9; i++)
		{
			int x;
			scanf("%d", &x);
			if (x >= k1)
				back[++totb] = x;
			else
				front[++totf] = x;	
		}
		for (int i = totf; i >= 1; i--)
			printf("%d ", front[i]);
		printf("%d ", k1);
		for (int i = 1; i <= totb; i++)
			printf("%d ", back[i]);
		printf("\n");
	}
}
