#include <cstdio>
#include <algorithm>
using namespace std;

struct Node
{
	int year, month, day;
	char s[105];
} a[100005];

bool cmp(Node x, Node y)
{
	if (x.year != y.year)
		return x.year > y.year;
	if (x.month != y.month)
		return x.month > y.month;
	if (x.day != y.day)
		return x.day > y.day;
	for (int i = 1; i <= 18; i++)
	{
		if (x.s[i] != y.s[i])
			return x.s[i] > y.s[i];
	}
}

int main()
{
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n;
	scanf("%d", &n);
	for (int x = 1; x <= n; x++)
	{
		scanf("%s", a[x].s + 1);
		for (int i = 7; i <= 10; i++)
			a[x].year = a[x].year * 10 + a[x].s[i] - '0';
		for (int i = 11; i <= 12; i++)
			a[x].month = a[x].month * 10 + a[x].s[i] - '0';
		for (int i = 13; i <= 14; i++)
			a[x].day = a[x].day * 10 + a[x].s[i] - '0';
	}
	sort(a + 1, a + 1 + n,cmp);
	for (int i = 1; i <= n; i++)
		printf("%s\n", a[i].s + 1);
	return 0;
}
