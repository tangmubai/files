#include <cstdio>
#include <algorithm>
#include <cstring>
#include <iostream>
using namespace std;

struct node
{
	int len;
	int year, c;
	char s[1005];
} a[1005];

bool cmp(node x, node y)
{
	if (x.c != y.c)
		return x.c < y.c;
	for (int i = 1; i <= min(x.len, y.len); i++)
	{
//		if (i > x.len)
//			return x.len < y.len;
//		if (i > y.len)
//			return y.len < x.len;
		if (x.s[i] != y.s[i])
			return x.s[i] < y.s[i];
	}
//	if (x.len > y.len)
//		return x.len > y.len;
//	if (x.len < y.len)
//		return x.len < y.len;
	if (x.len != y.len)
		return x.len < y.len;
	return x.year < y.year;
}

int main()
{
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	int n;
	while (cin >> n)
	{
		for (int i = 1; i <= n; i++)
		{
			scanf("%s %d %d", a[i].s+1, &a[i].year, &a[i].c);
			a[i].len = strlen(a[i].s + 1);
		}
		sort(a+ 1, a + 1 + n, cmp);
		for (int i = 1; i <= n; i++)
			printf("%s %d %d\n", a[i].s + 1, a[i].year, a[i].c);
	}
	return 0;
}
