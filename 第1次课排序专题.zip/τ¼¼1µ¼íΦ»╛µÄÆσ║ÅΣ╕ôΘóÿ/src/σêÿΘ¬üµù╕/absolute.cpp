#include <stdio.h>
#include <algorithm>
int n, o[105];
inline bool cmp(int p, int q) {
	return (p > 0 ? p : -p) > (q > 0 ? q : -q);
}
int main(void) {
	freopen("absolute.in", "r", stdin);
	freopen("absolute.out", "w", stdout);
	scanf("%d", &n);
	while (n) {
		for (int i = 1; i <= n; ++i)
			scanf("%d", &o[i]);
		std:: sort(o + 1, o + 1 + n, cmp);
		for (int i = 1; i <= n; ++i)
			printf("%d ", o[i]);
		puts("");
		scanf("%d", &n);
	}
	return 0;
}
