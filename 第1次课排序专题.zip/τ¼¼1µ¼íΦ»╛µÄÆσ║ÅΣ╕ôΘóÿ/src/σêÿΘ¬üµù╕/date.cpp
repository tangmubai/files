#include <stdio.h>
#include <algorithm>
struct Date {
	int m, d, y;
} da[105];
int n;
inline bool cmp(Date p, Date q) {
	return p.y != q.y ? p.y < q.y : (p.m != q.m ? p.m < q.m : p.d < q.d);
}
int main(void) {
	freopen("date.in ", "r", stdin);
	freopen("date.out", "w", stdout);
	for (n = 1; scanf("%d/%d/%d", &da[n].m, &da[n].d, &da[n].y) != EOF; ++n);
	--n;
	std:: sort(da + 1, da + 1 + n, cmp);
	for (int i = 1; i <= n; ++i) {
		if (da[i].m < 10)
			if (da[i].d < 10)
				printf("0%d/0%d/%d\n", da[i].m, da[i].d, da[i].y);
			else
				printf("0%d/%d/%d\n", da[i].m, da[i].d, da[i].y);
		else
			if (da[i].d < 10)
				printf("%d/0%d/%d\n", da[i].m, da[i].d, da[i].y);
			else
				printf("%d/%d/%d\n", da[i].m, da[i].d, da[i].y);
	}
	return 0;
}
