#include <stdio.h>
int k1, more[15], mcnt, less[15], lcnt;
int main(void) {
	freopen("grop.in", "r", stdin);
	freopen("grop.out", "w", stdout);
	int t;
	for (scanf("%d", &t); t--; ) {
		mcnt = lcnt = 0;
		scanf("%d", &k1);
		for (int i = 2, k; i <= 9; ++i) {
			scanf("%d", &k);
			if (k >= k1)
				more[++mcnt] = k;
			else
				less[++lcnt] = k;
		}
		for (int i = lcnt; i >= 1; --i)
			printf("%d ", less[i]);
		printf("%d ", k1);
		for (int i = 1; i <= mcnt; ++i)
			printf("%d ", more[i]);
		puts("");
	}
	return 0;
}
