#include <stdio.h>
#include <algorithm>
int n;
struct card {
	int y, m, d;
	long long id;
} c[100005];
inline bool cmp(card p, card q) {
	return p.y != q.y ? p.y > q.y : (p.m != q.m ? p.m > q.m : (p.d != q.d ? p.d > q.d : p.id > q.id));
}
int main(void) {
	freopen("idcard.in", "r", stdin);
	freopen("idcard.out", "w", stdout);
	scanf("%d", &n);
	char s[20];
	for (int i = 1; i <= n; ++i) {
		scanf("%s", s);
		c[i].id = 0ll;
		for (int j = 0; s[j] != '\0'; ++j)
			c[i].id = c[i].id * 10ll + (s[j] - '0');
		c[i].y = (s[6] - '0') * 1000 + (s[7] - '0') * 100 + (s[8] - '0') * 10 + (s[9] - '0');
		c[i].m = (s[10] - '0') * 10 + (s[11] - '0');
		c[i].d = (s[12] - '0') * 10 + (s[13] - '0');
	}
	std:: sort(c + 1, c + 1 + n, cmp);
	for (int i = 1; i <= n; ++i)
		printf("%lld\n", c[i].id);
	return 0;
}
