#include <iostream>
#include <algorithm>
using namespace std;
int n;
struct Stu {
	string name;
	int age, src;	
} stu[1005];
inline bool cmp(Stu p, Stu q) {
	return p.src != q.src ? p.src < q.src : (p.name != q.name ? p.name < q.name : p.age < q.age);
}
int main(void) {
	freopen("score.in", "r", stdin);
	freopen("score.out", "w", stdout);
	ios:: sync_with_stdio(false);
	while (cin >> n) {
		for (int i = 1; i <= n; ++i)
			cin >> stu[i].name >> stu[i].age >> stu[i].src;
		sort(stu + 1, stu + 1 + n, cmp);
		for (int i = 1; i <= n; ++i)
			cout << stu[i].name << ' ' << stu[i].age << ' ' << stu[i].src << '\n';
	}
	return 0;
}
