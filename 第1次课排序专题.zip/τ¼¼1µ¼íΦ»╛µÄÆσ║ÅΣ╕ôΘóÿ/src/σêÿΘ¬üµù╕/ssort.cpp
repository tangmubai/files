#include <stdio.h>
#include <algorithm>
int n, o[105];
int main(void) {
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	while (scanf("%d", &n) != EOF) {
		for (int i = 1; i <= n; ++i)
			scanf("%d", &o[i]);
		std:: sort(o + 1, o + 1 + n);
		for (int i = 1; i <= n; ++i)
			printf("%d ", o[i]);
		puts("");
	}
	return 0;
}
