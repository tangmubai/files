#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n;
int a[N];
inline bool cmp(int p,int q)
{
	return abs(p)>abs(q);
}
int main()
{
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	while(~scanf("%d",&n))
	{
		if(n==0) break;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++)
		{
			printf("%d ",a[i]);
		}
		puts(" ");
	}
	return 0;
}
