#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n;
struct node 
{
	int m,d,y;
}a[N];
inline bool cmp(node p,node q)
{
	if(p.y!=q.y) return p.y<q.y;
	if(p.m!=q.m) return p.m<q.m;
	else return p.d<q.d;
}
int main()
{
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	n=1;
	while(scanf("%d/%d/%d",&a[n].m,&a[n].d,&a[n].y)) n++;
	n--;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		printf("%02d/%02d/%4d\n",a[i].m,a[i].d,a[i].y);
	}
	return 0;
}
