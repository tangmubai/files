#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=15;
int t;
int a[N],ans[N];
int main()
{
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		for(int i=1;i<=9;i++)
		{
			scanf("%d",&a[i]);
		}
		for(int i=9;i>=1;i--)
		{
			if(a[i]<a[1])printf("%d ",a[i]);
		}
		for(int i=1;i<=9;i++)
		{
			if(a[i]>=a[1]) printf("%d ",a[i]);
		}
		puts(" ");
	}
	return 0;
}
