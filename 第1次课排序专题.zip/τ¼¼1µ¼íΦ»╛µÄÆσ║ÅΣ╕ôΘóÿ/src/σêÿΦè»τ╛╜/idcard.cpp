#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e5+5;
int n;
struct node
{
	string id;
	int m,d,y;
}a[N];
inline bool cmp(node p,node q)
{
	if(p.y!=q.y) return p.y>q.y;
	if(p.m!=q.m) return p.m>q.m;
	if(p.d!=q.d) return p.d>q.d;
	return p.id>q.id;
}
int main()
{
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	scanf("%d\n",&n);
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].id;
		a[i].y=a[i].m=a[i].d=0;
		for(int j=6;j<=9;j++)
		{
			a[i].y=a[i].y*10+a[i].id[j]-'0';
		}
		for(int j=10;j<=11;j++)
		{
			a[i].m=a[i].m*10+a[i].id[j]-'0';
		}
		for(int j=12;j<=13;j++)
		{
			a[i].d=a[i].d*10+a[i].id[j]-'0';
		}
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		cout<<a[i].id;
		puts(" ");
	}
	return 0;
}
