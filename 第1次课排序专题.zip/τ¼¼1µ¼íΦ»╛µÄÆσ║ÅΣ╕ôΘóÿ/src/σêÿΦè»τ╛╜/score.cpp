#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n;
struct node
{
	string name;
	int age,s;
}a[N];
inline bool cmp(node p,node q)
{
	if(p.s!=q.s) return p.s<q.s;
	if(p.name!=q.name) return p.name<q.name;
	return p.age<q.age;
}
int main()
{
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n))
	{
		for(int i=1;i<=n;i++)
		{
			cin>>a[i].name;
			scanf("%d%d",&a[i].age,&a[i].s);
		}
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++)
		{
			cout<<a[i].name;
			printf(" %d %d\n",a[i].age,a[i].s);
		}
	}
	return 0;
}
