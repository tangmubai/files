#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int a[101];
bool cmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
        int n;
		while(cin>>n&&n!=0){
     	for(int i=1;i<=n;i++)cin>>a[i];
		 sort(a+1,a+n+1,cmp);
	for(int j=1;j<=n;j++)cout<<a[j]<<" ";
	 cout<<endl;
}
	return 0;
}
