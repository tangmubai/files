#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	cin>>n;int a[n];
	for(int i=1;i<=n;i++)cin>>a[i];
	sort(a+1,a+1+n);
	for(int j=1;j<=n;j++)cout<<a[j]<<" ";
	return 0;
}
