#include<stdio.h>
#include<algorithm>
using namespace std;
int n,a[105];
bool cmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
	while(scanf("%d",&n)){
		if(n==0)break;
		for(int i=0;i<n;i++)scanf("%d",&a[i]);
		sort(a,a+n,cmp);
		for(int i=0;i<n;i++)printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
