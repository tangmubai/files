#include<stdio.h>
#include<algorithm>
using namespace std;
struct node{
	int a1,b,c;	
}a[105];
bool cmp(node x,node y){
	if(x.c<y.c)return 1;
	else if(x.c==y.c){
		if(x.b<y.b)return 1;
		else if(x.b==y.b){
			return x.a1<y.a1;
		}
	}
	else return 0;
}
int main(){
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	int i=1;
	while(scanf("%d/%d/%d",&a[i].a1,&a[i].b,&a[i].c)!=EOF)i++;
	sort(a+1,a+i,cmp);
	for(int j=1;j<=i-1;j++){
		if(a[j].a1<10)printf("0%d/",a[j].a1);
		if(a[j].b<10)printf("0%d/",a[j].b);
		if(a[j].c<10)printf("0%d\n",a[j].c);
		if(a[j].a1>=10)printf("%d/",a[j].a1);
		if(a[j].b>=10)printf("%d/",a[j].b);
		if(a[j].c>=10)printf("%d\n",a[j].c);
	}
	return 0;
}
