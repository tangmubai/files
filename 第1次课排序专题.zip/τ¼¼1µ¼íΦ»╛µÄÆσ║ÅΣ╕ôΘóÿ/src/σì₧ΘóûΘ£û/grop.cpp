#include<stdio.h>
#include<algorithm>
using namespace std;int n,a[20];
int main(){
	freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=0;j<9;j++)scanf("%d",&a[j]);
		int x=a[0];
		for(int j=8;j>0;j--)if(a[j]<x)printf("%d ",a[j]),a[j]=0;
		printf("%d ",a[0]);a[0]=0;
		for(int j=1;j<9;j++)if(a[j]!=0)printf("%d ",a[j]);
		printf("\n");
	}
	return 0;
}
