#include<stdio.h>
#include<algorithm>
using namespace std;
int n;char s[100005][20];
struct node{
	int a1,b,c,d;	
}a[105];
bool cmp(node x,node y){
	if(x.c<y.c)return 1;
	else if(x.c==y.c){
		if(x.b<y.b)return 1;
		else if(x.b==y.b){
			if(x.a1<y.a1)return 1;
			else return x.d<y.d;
		}
	}
	else return 0;
}
int main(){
	freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%s",s[i]);
		a[i].a1=(s[i][6]-'0')*1000+(s[i][7]-'0')*100+(s[i][8]-'0')*10+(s[i][9]);
		a[i].b=(s[i][10]-'0')*10+(s[i][11]-'0');
		a[i].c=(s[i][12]-'0')*10+(s[i][13]-'0');
		//a[i].d=(s[i][0]-'0')*1e17+(s[i][1]-'0')*1e16+(s[i][2]-'0')*1e15+(s[i][3]-'0')*1e14+(s[i][4]-'0')*1e13+(s[i][5]-'0')*1e12+(s[i][6]-'0')*1e11+(s[i][7]-'0')*1e10+(s[i][8]-'0')*1e9+(s[i][9]-'0')*1e8+(s[i][10]-'0')*1e7+(s[i][11]-'0')*1e6+(s[i][12]-'0')*1e5+(s[i][13]-'0')*1e4+(s[i][14]-'0')*1e3+(s[i][15]-'0')*100+(s[i][16]-'0')*10+(s[i][17]-'0');
	}
	sort(a+1,a+n+1,cmp);
	for(int j=1;j<=n;j++)printf("%lld\n",a[j].d);
	return 0;
}
