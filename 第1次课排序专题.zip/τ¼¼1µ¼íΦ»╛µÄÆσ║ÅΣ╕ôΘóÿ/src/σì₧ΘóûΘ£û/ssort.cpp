#include<stdio.h>
#include<algorithm>
using namespace std;
int n,a[105];
int main(){
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(int i=0;i<n;i++)scanf("%d",&a[i]);
		sort(a,a+n);
		for(int i=0;i<n;i++)printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
