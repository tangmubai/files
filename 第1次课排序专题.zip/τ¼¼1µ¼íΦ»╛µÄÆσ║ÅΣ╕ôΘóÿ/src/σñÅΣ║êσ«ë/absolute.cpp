#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int aa[110];
bool cmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	for(;;){
		int n,j=1,k=1;
		scanf("%d",&n);
		if(!n) break;
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			if(a[i]<0) b[j]=a[i],j++;
			else c[k]=a[i],k++;
		}
		sort(b+1,b+j);
		sort(c+1,c+k);
		for(int i=1;i<j;i++)
			printf("%d ",b[i]);
		for(int i=k-1;i>1;i--)
			printf("%d ",c[i]);
		printf("%d\n",c[1]);
	}
//	int n;
//	while(cin>>n && n!=0){
//		for(int i=0;i<n;i++)
//			cin>>aa[i];
//		sort(aa,aa+n,cmp);
//		for(int i=0;i<n;i++)
//			cout<<aa[i]<<' ';
//		cout<<endl;
//	}
	return 0;
}
