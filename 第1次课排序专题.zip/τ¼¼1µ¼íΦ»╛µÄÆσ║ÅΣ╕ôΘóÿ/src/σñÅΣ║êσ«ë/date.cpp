#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
struct Node{
	int m,y,d;
}a[110];
bool cmp(Node a,Node b){
	if(a.y==b.y){
		if(a.m==b.m) return a.d<b.d;
		else return a.m<b.m;
	}
	else return a.y<b.y;
}
int n=1;
int main(){
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	while(scanf("%d/%d/%d",&a[n].m,&a[n].d,&a[n].y)!=EOF) n++;
	sort(a+1,a+n,cmp);
	for(int i=1;i<=n-1;i++){
//		if(a[i].m<10) printf("0%d/",a[i].m);
//		else printf("%d/",a[i].m);
//		if(a[i].d<10) printf("0%d/",a[i].d);
//		else printf("%d/",a[i].d);
//		if(a[i].y<1000){
//			if(a[i].y<100){
//				if(a[i].y<10) printf("000%d\n",a[i].y);
//				else printf("00%d\n",a[i].y);
//			}
//			else printf("0%d\n",a[i].y);
//		}
//		else printf("%d\n",a[i].y);
printf("%02d/%02d/%04d\n",a[i].m,a[i].d,a[i].y);
	}
		
	return 0;
}
