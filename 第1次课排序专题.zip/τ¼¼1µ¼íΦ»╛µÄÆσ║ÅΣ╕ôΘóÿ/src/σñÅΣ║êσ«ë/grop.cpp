#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int k[1010],a[1010],b[1010];
int n;
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int l=1,ll=1;
		for(int j=1;j<=9;j++)
			scanf("%d",&k[j]);
		for(int j=2;j<=9;j++){
			if(k[j]<k[1]) a[l++]=k[j];
			else b[ll++]=k[j];
		}
		for(int j=l-1;j>=1;j--)
			printf("%d ",a[j]);
		printf("%d",k[1]);
		for(int j=1;j<ll;j++)
			printf(" %d",b[j]);
		puts("");
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
	}
}
