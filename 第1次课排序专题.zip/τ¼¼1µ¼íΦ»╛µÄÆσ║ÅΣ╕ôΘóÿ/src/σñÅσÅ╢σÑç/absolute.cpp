#include <stdio.h>
#include <cctype>
#include <algorithm>
#include <iostream>
using namespace std;
const int N=1e2+5;

inline int read(int &x){
	int f=0; x=0;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=1;
		ch=getchar();
	}
	while(isdigit(ch)) x=x*10+ch-48,ch=getchar();
	if(f==1) x=-x;
	return x;
}

int a[N];

bool cmp(int a,int b){
	return abs(a)>abs(b);
}

int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int n;
	while(cin>>n&&n!=0) {
		for(int i=1;i<=n;i++) cin>>a[i];
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++) printf("%d ",a[i]);
		putchar('\n');
	}
	return 0;
}
