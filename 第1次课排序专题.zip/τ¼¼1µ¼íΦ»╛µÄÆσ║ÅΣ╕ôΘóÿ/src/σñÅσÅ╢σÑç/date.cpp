#include <stdio.h>
#include <cctype>
#include <algorithm>
#include <iostream>
using namespace std;
const int N=1e2+5;

inline void read(int &x){
	int f=0; x=0;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=1;
		ch=getchar();
	}
	while(isdigit(ch)) x=x*10+ch-48,ch=getchar();
	if(f==1) x=-x;
}

struct node{
	int n,y,r;
} a[N];
int l=0;

bool cmp(node a,node b){
	if(a.n!=b.n) return a.n<b.n;
	if(a.y!=b.y) return a.y<b.y;
	return a.r<b.r;
}

int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	while(scanf("%d/%d/%d",&a[l].y,&a[l].r,&a[l].n)!=EOF){
		++l;
	}
	sort(a,a+l,cmp);
		for(int i=0;i<l;i++){
			printf("%02d/%02d/%4d\n",a[i].y,a[i].r,a[i].n);
		}
	return 0;
}

