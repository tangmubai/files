#include <stdio.h>
#include <cctype>
#include <algorithm>
using namespace std;
const int N=1e2+5;

inline void read(int &x){
	int f=0; x=0;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=1;
		ch=getchar();
	}
	while(isdigit(ch)) x=x*10+ch-48,ch=getchar();
	if(f==1) x=-x;
}

int a[N],b[N],s[N];

int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int n;
	read(n);
	for(int i=1;i<=n;i++){
		int ls=0,lb=0;
		read(a[1]);
		for(int j=2;j<=9;j++){
			read(a[j]);
			if(a[j]>=a[1]) b[++lb]=a[j];
		}
		for(int j=9;j>=2;j--) if(a[j]<a[1]) s[++ls]=a[j];
		for(int j=1;j<=ls;j++) printf("%d ",s[j]);	
		printf("%d ",a[1]);
		for(int j=1;j<=lb;j++) printf("%d ",b[j]);
		putchar('\n');
	} 
	return 0;
}

