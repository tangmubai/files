#include <stdio.h>
#include <cctype>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
const int N=1e2+5;

struct node{
	string x;
	int f;
	int n;
}a[N];

bool cmp(node a,node b){
	if(a.f!=b.f) return a.f<b.f;
	if(a.x!=b.x) return a.x<b.x;
	return a.n<b.n;
}

int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i].x>>a[i].n>>a[i].f;
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++) cout<<a[i].x<<' '<<a[i].n<<' '<<a[i].f<<'\n';
	return 0;
}

