#include <cstdio>
#include <algorithm>

const int N = 101;

int num[N];

inline bool cmp (const int tmp1, const int tmp2) { return std :: abs(tmp1) > std :: abs(tmp2); }

template <typename Tp>
inline void read(Tp &num) {
	Tp flag = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flag = -1;
		c = getchar();
	}
	for (num = 0; c >= '0' && c <= '9'; c = getchar()) num = (num << 1) + (num << 3) + (c ^ '0');
	num *= flag;
}

int main() {
	freopen("absolute.in", "r", stdin);
	freopen("absolute.out", "w", stdout);
	int n;
	while (~scanf("%d", &n) && n) {
		for (int i = 1; i <= n; i++) read(num[i]);
		std :: sort(num + 1, num + 1 + n, cmp);
		for (int i = 1; i <= n; i++) printf("%d ", num[i]);
		puts("");
	}
	return 0;
}

