#include <string>
#include <iostream>
#include <algorithm>

const int N = 101;

struct Node{
	int m, d, y;
} date[N];

inline bool cmp(const Node s1, const Node s2) {
	if (s1.y != s2.y) return s1.y < s2.y;
	if (s1.m != s2.m) return s1.m < s2.m;
	return s1.d < s2.d;
}

int main() {
	freopen("date.in", "r", stdin);
	freopen("date.out", "w", stdout);
	int n = 1;
	while (~scanf("%d/%d/%d", &date[n].m, &date[n].d, &date[n].y)) n++;
	n--;
	std :: sort(date + 1, date + 1 + n, cmp);
	for (int i = 1; i <= n; i++) printf("%02d/%02d/%4d\n", date[i].m, date[i].d, date[i].y);
	return 0;
}

