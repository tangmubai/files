#include <cstdio>
#include <queue>

const int N = 100;

int num[N];

template <typename Tp>
inline void read(Tp &num) {
	Tp flag = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flag = -1;
		c = getchar();
	}
	for (num = 0; c >= '0' && c <= '9'; c = getchar()) num = (num << 1) + (num << 3) + (c ^ '0');
	num *= flag;
}

int main() {
	freopen("grop.in", "r", stdin);
	freopen("grop.out", "w", stdout);
	int n;
	read(n);
	while (n--) {
		std :: deque <int> ans;
		for (int i = 1; i <= 9; i++) read(num[i]);
		ans.push_back(num[1]);
		for (int i = 2; i <= 9; i++)
			if (num[i] >= num[1]) ans.push_back(num[i]);
			else ans.push_front(num[i]);
		while (ans.size()) {
			printf("%d ", ans.front());
			ans.pop_front();
		} 
		puts("");
	}
	return 0;
}

