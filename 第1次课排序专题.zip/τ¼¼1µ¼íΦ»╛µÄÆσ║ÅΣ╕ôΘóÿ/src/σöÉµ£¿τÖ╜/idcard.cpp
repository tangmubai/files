#include <string>
#include <iostream>
#include <algorithm>

const int N = 100001;

std :: string id[N];

inline bool cmp(const std :: string s1, const std :: string s2) {
	std :: string t1 = s1.substr(6,8), t2 = s2.substr(6,8);
	if (t1 != t2) return t1 > t2;
	return s1 > s2;
}

int main() {
	freopen("idcard.in", "r", stdin);
	freopen("idcard.out", "w", stdout);
	int n;
	std :: cin >> n;
	for (int i = 1; i <= n; i++) std :: cin >> id[i];
	std :: sort(id + 1, id + 1 + n, cmp);
	for (int i = 1; i <= n; i++) std :: cout << id[i] << '\n';
	return 0;
}

