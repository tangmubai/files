#include <string>
#include <iostream>
#include <algorithm>

const int N = 1001;

struct Node {
	int s, y;
	std :: string name;
}s[N];

inline bool cmp(const Node s1, const Node s2) {
	if (s1.s != s2.s) return s1.s < s2.s;
	if (s1.name != s2.name) return s1.name < s2.name;
	return s1.y < s2.y;
}

int main() {
	freopen("score.in", "r", stdin);
	freopen("score.out", "w", stdout);
	int n;
	while (std :: cin >> n) {
		for (int i = 1; i <= n; i++) std :: cin >> s[i].name >> s[i].y >> s[i].s;
		std :: sort(s + 1, s + 1 + n, cmp);
		for (int i = 1; i <= n; i++) std :: cout << s[i].name << " " << s[i].y << " " << s[i].s << '\n';
	}
	return 0;
}

