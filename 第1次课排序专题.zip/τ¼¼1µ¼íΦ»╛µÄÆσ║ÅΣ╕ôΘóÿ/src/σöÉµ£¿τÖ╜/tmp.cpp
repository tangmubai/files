#include <iostream>
#include <string>
#include <algorithm>

const int N = 10;

std :: string date[N];

int main() {
	int n = 0;
	std :: string s1;
	std :: cin >> s1;
	int p1, p2, s = s1.size() - 1;
	std :: string y1, m1, d1, y2, m2, d2;
	p1 = s1.find("/"); m1 = s1.substr(0, p1);
	p2 = s1.find("/", p1 + 1); d1 = s1.substr(p1 + 1, p2 - p1 - 1);
	y1 = s1.substr(p2 + 1, s - p2);
	std :: cout << m1 << d1 << y1;
	return 0;
}

