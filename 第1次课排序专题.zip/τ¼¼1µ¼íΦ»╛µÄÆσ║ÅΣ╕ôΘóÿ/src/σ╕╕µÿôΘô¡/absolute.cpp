#include <stdio.h>
#include <algorithm>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
struct Node {
	int num;
	int anum;
}a[105];

bool cmp(Node x,Node y){
	return x.anum>y.anum;
}
main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int n;
	while(1){
		n=re();
		if(!n)break;
		for(int i=1;i<=n;++i){
			a[i].num=re();a[i].anum=abs(a[i].num);
		}
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;++i){
			printf("%d ",a[i].num);
		}
		printf("\n");
	}
	return 0;
}

