#include <stdio.h>
#include <algorithm>
#include <cmath>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	printf("%lld\n",pow(2,64));
	return 0;
}

