#include <stdio.h>
#include <algorithm>
#include <iostream>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}

struct Date{
	int year;
	int month;
	int day;
}a[105];

bool cmp(Date x,Date y){
	if(x.year==y.year){
		if(x.month=y.month){
			if(x.day==y.day){
				
			}
			return x.day<y.day;
		}
		return x.month<y.month;
	}
	return x.year<y.year;
}
main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
    int n,num=0;char ch;
	while(cin>>a[++num].month){
		scanf("/");
		a[num].day=re();
		scanf("/");
		a[num].year=re();
	}
	--num;
	sort(a+1,a+1+num,cmp);
	for(int i=1;i<=num;++i){
		printf("%02d/%02d/%4d\n",a[i].month,a[i].day,a[i].year);
	}
	return 0;
}

