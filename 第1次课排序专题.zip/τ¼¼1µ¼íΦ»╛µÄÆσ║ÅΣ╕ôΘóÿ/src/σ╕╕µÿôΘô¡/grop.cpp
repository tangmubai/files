#include <stdio.h>
#include <algorithm>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
int a[15];
main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int n=re();
	for(int k=1;k<=n;++k){
	for(int i=1;i<=9;++i){
		a[i]=re();
//		scanf("%d",&a[i]);
	}
	for(int j=9;j>=2;--j){
		if(a[j]<a[1])printf("%d ",a[j]);
	}
	printf("%d ",a[1]);
	for(int j=2;j<=9;++j){
		if(a[j]>=a[1])printf("%d ",a[j]);
	}
	printf("\n");
	}
	return 0;
}

