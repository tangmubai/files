#include <stdio.h>
#include <algorithm>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}

struct Node {
	char ch[20];
	int birth;
}a[100005];

bool cmp(Node x,Node y){
	if(x.birth==y.birth)return x.ch+1>y.ch+1;
	return x.birth>y.birth;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n=re(),d;
	for(int i=1;i<=n;++i){
		scanf("%s",a[i].ch+1);
		d=0;
		for(int j=7;j<=14;++j){
			d=(d<<3)+(d<<1)+(a[i].ch[j]-'0');
		}
		a[i].birth=d;
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;++i){
		printf("%s\n",a[i].ch+1);
	}
	return 0;
}

