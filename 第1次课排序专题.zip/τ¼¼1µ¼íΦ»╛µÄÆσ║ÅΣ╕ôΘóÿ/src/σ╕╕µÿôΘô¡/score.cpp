#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <iostream>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
struct Node {
	char name[105];
	int age;
	int score;
}a[105];

bool cmp(Node x,Node y){
	if(x.score==y.score){
		if(strcmp(x.name,y.name)==0){
			return x.age<y.age;
		}
		return strcmp(x.name,y.name)<0;
	}
	return x.score<y.score;
}
main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;++i){
			cin>>a[i].name;a[i].age=re();a[i].score=re();
		}
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;++i){
			cout << a[i].name <<' ';
			printf("%d %d\n",a[i].age,a[i].score);
		}
	}
	return 0;
}

