#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,a[105];
bool cmp(int p,int q){return abs(p)>abs(q);}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	scanf("%d",&n);
	while(n!=0){
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++)printf("%d ",a[i]);
		puts(""); 
		scanf("%d",&n);
	}
	return 0;
}
