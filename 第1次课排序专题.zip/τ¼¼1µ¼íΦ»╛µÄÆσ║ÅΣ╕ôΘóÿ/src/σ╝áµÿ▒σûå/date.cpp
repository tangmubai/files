#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
struct date{
	char ch[20];
	int a,b,c;
}s[105];
bool cmp(date p,date q){
	if(p.c!=q.c)return p.c<q.c;
	if(p.a!=q.a)return p.a<q.a;
	return p.b<q.b;
}
int main(){
freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int n=1;
	while(scanf("%s",s[n].ch)!=EOF){
		s[n].a=(s[n].ch[0]-'0')*10+(s[n].ch[1]-'0');
		s[n].b=(s[n].ch[3]-'0')*10+(s[n].ch[4]-'0');
		s[n].c=(s[n].ch[6]-'0')*1000+(s[n].ch[7]-'0')*100-+(s[n].ch[8]-'0')*10+(s[n].ch[9]-'0');
		n++;
	} 
//		for(int i=1;i<=n;i++)printf("%s\n",s[n].ch);

//	printf("%s\n",s[1].ch);
	n--;
	sort(s+1,s+1+n,cmp);
	for(int i=1;i<=n;i++)printf("%s\n",s[i].ch);
	return 0;
}
