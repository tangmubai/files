#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,a[1005];
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		memset(a,0,sizeof(a));
		for(int i=1;i<=9;i++)scanf("%d",&a[i]);
		for(int i=9;i>=2;i--)if(a[i]<a[1])printf("%d ",a[i]);
		printf("%d ",a[1]);
		for(int i=2;i<=9;i++)if(a[i]>=a[1])printf("%d ",a[i]);
		puts("");
	}
	
	return 0;
}
