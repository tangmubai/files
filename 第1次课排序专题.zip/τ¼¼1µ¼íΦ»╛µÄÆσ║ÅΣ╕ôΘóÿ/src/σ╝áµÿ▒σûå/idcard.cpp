#include<algorithm>
#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
int n;
struct date{
	int y,m,d;
	string id;
}s[105];
bool cmp(date p,date q){
	if(p.y!=q.y)return p.y>q.y;
	if(p.m!=q.m)return p.m>q.m;
	if(p.d!=q.d)return p.d>q.d;
	return p.id>q.id;
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;i++){
			cin>>s[i].id;
			s[i].y=1000*(s[i].id[0+6]-'0')*1000+(s[i].id[1+6]-'0')*100+(s[i].id[2+6]-'0')*10+(s[i].id[3+6]-'0');
			s[i].m=10*(s[i].id[4+6]-'0')+(s[i].id[5+6]-'0');
			s[i].d=10*(s[i].id[6+6]-'0')+(s[i].id[7+6]-'0');
		}
		sort(s+1,s+1+n,cmp);
		for(int i=1;i<=n;i++)cout<<s[i].id<<endl;
	}
	return 0;
}

