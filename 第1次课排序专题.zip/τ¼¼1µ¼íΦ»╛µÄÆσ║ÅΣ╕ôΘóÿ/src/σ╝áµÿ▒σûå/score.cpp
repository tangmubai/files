#include<bits/stdc++.h>
using namespace std;
struct soc{
	char id[101];
	int p,a;
}x[1001];
int n;
bool cmp(soc p,soc q){
	if(p.p!=q.p)return p.p<q.p;
	if(p.id!=q.id)return p.id<q.id;
	if(p.a!=q.a)return p.a<q.a;
}
int main(){
	freopen("score.in","r",stdin);
	freopen("score.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;i++)scanf("%s %d %d",x[i].id,&x[i].a,&x[i].p);
		sort(x+1,x+1+n,cmp);
		for(int i=1;i<=n;i++)printf("%s %d %d\n",x[i].id,x[i].a,x[i].p);
	}
	return 0;
}
