#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;
int a[101];
bool cmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int n;
	while(cin>>n&&n!=0){
		for(int i=0;i<n;i++){
			cin>>a[i];
		}
		sort(a,a+n,cmp);
		for(int i=0;i<n;i++){
			cout<<a[i]<<" ";
		}
		cout<<endl; 
	}
	return 0;
}

