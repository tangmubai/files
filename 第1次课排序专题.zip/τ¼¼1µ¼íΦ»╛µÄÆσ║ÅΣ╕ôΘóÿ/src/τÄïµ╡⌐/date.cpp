#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;
struct data{
	int day;
	int month;
	int year;
}ab[101];
bool cmp(struct data a,struct data b){
	if(a.year!=b.year){
		return a.year<b.year;
	}else{
		if(a.month!=b.month){
			return a.month<b.month;
		}else{
			return a.day<b.day;
		}
	}
}
int main(){
	freopen("date.in","r",stdin);
	freopen("date.out","w",stdout);
	int i=0;
	while(scanf("%d/%d/%d",&ab[i].month,&ab[i].day,&ab[i].year)!=EOF){
		i++;
	}
	sort(ab,ab+i,cmp);
	for(int s=0;s<i;s++){
		printf("%02d/%02d/%04d\n",ab[s].month,ab[s].day,ab[s].year);
	}
	return 0;
}

