#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int n;
	cin>>n;
	while(n--){
		int a[10];
		for(int i=1;i<=9;i++){
			cin>>a[i];
		}
		int x=a[1];
		for(int i=9;i>=2;i--){
			if(a[i]<x) cout<<a[i]<<" ";
		}
		cout<<x<<" ";
		for(int i=2;i<=9;i++){
			if(a[i]>=x) cout<<a[i]<<" ";
		}
		cout<<endl;
	}
	return 0;
}

