#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
struct pp{
	char num[20];
	char bro[10];
}ab[100001];
bool cmp(struct pp a,struct pp b){
	if(!strcmp(a.bro,b.bro))
		return strcmp(a.num,b.num)>0;
	else{
		return strcmp(a.bro,b.bro)>0;
	}
}
int main(){
	freopen("idcard.in","r",stdin);
	freopen("idcard.out","w",stdout);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		scanf("%s",&ab[i].num);
		strncpy(ab[i].bro,&ab[i].num[6],8);
	}
	sort(ab,ab+n,cmp);
	for(int i=0;i<n;i++){
		printf("%s\n",ab[i].num);
	}
	return 0;
}

