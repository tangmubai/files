#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[105];
int main(){
//	freopen("ssort.in","r",stdin);
//	freopen("ssort.out","w",stdout);
	int n;
	while(cin>>n){
		for(int i=0;i<n;i++){
			cin>>a[i];
		}
		sort(a,a+n);
		for(int i=0;i<n;i++){
			cout<<a[i]<<" ";
		}
		cout<<endl;
	}
	return 0;
}

