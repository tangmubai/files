#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int N = 110;

int a[N];

bool cmp(int a, int b)
{
	return abs(a) > abs(b);
}

int main()
{
	freopen("absolute.in", "r", stdin);
	freopen("absolute.out", "w", stdout);
	
	int n;
	while (cin >> n, n)
	{
		for (int i = 1; i <= n; i ++ )
			cin >> a[i];
		
		sort(a + 1, a + n + 1, cmp);
		
		for (int i = 1; i <= n; i ++ )
			cout << a[i] << ' ';
		
		cout << endl;
	}
	return 0;
}

