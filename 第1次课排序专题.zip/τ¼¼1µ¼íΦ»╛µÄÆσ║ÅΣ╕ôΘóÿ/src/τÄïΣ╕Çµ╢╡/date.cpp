#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

const int N = 110;

string str[N];

struct date
{
	int year, month, day, pos;	
}a[N];

bool cmp(date p, date q)
{
	if (p.year != q.year)
		return p.year < q.year;
	
	if (p.month != q.month)
		return p.month < q.month;	
		
	return p.day < q.day;
}

int main()
{
	freopen("date.in", "r", stdin);
	freopen("date.out", "w", stdout);

	int l = 0;
//	while (~scanf("%s*c%d*c%d", &a[ ++ l].month, &a[l].day, &a[l].year));
	
	while (cin >> str[ ++ l])
	{
		int cnt = 0;
		for (int i = 0; i < 2; i ++ )
			cnt = cnt * 10 + str[l][i] - '0';
		
		a[l].month = cnt;
		cnt = 0;
		for (int i = 3; i < 5; i ++ )
			cnt = cnt * 10 + str[l][i] - '0';
		a[l].day = cnt;
		
		cnt = 0;
		for (int i = 6; i < 10; i ++ )
			cnt = cnt * 10 + str[l][i] - '0';
		a[l].year = cnt;
		
		a[l].pos = l;
	}
//	cout << 1 << endl;
	l -- ;
	
	sort(a + 1, a + l + 1, cmp);
	
	for (int i = 1; i <= l; i ++ )
		cout << str[a[i].pos] << endl;
	
	return 0;
}

