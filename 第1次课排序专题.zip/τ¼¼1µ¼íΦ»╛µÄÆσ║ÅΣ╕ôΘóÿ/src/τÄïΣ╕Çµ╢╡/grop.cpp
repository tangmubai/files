#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

const int N = 11;

int la, lb;
int a[N], b[N], s[N];

int main()
{
	freopen("grop.in", "r", stdin);
	freopen("grop.out", "w", stdout);
	
	int t;
	cin >> t;
	
	while (t -- )
	{
		la = 0, lb = 0;
		
		for (int i = 1; i <= 9; i ++ )
			cin >> s[i];
		
		for (int i = 2; i <= 9; i ++ )	
			if (s[i] >= s[1])
				b[ ++ lb] = s[i];
		for (int i = 9; i >= 2; i -- )
			if (s[i] < s[1])
				a[ ++ la] = s[i];
					
		for (int i = 1; i <= la; i ++ )
			cout << a[i] << ' ';
		
		cout << s[1] << ' ';
		
		for (int i = 1; i <= lb; i ++ )
			cout << b[i] << ' ';
		
		cout << endl;
	}
	return 0;
}

