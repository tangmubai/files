#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

const int N = 100010;

struct cz
{
	string a;
	int y, m, d;
}c[N];

bool cmp(cz p, cz q)
{
	if (p.y != q.y)
		return p.y > q.y;
	
	if (p.m != q.m)
		return p.m > q.m;	
	if (p.d != q.d)	
		return p.d > q.d;
	
	return p.a > q.a;
}

int main()
{
	freopen("idcard.in", "r", stdin);
	freopen("idcard.out", "w", stdout);
	
	int n;
	cin >> n;
	for (int l = 1; l <= n; l ++ )
	{
		cin >> c[l].a;
		
		int cnt = 0;
		for (int i = 6; i < 10; i ++ )
			cnt = cnt * 10 + c[l].a[i] - '0';
		c[l].y = cnt;
		cnt = 0;
		for (int i = 10; i < 12; i ++ )
			cnt = cnt * 10 + c[l].a[i] - '0';
		c[l].m = cnt;
		
		cnt = 0;
		for (int i = 12; i < 14; i ++ )
			cnt = cnt * 10 + c[l].a[i] - '0';
		c[l].d = cnt;
	}
	
	sort(c + 1, c + n + 1, cmp);
	
	for (int i = 1; i <= n; i ++ )
		cout << c[i].a << endl;
		
	return 0;
}

