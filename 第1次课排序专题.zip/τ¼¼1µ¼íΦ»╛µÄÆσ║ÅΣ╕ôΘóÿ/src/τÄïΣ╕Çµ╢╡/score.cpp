#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

struct stu
{
	string n;
	int o, d;
}a[1010];// �����С��һ�����ܿ�С��Ҫ����ÿһ���⿴���ݷ�Χ�����뵱Ȼ 

bool cmp(stu p, stu q)
{
	if (p.d != q.d)
		return p.d < q.d;
	if (p.n != q.n)
		return p.n < q.n;
	return p.o < q.o;
}

int main()
{
	freopen("score.in", "r", stdin);
	freopen("score.out", "w", stdout);
	
	int n;
	while (cin >> n)
	{
		for (int i = 1; i <= n; i ++ )
			cin >> a[i].n >> a[i].o >> a[i].d;
	
		sort(a + 1, a + n + 1, cmp);
	
		for (int i = 1; i <= n; i ++ )
			cout << a[i].n << ' ' << a[i].o << ' ' << a[i].d << endl;
	}
	return 0;
}

