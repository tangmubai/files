#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

const int N = 110;

int a[N];

int main()
{
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);

	int n;
	while (cin >> n)
	{
		for (int i = 1; i <= n; i ++ )
			cin >> a[i];
		
		sort(a + 1, a + n + 1);
		
		for (int i = 1; i <= n; i ++ )
			cout << a[i] << ' ';
		
		cout << endl;
	}
	return 0;
}
