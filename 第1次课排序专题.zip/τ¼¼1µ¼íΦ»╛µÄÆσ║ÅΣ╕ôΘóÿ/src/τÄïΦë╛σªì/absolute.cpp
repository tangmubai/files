#include<bits/stdc++.h>
using namespace std;
bool cmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen("absolute.in","r",stdin);
	freopen("absolute.out","w",stdout);
	int a[105],n;
	scanf("%d",&n);
	while(n!=0){
	    for(int i=0;i<n;i++)
	    	scanf("%d",&a[i]);
	    sort(a,a+n,cmp);
	    for(int i=0;i<n;i++)
		    printf("%d ",a[i]);
	    printf("\n");
	    scanf("%d",&n);
    }
	return 0;
}
