#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("grop.in","r",stdin);
	freopen("grop.out","w",stdout);
	int n,k[10],k1;
	scanf("%d",&n);
	while(n--){
		int a1=1,b1=1,a[10],b[10];
		scanf("%d",&k1);
		for(int i=1;i<=8;i++){
			scanf("%d",&k[i]);
			if(k[i]<k1)a[a1++]=k[i];
			if(k[i]>=k1)b[b1++]=k[i];
		}
		for(int i=a1-1;i>=1;i--)printf("%d ",a[i]);
		printf("%d ",k1);
		for(int i=1;i<=b1-1;i++)printf("%d ",b[i]);
		printf("\n");
	}
	return 0;
}
