#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int a[105],n;
	while(scanf("%d",&n)!=EOF){
	    for(int i=1;i<=n;i++)
	         scanf("%d",&a[i]);
	    sort(a,a+n+1);
	    for(int i=1;i<=n;i++)
	        printf("%d ",a[i]);
	    printf("\n");
    }
	return 0;
}
