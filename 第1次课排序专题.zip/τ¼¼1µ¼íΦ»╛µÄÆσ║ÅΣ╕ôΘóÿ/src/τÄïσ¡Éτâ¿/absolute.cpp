#include "cstdio"
#include "cmath"
#include "algorithm"
using namespace std;
int n,a[100005];
int cmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen ("absolute.in","r",stdin);
	freopen ("absolute.out","w",stdout);
	while (1){
		scanf ("%d",&n);
		if (n==0) break;
		for (int i=1;i<=n;i++) scanf ("%d",&a[i]);
		sort (a+1,a+1+n,cmp);
		for (int i=1;i<=n;i++) printf ("%d ",a[i]);
		printf ("\n");
	}
	return 0;
}
