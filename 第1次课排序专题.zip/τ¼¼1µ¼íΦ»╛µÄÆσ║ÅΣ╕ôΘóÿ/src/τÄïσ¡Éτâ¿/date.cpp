#include "cstdio"
#include "algorithm"
using namespace std;
struct node{
	int y,m,d;
}a[100005];
int cmp(node a,node b){
	if (a.y!=b.y) return a.y<b.y;
	else if (a.m!=b.m) return a.m<b.m;
	else return a.d<b.d;
}
int main(){
	freopen ("date.in","r",stdin);
	freopen ("date.out","w",stdout);
	int n=1;
	while (scanf ("%d/%d/%d",&a[n].m,&a[n].d,&a[n].y)!=EOF){
		n++;
	}
	n--;
	sort (a+1,a+1+n,cmp);
	for (int i=1;i<=n;i++){
		if (a[i].m<10) printf ("0");
		printf ("%d/",a[i].m);
		if (a[i].d<10) printf ("0");
		printf ("%d/",a[i].d);
		if (a[i].y<10) printf ("0");
		if (a[i].y<100) printf ("0");
		if (a[i].y<1000) printf ("0");
		printf ("%d\n",a[i].y);
	}
	return 0;
} 
