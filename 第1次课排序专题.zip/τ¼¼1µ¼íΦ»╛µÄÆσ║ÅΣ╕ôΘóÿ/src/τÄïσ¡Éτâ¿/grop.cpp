#include "cstdio"
#include "algorithm"
using namespace std;
int n,a[10005];
int main(){
	freopen ("grop.in","r",stdin);
	freopen ("grop.out","w",stdout);
	scanf ("%d",&n);
	while (n--){
		for (int i=1;i<=9;i++) scanf ("%d",&a[i]);
		for (int i=9;i>1;i--) if (a[i]<a[1]) printf ("%d ",a[i]);
		printf ("%d ",a[1]);
		for (int i=2;i<=9;i++) if (a[i]>=a[1]) printf ("%d ",a[i]);
		printf ("\n");
	}
	return 0;
}
