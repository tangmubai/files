#include "cstdio"
#include "algorithm"
using namespace std;
int n;
struct node{
	unsigned long long x,y;
}a[100005];
int cmp(node a,node b){
	if (a.y!=b.y) return a.y>b.y;
	else return a.x>b.x;
}
int main(){
	freopen ("idcard.in","r",stdin);
	freopen ("idcard.out","w",stdout);
	scanf ("%d",&n);
	for (int i=1;i<=n;i++){
		scanf ("%llu",&a[i].x);
		a[i].y=(a[i].x/10000)%100000000;
		
	}
	sort (a+1,a+1+n,cmp);
	for (int i=1;i<=n;i++) printf ("%llu\n",a[i].x);
	return 0;
}
