#include "cstdio"
#include "iostream"
#include "cstring"
#include "string"
#include "algorithm"
using namespace std;
int n;
struct node{
	string s;
	int x,y;
}a[1005];
int cmp(node a,node b){
	if (a.y!=b.y) return a.y<b.y;
	else if (a.s!=b.s) return a.s<b.s;
	else return a.x<b.x;
}                                 
int main(){
	freopen ("score.in","r",stdin);
	freopen ("score.out","w",stdout);
	ios::sync_with_stdio(false);
	while (cin>>n){
		for (int i=1;i<=n;i++){
			cin>>a[i].s>>a[i].x>>a[i].y;
		}
		sort (a+1,a+1+n,cmp);
		for (int i=1;i<=n;i++) cout<<a[i].s<<' '<<a[i].x<<' '<<a[i].y<<endl;
	}
	return 0;
}
