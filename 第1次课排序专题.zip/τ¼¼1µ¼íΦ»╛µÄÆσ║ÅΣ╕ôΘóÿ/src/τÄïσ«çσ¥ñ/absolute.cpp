#include<algorithm>
#include<stdio.h>
#include<math.h>
using namespace std;
int input[100];
int qread(){
	int a=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a*f;
}
bool qcmp(int a,int b){
	return abs(a)>abs(b);
}
int main(){
	freopen("absolute.in","r",stdin);freopen("absolute.out","w",stdout);
	int n=qread();
	while(n){
		for(int i=1;i<=n;++i) input[i]=qread();
		sort(input+1,input+1+n,qcmp);
		for(int i=1;i<=n;++i){
			printf("%d",input[i]);putchar(' ');
		}
		puts("");
		scanf("%d",&n);
	}
	return 0;
}
