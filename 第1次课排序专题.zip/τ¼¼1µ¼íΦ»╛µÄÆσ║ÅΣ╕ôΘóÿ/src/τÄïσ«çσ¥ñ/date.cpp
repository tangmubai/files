#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
string a;
struct node{
	int m,d,y;
}input[105];
bool qcmp(node a,node b){
	if(a.y!=b.y) return a.y<b.y;
	if(a.m!=b.m) return a.m<b.m;
	return a.d<b.d;
}
int main(){
	freopen("date.in","r",stdin);freopen("date.out","w",stdout);
	int n=0;
	while(cin>>a){
		input[++n].m=(a[0]^'0')*10+(a[1]^'0');
		input[n].d=(a[3]^'0')*10+(a[4]^'0');
		input[n].y=(a[6]^'0')*1000+(a[7]^'0')*100+(a[8]^'0')*10+(a[9]^'0');
	}
	sort(input+1,input+1+n,qcmp);
	for(int i=1;i<=n;++i){
		if(input[i].m>=10) printf("%d",input[i].m);
		else printf("0%d",input[i].m);
		putchar('/');
		if(input[i].d>=10) printf("%d",input[i].d);
		else printf("0%d",input[i].d);
		putchar('/');
		printf("%d",input[i].y);puts("");
	}
	return 0;
}
