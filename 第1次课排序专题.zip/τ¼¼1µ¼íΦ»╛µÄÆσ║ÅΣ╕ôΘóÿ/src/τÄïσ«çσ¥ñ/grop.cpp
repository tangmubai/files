#include<stdio.h>
using namespace std;
int input[15];
int qread(){
	int a=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a*f;
}
int main(){
	freopen("grop.in","r",stdin);freopen("grop.out","w",stdout);
	int n=qread();
	while(n--){
		for(int i=1;i<=9;++i) input[i]=qread();
		for(int i=9;i>=1;--i){
			if(input[i]<input[1]){
				printf("%d",input[i]);putchar(' ');
			}
		}
		for(int i=1;i<=9;++i){
			if(input[i]>=input[1]){
				printf("%d",input[i]);putchar(' ');
			}
		}
		puts("");
	}
	return 0;
}
