#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
string q1,q2,input[100000];
bool qcmp(string a,string b){
	q1=a[6]+a[7]+a[8]+a[9]+a[10]+a[11]+a[12]+a[13];
	q2=b[6]+b[7]+b[8]+b[9]+b[10]+b[11]+b[12]+b[13];
	if(q1!=q2) return q1>q2;
	return a>b;
}
int main(){
	freopen("idcard.in","r",stdin);freopen("idcard.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i) cin>>input[i];
	sort(input+1,input+1+n,qcmp);
	for(int i=1;i<=n;++i){
		cout<<input[i];puts("");
	}
	return 0;
}
