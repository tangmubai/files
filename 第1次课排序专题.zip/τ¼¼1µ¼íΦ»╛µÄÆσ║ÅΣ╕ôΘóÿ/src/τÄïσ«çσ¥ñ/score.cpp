#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
struct node{
	int nl,f;
	string name;
}input[105];
int qread(){
	int a=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a*f;
}
bool qcmp(node a,node b){
	if(a.f!=b.f) return a.f<b.f;
	if(a.name!=b.name) return a.name<b.name;
	return a.nl<b.nl;
}
int main(){
	freopen("score.in","r",stdin);freopen("score.out","w",stdout);
	int n=qread();
	for(int i=1;i<=n;++i){
		cin>>input[i].name;
		input[i].nl=qread();
		input[i].f=qread();
	}
	sort(input+1,input+1+n,qcmp);
	for(int i=1;i<=n;++i){
		cout<<input[i].name;putchar(' ');printf("%d",input[i].nl);putchar(' ');printf("%d",input[i].f);puts("");
	}
	return 0;
}
