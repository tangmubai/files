#include<algorithm>
#include<stdio.h>
using namespace std;
int input[105];
int qread(){
	int a=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a*f;
}
int main(){
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	int n=qread();
	for(int i=1;i<=n;++i) input[i]=qread();
	sort(input+1,input+1+n);
	for(int i=1;i<=n;++i){
		printf("%d",input[i]);putchar(' ');
	}
	puts("");
	return 0;
}
