#include <cstdio>
#include <algorithm>
using namespace std;
int n,i,a[101];
bool cmp (int a,int b) {return (a>=0?a:a*-1)>(b>=0?b:b*-1);}
int main () {
	freopen ("absolute.in","r",stdin);
	freopen ("absolute.out","w",stdout);
	while (1) {
		scanf ("%d",&n);
		if (n==0) break;
		for (i=1;i<=n;i++) scanf ("%d",&a[i]);
		sort (a+1,a+n+1,cmp);
		for (i=1;i<=n;i++) printf ("%d ",a[i]);
		printf ("\n");
	}
	return 0;
}
