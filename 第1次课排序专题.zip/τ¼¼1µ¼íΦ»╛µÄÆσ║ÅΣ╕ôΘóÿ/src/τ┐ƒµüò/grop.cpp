#include <cstdio>
using namespace std;
int t,i,a[10],l[10],r[10],k1,k2;
int main () {
	freopen ("grop.in","r",stdin);
	freopen ("grop.out","w",stdout);
	scanf ("%d",&t);
	while (t--) {
		k1=k2=0;
		for (i=1;i<=9;i++) scanf ("%d",&a[i]);
		for (i=2;i<=9;i++) {
			if (a[i]<a[1]) l[++k1]=a[i];
			if (a[i]>=a[1]) r[++k2]=a[i];
		}
		for (i=k1;i;i--) printf ("%d ",l[i]);
		printf ("%d ",a[1]);
		for (i=1;i<=k2;i++) printf ("%d ",r[i]);
		printf ("\n");
	}
	return 0;
}
