#include <cstdio>
#include <algorithm>
using namespace std;
int n,i;
struct rq{char c[101];}a[101];
bool cmp (rq a,rq b) {
	int m1=(a.c[11]-48)*10+(a.c[12]-48);
	int d1=(a.c[13]-48)*10+(a.c[14]-48);
	int y1=(a.c[7]-48)*1000+(a.c[8]-48)*100+(a.c[9]-48)*10+(a.c[10]-48);
	int m2=(b.c[11]-48)*10+(b.c[12]-48);
	int d2=(b.c[13]-48)*10+(b.c[14]-48);
	int y2=(b.c[7]-48)*1000+(b.c[8]-48)*100+(b.c[9]-48)*10+(b.c[10]-48);
	if (y1!=y2) return y1>y2;
	if (m1!=m2) return m1>m2;
	return d1>d2;
}
int main () {
	freopen ("idcard.in","r",stdin);
	freopen ("idcard.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) scanf ("%s",a[i].c+1);
	sort (a+1,a+n+1,cmp);
	for (i=1;i<=n;i++) printf ("%s\n",a[i].c+1);
	return 0;
}
