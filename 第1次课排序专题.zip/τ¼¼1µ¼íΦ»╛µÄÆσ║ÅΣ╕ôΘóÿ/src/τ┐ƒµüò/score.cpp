#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n,i;
struct xs {char xm[101]; int nl,cj;}a[1001];
bool cmp (xs a,xs b) {
	if (a.cj!=b.cj) return a.cj<b.cj;
	if (strcmp (a.xm,b.xm)!=0) return strcmp (a.xm,b.xm)==-1;
	return a.nl<b.nl;
}
int main () {
	freopen ("score.in","r",stdin);
	freopen ("score.out","w",stdout);
	while (scanf ("%d",&n)!=EOF) {
		for (i=1;i<=n;i++) scanf ("%s%d%d",a[i].xm,&a[i].nl,&a[i].cj);
		sort (a+1,a+n+1,cmp);
		for (i=1;i<=n;i++) printf ("%s %d %d\n",a[i].xm,a[i].nl,a[i].cj);
		printf ("\n");
	}
	return 0;
}
