#include<iostream>
#include<algorithm>
#include<string>
#include<string.h>
#include <math.h>
using namespace std;

struct ee{
	int num;
	char color;
}ab[6]; 

bool cmp(struct ee aa,struct ee bb)
{
  if(aa.num==bb.num)
    return aa.color<bb.color;
  else 
    return aa.num<bb.num;
	
} 

int main()
{
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	char s[16];
	cin>>s;
	int a=0,b=0;
    for(int i=0;i<16;i++)
      {
      	if(s[i]>='2' && s[i]<='9') ab[a++].num=s[i]-'0';
		else if(s[i]=='1') ab[a++].num=10;
		else if(s[i]=='J') ab[a++].num=11;
		else if(s[i]=='Q') ab[a++].num=12;
		else if(s[i]=='K') ab[a++].num=13;
		else if(s[i]=='A') ab[a++].num=14;
		else if(s[i]=='d') ab[b++].color='0';
		else if(s[i]=='c') ab[b++].color='1';
		else if(s[i]=='h') ab[b++].color='2';
		else if(s[i]=='s') ab[b++].color='3';
      }	
      sort(ab,ab+5,cmp);
     for(int i=0;i<5;i++)
     {
     	if(ab[i].num>=2 && ab[i].num<=9) cout<<ab[i].num;
     	else if(ab[i].num==10) cout<<10;
		else if(ab[i].num==11) cout<<'J';
		else if(ab[i].num==12) cout<<'Q';
		else if(ab[i].num==13) cout<<'K';
		else if(ab[i].num==14) cout<<'A';
		if(ab[i].color=='0') cout<<'d'<<" ";
		else if(ab[i].color=='1') cout<<'c'<<" ";
		else if(ab[i].color=='2') cout<<'h'<<" ";
		else if(ab[i].color=='3') cout<<'s'<<" ";
     }
    return 0;
}
