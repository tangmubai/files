#include<iostream>
#include<algorithm>
#include<string>
#include<string.h> 
using namespace std;

int n,c;
    
struct ee{
	char num[10];
	char name[10];
	int score;
}ab[100010];

bool cmp(struct ee a,struct ee b)
{
	if(c==1)
		return strcmp(a.num,b.num)<0;
	else if(c==2)
		{
		  if(!strcmp(a.name,b.name)) 
		    return strcmp(a.num,b.num)<0;
		  else
		  	return strcmp(a.name,b.name)<0;
	    }
	else if(c==3)
	      {
	      	if(a.score!=b.score)
		      return a.score<b.score;
		    else 
		      return strcmp(a.num,b.num)<0; 
	      }
			
} 

int main()
{
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int sum=0;	
	while(cin>>n>>c && n!=0)
     {
     	sum++;
     	for(int i=0;i<n;i++)
    	 scanf("%s %s %d",&ab[i].num,&ab[i].name,&ab[i].score);
    	sort(ab,ab+n,cmp);
    	cout<<"Case "<<sum<<":"<<endl;
		for(int i=0;i<n;i++)
    	 printf("%s %s %d\n",ab[i].num,ab[i].name,ab[i].score);;  	
     }
    return 0;
}
