#include<iostream>
#include<algorithm>
using namespace std;

int ab[1001];

int main()
{
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
    int n;	
	while(cin>>n)
     {
     	for(int i=0;i<n;i++)
    	 cin>>ab[i];
    	sort(ab,ab+n);
    	cout<<ab[n-1]<<endl;
		if(n==1) cout<<-1<<endl;
		else
		{
		for(int i=0;i<n-1;i++)
    	  cout<<ab[i]<<' ';
     	cout<<endl;   
		} 
    	
     }
    return 0;
}
