#include<iostream>
#include<algorithm>
#include<string.h>
#include <math.h>
using namespace std;

char ss[21];
int m;

int main()
{
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	cin>>m;
    for(int i=0;i<m;i++) 
    {
    	scanf("%s",&ss);
    	int len;
    	len=strlen(ss);
    	sort(ss,ss+len);
    	printf("%s\n",ss);
    }
    return 0;
}
