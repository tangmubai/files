#include <cstdio>
#include <algorithm>
struct card{
	int num;
	char flor;
}a[11];
int gr[261],len;
bool cmp(card x,card y){
	if(x.num==y.num) return gr[x.flor]<gr[y.flor];
	return x.num<y.num;
}
char s[23];
int main(){
	freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	gr['d']=1,gr['c']=2,gr['h']=3,gr['s']=4;
	scanf("%s",s);
	for(int i=0;s[i];i++){
		int d=0;
		while(s[i]&&(s[i]>='0'&&s[i]<='9'||s[i]=='A'||s[i]=='Q'||s[i]=='J'||s[i]=='K')){
			if(s[i]=='A') d=14;
			else if(s[i]=='J') d=11;
			else if(s[i]=='Q') d=12;
			else if(s[i]=='K') d=13;
			else d=d*10+(s[i]-'0');
			++i;
		}
		a[++len].num=d,a[len].flor=s[i];
	}
	std::sort(a+1,a+1+len,cmp);
	for(int i=1;i<=len;i++){
		if(a[i].num==14) putchar('A');
		else if(a[i].num==11) putchar('J');
		else if(a[i].num==12) putchar('Q');
		else if(a[i].num==13) putchar('K');
		else printf("%d",a[i].num);
		putchar(a[i].flor);
		putchar(' ');
	}
	return 0;
}
