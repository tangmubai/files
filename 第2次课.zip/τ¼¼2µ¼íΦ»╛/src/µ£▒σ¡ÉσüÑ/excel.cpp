#include <string>
#include <iostream>
#include <algorithm>
struct stu{
	std::string id,name;
	int score;
}a[100003];
bool cmp1(stu x,stu y){
	return x.id<y.id;
}
bool cmp2(stu x,stu y){
	if(x.name==y.name) return x.id<y.id;
	return x.name<y.name;
}
bool cmp3(stu x,stu y){
	if(x.score==y.score) return x.id<y.id;
	return x.score<y.score;
}
int n,c,cas;
int main(){
	freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	while(std::cin>>n>>c){
		if(!n) break;
		++cas;
		std::cout<<"Case "<<cas<<":\n";
		for(int i=1;i<=n;i++) std::cin>>a[i].id>>a[i].name>>a[i].score;
		if(c==1) std::sort(a+1,a+1+n,cmp1);
		else if(c==2) std::sort(a+1,a+1+n,cmp2);
		else if(c==3) std::sort(a+1,a+1+n,cmp3);
		for(int i=1;i<=n;i++) std::cout<<a[i].id<<' '<<a[i].name<<' '<<a[i].score<<'\n';
	}
	return 0;
}
