#include <cstdio>
#include <algorithm>
int n,a[1003],b[1003],len,maxa;
int main(){
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		len=0,maxa=-(1<<30);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			if(maxa<a[i]) maxa=a[i];
		}
		printf("%d\n",maxa);
		if(n==1) puts("-1");
		else{
			bool ok=1;
			for(int i=1;i<=n;i++){
				if(a[i]==maxa&&ok) ok=0;
				else b[++len]=a[i];
			}
			std::sort(b+1,b+1+len);
			for(int i=1;i<=len;i++) printf("%d ",b[i]);puts("");
		}
	}
	return 0;
}
