#include <cstdio>
#include <algorithm>
#include <cstring>
int main(){
	freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
	int m;char s[23];
	scanf("%d",&m);
	while(m--){
		scanf("%s",s);
		std::sort(s,s+strlen(s));
		printf("%s\n",s);
	}
	return 0;
}
