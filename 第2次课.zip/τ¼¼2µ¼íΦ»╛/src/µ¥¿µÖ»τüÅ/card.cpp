#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
	{
		ch = getchar(), flag |= (ch == '-');
		if(ch == EOF)
		{
			n = EOF;
			return;
		}
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int w[200], col[200];
char nums[20], type_a[20], s[20];


struct CARD
{
	int type, num;
	
	bool operator<(const CARD &q) const
	{
		if(num != q.num)
			return num < q.num;
		
		return type < q.type;
	}
} a[20];


int main()
{
	freopen("card.in", "r", stdin);
	freopen("card.out", "w", stdout);
	
	w['J'] = 11, w['Q'] = 12, w['K'] = 13, w['A'] = 14;
	nums[11] = 'J', nums[12] = 'Q', nums[13] = 'K', nums[14] = 'A';
	col['d'] = 1, col['c'] = 2, col['h'] = 3, col['s'] = 4;
	type_a[1] = 'd', type_a[2] = 'c', type_a[3] = 'h', type_a[4] = 's';
	
	
	scanf("%s", s);
	int size = strlen(s), len = 0;
	
	for(int i=0; i<=size;)
	{
		if(s[i+1] == '0')
			a[++len].num = 10, a[len].type = col[int(s[i+2])], i+=3;
		
		else 
		{
			if(isdigit(s[i]))
				a[++len].num = s[i] - '0';
			else
				a[++len].num = w[int(s[i])];
			a[len].type = col[int(s[i+1])];
			
			i+=2;
		}
	}
	
	
	sort(a+1, a+6);
	
	
	for(int i=1; i<=5; i++)
	{
		if(a[i].num > 10)
			putchar(nums[a[i].num]);
		
		else
			out(a[i].num);
		
		putchar(type_a[a[i].type]), space;
	}
}

