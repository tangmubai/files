#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
	{
		ch = getchar(), flag |= (ch == '-');
		if(ch == EOF)
		{
			n = EOF;
			return;
		}
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


struct NODE
{
	int id, score;
	string name;
} a[100010];

inline bool cmp1(const NODE &p, const NODE &q)
{
	return p.id < q.id;
}

inline bool cmp2(const NODE &p, const NODE &q)
{
	if(p.name != q.name)
		return p.name < q.name;
		
	return p.id < q.id;
}

inline bool cmp3(const NODE &p, const NODE &q)
{
	if(p.score != q.score)
		return p.score < q.score;
		
	return p.id < q.id;
}


int main()
{
	freopen("excel.in", "r", stdin);
	freopen("excel.out", "w", stdout);
	
	
	int n, ii = 1;
	while(in(n), n != EOF && n != 0)
	{
		int c;
		in(c);
		
		for(int i=1; i<=n; i++)
			in(a[i].id), cin >> a[i].name, in(a[i].score);
		
		
		switch(c)
		{
			case 1:
				sort(a+1, a+n+1, cmp1);
				break;
			
			case 2:
				sort(a+1, a+n+1, cmp2);
				break;
			
			case 3:
				sort(a+1, a+n+1, cmp3);
				break;
		}
		
		
		printf("Case %d:\n", ii++);
		
		for(int i=1; i<=n; i++)
			printf("%06d ", a[i].id), cout << a[i].name, space, out(a[i].score), enter;
	}
}

