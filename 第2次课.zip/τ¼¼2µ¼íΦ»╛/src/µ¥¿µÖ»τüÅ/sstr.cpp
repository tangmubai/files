#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define space putchar(' ')
#define enter putchar('\n')

inline void in(int &n)
{
	int num = 0, flag = 0;
	char ch = ' ';
	while(!isdigit(ch))
	{
		ch = getchar(), flag |= (ch == '-');
		if(ch == EOF)
		{
			n = EOF;
			return;
		}
	}
	while(isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	n = flag ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


char s[30];

int main()
{
	freopen("sstr.in", "r", stdin);
	freopen("sstr.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	for(int ii=1; ii<=tt; ii++)
	{
		scanf("%s", s);
		sort(s, s+strlen(s));
		printf("%s\n", s);
	}
}

