#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct node{
	int level,hs;
}a[10];
bool cmp(node a,node b){
	if(a.level<b.level)return true;
	if(a.level>b.level)return false;
	if(a.level==b.level){
		if(a.hs<b.hs)return true;
		else return false;
	}
}
string level[20]={"","2","3","4","5","6","7","8","9","10","J","Q","K","A"};
char hs[10]={' ','d','c','h','s'};
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	char k[20];
	cin>>k;
	int num=1,flag=0;
	for(int i=0;i<strlen(k);i++){
		if(k[i+1]=='0'){
			a[num].level=9;
			i++;
			flag++;
			continue;
		}
		else{
			if(k[i]=='A')a[num].level=13;
			if(k[i]=='J')a[num].level=10;
			if(k[i]=='Q')a[num].level=11;
			if(k[i]=='K')a[num].level=12;
			if(k[i]=='s')a[num].hs=4;
			if(k[i]=='h')a[num].hs=3;
			if(k[i]=='c')a[num].hs=2;
			if(k[i]=='d')a[num].hs=1;
			if(isdigit(k[i]))a[num].level=k[i]-49;
			flag++;
		}
		if(flag==2){
			flag=0;
			num++;
		}
	}
	sort(a+1,a+6,cmp);
	for(int i=1;i<=5;i++)cout<<level[a[i].level]<<hs[a[i].hs]<<" ";
	return 0;
}
