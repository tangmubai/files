#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
struct node{
	string xh,name;
	int score;
}a[100005];
int c;
bool cmp(node a,node b){
	if(c==1){
		if(a.xh<b.xh)return true;
		else return false;
	}
	if(c==2){
		if(a.name<b.name)return true;
		if(a.name>b.name)return false;
		if(a.name==b.name){
			if(a.xh<b.xh)return true;
			else return false;
		}
	}
	if(c==3){
		if(a.score<b.score)return true;
		if(a.score>b.score)return false;
		if(a.score==b.score){
			if(a.xh<b.xh)return true;
			else return false;
		}
	}
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int n;
	int num=0;
	cin>>n>>c;
	while(n!=0){
		num++;
		for(int i=1;i<=n;i++)cin>>a[i].xh>>a[i].name>>a[i].score;
		cout<<"Case "<<num<<":"<<endl;
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)cout<<a[i].xh<<" "<<a[i].name<<" "<<a[i].score<<endl;
		cin>>n>>c;
	}
	return 0;
}
