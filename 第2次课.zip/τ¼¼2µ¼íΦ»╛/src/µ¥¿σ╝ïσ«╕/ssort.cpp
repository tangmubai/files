#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	int a[1005];
	while(cin>>n){
		for(int i=1;i<=n;i++)cin>>a[i];
		sort(a+1,a+1+n);
		cout<<a[n]<<endl;
		if(n==1){
			cout<<-1;
			continue;
		}
		for(int i=1;i<n;i++)cout<<a[i]<<" ";
		cout<<endl;
	}
	return 0;
}
