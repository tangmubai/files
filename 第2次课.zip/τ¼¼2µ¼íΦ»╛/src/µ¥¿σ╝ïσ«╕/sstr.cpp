#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
bool cmp(char a,char b){
	if(a>=b)return false;
	else return true;
}
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int n;
	cin>>n;
	char a[25];
	while(n--){
		cin>>a;
		sort(a,a+strlen(a),cmp);
		cout<<a<<endl;
	}
	return 0;
}
