#include<cstring>
#include<string>
#include<stdio.h>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
struct node{
	char x,y;
	ll num,numx;
}a[10];
bool cmp(node p,node q){
	if(p.num!=q.num)return p.num<q.num;
	return p.numx<q.numx;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	ll n=5,len;
	for(ll i=1;i<=n;i++){
		scanf("%c%c",&a[i].x,&a[i].y);
		if(a[i].x=='J')a[i].num=11;
		else{
			if(a[i].x=='Q')a[i].num=12;
			else{
				if(a[i].x=='K')a[i].num=13;
				else{
					if(a[i].x=='A')a[i].num=14;
					else a[i].num=a[i].x-'0';
				}
			}
		}
		if(a[i].y=='d')a[i].numx=1;
		if(a[i].y=='c')a[i].numx=2;
		if(a[i].y=='h')a[i].numx=3;
		if(a[i].y=='s')a[i].numx=4;	
	}
	sort(a+1,a+n+1,cmp);
	for(ll i=1;i<=n;i++){
		printf("%c%c ",a[i].x,a[i].y);
	}
	printf("\n");
	return 0;
}
// d<c<h<s
