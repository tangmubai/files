#include<cstring>
#include<string>
#include<stdio.h>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
struct Node{
	ll score;
	string num,name;
}a[100005];
bool cmpa(Node p,Node q){
	return p.num<q.num;
}
bool cmpb(Node p,Node q){
	return p.name<q.name;
}
bool cmpc(Node p,Node q){
	if(p.score!=q.score)return p.score<q.score;
	return p.num<q.num;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	ll n,c,x=1;
	scanf("%lld%lld",&n,&c);
	while(n){
		printf("Case %lld:\n",x);
		for(ll i=1;i<=n;i++){
			cin>>a[i].num>>a[i].name;
			scanf("%lld",&a[i].score);
		}
		if(c==1){
			sort(a+1,a+n+1,cmpa);
			for(ll i=1;i<=n;i++){
				cout<<a[i].num<<' '<<a[i].name<<' ';
				printf("%lld\n",a[i].score);
			}
		}
		if(c==2){
			sort(a+1,a+n+1,cmpb);
			for(ll i=1;i<=n;i++){
				cout<<a[i].num<<' '<<a[i].name<<' ';
				printf("%lld\n",a[i].score);
			}
		}
		if(c==3){
			sort(a+1,a+n+1,cmpc);
			for(ll i=1;i<=n;i++){
				cout<<a[i].num<<' '<<a[i].name<<' ';
				printf("%lld\n",a[i].score);
			}
		}
		x++;
		scanf("%lld%lld",&n,&c);
	}
	return 0;
}
