#include<cstring>
#include<string>
#include<stdio.h>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	ll n,len,x;
	while(scanf("%lld",&n)!=EOF){
		ll a[1005];
		if(n==1){
			scanf("%lld",&x);
			printf("%lld\n",x);
			printf("-1\n");
			continue;
		}
		for(ll i=1;i<=n;i++)scanf("%lld",&a[i]);		
		sort(a+1,a+n+1);
		printf("%lld\n",a[n]);
		for(ll i=1;i<n;i++)printf("%lld ",a[i]);
		printf("\n");
	}
	return 0;
}
