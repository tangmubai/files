#include<cstring>
#include<string>
#include<stdio.h>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	ll n,len;char a[20];
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++){
		cin>>a;
		len=strlen(a);
		sort(a,a+len);
		for(int i=0;i<len;i++)printf("%c",a[i]);
		printf("\n");	
	}
	return 0;
}
