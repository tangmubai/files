#include<stdio.h>
#include<algorithm>
#include<string.h>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
using std::sort;
struct Node{
	int num,col;
}a[10];
bool cmp(Node a,Node b){
	if(a.num-b.num){
		return a.num<b.num;
	}
	return a.col<b.col;
}
char s[20];
int main(){
	file("card");
	scanf("%s",s);
	int len=0;
	bool flag=1;
	int plen=strlen(s);
	for(int i=0;i<plen; ){
		if(flag==1){
			if(s[i]=='J'){
				i+=1;
				a[++len].num=11;
				flag=0;
			}else if(s[i]=='Q'){
				i+=1;
				a[++len].num=12;
				flag=0;
			}else if(s[i]=='K'){
				i+=1;
				a[++len].num=13;
				flag=0;
			}else if(s[i]=='A'){
				i+=1;
				a[++len].num=14;
				flag=0;
			}else if(s[i]=='1'){
				i+=2;
				a[++len].num=10;
				flag=0;
			}else{
				i+=1;
				a[++len].num=(s[i]-'0');
				flag=0;
			}
		}else{
			if(s[i]=='d'){
				i++;
				flag=1;
				a[len].col=1;
			}else if(s[i]=='c'){
				i++;
				flag=1;
				a[len].col=2;
			}else if(s[i]=='h'){
				i++;
				flag=1;
				a[len].col=3;
			}else{
				i++;
				flag=1;
				a[len].col=4;
			}
		}
	}
	sort(a+1,a+len+1,cmp);
	for(int i=1;i<=len;i++){
		if(a[i].num<=10){
			printf("%d ",a[i].num);
		}
		if(a[i].num==11){
			putchar('J');
		}
		if(a[i].num==12){
			putchar('Q');
		}
		if(a[i].num==13){
			putchar('K');
		}
		if(a[i].num==14){
			putchar('A');
		}
		if(a[i].col==1){
			putchar('d');
		}
		if(a[i].col==2){
			putchar('c');
		}
		if(a[i].col==3){
			putchar('h');
		}
		if(a[i].col==4){
			putchar('s');
		}
	}
}
