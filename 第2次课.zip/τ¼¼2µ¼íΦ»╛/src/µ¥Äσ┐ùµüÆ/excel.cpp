#include<stdio.h>
#include<algorithm>
#include<string.h>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
struct Node{
	int id,score;
	char name[20];
}a[100050];
bool cmp1(Node a,Node b){
	return a.id<b.id;
}
bool cmp2(Node a,Node b){
	if(strcmp(a.name,b.name)){
		return strcmp(a.name,b.name)<0;
	}
	return a.id<b.id;
}
bool cmp3(Node a,Node b){
	if(a.score-b.score){
		return a.score<b.score;
	}
	return a.id<b.id;
}
int main(){
	file("excel");
	while(1){
		int n,m;
		scanf("%d%d",&n,&m);
		if(n==0){
			return 0;
		}
		for(int i=1;i<=n;i++){
			scanf("%d %s %d",&a[i].id,a[i].name,&a[i].score);
		}
		printf("Case %d:\n",m);
		if(m==1){
			std::sort(a+1,a+n+1,cmp1);
		}
		if(m==2){
			std::sort(a+1,a+n+1,cmp2);
		}
		if(m==3){
			std::sort(a+1,a+n+1,cmp3);
		}
		for(int i=1;i<=n;i++){
			printf("%06d %s %d\n",a[i].id,a[i].name,a[i].score);
		}
	}
	return 0;
}
