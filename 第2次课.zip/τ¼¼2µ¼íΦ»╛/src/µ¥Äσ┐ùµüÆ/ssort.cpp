#include<stdio.h>
#include<algorithm>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
using std::sort;
int a[1050];
int main(){
	file("ssort");
	int n;
	while((scanf("%d",&n))!=EOF){
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		printf("%d\n",a[n]);
		for(int i=1;i<n;i++){
			printf("%d ",a[i]);
		}
		printf("\n");
	}
}
