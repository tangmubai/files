#include<stdio.h>
#include<algorithm>
#define file(name)freopen(name".in","r",stdin),freopen(name".out","w",stdout)
using std::sort;
char a[50];
inline bool cmp(char a,char b){
	return a<b;
}
int main(){
	file("sstr");
	register int t;
	scanf("%d",&t);
	while(t--){
		scanf("%s",a);
		register int len=0;
		while(a[len]){
			len++;
		}
		sort(a,a+len,cmp);
		printf("%s\n",a);
	}
	return 0;
}
