#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
struct Node {
	int s;
	int hs;
	char HS;
}a[10];
bool operator < (const Node &a,const Node &b) {
	if (a.s!=b.s) 
		return a.s<b.s;
	return a.hs<b.hs;
}
char s[110];
int len,i,ss,j,t;
int main () {
	freopen ("card.in","r",stdin);
	freopen ("card.out","w",stdout);
	scanf ("%s",s+1);
	len=strlen (s+1);
	for (i=1;i<=len;i++) {
		if (s[i]>='0'&&s[i]<='9') {
			ss=0;
			j=i;
			while (s[i]>='0'&&s[i]<='9') ss=ss*10+(s[i]-'0'),i++;
			a[++t].s=ss;
		}
		else {
			if (s[i]=='J') a[++t].s=11;
			if (s[i]=='Q') a[++t].s=12;
			if (s[i]=='K') a[++t].s=13;
			if (s[i]=='A') a[++t].s=14;
		}
	}
	t=0;
	for (i=1;i<=len;i++) {
		if (s[i]=='d') a[++t].hs=1,a[t].HS=s[i];
		if (s[i]=='c') a[++t].hs=2,a[t].HS=s[i];
		if (s[i]=='h') a[++t].hs=3,a[t].HS=s[i];
		if (s[i]=='s') a[++t].hs=4,a[t].HS=s[i];
	}
	sort (a+1,a+1+5);
	for (i=1;i<=5;i++) {
		if (a[i].s<=10) printf ("%d",a[i].s);
		if (a[i].s==11) printf ("J");
		if (a[i].s==12) printf ("Q");
		if (a[i].s==13) printf ("K");
		if (a[i].s==14) printf ("A");
		printf ("%c ",a[i].HS);
	} 
	puts ("");
	return 0;
}
