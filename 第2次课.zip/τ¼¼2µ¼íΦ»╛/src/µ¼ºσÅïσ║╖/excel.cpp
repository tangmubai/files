#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
struct Node {
	int s;
	int id;
	char h[10];
	char name[110];
}a[100010];
int n,c,i,t,j,len;
bool operator < (const Node &a,const Node &b) {
	if (c==1) 
		return a.id<b.id;
	if (c==2) {
		if (strcmp (a.name,b.name)!=0) 
			return strcmp (a.name,b.name)<1;
		else 
			return a.id<b.id;
	} 
	if (c==3) {
		if (a.s!=b.s)
			return a.s<b.s;
		else 
			return a.id<b.id;
	}
}
int main () {
	freopen ("excel.in","r",stdin);
	freopen ("excel.out","w",stdout);
	while (scanf ("%d%d",&n,&c)!=EOF) {
		if (n==0) 
			return 0;
		t++;
		printf ("Case %d:\n",t);
		for (i=1;i<=n;i++) {
			scanf ("%s%s%d",a[i].h,a[i].name,&a[i].s);
			a[i].id=0;
			len=strlen (a[i].h);
			for (j=1;j<=len;j++) 
				a[i].id=a[i].id*10+(a[i].h[j]-'0');
		}
		sort (a+1,a+1+n);
		for (i=1;i<=n;i++)
			printf ("%s %s %d\n",a[i].h,a[i].name,a[i].s);
	}
	return 0;
}
