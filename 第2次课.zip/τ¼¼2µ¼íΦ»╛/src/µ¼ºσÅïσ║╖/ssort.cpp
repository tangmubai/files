#include <cstdio>
#include <algorithm>
using namespace std;
int n,i,a[1010],s;
int main () {
	freopen ("ssort.in","r",stdin);
	freopen ("ssort.out","w",stdout);
	while (scanf ("%d",&n)!=EOF) {
		for (i=1;i<=n;i++)
			scanf ("%d",&a[i]);
		sort (a+1,a+1+n);
		printf ("%d\n",a[n]);
		if (n==1) {
			puts ("-1");
			continue;
		}
		for (i=1;i<n;i++) 
			printf ("%d ",a[i]);
		puts ("");
	}
	return 0;
}
