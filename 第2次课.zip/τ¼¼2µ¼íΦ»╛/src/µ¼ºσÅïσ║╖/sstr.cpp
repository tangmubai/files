#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
char s[30];
int m,i,len,j;
int main () {
	freopen ("sstr.in","r",stdin);
	freopen ("sstr.out","w",stdout);
	scanf ("%d",&m);
	while (m--) {
		scanf ("%s",s+1);
		len=strlen (s+1);
		for (i=1;i<=len;i++) 
			for (j=i+1;j<=len;j++)
				if (s[i]>s[j]) 
					swap (s[i],s[j]);
		for (i=1;i<=len;i++) 
			printf ("%c",s[i]);
		puts ("");
	}
	return 0;
}
