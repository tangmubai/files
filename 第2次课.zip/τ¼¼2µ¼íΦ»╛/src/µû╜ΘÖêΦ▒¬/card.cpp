#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
char a[105];
struct stu{
	char t[15];
	int top;
	int s1,s2;
}s[105];
bool cmp(stu x,stu y){
	if(x.s1!=y.s1)return x.s1<y.s1;
	return x.s2<y.s2;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	scanf("%s",a+1);
	int l=strlen(a+1);
	int k=0;
	for(int i=1;i<=l;i++){
		int j=i;
		k++;
		s[k].top=0;
		while(a[j]!='d'&&a[j]!='c'&&a[j]!='h'&&a[j]!='s'){
			s[k].top++;
			s[k].t[s[k].top]=a[j++];
		}
		s[k].top++;
		s[k].t[s[k].top]=a[j];
		i=j;
	}
	for(int i=1;i<=k;i++){
		if(s[i].top==3)s[i].s1=10;
		if(s[i].top==2){
			if(s[i].t[1]>='0'&&s[i].t[1]<='9')s[i].s1=s[i].t[1]-'0';
			else {
				if(s[i].t[1]=='J')s[i].s1=11;
				if(s[i].t[1]=='Q')s[i].s1=12;
				if(s[i].t[1]=='K')s[i].s1=13;
				if(s[i].t[1]=='A')s[i].s1=14;
			}
		}
		if(s[i].t[s[i].top]=='d')s[i].s2=1;
		if(s[i].t[s[i].top]=='c')s[i].s2=2;
		if(s[i].t[s[i].top]=='h')s[i].s2=3;
		if(s[i].t[s[i].top]=='s')s[i].s2=4;	
	}
	sort(s+1,s+1+k,cmp);
//	for(int i=1;i<=k;i++){
//		printf("%d %d\n",s[i].s1,s[i].s2);
//	}
	for(int i=1;i<=k;i++){
		for(int j=1;j<=s[i].top;j++){
			printf("%c",s[i].t[j]);
		}printf(" ");
	}
	return 0;
}


