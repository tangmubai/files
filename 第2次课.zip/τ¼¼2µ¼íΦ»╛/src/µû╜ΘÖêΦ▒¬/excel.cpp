#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
struct stu{
	char a[10],b[10];
	int c;
}s[100005];
int n,c;
bool cmp1(stu x,stu y){
	return strcmp(x.a,y.a)<0;
}
bool cmp2(stu x,stu y){
	if(strcmp(x.b,y.b)!=0)return strcmp(x.b,y.b)<0;
	return strcmp(x.a,y.a)<0;
}
bool cmp3(stu x,stu y){
	if(x.c!=y.c)return x.c<y.c;
	return strcmp(x.a,y.a)<0;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int k=0;
	while(1){
		scanf("%d%d",&n,&c);
		if(n==0){
			return 0;
		}
		k++;
		printf("Case %d:\n",k);
		for(int i=1;i<=n;i++){
			scanf("%s",s[i].a);
			scanf("%s",s[i].b);
			scanf("%d",&s[i].c);
		}
		if(c==1){
			sort(s+1,s+1+n,cmp1);
		}
		if(c==2){
			sort(s+1,s+1+n,cmp2);
		}
		if(c==3){
			sort(s+1,s+1+n,cmp3);
		}
		for(int i=1;i<=n;i++){
			printf("%s %s %d\n",s[i].a,s[i].b,s[i].c);
		}
	}
	return 0;
}


