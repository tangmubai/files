#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int a[1005];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while(cin>>n){
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		if(n==1){
			printf("%d\n",a[1]);printf("-1\n");continue;
		}
		printf("%d\n",a[n]);
		for(int i=1;i<n;i++){
			printf("%d ",a[i]);
		}puts("");
	}
	return 0;
}


