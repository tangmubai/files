#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
char a[105];
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%s",a+1);
		int l=strlen(a+1);
		sort(a+1,a+1+l);
		for(int j=1;j<=l;j++){
			printf("%c",a[j]);
		}
		puts("");
	}
	return 0;
}
