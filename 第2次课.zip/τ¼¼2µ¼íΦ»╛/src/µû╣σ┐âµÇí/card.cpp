#include <cstdio>
#include <algorithm>
using namespace std;
struct Node{
	int num,hs;
}a[10];
bool cmp(Node p,Node q){
	if(p.num!=q.num)return p.num<q.num;
	return p.hs<q.hs;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	char c;
	for(int i=1;i<=5;i++){
		c=getchar();
		if(c>='2'&&c<='9')a[i].num=c-'0';
		else if(c=='1'){
			c=getchar();
			a[i].num=10;
		}
		else if(c=='J')a[i].num=11;
		else if(c=='Q')a[i].num=12;
		else if(c=='K')a[i].num=13;
		else a[i].num=14;
		c=getchar();
		if(c=='d')a[i].hs=1;
		else if(c=='c')a[i].hs=2;
		else if(c=='h')a[i].hs=3;
		else a[i].hs=4;
	}
	sort(a+1,a+6,cmp);
	for(int i=1;i<=5;i++){
		if(a[i].num<=10)printf("%d",a[i].num);
		else if(a[i].num==11)printf("J");
		else if(a[i].num==12)printf("Q");
		else if(a[i].num==13)printf("K");
		else printf("A");
		if(a[i].hs==1)printf("d");
		else if(a[i].hs==2)printf("c");
		else if(a[i].hs==3)printf("h");
		else printf("s");
		printf(" ");
	}
	return 0;
}
