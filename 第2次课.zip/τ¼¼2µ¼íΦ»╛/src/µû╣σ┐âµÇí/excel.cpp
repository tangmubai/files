#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
struct Node{
	int xh;char name[20];int num;
}a[100010];
bool cmp1(Node p,Node q){
	return p.xh<q.xh;
}
bool cmp2(Node p,Node q){
	int tmp=strcmp(p.name,q.name);
	if(tmp==0)return p.xh<q.xh;
	return tmp<0;
}
bool cmp3(Node p,Node q){
	if(p.num!=q.num)return p.num<q.num;
	return p.xh<q.xh;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int cnt=0,n,c;
	while(1){
		scanf("%d%d",&n,&c);
		if(n==0)break;
		cnt++;
		for(int i=1;i<=n;i++)
			scanf("%d %s %d",&a[i].xh,a[i].name,&a[i].num);
		if(c==1)sort(a+1,a+1+n,cmp1);
		else if(c==2)sort(a+1,a+1+n,cmp2);
		else sort(a+1,a+1+n,cmp3);
		printf("Case %d:\n",cnt);
		for(int i=1;i<=n;i++)
			printf("%06d %s %d\n",a[i].xh,a[i].name,a[i].num);
	}
	return 0;
}
