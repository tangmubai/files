#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;
int a[1010];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while(cin>>n){
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	if(n==1){
		printf("%d\n-1\n",a[1]);
		return 0;
	}
	sort(a+1,a+1+n);
	printf("%d\n",a[n]);
	for(int i=1;i<n;i++)
		printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
