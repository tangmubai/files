#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
char s[30];
bool cmp(char p,char q){
	return p<q;
}
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int m;scanf("%d",&m);
	for(int i=1;i<=m;i++){
		getchar();
		scanf("%s",s+1);
		int len=strlen(s+1);
		sort(s+1,s+1+len,cmp);
		printf("%s\n",s+1);
	}
	return 0;
}
