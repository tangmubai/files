#include <cstdio>
#include <map>
#include <algorithm>
using namespace std;
map < char,int > mp;
map < char,int > mp2;

struct Node{
	char num,pic;
}a[10];

char s[25];

bool cmp(Node x,Node y){
	if(mp[x.num]!=mp[y.num]){
		return mp[x.num]<mp[y.num];
	}
	return mp2[x.pic]<mp2[y.pic];
}

int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	scanf("%s",s+1);
	for(int i=1,j=1;s[i];++j){
		if(s[i]=='1' && s[i+1]=='0'){
			a[j].num='+';
			i+=2;
		}else {
			a[j].num=s[i];
			++i;
		}
		a[j].pic=s[i];
		++i;
	}
	mp['2']=1;
	mp['3']=2;
	mp['4']=3;
	mp['5']=4;
	mp['6']=5;
	mp['7']=6;
	mp['8']=7;
	mp['9']=8;
	mp['+']=9;
	mp['J']=10;
	mp['Q']=11;
	mp['K']=12;
	mp['A']=13;
	mp2['d']=1;
	mp2['c']=2;
	mp2['h']=3;
	mp2['s']=4;
	sort(a+1,a+6,cmp);
	for(int i=1;i<=5;++i){
		if(a[i].num=='+'){
			printf("10");
		}else {
			printf("%c",a[i].num);
		}
		printf("%c ",a[i].pic);
	}
	return 0;
}
