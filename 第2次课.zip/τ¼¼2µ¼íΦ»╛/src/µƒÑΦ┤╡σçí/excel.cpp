#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n,c;

struct Student{
	char name[15];
	int id,mark;
}a[100005];

bool cmp1(Student x,Student y){
	return x.id<y.id;
}

bool cmp2(Student x,Student y){
	if(strcmp(x.name+1,y.name+1)==0){
		return x.id<y.id;
	}
	return strcmp(x.name+1,y.name+1)<0;
}

bool cmp3(Student x,Student y){
	if(x.mark==y.mark){
		return x.id<y.id;
	}
	return x.mark<y.mark;
}

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	for(int Case=1;;++Case){
		n=read(),c=read();
		if(n==0)break;
		printf("Case %d:\n",Case);
		for(int i=1;i<=n;++i){
			a[i].id=read();
			scanf("%s",a[i].name+1);
			a[i].mark=read();
		}
		if(c==1){
			sort(a+1,a+n+1,cmp1);
		}
		if(c==2){
			sort(a+1,a+n+1,cmp2);
		}
		if(c==3){
			sort(a+1,a+n+1,cmp3);
		}
		for(int i=1;i<=n;++i){
			printf("%06d %s %d\n",a[i].id,a[i].name+1,a[i].mark);
		}
	}
	return 0;
}
