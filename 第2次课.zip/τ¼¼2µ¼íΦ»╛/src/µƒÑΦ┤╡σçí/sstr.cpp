#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int test_num,n;
char s[25];

int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&test_num);
	while(test_num--){
		scanf("%s",s+1);
		n=strlen(s+1);
		sort(s+1,s+n+1);
		printf("%s\n",s+1);
	}
	return 0;
}
