#include<algorithm>
#include<iostream>
#include<string>
#include<map>
#include<string.h>
using namespace std;
int g[133],len,lenn;
#define kk(x) x>='0'&&x<='9'
#define kkk(x) x=='J'||x=='Q'||x=='K'||x=='A'
map<string,int>h;
struct stu{
	string a;char b;
	friend bool operator <(stu x,stu y){
		if(x.a!=y.a)return h[x.a]<h[y.a];
		return g[x.b]<g[y.b];
	}
}s[10];
char c[15];
int main(){
	freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	cin>>c;g['d']=1,g['c']=2;g['h']=3;g['s']=4;lenn=strlen(c);
	h["1"]=1;h["2"]=2;h["3"]=3;h["4"]=4;h["5"]=5;h["6"]=6;h["7"]=7;h["8"]=8;h["9"]=9;h["10"]=10;
	h["J"]=11;h["Q"]=12;h["K"]=13;h["A"]=13;
	for(register int i=1;i<=5;++i){
		while((kk(c[len])||kkk(c[len]))&&len<lenn)s[i].a+=c[len],++len;
		s[i].b=c[len];++len;
	}
	sort(s+1,s+6);
	for(register int i=1;i<=5;++i)
	cout<<s[i].a<<s[i].b<<' ';
}
