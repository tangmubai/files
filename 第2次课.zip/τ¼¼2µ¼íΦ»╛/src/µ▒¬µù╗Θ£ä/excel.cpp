#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
struct stu{
	char a[8],b[10];int c;
}s[100005];
bool cmp1(stu x,stu y){
	return strcmp(x.a,y.a)<0;
}
bool cmp2(stu x,stu y){
	return strcmp(x.b,y.b)?strcmp(x.b,y.b)<0:strcmp(x.a,y.a)<0;
}
bool cmp3(stu x,stu y){
	return x.c==y.c?strcmp(x.a,y.a)<0:x.c<y.c;
}
int A(){
	char c=getchar();
	int a=0,k=1;
	while(c<'0'||c>'9'){
		c=='-'?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int i,n,k;
int main(){
	freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	while((n=A(),k=A())&&n){
		++i;
		for(register int j=1;j<=n;++j){
			scanf("%s%s",s[j].a,s[j].b);s[j].c=A();
		}
		k==1?sort(s+1,s+1+n,cmp1),0:0;
		k==2?sort(s+1,s+1+n,cmp2),0:0;
		k==3?sort(s+1,s+1+n,cmp3),0:0;
		printf("Case %d:\n",i);
		for(register int j=1;j<=n;++j)
		printf("%s %s %d\n",s[j].a,s[j].b,s[j].c);
	}
}
