#include<stdio.h>
#include<algorithm>
using namespace std;
int A(){
	char c=getchar();
	int a=0,k=1;
	while(c<'0'||c>'9'){
		c=='-'?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int a[1005],n;
int main(){
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	while(~scanf("%d",&n)){
		for(register int i=1;i<=n;++i)a[i]=A();
		sort(a+1,a+1+n);
		printf("%d\n",a[n]);
		if(n==1){
			printf("-1\n");continue;
		}
		for(register int i=1;i<n;++i)printf("%d ",a[i]);printf("\n");
	}
}
