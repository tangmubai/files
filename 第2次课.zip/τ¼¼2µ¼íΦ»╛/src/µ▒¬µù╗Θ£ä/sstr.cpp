#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
char c[22];
int n;
int main(){
	freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		scanf("%s",c+1);
		sort(c+1,c+1+strlen(c+1));printf("%s\n",c+1);
	}
}
