#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
struct node{
	int f,s;
}a[10];
bool cmp(node x,node y){
	if(x.f==y.f)
	    return x.s<y.s;
	return x.f<y.f;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
    for(int i=1;i<6;i++){
    	char t,u,o;
	    scanf("%c%c",&t,&u);
	    if(u=='0'){
	        a[i].f=(t-'0')*10+(u-'0');
	        scanf("%c",&o);
	        a[i].s=o;
	    }
	    else{
	    	a[i].f=t;
	    	a[i].s=u;
	    	if(t>'1'&&t<='9')
	    	    a[i].f=t-'0';
	    	else{
	            if(a[i].f=='J')
	                a[i].f=11;
	            if(a[i].f=='Q')
	                a[i].f=12;
	            if(a[i].f=='K')
	                a[i].f=13;
	            if(a[i].f=='A')
	                a[i].f=14;
	            if(a[i].s=='d')
	                a[i].s='a';
	        }
	    }
	}
	sort(a+1,a+6,cmp);
	for(int i=1;i<6;i++){
		if(a[i].f==11)
	        a[i].f='J';
	    if(a[i].f==12)
	        a[i].f='Q';
	    if(a[i].f==13)
	        a[i].f='K';
	    if(a[i].f==14)
	        a[i].f='A';
	    if(a[i].s=='a')
	        a[i].s='d';
	    if(a[i].f>=2&&a[i].f<=10)
	        printf("%d%c ",a[i].f,a[i].s);
	    else
	        printf("%c%c ",a[i].f,a[i].s);
	}
	puts("");
	return 0;
}
