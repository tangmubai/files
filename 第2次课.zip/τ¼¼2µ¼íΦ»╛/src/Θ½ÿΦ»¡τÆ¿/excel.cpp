#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int n,f;
struct node{
	string xh,name;
	int cj;
}a[100010];
bool cmp1(node x,node y){
	return x.xh<y.xh;
}
bool cmp2(node x,node y){
	if(x.name==y.name)
	    return x.xh<y.xh;
	return x.name<=y.name;
}
bool cmp3(node x,node y){
	if(x.cj==y.cj)
	    return x.xh<y.xh;
	return x.cj<=y.cj;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
    scanf("%d%d",&n,&f);
	while(n!=0){
		for(int i=1;i<=n;i++)
		    cin>>a[i].xh>>a[i].name>>a[i].cj;
		if(f==1)
		    sort(a+1,a+1+n,cmp1);
		if(f==2)
		    sort(a+1,a+1+n,cmp2);
		if(f==3)
		    sort(a+1,a+1+n,cmp3);
		printf("Case %d:\n",f);
		for(int i=1;i<=n;i++)
		    cout<<a[i].xh<<' '<<a[i].name<<' '<<a[i].cj<<endl;
		scanf("%d%d",&n,&f);
	}
	return 0;
}

