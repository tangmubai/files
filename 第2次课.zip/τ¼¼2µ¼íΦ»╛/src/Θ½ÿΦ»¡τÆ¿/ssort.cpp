#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int n,a[1050];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		if(n==1){
			scanf("%d",&a[1]);
			printf("%d\n-1\n",a[1]);
			continue;
		}
		for(int i=1;i<=n;i++)
		    scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		printf("%d\n",a[n]);
		for(int i=1;i<n;i++)
		    printf("%d ",a[i]);
		puts("");
	}
	return 0;
}

