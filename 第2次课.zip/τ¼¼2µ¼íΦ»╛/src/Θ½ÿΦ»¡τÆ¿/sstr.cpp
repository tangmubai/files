#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int n;
char a[50];
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		scanf("%s",a);
		int l=strlen(a);
		sort(a,a+l);
		for(int i=0;i<l;i++)
	        printf("%c",a[i]);
	    puts("");
	}
	return 0;
}
