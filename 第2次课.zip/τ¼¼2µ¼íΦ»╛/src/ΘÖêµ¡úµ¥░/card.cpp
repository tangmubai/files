#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
struct sj{
	int hs,sz;
}a[10];
char c1,c;
bool cmp(sj p,sj q){
	if(p.sz==q.sz)return p.hs<q.hs;
	else return p.sz<q.sz;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	int t=1;
	while(cin>>c>>c1){
		//cout<<c<<' '<<c1<<endl;
		if(c>='2'&&c<='9')a[t].sz=c-'0';
		else
		if(c=='A')a[t].sz=14;
		else
		if(c=='J')a[t].sz=11;
		else
		if(c=='Q')a[t].sz=12;
		else
		if(c=='K')a[t].sz=13;
		else
		if(c=='1'){cin>>c1;a[t].sz=10;}
		if(c1=='d')a[t].hs=1;
		else
		if(c1=='c')a[t].hs=2;
		else
		if(c1=='h')a[t].hs=3;
		else
		if(c1=='s')a[t].hs=4;
		//cout<<a[t].sz<<' '<<a[t].hs<<endl;
		t++;
	}
	sort(a+1,a+t,cmp);
	//for(int i=1;i<=5;i++)
	//cout<<a[i].sz<<' '<<a[i].hs<<endl;;
	for(int i=1;i<=5;i++){
		if(a[i].sz>=2&&a[i].sz<=10)cout<<a[i].sz;
		else
		if(a[i].sz==14)cout<<'A';
		else
		if(a[i].sz==11)cout<<'J';
		else
		if(a[i].sz=12)cout<<'Q';
		else
		if(a[i].sz==13)cout<<'K';
		if(a[i].hs==1)cout<<'d';
		else
		if(a[i].hs==2)cout<<'c';
		else
		if(a[i].hs==3)cout<<'h';
		else
		if(a[i].hs==4)cout<<'s';
		cout<<' ';
	}
}
