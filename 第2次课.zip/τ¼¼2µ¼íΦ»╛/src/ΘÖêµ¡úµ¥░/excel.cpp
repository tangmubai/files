#include <iostream>
#include <algorithm>
using namespace std;
int n,c;
struct sj{
	string xh;
	string na;
	int sc;
}a[100005];
bool cmp1(sj p,sj q){
	return p.xh<q.xh;
}
bool cmp2(sj p,sj q){
	if(p.na==q.na)return p.xh<q.xh;
	else return p.na<q.na;
}
bool cmp3(sj p,sj q){
	if(p.sc==q.sc)return p.xh<q.xh;
	else return p.sc<q.sc;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int t=1;
	while(cin>>n){
		if(!n)return 0;
		cin>>c;
		cout<<"Case "<<t<<':'<<endl;
		t++;
		for(int i=1;i<=n;i++)
		cin>>a[i].xh>>a[i].na>>a[i].sc;
		if(c==1)sort(a+1,a+1+n,cmp1);
		if(c==2)sort(a+1,a+1+n,cmp2);
		if(c==3)sort(a+1,a+1+n,cmp3);
		for(int i=1;i<=n;i++)
		cout<<a[i].xh<<' '<<a[i].na<<' '<<a[i].sc<<endl;
	}
}
