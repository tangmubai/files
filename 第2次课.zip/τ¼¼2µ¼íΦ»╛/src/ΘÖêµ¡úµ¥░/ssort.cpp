#include <iostream>
#include <algorithm>
using namespace std;
int n;
int a[1005];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	if(n==1){
		cout<<a[1]<<endl<<-1;
		return 0;
	}
	sort(a+1,a+1+n);
	cout<<a[n]<<endl;
	for(int i=1;i<n;i++)
	cout<<a[i]<<' ';
}
