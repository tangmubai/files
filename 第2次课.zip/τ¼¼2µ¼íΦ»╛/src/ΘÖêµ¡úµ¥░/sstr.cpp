#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
char c[25];
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int n;
	cin>>n;
	while(n--){
		cin>>c;
		sort(c,c+strlen(c));
		cout<<c<<endl;
	}
}
