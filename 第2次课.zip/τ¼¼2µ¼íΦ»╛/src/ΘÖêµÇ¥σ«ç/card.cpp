#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

struct sj{
	char a[1],b[1];
}s[25];

bool cmp(sj x,sj y)
{
	if(x.a[0]!=y.a[0])return x.a[0]>y.a[0];
	else {
		return x.a[0]>y.a[0];
	}
}
int main()

{
	int n=5,i=0;
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	while(n--)
	{
		scanf("%c%c",&s[i].a[0],&s[i].b[0]);
		sort(s,s+5,cmp);
		for(i=0;i<n;i++)printf("%c%c ",s[i].a[0],s[i].b[0]);
	}
}
