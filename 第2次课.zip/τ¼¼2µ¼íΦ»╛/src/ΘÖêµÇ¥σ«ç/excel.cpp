#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

struct sj{
	string xh,name;
	int score;
}a[100005];
bool cmp1(sj a,sj b)
{
	return a.xh<b.xh;
}
bool cmp2(sj a,sj b)
{
	return a.name<b.name;
}
bool cmp3 (sj a,sj b)
{
	if(a.score!=b.score&&a.name!=b.name)return a.score<b.score;
	else 
	{
		return a.xh<b.xh;
	}
}
int main()
{
	int n,c,i,j=1;
	
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while(cin>>n>>c)
	
	{
		if(n==0)return 0;
		for(i=0;i<n;i++){
			cin>>a[i].xh>>a[i].name>>a[i].score;
		}
		if(c==1)sort(a,a+n,cmp1);
		if(c==2)sort(a,a+n,cmp2);
		if(c==3)sort(a,a+n,cmp3);
		cout<<"Case "<<j++<<": "<<endl;
		for(i=0;i<n;i++)cout<<a[i].xh<<" "<<a[i].name<<" "<<a[i].score<<endl;

	}
}
