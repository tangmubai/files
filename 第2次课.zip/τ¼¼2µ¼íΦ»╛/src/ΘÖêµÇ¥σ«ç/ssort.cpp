#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<cmath>

using namespace std;

int a[1005];
const int oo=99999999;
void maxmax(int n)
{
	int i,x=0,xi=0;
	for(i=0;i<n;i++)
	{
		if(x<a[i])x=a[i],xi=i;
	}
	printf("%d\n",x);a[xi]=oo;
	return ;
}
int main()
{
	
	int n,m;
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(cin>>n)
	{
		memset(a,0,sizeof(a));
		for(int i=0;i<n;i++)scanf("%d",&a[i]);
		maxmax(n);
		sort(a,a+n);
		if(n==1)
		{
			cout<<-1;
		}else for(int i=0;i<n-1;i++)printf("%d ",a[i]);
		cout<<endl;
	}
}
