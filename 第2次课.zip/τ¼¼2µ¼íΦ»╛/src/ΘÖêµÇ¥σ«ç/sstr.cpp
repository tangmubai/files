#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;

char s[125];

bool cmp(char a, char b)

{
	return a<b;
}
int main()
{
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int l,m;
	scanf("%d",&m);
	while(m--)
	{
	scanf("%s",s);
	l=strlen(s);
	sort(s,s+l,cmp);
	printf("%s\n",s);
	}
	
}
