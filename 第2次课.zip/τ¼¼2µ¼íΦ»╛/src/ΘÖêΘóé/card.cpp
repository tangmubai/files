#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

int t;
char c[15];
struct Card{
	int val,col;
}a[5];

bool cmp(Card x,Card y){
	if(x.val!=y.val) return x.val<y.val;
	else return x.col<y.col;
}

int main(){
	freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	scanf("%s",c);
	for(int i=0;i<strlen(c);i++){
		if(c[i]=='d'||c[i]=='c'||c[i]=='h'||c[i]=='s'){
			if(c[i]=='d') a[t].col=1;
			if(c[i]=='c') a[t].col=2;
			if(c[i]=='h') a[t].col=3;
			if(c[i]=='s') a[t].col=4;
			t++;
		}
		else{
			if(c[i]=='1') i++,a[t].val=10;
			if(c[i]>='2'&&c[i]<='9') a[t].val=c[i]-'0';
			if(c[i]=='A') a[t].val=14;
			if(c[i]=='J') a[t].val=11;
			if(c[i]=='Q') a[t].val=12;
			if(c[i]=='K') a[t].val=13; 
		}
	}
	sort(a,a+5,cmp);
	for(int i=0;i<10;i++){
		if(i%2==0){
			if(a[i/2].val>=2&&a[i/2].val<=10) printf("%d",a[i/2].val);
			if(a[i/2].val==14) printf("A");
			if(a[i/2].val==11) printf("J");
			if(a[i/2].val==12) printf("Q");
			if(a[i/2].val==13) printf("K");
		}
		else{
			if(a[i/2].col==1) printf("d ");
			if(a[i/2].col==2) printf("c ");
			if(a[i/2].col==3) printf("h ");
			if(a[i/2].col==4) printf("s ");
		}
	}
	return 0;
}
