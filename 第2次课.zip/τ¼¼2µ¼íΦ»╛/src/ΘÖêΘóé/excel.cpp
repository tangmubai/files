#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

inline void in(int &x){
	x=0;register char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
}

int n,c;
struct Stu{
	int id,mark;
	char name[10];
}a[100005];

bool cmp(Stu x,Stu y){
	if(c==1) return x.id<y.id;
	if(c==2) return strcmp(x.name,y.name)<0||strcmp(x.name,y.name)==0&&x.id<y.id;
	if(c==3) return x.mark<y.mark||x.mark==y.mark&&x.id<y.id;
}

int main(){
	freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	for(int chen_zhe_233=1;;chen_zhe_233++){
		in(n),in(c);
		if(!n) break;
		for(int i=1;i<=n;i++) in(a[i].id),scanf("%s",a[i].name),in(a[i].mark);
		sort(a+1,a+1+n,cmp);
		printf("Case %d:\n",chen_zhe_233);
		for(int i=1;i<=n;i++) printf("%06d %s %d\n",a[i].id,a[i].name,a[i].mark);
	}
	return 0;
}
