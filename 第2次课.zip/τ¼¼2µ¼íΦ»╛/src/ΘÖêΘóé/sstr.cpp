#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

char s[25];

int main(){
	freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
	int Dry_ice;scanf("%d",&Dry_ice);
	while(Dry_ice--){
		scanf("%s",s+1);
		int n=strlen(s+1);
		sort(s+1,s+1+n);
		printf("%s\n",s+1);
	}
	return 0;
}
