#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
const string val[]={"0","1","2","3","4","5","6","7","8","9"};
struct node
{
	string s1;
	string s2;
	int num;
	int hs;
}a[15];
char x[20];
int pos;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
inline string cg1(int p)
{
	if(x[p]=='1'&&x[p+1]=='0') 
	{
		pos+=2;
		return "10";
	}
	else{
		pos++;
		if(x[p]=='J') return "J";
		if(x[p]=='Q') return "Q";
		if(x[p]=='K') return "K";
		if(x[p]=='A') return "A";
		return val[x[p]-'0'];
	}
}
inline bool cmp(node p,node q){
	if(p.num!=q.num) return p.num<q.num;
	else return p.hs<q.hs;
}
int main()
{
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	scanf("%s",1+x);
	pos=1;
	for(int i=1;i<=5;i++)
	{
		a[i].s1=cg1(pos);
		a[i].s2=x[pos];pos++;
		if(a[i].s1.size()==1) 
		{
			if(a[i].s1[0]>='2'&&a[i].s1[0]<='9') 
				a[i].num=a[i].s1[0]-'0';
			else{
				if(a[i].s1[0]=='J') a[i].num=11;
				if(a[i].s1[0]=='Q') a[i].num=12;
				if(a[i].s1[0]=='K') a[i].num=13;
				if(a[i].s1[0]=='A') a[i].num=14;
			}
		}
		else
		{
			a[i].num=10;
		}
		if(a[i].s2[0]=='d') a[i].hs=1;
		if(a[i].s2[0]=='c') a[i].hs=2;
		if(a[i].s2[0]=='h') a[i].hs=3;
		if(a[i].s2[0]=='s') a[i].hs=4;
	}
//	puts("E");
	sort(a+1,a+6,cmp);
	for(int i=1;i<=5;i++) {
		cout<<a[i].s1<<a[i].s2;
		printf(" "); 
	}
	puts("");
	return 0;
}
