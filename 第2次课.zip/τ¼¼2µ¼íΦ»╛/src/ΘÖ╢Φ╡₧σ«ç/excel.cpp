#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
struct node
{
	int xh;
	char s[15];
	int sc;
}a[100005];
int cs;
int n,c;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
inline bool cmp1(node p,node q)
{
	return p.xh<q.xh;
}
inline bool cmp2(node p,node q)
{
	if(strcmp(p.s,q.s)!=0) return strcmp(p.s,q.s)<0;
	return p.xh<q.xh;	
}
inline bool cmp3(node p,node q)
{
	if(p.sc!=q.sc) return p.sc<q.sc;
	return p.xh<q.xh;
}
int main()
{
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while(scanf("%d %d",&n,&c)!=EOF&&n){
		for(int i=1;i<=n;i++){
			scanf("%d %s %d",&a[i].xh,a[i].s,&a[i].sc);
		}
		if(c==1) sort(a+1,a+n+1,cmp1);
		if(c==2) sort(a+1,a+n+1,cmp2);
		if(c==3) sort(a+1,a+n+1,cmp3);
		cs++;
		printf("Case %d:\n",cs);
		for(int i=1;i<=n;i++){
			printf("%06d %s %d\n",a[i].xh,a[i].s,a[i].sc);	
		}
	}
	return 0;
}
