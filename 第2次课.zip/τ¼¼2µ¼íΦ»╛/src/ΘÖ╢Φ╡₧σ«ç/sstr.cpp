#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
char s[50];
int n;
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
inline int ab(int _x)
{
	if(_x<0) return -_x;
	else return _x;
}
inline bool cmp(char p,char q)
{
	return p<q;
}
int main()
{
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++) 
	{
		scanf("%s",s);
		sort(s,s+strlen(s),cmp);
		printf("%s\n",s);
	}
	return 0;
}
