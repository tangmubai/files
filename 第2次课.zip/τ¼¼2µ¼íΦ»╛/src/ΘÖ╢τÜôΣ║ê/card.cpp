#include<stdio.h>
#include<algorithm>
#include<iostream>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
struct pp{int ph,hs;}a[10];
bool cmp(const pp &p1,const pp &p2){
	if(p1.ph!=p2.ph)return p1.ph<p2.ph;
	return p1.hs<p1.hs;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	for(int i=1;i<=5;i++){
		char x;cin>>x;a[i].ph=0;
		if(x=='A'){a[i].ph=14;cin>>x;}
		else if(x=='J'){a[i].ph=11;cin>>x;}
		else if(x=='Q'){a[i].ph=12;cin>>x;}
		else if(x=='K'){a[i].ph=13;cin>>x;}
		else while(x>='0'&&x<='9'){a[i].ph=a[i].ph*10+x-'0';cin>>x;}
		if(x=='d')a[i].hs=1;
		if(x=='c')a[i].hs=2;
		if(x=='h')a[i].hs=3;
		if(x=='s')a[i].hs=4;
	}
	sort(a+1,a+1+5,cmp);
	for(int i=1;i<=5;i++){
		if(a[i].ph!=1&&a[i].ph<=10)printf("%d",a[i].ph);
		else if(a[i].ph==14)printf("A");
		else if(a[i].ph==11)printf("J");
		else if(a[i].ph==12)printf("Q");
		else if(a[i].ph==13)printf("K");
		if(a[i].hs==1)printf("d ");
		if(a[i].hs==2)printf("c ");
		if(a[i].hs==3)printf("h ");
		if(a[i].hs==4)printf("s ");
	}
	return 0;
}

