#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<string>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
struct pp{int xh,s;string p;}a[100005];
bool cmp1(const pp &p1,const pp &p2){
	return p1.xh<p2.xh;
}
bool cmp2(const pp &p1,const pp &p2){
	return p1.p<p2.p;
}
bool cmp3(const pp &p1,const pp &p2){
	if(p1.s==p2.s||p1.p==p2.p)return p1.xh<p2.xh;
	if(p1.s!=p2.s)return p1.s<p2.s;
	if(p1.p!=p2.p)return p1.p<p2.p;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int n=read(),c=read(),i=1;
	while(n){
		for(int i=1;i<=n;i++){
			a[i].xh=read();cin>>a[i].p;a[i].s=read();
		}
		if(c==1)sort(a+1,a+1+n,cmp1);
		if(c==2)sort(a+1,a+1+n,cmp2);
		if(c==3)sort(a+1,a+1+n,cmp3);
		printf("Case %d:\n",i);i++;
		for(int i=1;i<=n;i++){
			printf("%06d ",a[i].xh);
			cout<<a[i].p;printf(" %d\n",a[i].s);
		}
		n=read(),c=read();
	}
	return 0;
}

