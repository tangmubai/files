#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
int a[1005];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;i++)a[i]=read();
		sort(a+1,a+1+n);
		printf("%d\n",a[n]);
		for(int i=1;i<n;i++)printf("%d ",a[i]);
		if(n==1)printf("-1");
		printf("\n");
	}
	return 0;
}

