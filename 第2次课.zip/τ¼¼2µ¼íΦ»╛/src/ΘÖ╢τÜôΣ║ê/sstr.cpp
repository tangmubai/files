#include<stdio.h>
#include<algorithm>
#include<cstring>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+c-'0',c=getchar();
	return k*j;
}
bool cmp(char a,char b){
	return a<b;
}
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int m=read();
	while(m--){
		char a[25];
		scanf("%s",a);
		int i=strlen(a);
		sort(a,a+i,cmp);
		printf("%s\n",a);
	}
	return 0;
}

