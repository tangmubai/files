#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
char x;
struct node{
	char num1;
	int num;
	char ch;
	int chh;
}a[10];
bool cmp(node c,node d){
	if(c.num!=d.num) return c.num<d.num;
	else return c.chh<d.chh;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	for(int i=1;i<=5;i++){
		cin>>a[i].num1;
		if(a[i].num==1) {
			cin>>x;
			a[i].num=10;
		}
		cin>>a[i].ch;
		if(a[i].num!=10){
			if(a[i].num1=='J') a[i].num=11;
			else if(a[i].num1=='Q') a[i].num=12;
			else if(a[i].num1=='K') a[i].num=13;
			else if(a[i].num1=='A') a[i].num=14;
			else a[i].num=a[i].num1-'0';
		}
		if(a[i].ch=='d') a[i].chh=1;
		else if(a[i].ch=='c') a[i].chh=2;
		else if(a[i].ch=='h') a[i].chh=3;
		else a[i].chh=4;
	} 
	sort(a+1,a+5+1,cmp);
	for(int i=1;i<=5;i++) printf("%c%c ",a[i].num1,a[i].ch);
	printf("\n");
	return 0;
}

