#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,c,k=1;
struct node{
	string num;
	string name;
	int score;
}a[100005];
bool cmp1(node a,node b){
	return a.num<b.num;
}
bool cmp2(node a,node b){
	if(a.name!=b.name) return a.name<=b.name;
	else return a.num<b.num;
}
bool cmp3(node a,node b){
	if(a.score!=b.score) return a.score<=b.score;
	else return a.num<b.num;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while(1){
		scanf("%d%d",&n,&c);
		if(n==0) break;
		printf("Case %d:\n",k);
		k++;
		for(int i=1;i<=n;i++) cin>>a[i].num>>a[i].name>>a[i].score;
		if(c==1) sort(a+1,a+n+1,cmp1);
		if(c==2) sort(a+1,a+n+1,cmp2);
		if(c==3) sort(a+1,a+n+1,cmp3);
		for(int i=1;i<=n;i++) cout<<a[i].num<<" "<<a[i].name<<" "<<a[i].score<<endl;
	}
	return 0;
}

