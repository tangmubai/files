#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,a[1005];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(cin>>n){
		int maxx=0;
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			if(a[i]>maxx) maxx=a[i];
		}
		if(n==1){
			printf("%d\n",a[1]);
			printf("-1");
		}
		else{
			sort(a+1,a+n+1);
			printf("%d\n",maxx);
			for(int i=1;i<=n;i++){
				if(a[i]==maxx){
					maxx=0x7fffffff;
					continue;
				} 
				printf("%d ",a[i]);
			}
		} 
		printf("\n");
	}
	return 0;
}

