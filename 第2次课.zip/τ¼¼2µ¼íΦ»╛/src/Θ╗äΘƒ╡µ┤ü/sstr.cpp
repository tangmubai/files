#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
char c[25],n,x,len;
bool cmp(char a,char b){
	return a<b;
}
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		scanf("%s",c);
		len=strlen(c);
		sort(c,c+len,cmp);
		for(int i=0;i<len;i++) printf("%c",c[i]);
		printf("\n");
	}
	return 0;
}

