
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
char aa,bb,cc;
struct node{int c;char a,b;}a[100];
bool cmp(node x,node y)
{if(x.c==y.c)
{if(x.b=='d')
 return x.b<y.b;
 else if(x.b=='c'&&y.b!='d')
 return x.b<y.b;
 else if(x.b=='h'&&y.b!='c'&&y.b!='d')
 return x.b<y.b;
 else if(x.b=='s'&&y.b!='c'&&y.b!='d'&&y.b!='h')
 return x.b<y.b;
 else return x.b>y.b;
}
 else return x.c<y.c;
}
int main()
{freopen("card.in","r",stdin);freopen("card.out","w",stdout);
 for(int i=1;i<=5;i++)
{cin>>aa>>bb;
 if(aa=='1'&&bb=='0')
{cin>>cc;
 a[i].c=10;a[i].a='0';
 a[i].b=cc;
 continue;
}
 if(aa=='J') a[i].c=11,a[i].a=aa;
 else if(aa=='Q') a[i].c=12,a[i].a=aa;
 else if(aa=='K') a[i].c=13,a[i].a=aa;
 else if(aa=='A') a[i].c=14,a[i].a=aa;
 else a[i].a=aa,a[i].c=aa-'0';
 a[i].b=bb;
}
 sort(a+1,a+5+1,cmp);
 for(int i=1;i<=5;i++)
{if(a[i].a=='0') cout<<10<<a[i].b<<" ";
 else cout<<a[i].a<<a[i].b<<" ";
}
 cout<<endl;
 return 0;
}
