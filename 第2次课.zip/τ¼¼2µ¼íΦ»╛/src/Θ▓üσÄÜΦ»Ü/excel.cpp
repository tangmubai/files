
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
struct node{string a,b;int c;}a[100010];
int n,nn,c;
bool cmp(node x,node y)
{if(c==1) return x.a<y.a;
 else if(c==2)
{if(x.b==y.b) return x.a<y.a;
 else return x.b<y.b;
}
 else if(c==3)
{if(x.c==y.c) return x.a<y.a;
 else return x.c<y.c;
}
}
int main()
{freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
 while(scanf("%d",&n)!=EOF)
{nn++;cin>>c;
 if(n==0) return 0;
 for(int i=1;i<=n;i++)
 cin>>a[i].a>>a[i].b>>a[i].c;
 cout<<"Case "<<nn<<":"<<endl;
 sort(a+1,a+n+1,cmp);
 if(c==1)
{for(int i=1;i<=n;i++)
 cout<<a[i].a<<" "<<a[i].b<<" "<<a[i].c<<endl;
}
 else if(c==2)
{for(int i=1;i<=n;i++)
 cout<<a[i].a<<" "<<a[i].b<<" "<<a[i].c<<endl;
}
 else
{for(int i=1;i<=n;i++)
 cout<<a[i].a<<" "<<a[i].b<<" "<<a[i].c<<endl;
}
}
 return 0;
}
