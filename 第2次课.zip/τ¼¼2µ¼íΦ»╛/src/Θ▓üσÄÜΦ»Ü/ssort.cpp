
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int n,a[1010];
bool cmp(int x,int y){return x<y;}
int main()
{freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
 while(scanf("%d",&n)!=EOF)
{for(int i=1;i<=n;i++)
 cin>>a[i];
 sort(a+1,a+n+1,cmp);
 cout<<a[n]<<endl;
 if(n==1) cout<<-1<<endl;
 else
{for(int i=1;i<=n-1;i++)
 cout<<a[i]<<" ";
 cout<<endl;
}
}
 return 0;
}
