
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int n;
char a[100];
bool cmp(char x,char y){return x<y;}
int main()
{freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
 cin>>n;
 while(n--)
{cin>>a+1;
 int m=strlen(a+1);
 sort(a+1,a+m+1,cmp);
 for(int i=1;i<=m;i++)
 cout<<a[i];
 cout<<endl;
}
 return 0;
}
