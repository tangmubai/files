#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"vector"
#include"map"
#include"set"
#include"queue"
#include"iomanip"
using namespace std;
char s[15];
struct pkp{
	char c1,c2;
}a[7];
bool cmp(pkp x,pkp y){
	if(x.c1==y.c1){
		if((x.c2=='d'&&y.c2=='c')||(x.c2=='c'&&y.c2=='d')) return x.c2>y.c2;
		else return x.c2<y.c2;
	}
	else{
		if(x.c1>='A'&&x.c1<='Z'&&y.c1>='A'&&y.c1<='Z'){
			if(x.c1=='J') return 1;
			else if(y.c1=='J') return 0;
			else return x.c1>y.c1;
		}
		else return x.c1<y.c1;
	}
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	scanf("%s",s+1);
	for(register int i=1;i<=5;i++){
		a[i].c1=s[i*2-1];a[i].c2=s[i*2];
	}
	sort(a+1,a+6,cmp);
	for(register int i=1;i<=5;i++)
	printf("%c%c ",a[i].c1,a[i].c2);
	return 0;
}
