#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"vector"
#include"map"
#include"set"
#include"queue"
#include"iomanip"
using namespace std;
int n,t;
struct xs{
	int xh,fs;char s[105];
}a[100005];
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
bool cmp1(xs x,xs y){
	return x.xh<y.xh;
}
bool cmp2(xs x,xs y){
	if(strcmp(x.s,y.s)==0) return x.xh<y.xh;
	else return (strcmp(x.s,y.s))<0;
}
bool cmp3(xs x,xs y){
	if(x.fs==y.fs) return x.xh<y.xh;
	else return x.fs<y.fs;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	n=read();t=read();
	while(n){
		for(register int i=1;i<=n;i++){
			a[i].xh=read();
			scanf("%s",a[i].s);
			a[i].fs=read();
		}
		printf("Case %d:\n",t);
		if(t==1){
			sort(a+1,a+n+1,cmp1);
			for(register int i=1;i<=n;i++)
			printf("%06d %s %d\n",a[i].xh,a[i].s,a[i].fs);
		}
		else if(t==2){
			sort(a+1,a+n+1,cmp2);
			for(register int i=1;i<=n;i++)
			printf("%06d %s %d\n",a[i].xh,a[i].s,a[i].fs);
		}
		else{
			sort(a+1,a+n+1,cmp3);
			for(register int i=1;i<=n;i++)
			printf("%06d %s %d\n",a[i].xh,a[i].s,a[i].fs);
		}
		n=read();t=read();
	}
	return 0;
}
