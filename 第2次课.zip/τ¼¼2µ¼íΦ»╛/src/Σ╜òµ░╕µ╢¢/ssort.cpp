#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"vector"
#include"map"
#include"set"
#include"queue"
#include"iomanip"
using namespace std;
int a[1005],n;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(register int i=1;i<=n;i++) a[i]=read();
		if(n==1){
			printf("%d\n-1\n",a[1]);
			continue;
		}
		sort(a+1,a+n+1);
		printf("%d\n",a[n]);
		for(register int i=1;i<n;i++)
		printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
