#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"vector"
#include"map"
#include"set"
#include"queue"
#include"iomanip"
using namespace std;
int n,l;char s[105];
bool cmp(char x,char y){
	return x<y;
}
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		scanf("%s",s);
		l=strlen(s);
		sort(s,s+l,cmp);
		printf("%s\n",s);
	}
	return 0;
}
