#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
char s[30];
struct q{
	char num1;
	int num2;
	char hua;
}a[15];
bool cmp(q x,q y){
	if(x.num2!=y.num2) return x.num2<y.num2;
	if(x.hua=='d') return 1;
	if(y.hua=='d') return 0;
	return x.hua<y.hua;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	scanf("%s",s);
	int m=0;
	for(int i=0;i<strlen(s);i+=2){
		m++;
		if(s[i]=='A') a[m].num2=14;
		if(s[i]=='J') a[m].num2=11;
		if(s[i]=='Q') a[m].num2=12;
		if(s[i]=='K') a[m].num2=13;
		if(s[i]=='1'&&s[i+1]=='0'){
			a[m].num2=10;
			i++;
		}
		else if(s[i]<='9'&&s[i]>='0') a[m].num2=s[i]-'0';
		a[m].num1=s[i];
		a[m].hua=s[i+1];
	}
	sort(a+1,a+1+m,cmp);
	for(int i=1;i<=m;i++){
		if(a[i].num2==10) printf("%d%c ",a[i].num2,a[i].hua);
		else printf("%c%c ",a[i].num1,a[i].hua);
	}
	return 0;
}
