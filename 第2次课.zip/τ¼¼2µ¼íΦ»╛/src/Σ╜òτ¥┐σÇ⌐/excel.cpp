#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct q{
	char id[20];
	char na[20];
	int cj;
}a[100010];
bool cmp1(q x,q y){
	for(int i=0;i<8;i++)
		if(x.id[i]!=y.id[i]) return x.id[i]<y.id[i];
}
bool cmp2(q x,q y){
	for(int i=0;i<=strlen(x.na);i++)
		if(x.na[i]!=y.na[i]) return x.na[i]<y.na[i];
	return cmp1(x,y);
}
bool cmp3(q x,q y){
	if(x.cj!=y.cj) return x.cj<y.cj;
	return cmp1(x,y);
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int n;scanf("%d",&n);
	while(n!=0){
		memset(a,'\0',sizeof(a));
		int c;scanf("%d",&c);
		for(int i=1;i<=n;i++) scanf("%s %s %d",a[i].id,a[i].na,&a[i].cj);
		if(c==1){
			printf("Case 1:\n");
			sort(a+1,a+1+n,cmp1);
			for(int i=1;i<=n;i++) printf("%s %s %d\n",a[i].id,a[i].na,a[i].cj);
		}
		if(c==2){
			printf("Case 2:\n");
			sort(a+1,a+1+n,cmp2);
			for(int i=1;i<=n;i++) printf("%s %s %d\n",a[i].id,a[i].na,a[i].cj);
		}
		if(c==3){
			printf("Case 3:\n");
			sort(a+1,a+1+n,cmp3);
			for(int i=1;i<=n;i++) printf("%s %s %d\n",a[i].id,a[i].na,a[i].cj);
		}
		scanf("%d",&n);
	}
	return 0;
}
