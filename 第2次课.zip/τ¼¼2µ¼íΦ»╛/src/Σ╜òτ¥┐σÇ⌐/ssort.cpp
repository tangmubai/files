#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int a[1010];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		if(n==1){
			printf("-1\n");
		}
		else{
			sort(a+1,a+1+n);
			for(int i=1;i<n;i++) printf("%d ",a[i]);
			printf("\n");
		}
	}
	return 0;
}
