#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct q{
	char s[30];
}a[110];
bool cmp(q x,q y){
	for(int i=0;i<=strlen(x.s);i++)
	if(x.s[i]!=y.s[i]) return x.s[i]<y.s[i];
}
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int m;
	while(scanf("%d",&m)!=EOF){
		memset(a,'\0',sizeof(a));
		for(int i=1;i<=m;i++) scanf("%s",a[i].s);
		sort(a+1,a+1+m,cmp);
		for(int i=1;i<=m;i++) printf("%s\n",a[i].s);
	}
	return 0;
}
