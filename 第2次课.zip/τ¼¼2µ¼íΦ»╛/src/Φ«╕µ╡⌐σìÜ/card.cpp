#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
struct Node
{
	int num; char hs;
}a[25];
int main()
{
	freopen("card.in", "r", stdin);
	freopen("card.out", "w", stdout);
	for (int i = 1; i <= 5; i++) 
	{
		char ch;
		scanf("%c", &ch);
		if (ch == '1') 
		{
			a[i].num = 10;
			scanf("%*c%c", &a[i].hs);
		}
		else scanf("%c", &a[i].hs);
		if (ch == 'J') a[i].num = 11;
		if (ch == 'Q') a[i].num = 12;
		if (ch == 'K') a[i].num = 13;
		if (ch == 'A') a[i].num = 14;
		if (ch == '2') a[i].num = 2;
		if (ch == '3') a[i].num = 3;
		if (ch == '4') a[i].num = 4;
		if (ch == '5') a[i].num = 5;
		if (ch == '6') a[i].num = 6;
		if (ch == '7') a[i].num = 7;
		if (ch == '8') a[i].num = 8;
		if (ch == '9') a[i].num = 9;
		if (ch == '10') a[i].num = 10;
	}
	for (int i = 1; i <= 5; i++)
		for (int j = 1; j <= 5; j++)
		{	
			if (a[i].num > a[j].num) swap(a[i], a[j]);
			else if ((a[i].num == a[j].num) && ((a[i].hs=='c'&&a[j].hs=='d')||(a[i].hs=='h'&&a[j].hs=='d')||(a[i].hs=='s'&&a[j].hs=='d')||(a[i].hs=='h'&&a[j].hs=='c')||(a[i].hs=='s'&&a[j].hs=='c')||(a[i].hs=='s'&&a[j].hs=='h')))
				swap(a[i], a[j]);
			}
	for (int i = 5; i >=1; i--) 
	{
		if (a[i].num == 11) cout << 'J';
		else if (a[i].num == 12) cout << 'Q';
		else if (a[i].num == 13) cout << 'K';
		else if (a[i].num == 14) cout << 'A';
		else cout << a[i].num;
		cout << a[i].hs << ' ';
	}
	return 0;
}

