#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n, cnt, c;
struct Node
{
	string name, id;
	int score;
}a[100005];
bool cmp1(Node a, Node b)
{
	return a.id < b.id;
}
bool cmp2(Node a, Node b)
{
	if (a.name == b.name) return a.id < b.id;
	else return a.name < b.name;
}
bool cmp3(Node a, Node b)
{
	if (a.score == b.score) return a.id < b.id;
	else return a.score < b.score;
}
int main()
{
	freopen("excel.in", "r", stdin);
	freopen("excel.out", "w", stdout);
	while(~scanf("%d", &n) && n)
	{
		scanf("%d", &c);
		for (int i = 1; i <= n; i++) cin >> a[i].id >> a[i].name>>a[i].score;
		if (c == 1) sort(a + 1, a + 1 + n, cmp1);
		else if (c == 2) sort(a + 1, a + 1 + n, cmp2);
		else if (c == 3) sort(a + 1, a + 1 + n, cmp3);
		cnt++;
		printf("Case %d:\n", cnt);
		for (int i = 1; i <= n; i++)
			cout << a[i].id << ' ' << a[i].name << ' ' << a[i].score << endl;
	}
	return 0;
}

