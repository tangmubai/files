#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n, a[100005];
int main()
{
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	while(~scanf("%d", &n))
	{
		for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
		sort(a + 1, a + 1 + n);
		if (n == 1)
		{
			printf("%d\n-1\n", a[n]);
		}
		else
		{
			printf("%d\n", a[n]);
			for (int i = 1; i < n; i++)
				printf("%d ", a[i]);
			puts("");
		}
	}
	return 0;
}

