#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int m; char s[100005];
bool cmp(char a, char b)
{
	return a < b;
}
int main()
{
	freopen("sstr.in", "r", stdin);
	freopen("sstr.out", "w", stdout);
	scanf("%d", &m);
	for (int i = 1; i <= m; i++) 
	{
		scanf("%s", s);
		sort(s, s + strlen(s), cmp);
		printf("%s\n", s);
	}
	return 0;
}
