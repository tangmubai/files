#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
struct Node{
	int p, t;
}ps[15];
char a[60];
bool cmp(Node p, Node q) {
	if (p.p != q.p)
		return p.p < q.p;
	else return p.t < q.t;	
}
int main() {
	freopen("card.in", "r", stdin);
	freopen("card.out", "w", stdout);
	scanf("%s", a);
	int l = strlen(a);
	int tot = 0, x = 0;
	for(int i = 0; i < l; ++i) {
		if (a[i] == 'd' || a[i] == 'c' || a[i] == 'h' || a[i] == 's') {
			ps[++tot].p = x;
			x = 0; 
			if (a[i] == 'd')
				ps[tot].t = 1;
			else if (a[i] == 'c')
				ps[tot].t = 2;
			else if (a[i] == 'h')
				ps[tot].t = 3;
			else if (a[i] == 's')
				ps[tot].t = 4;		  	  
		}
		else {
			if (a[i] == 'J')
				x = 11;
			else if (a[i] == 'Q')
				x = 12;
			else if (a[i] == 'K')
				x = 13;
			else if (a[i] == 'A')
				x = 14;
			else x = x * 10 + a[i] - '0'; 				
		}	
	}
	sort(ps+ 1, ps + 5 + 1, cmp);
	for(int i = 1; i <= tot; ++i) {
		if (ps[i].p <= 10)
			printf("%d", ps[i].p);
		else {
			if (ps[i].p == 11)
				printf("J");
			else if (ps[i].p == 12)
				printf("Q");
			else if (ps[i].p == 13)
				printf("K");
			else if (ps[i].p == 14)
				printf("A");			
		}	
		if (ps[i].t == 1)
			printf("d");
		if (ps[i].t == 2)
			printf("c");
		if (ps[i].t == 3)
			printf("h");
		if (ps[i].t == 4)
			printf("s");	
		printf(" ");			
	}
	return 0;
}
