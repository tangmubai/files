#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<iostream>
const int N = 100000;
using namespace std;
int n, c, t;
struct Node{
	char name[15], id[15];
	int score;
}a[N + 5];
bool cmp1(Node p, Node q) {
	return strcmp(p.id, q.id) < 0;
}
bool cmp2(Node p, Node q) {
	int t = strcmp(p.name, q.name);
	if (t == 0)
		return strcmp(p.id, q.id) < 0;
	else return t < 0;	
}
bool cmp3(Node p, Node q) {
	if (p.score == q.score)
		return strcmp(p.id, q.id) < 0;
	else return p.score < q.score;	
}
int main() {
	freopen("excel.in", "r", stdin);
	freopen("excel.out", "w", stdout);
	while(scanf("%d%d", &n, &c) != EOF) {
		if (n == 0)
			return 0;
		for(int i = 1; i <= n; ++i) 
			scanf("%s %s %d", a[i].id, a[i].name, &a[i].score);		
		if (c == 1)
			sort(a + 1, a + n + 1, cmp1);
		else if (c == 2)
			sort(a + 1, a + n + 1, cmp2);
		else if (c == 3)
			sort(a + 1, a + n + 1, cmp3);	
		printf("Case %d:\n", ++t);		
		for(int i = 1; i <= n; ++i)
			printf("%s %s %d\n", a[i].id, a[i].name, a[i].score);	
	}
}
