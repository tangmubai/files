#include<stdio.h>
#include<algorithm>
const int N = 1000;
using namespace std;

int n, a[N + 5];

void read(int &x) {
	x = 0;char c = getchar();int w = 1;
	for(; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = -1;
	for(; c <= '9' && c >= '0'; c = getchar())
		x = x * 10 + c - '0';
	x *= w;			
}

int main()

{
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	while(scanf("%d", &n) != EOF) {
		for(int i = 1; i <= n; ++i)
			read(a[i]);
		sort(a + 1, a + n + 1);
		if (n == 1) 
			printf("%d\n%d\n", a[1], -1);
		else {
			printf("%d\n", a[n]);
			for(int i = 1; i < n; ++i)
				printf("%d ", a[i]);
			puts("");	
		} 	
	}
	return 0;
}
