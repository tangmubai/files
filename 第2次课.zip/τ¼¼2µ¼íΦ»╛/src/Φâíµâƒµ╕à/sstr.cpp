#include<stdio.h>
#include<iostream>
#include<string.h>
const int N = 20;
using namespace std;
int Q;
char a[N + 5];
int main() {
	freopen("sstr.in", "r", stdin);
	freopen("sstr.out", "w", stdout);
	scanf("%d", &Q);
	while(Q--) {
		cin >> a;
		int l = strlen(a);	
		for(int i = 0; i < l; ++i)
			for(int j = 0; j < i; ++j)
				if (a[i] < a[j]) {
					char s = a[i];
					a[i] = a[j];
					a[j] = s;
				}	
		for(int i = 0; i < l; ++i)
			printf("%c", a[i]);
		puts("");			
	}
	return 0;
}
