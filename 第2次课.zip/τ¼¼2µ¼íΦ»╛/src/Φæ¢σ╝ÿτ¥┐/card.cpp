#include <stdio.h>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
char s[1005];
int len,tmp;
struct Node{
	int num,hs;
}a[1005];
bool cmp(Node a,Node b){
	if(a.num==b.num)
		return a.hs<b.hs;
	else return a.num<b.num;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	cin>>s;
	len=strlen(s);
	for(int i=0;i<=len-1;i++){
		if(i%2==0){
			if(s[i]>='1'&&s[i]<='9')
				a[++tmp].num=s[i]-'0';
			else{
				if(s[i]=='A')a[++tmp].num=14;
				if(s[i]=='J')a[++tmp].num=11;
				if(s[i]=='Q')a[++tmp].num=12;
				if(s[i]=='K')a[++tmp].num=13;
			}
		}
		else{
			if(s[i]=='d')a[tmp].hs=1;
			if(s[i]=='c')a[tmp].hs=2;
			if(s[i]=='h')a[tmp].hs=3;
			if(s[i]=='s')a[tmp].hs=4;
		}	
	}	
	sort(a+1,a+1+tmp,cmp);
	for(int i=1;i<=tmp;i++){
		if(a[i].num>=1&&a[i].num<=9)
			printf("%d",a[i].num);
		if(a[i].num==11)printf("J");
		if(a[i].num==12)printf("Q");
		if(a[i].num==13)printf("K");
		if(a[i].num==14)printf("A");
		if(a[i].hs==1)printf("d ");
		if(a[i].hs==2)printf("c ");
		if(a[i].hs==3)printf("h ");
		if(a[i].hs==4)printf("s ");
	}
	return 0;
}
