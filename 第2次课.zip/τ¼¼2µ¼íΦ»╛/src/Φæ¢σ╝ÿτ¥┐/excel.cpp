#include <stdio.h>
#include <cstring>
#include <algorithm>
using namespace std;
int n,c,tmp=1;
struct Node{
	int f;
	char x[1005],m[1005];
}a[100005];
bool cmp1(Node a,Node b){
	return strcmp(a.x,b.x)<0;
}
bool cmp2(Node a,Node b){
	if(strcmp(a.m,b.m)==0)
		return strcmp(a.x,b.x)<0;
	else return strcmp(a.m,b.m)<0;
}
bool cmp3(Node a,Node b){
	if(a.f==b.f)
		return strcmp(a.x,b.x)<0;
	else return a.f<b.f;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while(~scanf("%d%d",&n,&c)){
		if(n==0){
			break;
		}
		for(int i=1;i<=n;i++)
			scanf("%s %s%d",&a[i].x,a[i].m,&a[i].f);
		printf("Case %d:\n",tmp);
		if(c==1){
			sort(a+1,a+1+n,cmp1);
			for(int i=1;i<=n;i++)	
				printf("%s %s %d\n",a[i].x,a[i].m,a[i].f);
		}
		if(c==2){
			sort(a+1,a+1+n,cmp2);
			for(int i=1;i<=n;i++)
				printf("%s %s %d\n",a[i].x,a[i].m,a[i].f);
		}
		if(c==3){
			sort(a+1,a+1+n,cmp3);
			for(int i=1;i<=n;i++)
				printf("%s %s %d\n",a[i].x,a[i].m,a[i].f);
		}
		tmp++;
	}
	return 0;
}
