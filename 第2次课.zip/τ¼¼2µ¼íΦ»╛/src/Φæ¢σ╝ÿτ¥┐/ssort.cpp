#include <stdio.h>
#include <cstring>
#include <algorithm>
using namespace std;
int n,a[1005];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(~scanf("%d",&n)){
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		printf("%d\n",a[n]);
		for(int i=1;i<=n-1;i++)
			printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
