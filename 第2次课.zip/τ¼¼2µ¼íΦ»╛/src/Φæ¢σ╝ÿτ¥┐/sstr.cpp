#include <stdio.h>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int t;
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&t);
	while(t--){	
		char s[1005];
		cin>>s;
		int len=strlen(s);
		sort(s,s+len);
		printf("%s\n",s);
	}
	return 0;
}
