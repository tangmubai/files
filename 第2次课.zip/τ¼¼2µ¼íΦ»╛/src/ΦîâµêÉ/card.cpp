#include <cstdio>
#include <cctype>
#include <algorithm>
using namespace std;
int t[255],to[255];
char s[233];
struct qwq{
	char d,h;
}a[10];
bool cmp(qwq x,qwq y){
	if(to[x.d]!=to[y.d]) return to[x.d]<to[y.d];
	else return t[x.h]<t[y.h];
}
int main(){
	freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	t['d']=1;t['c']=2;t['h']=3;t['s']=4;
	for(int i=2;i<=10;++i) to[i+'0']=i-1;
	to['A']=13;
	to['J']=10;
	to['Q']=11;
	to['K']=12;
	scanf("%s",s+1);
	int tot=0;
	for(int i=1;s[i];++i){
		if(!isdigit(s[i])){
			a[++tot].d=s[i];
			++i;
			a[tot].h=s[i];
		}
		else{
			int now=0;
			while(isdigit(s[i])) now=now*10+(s[i]-'0'),++i;
			a[++tot].d=now+'0';
			a[tot].h=s[i];
		}
	}
	sort(a+1,a+5+1,cmp);
	for(int i=1;i<=5;++i){
		if(a[i].d==10+'0') printf("10%c ",a[i].h);
		else printf("%c%c ",a[i].d,a[i].h);
	}
	return 0;
}
