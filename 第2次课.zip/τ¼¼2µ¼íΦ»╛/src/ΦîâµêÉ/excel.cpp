#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
struct qwq{
	string id,name;
	int score;
}a[100005];
bool cmp1(qwq x,qwq y){
	return x.id<y.id;
}
bool cmp2(qwq x,qwq y){
	if(x.name!=y.name) return x.name<y.name;
	return x.id<y.id;
}
bool cmp3(qwq x,qwq y){
	if(x.score!=y.score) return x.score<y.score;
	return x.id<y.id;
}
int main(){
	freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	ios::sync_with_stdio(false);
	int kase=0;
	int n,c;
	while(cin>>n>>c&&n!=0){
		for(int i=1;i<=n;++i) cin>>a[i].id>>a[i].name>>a[i].score;
		if(c==1) sort(a+1,a+n+1,cmp1);
		if(c==2) sort(a+1,a+n+1,cmp2);
		if(c==3) sort(a+1,a+n+1,cmp3);
		cout<<"Case "<<++kase<<":"<<endl;
		for(int i=1;i<=n;++i){
			cout<<a[i].id<<' '<<a[i].name<<' '<<a[i].score<<endl;
		}
	}
	return 0;
}
