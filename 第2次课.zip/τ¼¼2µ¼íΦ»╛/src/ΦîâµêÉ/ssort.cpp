#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
int a[1005];
bool cmp(int a,int b){
    return a>b;
}
int main(){
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	ios::sync_with_stdio(false);
	int n;
	while(cin>>n){
		for(int i=1;i<=n;++i){
            cin>>a[i];
        }
        if(n==1){
            printf("%d\n-1\n",a[n]);
            continue;
        }
        sort(a+1,a+n+1,cmp);
        printf("%d\n",a[1]);
        sort(a+2,a+n+1);
        for(int i=2;i<=n;++i){
            printf("%d ",a[i]);
        }
        puts("");
	}
    return 0;
}
