#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
int main(){
    freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
    ios::sync_with_stdio(false);
    int n;cin>>n;
    while(n--){
        string a;
        cin>>a;
        sort(a.begin(),a.end());
        cout<<a<<endl;
    }
    return 0;
}