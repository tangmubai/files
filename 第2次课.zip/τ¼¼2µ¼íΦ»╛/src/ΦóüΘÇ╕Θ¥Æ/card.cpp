#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <sstream>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
using namespace std;
typedef long long ll;
struct ac {
	int num;
	char paint;
} ans[10];
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline bool cmp(ac x, ac y) {
	if (x.num == y.num) return x.paint < x.paint;
	return x.num < y.num;
}
/*inline int mx(int x, int y) {
	return x > y ? x : y;
}*/
main() {
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	for (register int i = 1; i <= 5; i ++) {
		char a, b;
		scanf ("%c%c", &a, &b);
		if (a == 'J') ans[i].num = 11;
		else if (a == 'Q') ans[i].num = 12;
		else if (a == 'K') ans[i].num = 13;
		else if (a == 'A') ans[i].num = 14;
		else if (a >= '2' && a <= '10') ans[i].num = a-48;
		if (b == 'c') ans[i].paint = 2;
		else if (b == 'h') ans[i].paint = 3;
		else if (b == 's') ans[i].paint = 4;
		else if (b == 'd') ans[i].paint = 1;
	}
	sort (ans+1, ans+6, cmp);
	for (register int i = 1; i <= 5; i ++) {
		if (ans[i].num <= 10) printf ("%d", ans[i].num);
		else {
			if (ans[i].num == 11) putchar('J');
			else if (ans[i].num == 12) putchar('Q');
			else if (ans[i].num == 13) putchar('K');
			else if (ans[i].num == 14) putchar('A');
		}
		if (ans[i].paint == 1) putchar('d');
		else if (ans[i].paint == 2) putchar('c');
		else if (ans[i].paint == 3) putchar('h');
		else if (ans[i].paint == 4) putchar('s');
		putchar(' ');
	}
	return 0;
}
