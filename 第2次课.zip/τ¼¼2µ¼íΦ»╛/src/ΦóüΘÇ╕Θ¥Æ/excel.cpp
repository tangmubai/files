#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <sstream>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
#include <iostream>
using namespace std;
typedef long long ll;
struct ac {
	int id, mark;
	string name;
}a[100005];
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline bool cmp1(ac x, ac y) {
	return x.id < y.id;
}
inline bool cmp2(ac x, ac y) {
	if (x.name == y.name) return x.id < y.id;
	return x.name < y.name;
}
inline bool cmp3(ac x, ac y) {
	if (x.mark == y.mark) return x.id < y.id;
	return x.mark < y.mark;
}
/*inline int mx(int x, int y) {
	return x > y ? x : y;
}*/
main() {
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int n, c, i = 0;
	while (cin >> n >> c) {
		i ++;
		if (n == 0) break;
		for (register int i = 1; i <= n; i ++) {
			read(a[i].id);
			cin >> a[i].name;
			read(a[i].mark);
		}
		if (c == 1)	sort (a+1, a+n+1, cmp1);
		else if (c == 2) sort (a+1, a+n+1, cmp2);
		else if (c == 3) sort (a+1, a+n+1, cmp3);
		printf ("Case %d:\n", i);
		for (register int i = 1; i <= n; i++) {
			printf ("%06d ", a[i].id);
			cout << a[i].name << " ";
			printf ("%d\n", a[i].mark);
		}
	//	puts ("");
	}
	return 0;
}
