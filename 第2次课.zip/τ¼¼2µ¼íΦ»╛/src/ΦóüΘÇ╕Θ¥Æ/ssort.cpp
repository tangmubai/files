#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <sstream>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
using namespace std;
typedef long long ll;
int a[1005];
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
/*inline bool cmp(int x, int y) {
	return x < y;
}*/
/*inline int mx(int x, int y) {
	return x > y ? x : y;
}*/
main() {
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while (scanf ("%d", &n) == 1) {
		for (register int i = 1; i <= n; i ++) read(a[i]);
		if (n == 1) puts ("-1");
		else {
			sort (a+1, a+n+1);
			printf ("%d\n", a[n]);
			for (register int i = 1; i < n; i++) printf ("%d ", a[i]);
			puts ("");
		}
	}
	return 0;
}
