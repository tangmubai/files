#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <sstream>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
#include <iostream>
using namespace std;
typedef long long ll;
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
string c;
int a[105];
/*inline int mx(int x, int y) {
	return x > y ? x : y;
}*/
main() {
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int t;
	read(t);
	while (t --) {
		cin >> c;
		int len = c.length();
		for (register int i = 0; i < len; i ++) a[i] = c[i]-64;
		sort (a, a+len);
		for (register int i = 0; i < len; i ++) printf("%c", a[i]+64);
		puts ("");
	} 
	return 0;
}
