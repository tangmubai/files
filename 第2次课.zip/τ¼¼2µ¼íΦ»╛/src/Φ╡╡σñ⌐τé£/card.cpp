#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
string s[10];
const string p1[25] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "End"};
const string p2[25] = {"d", "c", "h", "s", "End"}; 
struct node {
	int val1, val2;
};
node calc (string x) {
	node res;
	string q, q2;
	if (x[1] == '0')
		q += x[0], q += x[1], q2 += x[2];
	else
		q += x[0], q2 += x[1];
	for (int i = 0; p1[i] != "End"; i ++) {
		if (q == p1[i]) {
			res.val1 = i;
			break;
		}
	}
	for (int i = 0; p2[i] != "End"; i ++) {
		if (q2 == p2[i]) {
			res.val2 = i;
			break;
		}
	}
	return res;
}
bool cmp (string a, string b) {
	int id1 = calc(a).val1, id2 = calc(b).val1, col1 = calc(a).val2, col2 = calc(b).val2;
	if (id1 == id2)
		return col1 < col2;
	return id1 < id2;
}
int main () {
	freopen ("card.in", "r", stdin);
	freopen ("card.out", "w", stdout);
	int cnt = 0;
	string q;
	cin >> q;
	for (int i = 0; q[i]; ) {
		if (q[i] == '1' && q[i + 1] == '0') {
			s[++ cnt] += q[i];
			s[cnt] += q[i + 1];
			s[cnt] += q[i + 2];
			i += 3;
		}
		else {
			s[++ cnt] += q[i];
			s[cnt] += q[i + 1];
			i += 2;
		}
	}
	sort (s + 1, s + 6, cmp);
	for (int i = 1; i <= 5; i ++)
		cout << s[i] << ' ';
}
//10s10h3sAdJc
