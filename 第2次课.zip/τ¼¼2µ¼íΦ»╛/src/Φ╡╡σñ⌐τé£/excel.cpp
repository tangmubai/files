#include <cstdio>
#include <string>
#include <algorithm>
#include <iostream>
using namespace std;
int n, c;
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
struct node {
	int id;
	string str;
	int pts;
} a[100005];
bool cmp (node x, node y) {
	if (c == 1)
		return x.id < y.id;
	if (c == 2) {
		if (x.str == y.str)
			return x.id < y.id;
		return x.str < y.str;
	}
	if (c == 3) {
		if (x.pts == y.pts)
			return x.id < y.id;
		return x.pts < y.pts;
	}
}
void print (int x) {
	int t = x;
	int sz = 0;
	while (t) {
		sz ++;
		t /= 10;
	}
	for (int i = 1; i <= 6 - sz; i ++)
		putchar('0');
	printf ("%d", x);
}
int Case;
int main () {
	freopen("excel.in", "r", stdin);
	freopen("excel.out", "w", stdout);
	while (1) {
		scanf ("%d%d", &n, &c);
		if (n == 0)
			break;
		for (int i = 1; i <= n; i ++) {
			a[i].id = read();
			cin >> a[i].str;
			a[i].pts = read();
		}
		sort (a + 1, a + n + 1, cmp);
		printf ("Case %d:\n", ++ Case);
		for (int i = 1; i <= n; i ++) {
			print (a[i].id);
			putchar (' ');
			cout << a[i].str;
			printf (" %d\n", a[i].pts);
		}
	}
}
