#include <cstdio>
#include <cmath>
#include <string>
#include <algorithm>
#include <iostream>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int n, a[1005]; 
int main () {
	freopen ("ssort.in", "r", stdin);
	freopen ("ssort.out", "w", stdout);
	while (scanf ("%d", &n) != EOF) {
		for (int i = 1; i <= n; i ++)
			a[i] = read();
		sort (a + 1, a + n + 1);
		printf ("%d\n", a[n]);
		int sz = n - 1;
		while (sz >= 1 && a[sz] == a[sz + 1])
			sz --;
		if (sz == 0) 
			puts("-1");
		else {
			for (int i = 1; i <= sz; i ++)
				printf ("%d ", a[i]);
			putchar('\n');
		}
	}
}
