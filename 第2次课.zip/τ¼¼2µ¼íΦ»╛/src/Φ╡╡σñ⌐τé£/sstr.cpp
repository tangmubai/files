#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
int max (int a, int b) {
	return a > b ? a : b;
}
int min (int a, int b) {
	return a < b ? a : b;
}
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int main () {
	freopen ("sstr.in", "r", stdin);
	freopen ("sstr.out", "w", stdout);
	int t = read();
	while (t --) {
		string a;
		cin >> a;
		sort (a.begin(), a.end());
		cout << a << '\n';
	}
}
