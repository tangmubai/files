#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
struct node{int a,b;}f[10];
bool cmp(node a,node b){if(a.a==b.a)return a.b<b.b;return a.a<b.a;}
char a[10],b;
char s[100];
int main(){//freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	ll now=1;
	scanf("%s",s+1);
	for(ll i=1,now=1;i<=5;i++){
		ll len=0,sum=0;
		while((s[now]>'z'||s[now]<'a')&&(now)<=strlen(s+1)){
			a[++len]=s[now];
			now++;
		}
		printf("%d\n",now);
		if(len==3){
			f[i].a=10;
		}else{
			if('2'<=a[1]&&9>=a[1])f[i].a=a[i]-'0';
			if(a[1]=='A')f[i].a=70;
			if(a[1]=='J')f[i].a=20;
			if(a[1]=='Q')f[i].a=30;
			if(a[1]=='K')f[i].a=40;
		}	
		if(a[len]=='d')f[i].b=1;		
		if(a[len]=='c')f[i].b=2;		
		if(a[len]=='h')f[i].b=3;		
		if(a[len]=='s')f[i].b=4;
	}
	sort(f+1,f+6,cmp);
	for(ll i=1;i<=5;i++){
		if(2<=f[i].a&&10>=f[i].a)printf("%d",f[i].a);
		if(f[i].a==70)printf("A");
		if(f[i].a==20)printf("J");
		if(f[i].a==30)printf("Q");
		if(f[i].a==40)printf("K");		
		if(f[i].b==1)printf("d ");		
		if(f[i].b==2)printf("c ");		
		if(f[i].b==3)printf("h ");		
		if(f[i].b==4)printf("s ");
	}
	return 0;
}
//2sAd3hJc3s
