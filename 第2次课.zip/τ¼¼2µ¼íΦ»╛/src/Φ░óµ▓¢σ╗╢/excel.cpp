#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
struct node{
	int id,rant;
	char c[10];
}f[100005];
bool cmp1(node a,node b){return a.id<b.id;}
bool cmp2(node a,node b){if(strcmp(a.c,b.c)==0)return a.id<b.id;if(strcmp(a.c,b.c)==1)return false;return true;}
bool cmp3(node a,node b){if(a.rant!=b.rant)return a.rant<b.rant;return a.id<b.id;}
int main(){freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	ll n,c;
	ll now=0;
	while(scanf("%d%d",&n,&c)){
		if(n==0)break;
		for(ll i=1;i<=n;i++){
			scanf("%d %s %d",&f[i].id,f[i].c,&f[i].rant);
		}
		if(c==1)sort(f+1,f+1+n,cmp1);
		if(c==2)sort(f+1,f+1+n,cmp2);
		if(c==3)sort(f+1,f+1+n,cmp3);
		printf("Case %d:\n",++now);
		for(ll i=1;i<=n;i++)printf("%06d %s %d\n",f[i].id,f[i].c,f[i].rant);
	}
	return 0;
}

