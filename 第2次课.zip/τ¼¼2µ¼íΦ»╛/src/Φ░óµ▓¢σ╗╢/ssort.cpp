#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
int a[1005]={0};
int main(){freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	ll n;
	while(~scanf("%d",&n)){register bool ok=0;
		for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		printf("%d\n",a[n]);
		for(ll i=1;i<=n-1;i++,ok=1)printf("%d ",a[i]);
		if(!ok)printf("-1");
		printf("\n");
	}
	return 0;
}

