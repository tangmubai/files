#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<math.h>
#include<vector>
#include<stdio.h>
#include<cstring>
#include<string.h>
#include<iostream>
#include<algorithm>
#define ll register int
#define mod 20070707
#define oo 20070707

using namespace std;
char c[50];
int main(){freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
	ll n;
	scanf("%d",&n);
	for(ll i=1;i<=n;i++)scanf("%s",c+1),sort(c+1,c+1+strlen(c+1)),printf("%s\n",c+1);
	return 0;
}

