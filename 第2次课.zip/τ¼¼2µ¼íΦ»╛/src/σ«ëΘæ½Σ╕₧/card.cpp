#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
struct node{
	char s[5];
}a[10];
int find(char h){
	if(h=='d')return 1;
	if(h=='c')return 2;
	if(h=='h')return 3;
	if(h=='s')return 4;
}
int find1(char k){
	if(k=='2')return 2;
	if(k=='3')return 3;
	if(k=='4')return 4;
	if(k=='5')return 5;
	if(k=='6')return 6;
	if(k=='7')return 7;
	if(k=='8')return 8;
	if(k=='9')return 9;
	if(k=='10')return 10;
	if(k=='J')return 11;
	if(k=='Q')return 12;
	if(k=='K')return 13;
	if(k=='A')return 14;
}
bool cmp(node x,node y){
	int t1=find1(x.s[0]),t2=find1(y.s[0]);
	if(t1!=t2)return t1<t2;
	else return find(x.s[1])<find(y.s[1]);
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	int n=5,i;
	for(i=1;i<=n;i++){
		cin>>a[i].s[0]>>a[i].s[1];
	}
	sort(a+1,a+6,cmp);
	for(i=1;i<=n;i++){
		printf("%c%c ",a[i].s[0],a[i].s[1]);
	}
	return 0;
}
