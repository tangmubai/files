#include<stdio.h>
#include<algorithm>
using namespace std;
struct node{
	char num[10],name[15];
	int s;
}a[100005];
int c;
bool cmp(node x,node y){
	int i;
	if(c==1){
		for(i=0;i<6;i++){
			if(x.num[i]<y.num[i])return 1;
			if(x.num[i]>y.num[i])return 0;
		}
	}
	if(c==2){
		int flag=1;
		for(i=0;x.name[i]||y.name[i];i++){
			if(x.name[i]<y.name[i])return 1;
			if(x.name[i]>y.name[i])return 0;
		}
		if(flag){
			for(i=0;i<6;i++){
				if(x.num[i]<y.num[i])return 1;
				if(x.num[i]>y.num[i])return 0;
			}
		}
	}
	if(c==3){
		if(x.s!=y.s)return x.s<y.s;
		else{
			for(i=0;i<6;i++){
				if(x.num[i]<y.num[i])return 1;
				if(x.num[i]>y.num[i])return 0;
			}
		}
	}
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int n,sum=0;
	scanf("%d%d",&n,&c);
	while(n!=0){
		int i,j;
		for(i=1;i<=n;i++){
			scanf("%s%s%d",a[i].num,a[i].name,&a[i].s);
		}
		sort(a+1,a+1+n,cmp);
		sum++;
		printf("Case %d:\n",sum);
		for(i=1;i<=n;i++){
			for(j=0;j<6;j++)printf("%c",a[i].num[j]);
			printf(" ");
			for(j=0;a[i].name[j];j++)printf("%c",a[i].name[j]);
			printf(" %d\n",a[i].s);
		}
		scanf("%d%d",&n,&c);
	}
	return 0;
}
