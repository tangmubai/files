#include<stdio.h>
#include<algorithm>
using namespace std;
char a[25];
bool cmp(char x,char y){
	return x<y;
}
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int m;
	scanf("%d",&m);
	while(m--){
		scanf("%s",a);
		int n=0,i;
		for(n=0;a[n];n++);
		sort(a,a+n,cmp);
		for(i=0;i<n;i++){
			printf("%c",a[i]);
		}
		printf("\n");
	}
	return 0;
}
