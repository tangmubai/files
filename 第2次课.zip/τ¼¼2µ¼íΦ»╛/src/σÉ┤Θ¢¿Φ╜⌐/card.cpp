#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
struct Node{
	int x,y;
	char ans1,ans2;
}a[20];
bool cmp(Node xx,Node yy){
	if(xx.x==yy.x){
		return xx.y<yy.y;
	}
	else return xx.x<yy.x;
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	for(int i=1;i<=5;i++){
		char c1,c2;
		scanf("%c%c",&c1,&c2);
		if(c1>='A'&&c1<='Z'){
			if(c1=='A')a[i].x=14;
			if(c1=='K')a[i].x=13;
			if(c1=='Q')a[i].x=12;
			if(c1=='J')a[i].x=11;
			a[i].ans1=c1;	
		}
		else a[i].x=c1-'0';
		if(c2=='d')a[i].y=1;
		if(c2=='c')a[i].y=2;
		if(c2=='h')a[i].y=3;
		if(c2=='s')a[i].y=4;
		a[i].ans2=c2;
	}
	sort(a+1,a+1+5,cmp);
	for(int i=1;i<=5;i++){
		if(a[i].x>=11)printf("%c",a[i].ans1);
		else printf("%d",a[i].x);
		printf("%c ",a[i].ans2);
	}
	return 0;
}
