#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
int n,m,s;
struct Node{
	int sc;
	char na[10],num[10];
}a[100005];
bool cmp1(Node xx,Node yy){
	return strcmp(xx.num,yy.num)<0;
}
bool cmp2(Node xx,Node yy){
	if(strcmp(xx.na,yy.na)==0)return strcmp(xx.num,yy.num)<0;
	else return strcmp(xx.na,yy.na)<0;
}
bool cmp3(Node xx,Node yy){
	if(xx.sc==yy.sc)return strcmp(xx.num,yy.num)<0;
	else return xx.sc<yy.sc;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while(1){
		scanf("%d %d",&n,&m);
		if(n==0)break;
		for(int i=1;i<=n;i++)scanf("%s %s %d",&a[i].num,&a[i].na,&a[i].sc);
		s++;
		if(m==1)sort(a+1,a+1+n,cmp1);
		if(m==2)sort(a+1,a+1+n,cmp2);
		if(m==3)sort(a+1,a+1+n,cmp3);
		printf("Case %d:\n",s);
		for(int i=1;i<=n;i++)printf("%s %s %d\n",a[i].num,a[i].na,a[i].sc);
	}
	return 0;
}
