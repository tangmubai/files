#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
int n,a[1005],maxn,ok;
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		maxn=0;ok=1;
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			maxn=max(maxn,a[i]);
		}
		if(n==1){
			printf("%d\n",a[1]);
			printf("-1\n");
			continue;
		}
		printf("%d\n",maxn);
		sort(a+1,a+1+n);
		for(int i=1;i<=n;i++){
			if(a[i]==maxn&&ok){
				ok=0;
				continue;
			}
			printf("%d ",a[i]);
		}
		printf("\n");
	}
	return 0;
}
