#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<math.h>
using namespace std;
int n;
char a[25];
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>a;
		sort(a,a+strlen(a));
		cout<<a<<endl;
	}
	return 0;
}
