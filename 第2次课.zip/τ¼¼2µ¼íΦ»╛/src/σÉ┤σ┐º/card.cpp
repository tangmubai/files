#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
struct node
{
	int z,b;
	char c,y;
}a[110];
bool cmp(node a,node b)
{
	if(a.z!=b.z) return a.z<b.z;
	else return a.b<b.b;
}
string s;
int num=0;
int main()
{
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i+=2)
	{
		int flag=0;
		num++;
		if(s[i]=='J')
		{
			a[num].z=11;
			a[num].y=s[i];
			flag=1;
		}
		if(s[i]=='Q')
		{
			a[num].z=12;
			a[num].y=s[i];
			flag=1;
		}
		if(s[i]=='K')
		{
			a[num].z=13;
			a[num].y=s[i];
			flag=1;
		}
		if(s[i]=='A')
		{
			a[num].z=14;
			a[num].y=s[i];
			flag=1;
		}
		if(flag==0)
		{
			a[num].z=s[i]-'0';
			a[num].y=s[i];
		}
		flag=0;
		if(s[i+1]=='d')
		{
			a[num].b=1;
			a[num].c=s[i+1];
			flag=1;
		}
		if(s[i+1]=='c')
		{
			a[num].b=2;
			a[num].c=s[i+1];
			flag=1;
		}
		if(s[i+1]=='h')
		{
			a[num].b=3;
			a[num].c=s[i+1];
			flag=1;
		}
		if(s[i+1]=='s')
		{
			a[num].b=4;
			a[num].c=s[i+1];
			flag=1;
		}
		if(flag==0)
		a[num].c=s[i+1];
	}
	sort(a+1,a+num+1,cmp);
	for(int i=1;i<=num;i++)
	{
		printf("%c%c ",a[i].y,a[i].c);
	}
	return 0;
}

