#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
inline int read()
{
	int s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
struct node
{
	string x,name;
	int s;
}a[101000];
bool cmp1(node a,node b)
{
	return a.x<b.x;
}
bool cmp2(node a,node b)
{
	if(a.name!=b.name) return a.name<b.name;
	else return a.x<b.x;
}
bool cmp3(node a,node b)
{
	if(a.s!=b.s) return a.s<b.s;
	else return a.x<b.x;
}
int n,m,i=1;
int main()
{
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while(1)
	{
		n=read();
		if(n==0)
		{
			return 0;
		}
		m=read();
		printf("Case %d:\n",i);
		for(int j=1;j<=n;j++)
		{
			cin>>a[j].x>>a[j].name>>a[j].s;
		}
		if(m==1)
			sort(a+1,a+n+1,cmp1);
		if(m==2)
			sort(a+1,a+n+1,cmp2);
		if(m==3)
			sort(a+1,a+n+1,cmp3);
		for(int j=1;j<=n;j++)
		{
			cout<<a[j].x<<" "<<a[j].name<<" "<<a[j].s<<endl;
		}
		i++;
	}
	return 0;
}

