#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
inline int read()
{
	int s=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-')
			f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9')
	{
		s=(s<<3)+(s<<1)+(c^48);
		c=getchar();
	}
	return s*f;
}
int n,a[11100];
int main()
{
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(cin>>n)
	{
		for(int i=1;i<=n;i++)
		{
			a[i]=read();
		}
		if(n==1)
		{
			printf("%d\n-1\n",a[1]);
			continue;
		}
		sort(a+1,a+n+1);
		printf("%d\n",a[n]);
		for(int i=1;i<=n-2;i++)
		{
			printf("%d ",a[i]);
		}
		printf("%d\n",a[n-1]);
	}
	return 0;
}

