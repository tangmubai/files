#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n;
string s;
int main()
{
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		sort(s.begin(),s.end());
		cout<<s<<endl;
	}
	return 0;
}
