#include<stdio.h>
#include<algorithm>
struct node
{
	char a,b;int num,col;
	inline void in()
	{
		a=getchar();b=getchar();
		switch(a)
		{
			case'J':num=11;break;
			case'Q':num=12;break;
			case'K':num=13;break;
			case'A':num=14;break;
			default:num=a-'0';
		}
		if(b=='0'){num=10;b=getchar();}
		switch(b)
		{
			case'd':col=1;break;
			case'c':col=2;break;
			case'h':col=3;break;
			case's':col=4;break;
		}
	}
	inline void ou()const
	{
		if(num==10)putchar('1'),putchar('0');
		else putchar(a);
		putchar(b);putchar(' ');
	}
	inline bool operator<(const node&kkk)const
	{
		if(num!=kkk.num)return num<kkk.num;
		return col<kkk.col;
	}
}a[5];
main()
{
	freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	for(register int i=0;i<5;a[i++].in());
	std::sort(a,a+5);
	for(register int i=0;i<5;a[i++].ou());
}
