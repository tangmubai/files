#include<stdio.h>
#include<algorithm>
inline void read(int&x)
{
	register char c=getchar();for(;c<'0'||'9'<c;c=getchar());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=getchar());
}
struct node
{
	int id,sc;char name[9];
	inline void in(){read(id);scanf("%s",name);read(sc);}
	inline void ou()const{printf("%06d %s %d\n",id,name,sc);}
}a[100000];
inline bool cmp1(const node&x,const node&y)
{
	return x.id<y.id;
}
inline bool cmp2(const node&x,const node&y)
{
	register int i=0;
	for(;x.name[i]&&y.name[i];++i)
		if(x.name[i]!=y.name[i])return x.name[i]<y.name[i];
	if(x.name[i]!=y.name[i])return x.name[i]<y.name[i];
	return x.id<y.id;
}
inline bool cmp3(const node&x,const node&y)
{
	if(x.sc!=y.sc)return x.sc<y.sc;
	return x.id<y.id;
}
main()
{
	freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	for(register int cases=1,n,c;read(n),n;)
	{
		read(c);
		for(register int i=0;i<n;a[i++].in());
		if(c==1)std::sort(a,a+n,cmp1);
		if(c==2)std::sort(a,a+n,cmp2);
		if(c==3)std::sort(a,a+n,cmp3);
		printf("Case %d:\n",cases++);
		for(register int i=0;i<n;a[i++].ou());
	}
}
