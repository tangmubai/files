#include<stdio.h>
#include<algorithm>
inline void read(int&x)
{
	register bool t=0;register char c=getchar();for(;c<'0'||'9'<c;t|=c=='-',c=getchar());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=getchar());if(t)x=-x;
}
int a[1001];
main()
{
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	for(register int n;scanf("%d",&n)!=EOF;putchar('\n'))
	{
		for(register int i=0;i<n;read(a[i++]));
		std::sort(a,a+n);
		printf("%d\n",a[n-1]);
		if(n==1)putchar('-'),putchar('1');
		else for(register int i=0;i<n-1;++i)printf("%d ",a[i]);
	}
}
