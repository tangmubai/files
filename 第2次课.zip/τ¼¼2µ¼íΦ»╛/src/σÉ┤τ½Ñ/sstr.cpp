#include<stdio.h>
#include<string.h>
#include<algorithm>
main()
{
	freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
	register int t,n;register char s[22];
	for(scanf("%d",&t);t--;)
	{
		scanf("%s",s);n=strlen(s);
		std::sort(s,s+n);
		printf("%s\n",s);
	}
}
