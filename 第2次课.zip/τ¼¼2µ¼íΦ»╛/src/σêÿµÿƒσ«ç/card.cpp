#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int tot = 0;
struct Node 
{
	int num, flw;
} a[105];
char s[1005];

bool cmp(Node x , Node y)
{
	if (x.num != y.num)
		return x.num < y.num;
	return x.flw < y.flw;
}

int main()
{
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	scanf("%s", s + 1);
	for (int i = 1; s[i]; i++)
	{
		if (s[i] == '1' && s[i + 1] == '0')
		{
			a[++tot].num = 10;
			i++;
		}
		else if (s[i] >= '0' && s[i] <= '9')
			a[++tot].num = s[i] - '0';
		if (s[i] == 'J' || s[i] == 'Q' || s[i] == 'K' || s[i] == 'A')
		{
			if (s[i] == 'J')
				a[++tot].num = 11;
			if (s[i] == 'Q')
				a[++tot].num = 12;
			if (s[i] == 'K')
				a[++tot].num = 13;
			if (s[i] == 'A')
				a[++tot].num = 14;
		}
		if (s[i] == 'd')
			a[tot].flw = 1;
		if (s[i] == 'c')
			a[tot].flw = 2;
		if (s[i] == 'h')
			a[tot].flw = 3;
		if (s[i] == 's')
			a[tot].flw = 4;
	}
	sort(a + 1, a + 1 + tot, cmp);
	for (int i = 1; i <= tot; i++)
	{
		if (a[i].num <= 10)
			printf("%d", a[i].num);
		else
		{
			if (a[i].num == 11)
				printf("J");
			if (a[i].num == 12)
				printf("Q");
			if (a[i].num == 13)
				printf("K");
			if (a[i].num == 14)
				printf("A");
		}
		if (a[i].flw == 1)
			printf("d");
		if (a[i].flw == 2)
			printf("c");
		if (a[i].flw == 3)
			printf("h");
		if (a[i].flw == 4)
			printf("s");
		printf(" ");
	}
	return 0;
}
