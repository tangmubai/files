#include <cstdio>
#include <algorithm>
#include <cstring>
#include <iostream>
using namespace std;

struct Node
{
	int x;
	char name[10];
	int c;
} a[100005];

bool cmp1(Node x, Node y)
{
	return x.x < y.x;
}

bool cmp2(Node x, Node y)
{
	int lenx = strlen(x.name + 1), leny = strlen(y.name + 1);
	if (lenx != leny)
	{
		for (int i = 1; i <= min(lenx, leny); i++)
			if (x.name[i] != y.name[i])
				return x.name[i] < y.name[i];
		return lenx < leny;
	}
	else
	{
		for (int i = 1; i <= lenx; i++)
			if (x.name[i] != y.name[i])
				return x.name[i] < y.name[i];
		return x.x < y.x;
	}
}

bool cmp3(Node x, Node y)
{
	if (x.c != y.c)
		return x.c < y.c;
	else
		return x.x < y.x;
}

int main()
{
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int t = 1;
	int n, c;
	while ((scanf("%d %d", &n, &c)) != EOF)
	{
		if (n == 0)
			break;
		for (int i = 1; i <= n; i++)
		{
			scanf("%d %s %d", &a[i].x, a[i].name + 1, &a[i].c);
		}
		if (c == 1)
			sort(a + 1, a + 1 + n, cmp1);
		if (c == 2)
			sort(a + 1, a + 1 + n, cmp2);
		if (c == 3)
			sort(a + 1, a + 1 + n, cmp3);
		printf("Case %d:\n", t);
		t++;
		for (int i = 1; i <= n; i++)
			printf("%06d %s %d\n", a[i].x, a[i].name + 1, a[i].c);
	}
	return 0;
}
