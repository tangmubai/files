#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;

int a[10005];

int main()
{
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while (cin >> n)
	{
		for (int i = 1; i <= n; i++)
			scanf("%d", &a[i]);
		sort(a + 1, a + 1 + n);
		printf("%d\n", a[n]);
		if (n == 1)
		{
			printf("%d\n", -1);
			continue;
		}
		for (int i = 1; i < n; i++)
		{
			printf("%d ", a[i]);
		}
		printf("\n");
	}
	return 0;
}
