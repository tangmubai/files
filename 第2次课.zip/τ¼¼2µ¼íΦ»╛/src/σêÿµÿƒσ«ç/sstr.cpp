#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

char a[105];

bool cmp(char x, char y)
{
	return x < y;
}

int main()
{
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int t;
	scanf("%d", &t);
	while (t--)
	{
		int n = 0;
		scanf("%s", a + 1);
		for (n = 1; a[n]; n++);
		n--;
		sort(a + 1, a + 1 + n);
		printf("%s", a + 1);
		printf("\n");
	}
}
