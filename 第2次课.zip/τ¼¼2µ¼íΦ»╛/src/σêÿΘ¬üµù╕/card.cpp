#include <iostream>
#include <algorithm>
using namespace std;
struct poke {
	int num, color;
} a[10];
string s;
inline int ctod(char c) {
	if (c >= '2' && c <= '9')
		return c - '0';
	if (c == 'J')
		return 11;
	if (c == 'Q')
		return 12;
	if (c == 'K')
		return 13;
	if (c == 'A')
		return 14;
}
inline char dtoc(int d) {
	if (d >= 2 && d <= 9)
		return '0' + d;
	if (d == 11)
		return 'J';
	if (d == 12)
		return 'Q';
	if (d == 13)
		return 'K';
	if (d == 14)
		return 'A';
}
inline int color_d(char c) {
	if (c == 's')
		return 1;
	if (c == 'h')
		return 2;
	if (c == 'c')
		return 3;
	if (c == 'd')
		return 4;
}
inline char color_c(int d) {
	if (d == 1)
		return 's';
	if (d == 2)
		return 'h';
	if (d == 3)
		return 'c';
	if (d == 4)
		return 'd';
}
inline bool cmp(poke p, poke q) {
	return p.num != q.num ? p.num < q.num : p.color > q.color;
}
int main(void) {
	freopen("card.in", "r", stdin);
	freopen("card.out", "w", stdout);
	cin >> s;
	for (int i = 0; i < s.length(); i += 2) {
		if (s[i] == '1' && s[i + 1] == '0') {
			a[i >> 1].num = 10;
			++i;
		}
		else
			a[i >> 1].num = ctod(s[i]);
		a[i >> 1].color = color_d(s[i + 1]);
	}
	sort(a, a + 5, cmp);
	for (int i = 0; i < 5; ++i) {
		if (a[i].num == 10)
			cout << "10";
		else
			cout << dtoc(a[i].num);
		cout << color_c(a[i].color) << ' ';
	}
	return 0;
}
