#include <iostream>
#include <algorithm>
using namespace std;
int n, c;
struct Stu {
	string id, name;
	int src;
} a[100005];
inline bool cmp(Stu p, Stu q) {
	if (c == 1)
		return p.id < q.id;
	if (c == 2)
		return p.name != q.name ? p.name < q.name : p.id < q.id;
	if (c == 3)
		return p.src != q.src ? p.src < q.src : p.id < q.id;
}
int main(void) {
	freopen("excel.in", "r", stdin);
	freopen("excel.out", "w", stdout);
	cin >> n;
	for (int i = 1; n; ++i) {
		cout << "Case " << i << ":\n";
		cin >> c;
		for (int j = 1; j <= n; ++j)
			cin >> a[j].id >> a[j].name >> a[j].src;
		sort(a + 1, a + 1 + n, cmp);
		for (int j = 1; j <= n; ++j)
			cout << a[j].id << ' ' << a[j].name << ' ' << a[j].src << '\n';
		cin >> n;
	}
	return 0;
}
