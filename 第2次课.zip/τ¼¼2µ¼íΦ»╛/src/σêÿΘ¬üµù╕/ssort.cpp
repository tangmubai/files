#include <stdio.h>
#include <algorithm>
int n, a[1005];
int main(void) {
	freopen("ssort.in", "r", stdin);
	freopen("ssort.out", "w", stdout);
	while (~scanf("%d", &n)) {
		for (int i = 1; i <= n; ++i)
			scanf("%d", &a[i]);
		std:: sort(a + 1, a + 1 + n);
		printf("%d\n", a[n]);
		if (n > 1) {
			for (int i = 1; i < n; ++i)
				printf("%d ", a[i]);
			puts("");
		}
		else
			puts("-1");
	}
	return 0;
}
