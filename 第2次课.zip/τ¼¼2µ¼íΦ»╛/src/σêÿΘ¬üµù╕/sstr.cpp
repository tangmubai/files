#include <stdio.h>
#include <string.h>
#include <algorithm>
char c[25];
int main(void) {
	freopen("sstr.in", "r", stdin);
	freopen("sstr.out", "w", stdout);
	int m;
	for (scanf("%d", &m); m--; ) {
		scanf("%s", c);
		std:: sort(c, c + strlen(c));
		for (int i = 0; c[i] != '\0'; ++i)
			putchar(c[i]);
		puts("");
	}
	return 0;
}
