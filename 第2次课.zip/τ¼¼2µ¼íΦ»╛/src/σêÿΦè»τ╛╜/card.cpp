#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
map<string,int> mp;
map<string,int> m;
int n;
string s;
struct node
{
	string x,y;
}a[N];
inline bool cmp(node p,node q)
{
	if(p.x!=q.x) return mp[p.x]<mp[q.x];
	return m[p.y]<m[q.y];
}
int main()
{
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	for(int i=1;i<=9;i++) mp[(string)(i+"1")]=i;
	mp["J"]=10;
	mp["Q"]=11;
	mp["K"]=12;
	mp["A"]=13;
	m["d"]=1;
	m["c"]=2;
	m["h"]=3;
	m["s"]=4;
	cin>>s;
	for(int i=0;i<s.size();i+=2)
	{
		a[++n].x=s[i];
		if(s[i]=='1') a[n].x='10',getchar();
		a[n].y=s[i+1];
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		cout<<a[i].x<<a[i].y<<" ";
	}
	return 0;
}
