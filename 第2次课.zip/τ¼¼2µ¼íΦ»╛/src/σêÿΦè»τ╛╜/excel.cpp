#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e5+5;
int n,i,c;
struct node
{
	string num,name;
	int sum;
}a[N];
inline bool cmp1(node p,node q)
{
	return p.num<q.num;
}
inline bool cmp2(node p,node q)
{
	if(p.name!=q.name) return p.name<q.name;
	return p.num<q.num;
}
inline bool cmp3(node p,node q)
{
	if(p.sum!=q.sum) return p.sum<q.sum;
	return p.num<q.num;
}
int main()
{
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while(~scanf("%d",&n))
	{
		i++;
		if(n==0) return 0;
		printf("Case %d:\n",i);
		scanf("%d",&c);
		for(int j=1;j<=n;j++)
		{
			cin>>a[j].num>>a[j].name;
			scanf("%d",&a[j].sum);
		}
		if(c==1) sort(a+1,a+n+1,cmp1);
		if(c==2) sort(a+1,a+n+1,cmp2);
		if(c==3) sort(a+1,a+n+1,cmp3);
		for(int j=1;j<=n;j++)
		{
			cout<<a[j].num<<" "<<a[j].name;
			printf(" %d\n",a[j].sum);
		}
	}
	return 0;
}
