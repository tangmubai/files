#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
int t;
string a;
int main()
{
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		cin>>a;
		sort(a.begin(),a.end());
		cout<<a;
		puts(" ");
	}
	return 0;
}
