#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n,a[1001],max=0;cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	if(n==1){
	   cout<<a<<endl;
	   cout<<"-1"<<endl;
	   return 0;
	}
	sort(a+1,a+n+1);
	max=a[n];
	cout<<max<<endl;
	for(int i=1;i<=n-1;i++)cout<<a[i]<<" ";
	return 0;
} 
