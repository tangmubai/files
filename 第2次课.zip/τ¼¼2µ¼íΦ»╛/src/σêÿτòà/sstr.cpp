#include<iostream>
#include<algorithm>
#include<string.h>
#include<cstdio>
using namespace std;
int main(){
	//freopen("sstr.in","r",stdin);
	//freopen("sstr.out","w",stdout);
	int m,l=20,i=1;
	char a[100];
	cin>>m;
       for(int i=1;i<=m;i++){
	       cin>>a[i];
	    for(int i=1;i<=strlen(a[i]);i++){
	        for(int j=1;j<=strlen(a[i])-1;j++){
	            if(a[i]-'A'>a[j]-'A'){
				   swap(a[i],a[j]);
	            }
		    }
	    }
	   }
	for(int i=1;i<=strlen(a[i]);i++)cout<<a[i];
	m--;
	}
	return 0;
}

