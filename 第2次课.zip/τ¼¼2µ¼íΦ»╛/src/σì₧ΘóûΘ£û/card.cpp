#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
char p[100];
int main(){
	freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	scanf("%s",&p);
	printf("%s",p);
	return 0;
}
