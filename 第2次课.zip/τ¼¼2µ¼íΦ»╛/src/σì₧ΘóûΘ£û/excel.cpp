#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
struct no{
	int xh,cj;
	char nam[10];
}p[100005];
bool cmp1(no x,no y){
	return x.xh<y.xh;
}
bool cmp2(no x,no y){
	for(int i=0,j=0;i<strlen(x.nam)&&j<strlen(y.nam);i++,j++){
		if(x.nam[i]<y.nam[j])return 1;
		if(x.nam[i]>y.nam[j])return 0;
	}
	return x.xh<y.xh;
}
bool cmp3(no x,no y){
	if(x.cj!=y.cj)return x.cj<y.cj;
	else return x.xh<y.xh;
}
int n,c,a[1005],num;
int main(){
	freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	while(scanf("%d %d",&n,&c)){
		if(n==0)return 0;num++;
		for(int i=1;i<=n;i++)scanf("%d %s %d",&p[i].xh,p[i].nam,&p[i].cj);
		if(c==1)sort(p+1,p+1+n,cmp1);
		if(c==2)sort(p+1,p+1+n,cmp2);
		if(c==3)sort(p+1,p+1+n,cmp3);
		printf("Case %d:\n",num);
		for(int i=1;i<=n;i++){
			printf("%06d %s %d\n",p[i].xh,p[i].nam,p[i].cj);
		}
	}
	return 0;
}
