#include<stdio.h>
#include<algorithm>
using namespace std;
int n,a[1005];
int main(){
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+1+n);printf("%d\n",a[n]);
		if(n==1){
			printf("-1\n");
		}
		else{
			for(int i=n-1;i>0;i--)printf("%d ",a[i]);
			printf("\n");
		}
	}
	return 0;
}
