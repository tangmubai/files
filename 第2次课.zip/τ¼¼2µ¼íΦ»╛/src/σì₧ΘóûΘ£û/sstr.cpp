#include<stdio.h>
#include<string.h>
using namespace std;
int t,q[1000];
char a[26];
int main(){
	freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		for(int i=0;i<200;i++)q[i]=0;
		scanf("%s",a);
		for(int i=0;i<strlen(a);i++)q[a[i]]++;
		for(int i=97;i<150;i++){
			if(q[i]!=0){
				for(int j=0;j<q[i];j++)printf("%c",i);	
			}
		}
		printf("\n");
	}
	return 0;
}
