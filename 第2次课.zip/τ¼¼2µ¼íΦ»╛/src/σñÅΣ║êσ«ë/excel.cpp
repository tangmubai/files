#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
struct Node{
	char xh[10],mz[10];
	int cj;
}a[100010];
bool cmpxh(Node q,Node p){
	return q.xh<p.xh;
}
bool cmpcj(Node q,Node p){
	return q.cj<p.cj;
}
bool kkkkk(Node q,Node p){
	return q.mz<p.mz;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int t=1;
	int n,m;
	while(scanf("%d%d",&n,&m)){
		if(n==0) break;
		else{
			for(int i=1;i<=n;i++)
				cin>>a[i].xh+1>>a[i].mz+1>>a[i].cj;
			printf("Case %d:\n",t);
			t++;
			if(m==1){
				sort(a+1,a+1+n,cmpxh);
				cout<<a[n].xh+1<<" "<<a[n].mz+1<<" "<<a[n].cj<<endl;
				for(int i=1;i<n;i++)
					cout<<a[i].xh+1<<" "<<a[i].mz+1<<" "<<a[i].cj<<endl;
			}
			else if(m==2){
				sort(a+1,a+1+n,kkkkk);
				for(int i=1;i<=n;i++)
					cout<<a[i].xh+1<<" "<<a[i].mz+1<<" "<<a[i].cj<<endl;
			}
			else if(m==3){
				sort(a+1,a+1+n,cmpcj);
				for(int i=1;i<=n;i++)
					cout<<a[i].xh+1<<" "<<a[i].mz+1<<" "<<a[i].cj<<endl;
			}
		}
	}
	return 0;
}

