#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
using namespace std;
int n,a[1010];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while(cin>>n){
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		printf("%d\n",a[n]);
		if(n==1){
			puts("-1");
			continue;
		}
		for(int i=1;i<n;i++)
			printf("%d ",a[i]);
		puts("");
	}
	return 0;
}
