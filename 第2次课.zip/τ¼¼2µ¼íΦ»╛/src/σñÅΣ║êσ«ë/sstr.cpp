#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
int m;
char s[25];
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		getchar();
		scanf("%s",s+1);
		int len=strlen(s+1);
		sort(s+1,s+1+len);
		printf("%s\n",s+1);
	}
	return 0;
}
