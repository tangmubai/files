#include <stdio.h>
#include <string>
#include <cctype>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

struct node {
	char s, h;
} s[10], z[10];
//d c h s
bool judge_h(char x, char y) {
	if (x == 'd') return true;
	if (y == 'd') return false;
	if (x == 'c') return true;
	if (y == 'c') return false;
	if (x == 'h') return true;
	if (y == 'h') return false;
	return true;
}

bool judge_z(char x, char y) {
	if (x == 'J') return true;
	if (y == 'J') return false;
	if (x == 'Q') return true;
	if (y == 'Q') return false;
	if (x == 'K') return true;
	if (y == 'K') return false;
	return true;
}

bool cmps(node x ,node y) {
	cout <<"!";
	if (x.s == y.s) {
		if (judge_h(x.h,y.h) == true) 
//			return true;
			return false;
		else 
			return true;
//			return false;
			
	}
	return x.s < y.s;
}

bool cmpz(node x,node y) {
	if (x.s == y.s) {
		if (judge_h(x.h,y.h) == true) 
//			return true;
			return false;
		else 
//			return false;
			return true;
	}
	if (judge_z(x.s,y.s) == true) 
//			return true;
			return false;
		else 
//			return false;
			return true;
}

string ss;

int main() {
//	ios :: sync_with_stdio(false);
//	freopen("card.in","r",stdin);
//	freopen("card.out","w",stdout);
	cin >> ss;
//	cout << ss;
	int cnt_s = 0, cnt_z = 0;
	for (int i = 0; i <= 8; i += 2) {
		if (isdigit(ss[i])) s[++cnt_s].s = ss[i], s[cnt_s].h = ss[i + 1];
		else z[++cnt_z].s = ss[i], z[cnt_z].h = ss[i + 1];
	}	
	sort(s + 1, s + 1 + 5, cmps);
	sort(z + 1, z + 1 + 5, cmpz);
	for (int i = 1; i <= cnt_s; i++) {
		cout << s[i].s << s[i].h << ' ';
	} 
	cout << '\n';
	for (int i = 1; i <= cnt_z; i++) {
		cout << z[i].s << z[i].h << ' ';
	}
	return 0;
}
