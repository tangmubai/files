#include <stdio.h>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

struct node {
	string x, name;
	int c;
} a[N];
bool cmp1(node x, node y) {
	return x.x < y.x;
}
bool cmp2(node x, node y) {
	if (x.name == y.name) return x.x < y.x;
	return x.name < y.name;
}
bool cmp3(node x, node y) {
	if (x.c == y.c) return x.x < y.x;
	return x.c < y.c;
}

int n, c, t;

int main() {
	ios :: sync_with_stdio(false);
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	while (cin >> n >> c && n != 0) {
		cout << "Case " << ++t << ":\n";
		for (int i = 1; i <= n; i++) {
			cin >> a[i].x >> a[i].name >> a[i].c;
		}
		switch(c) {
			case 1 : sort(a + 1, a + 1 + n, cmp1); break;
			case 2 : sort(a + 1, a + 1 + n, cmp2); break;
			case 3 : sort(a + 1, a + 1 + n, cmp3); break;
		}
		for (int i = 1; i <= n; i++) {
			cout << a[i].x << ' ' << a[i].name << ' ' << a[i].c << '\n';
		}
	}
	return 0;
} 
