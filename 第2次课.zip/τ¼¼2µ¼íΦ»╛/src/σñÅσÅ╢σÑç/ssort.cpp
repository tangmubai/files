#include <stdio.h>
#include <queue>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

int n;
int a[N];

int main() {
	ios :: sync_with_stdio(false);
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	while (cin >> n) {
		for (int i = 1; i <= n; i++) {
			cin >> a[i];
		}
		if (n == 1) {
			cout << "-1\n";
			continue;
		}
		sort(a + 1, a + 1 + n);
		for (int i = 1; i < n; i++) {
			cout << a[i] << ' ';
		}
		cout << ' ';
	}
	
	return 0;
}
