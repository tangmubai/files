#include <stdio.h>
#include <cctype>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e2 + 5;

int n;
string s[N];

int main() {
	ios :: sync_with_stdio(false);
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> s[i];
	}
	sort(s + 1, s + 1 + n);
	for (int i = 1; i <= n; i++) {
		cout << s[i] << '\n';
	}
	return 0;
}
/*
2
dzcab
dgak
*/
