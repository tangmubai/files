#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <algorithm>

const int N = 100001;

struct Node {
    char s1, s2;
    int a, b;
} a[N];
char s[N];
bool cmp(const Node tmp1, const Node tmp2) {
    if (tmp1.a == tmp2.a) return tmp1.b < tmp2.b;
    return tmp1.a < tmp2.a;
}
int main() {
    freopen("card.in", "r", stdin);
    freopen("card.out", "w", stdout);
        scanf("%s", s + 1);
        int p = 0;
        for (int i = 1; i <= 5; i++) {
            int x, y;
            p++;
            a[i].s1 = s[p];
            if (s[p] == '1') {
                x = 10;
                p++;
            } else if (s[p] >='2' && s[p] <= '9') x = s[p] - '0';
            else if (s[p] == 'J') x = 11;
            else if (s[p] == 'Q') x = 12;
            else if (s[p] == 'K') x = 13;
            else if (s[p] == 'A') x = 14;
            p++;
            if (s[p] == 'd') y = 11;
            else if (s[p] == 'c') y = 12;
            else if (s[p] == 'h') y = 13;
            else if (s[p] == 's') y = 14;
            a[i].s2 = s[p];
            a[i].a = x; a[i].b = y;
        }
        std :: sort(a + 1, a + 6, cmp);
        for (int i = 1; i <= 5; i++) {
            if (a[i].s1 == '1') printf("10");
            else std :: cout << a[i].s1;
            std :: cout << a[i].s2 << " ";
        }
    return 0;
}

