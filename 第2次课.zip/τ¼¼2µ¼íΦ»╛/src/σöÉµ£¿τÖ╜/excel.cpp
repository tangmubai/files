#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <algorithm>

const int N = 100001;

struct Node {
    std :: string id, name;
    int s;
} a[N];
bool cmp1(const Node tmp1, const Node tmp2) {
    return tmp1.id < tmp2.id;
}
bool cmp2(const Node tmp1, const Node tmp2) {
    if (tmp1.name == tmp2.name) return tmp1.id < tmp2.id;
    return tmp1.name < tmp2.name;
}
bool cmp3(const Node tmp1, const Node tmp2) {
    if (tmp1.s == tmp2.s) return tmp1.id < tmp2.id;
    return tmp1.s < tmp2.s;
}
int main() {
    freopen("excel.in", "r", stdin);
    freopen("excel.out", "w", stdout);
    int n, x, T = 0;
    while (std :: cin >> n >> x && n) {
        for (int i = 1; i <= n; i++) std :: cin >> a[i].id >> a[i].name >> a[i].s;
        if (x == 1) std :: sort(a + 1, a + 1 + n, cmp1);
        if (x == 2) std :: sort(a + 1, a + 1 + n, cmp2);
        if (x == 3) std :: sort(a + 1, a + 1 + n, cmp3);
        printf("Case %d:\n", ++T);
        for (int i = 1; i <= n; i++) std :: cout << a[i].id << " " << a[i].name << " " << a[i].s << '\n';
    }
    return 0;
}

