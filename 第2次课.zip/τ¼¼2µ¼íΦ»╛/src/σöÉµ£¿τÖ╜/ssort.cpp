#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

const int N = 1001;

int a[N];

int main() {
    freopen("ssort.in", "r", stdin);
    freopen("ssort.out", "w", stdout);
    int n;
    while (std :: cin >> n) {
        for (int i = 1; i <= n; i++) std :: cin >> a[i];
        std :: sort(a + 1, a + 1 + n);
        for (int i = 1; i < n; i++) std :: cout << a[i] << " ";
        puts("");
    }
    return 0;
}

