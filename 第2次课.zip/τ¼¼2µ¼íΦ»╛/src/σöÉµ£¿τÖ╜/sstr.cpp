#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

const int N = 101;

char s[N];

int main() {
    freopen("sstr.in", "r", stdin);
    freopen("sstr.out", "w", stdout);
    int n;
    std :: cin >> n;
    for (int i = 1; i <= n; i++) {
        int len;
        scanf("%s", s + 1);
        len = strlen(s + 1);
        std :: sort(s + 1, s + 1 + len);
        printf("%s\n", s + 1);
    }
    return 0;
}

