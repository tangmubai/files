#include <stdio.h>
#include <algorithm>
#include <cstring>
#include <iostream>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}

char a[15];

struct Node {
	int num;
	char no;
}s[10];
main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	scanf("%s",a+1);int len=strlen(a+1),x;
	for(int i=1,j=1;i<=len;++i,++j){
		x=0;
		while(a[i]>='0'&&a[i]<='9'){
			x=(x<<3)+(x<<1)+(a[i]^48);
			++i;
		}
		while(a[i]>='A'&&a[i]<=)
		s[j].no=a[i];
		s[j].num=x;
//		printf("%c%d\n",s[j].no,s[j].num);
	}
	for(int i=1;i<=5;++i){
		printf("%c%d\n",s[i].no,s[i].num);
	}
	return 0;
}

