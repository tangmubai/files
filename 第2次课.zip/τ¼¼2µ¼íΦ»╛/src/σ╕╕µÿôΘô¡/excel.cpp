#include <stdio.h>
#include <algorithm>
#include <iostream>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}

struct Node{
	int id;
	string na;
	int sc;
}a[100005];

bool cmp1(Node x,Node y){
	return x.id<y.id;
}

bool cmp2(Node x,Node y){
	if(x.na==y.na||x.sc==y.sc)return x.id<y.id;
	return x.na<y.na;
}

bool cmp3(Node x,Node y){
	if(x.na==y.na||x.sc==y.sc)return x.id<y.id;
	return x.sc<y.sc;
}
main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int n,c,num=1;
	while(1){
		n=re();
		if(n==0)break;
		c=re();
		for(int i=1;i<=n;++i){
			a[i].id=re();
//			scanf("%05d",&a[i].id);
			cin>>a[i].na;a[i].sc=re();
		}
//		printf("Case %d:\n",num);
//		for(int i=1;i<=n;++i){
//			printf("%05d ",a[i].id);
//			cout<<a[i].na;
//			printf(" %d\n",a[i].sc);
//		}
		
		if(c==1)sort(a+1,a+1+n,cmp1);
		if(c==2)sort(a+1,a+1+n,cmp2);
		if(c==3)sort(a+1,a+1+n,cmp3);
		printf("Case %d:\n",num);
		for(int i=1;i<=n;++i){
			printf("%06d ",a[i].id);
			cout<<a[i].na;
			printf(" %d\n",a[i].sc);
		}
		num++;
	}
	return 0;
}

