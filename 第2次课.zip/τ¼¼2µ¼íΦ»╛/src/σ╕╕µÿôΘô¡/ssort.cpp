#include <stdio.h>
#include <algorithm>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
int a[1005];
main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;++i){
			a[i]=re();
		}
		sort(a+1,a+1+n);
		printf("%d\n",a[n]);
		for(int i=1;i<n;++i){
			printf("%d ",a[i]);
		}
		printf("\n");
	}
	return 0;
}

