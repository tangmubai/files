#include <stdio.h>
#include <algorithm>
#include <cstring>
using namespace std;

int re(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
char a[25];
main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int n=re();
	for(int i=1;i<=n;++i){
		scanf("%s",a+1);int len=strlen(a+1);
		sort(a+1,a+len+1);
		printf("%s\n",a+1);
	}
	return 0;
}

