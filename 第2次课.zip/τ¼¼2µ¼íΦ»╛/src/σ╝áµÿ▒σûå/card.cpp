#include<cstdio>
#include<algorithm>
#include<string>
#include<cstring>
#include<iostream>
using namespace std;
char s[30];
struct node{
	int num,c;
	char ch;
}a[6];
bool cmp(node p,node q){
	if(p.num!=q.num)return p.num<q.num;
	return p.c<q.c;
} 
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	cin>>s;
	int len=strlen(s),i=0;
	while(i<len){
		if(s[i]=='J')a[i+1].num=11;
		if(s[i]=='Q')a[i+1].num=12;
		if(s[i]=='K')a[i+1].num=13;
		if(s[i]=='A')a[i+1].num=14;
		i++;
		if(s[i]=='d')a[i].c=1;
		if(s[i]=='c')a[i].c=2;
		if(s[i]=='h')a[i].c=3;
		if(s[i]=='s')a[i].c=4;
		a[i].ch=s[i-1];
		i++;
	}
	sort(a+1,a+6,cmp);
	for(int i=1;i<=5;i++)printf("%d%s ",a[i].num,a[i].ch);
	return 0;
}
