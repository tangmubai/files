#include<cstdio>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
struct node{
	char a[10],b[10];
	int c;
}a[100005];
int n,t,k;
bool cmp1(node p,node q){
	return strcmp(p.a,q.a)<0;
}
bool cmp2(node p,node q){
	if(strcmp(p.b,q.b)!=0)return strcmp(p.b,q.b)<0;
	return strcmp(p.a,q.a)<0;
}
bool cmp3(node p,node q){
	if(p.c!=q.c)return p.c<q.c;
	return strcmp(p.a,q.a)<0;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	scanf("%d%d",&n,&t);
	while(n!=0){
		k++;
		printf("Case %d:\n",k);
		for(int i=1;i<=n;i++){
			scanf("%s",a[i].a);
			scanf("%s",a[i].b);
			scanf("%d",&a[i].c);
		}
		if(t==1)sort(a+1,a+1+n,cmp1);
		if(t==2)sort(a+1,a+1+n,cmp2);
		if(t==3)sort(a+1,a+1+n,cmp3);
		for(int i=1;i<=n;i++)printf("%s %s %d\n",a[i].a,a[i].b,a[i].c);
		scanf("%d%d",&n,&t);
	}
	return 0;
}
