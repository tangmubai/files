#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int t;
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		char s[31];
		scanf("%s",s);
		int len=strlen(s);
		sort(s,s+len);
		printf("%s\n",s);
	}
	return 0;	
}
