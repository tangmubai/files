#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n,c;
struct Node{
	int id;
	char name[10];
	int score;
}a[100005];
bool cmp(Node x,Node y){
	if(c==1){
		return x.id<y.id;
	}
	if(c==2){
		if(x.name == y.name){
			return x.id<y.id;
		}
		return x.name<y.name;
	}
	if(c==3){
		if(x.score==y.score){
			return x.id<y.id;
		}
		return x.score<y.score;
	}
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int cnt=1;
	while(cin>>n>>c){
		if(n==0) break;
		for(int i=1;i<=n;i++){
			scanf("%d %s %d",&a[i].id,a[i].name,&a[i].score);
		}
		if(c==1){
			sort(a+1,a+n+1,cmp);
			printf("Case %d:\n",cnt);
			for(int i=1;i<=n;i++){
				printf("%06d %s %d\n",a[i].id,a[i].name,a[i].score);
			}
		}
		if(c==2){
			sort(a+1,a+n+1,cmp);
			printf("Case %d:\n",cnt);
			for(int i=1;i<=n;i++){
				printf("%06d %s %d\n",a[i].id,a[i].name,a[i].score);
			}
		}
		if(c==3){
			sort(a+1,a+n+1,cmp);
			printf("Case %d:\n",cnt);
			for(int i=1;i<=n;i++){
				printf("%06d %s %d\n",a[i].id,a[i].name,a[i].score);
			}
		}
		cnt++;
	}
	return 0;
}
