#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[1005];
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		if(n==1){
			cout<<"-1"<<endl;
			continue;
		}
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=n-1;i++){
			cout<<a[i]<<" ";
		}
		cout<<endl;
	}
	return 0;
}
