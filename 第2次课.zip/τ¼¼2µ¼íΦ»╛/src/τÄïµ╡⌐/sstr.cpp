#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int m;
	scanf("%d",&m);
	while(m--){
		string a;
		cin>>a;
		sort(a.begin(),a.end());
		cout<<a<<endl;
	}
	return 0;
}
