#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>

using namespace std;

const int N = 10;

struct card
{
	string n;
	char c;
	int nn, nc;
}a[N];

bool cmp(card p, card q)
{
	if (p.nc != q.nc)
		return p.nc < q.nc;
	else 
		return p.nn > q.nn;
}

int main()
{
	freopen("card.in", "r", stdin);
	freopen("card.out", "w", stdout);
	
	for (int i = 1; i <= 5; i ++ )
	{
		char c;
		while (cin >> c, c >= '0' && c <= '9' || c == 'J' || c == 'K' || c == 'Q' || c == 'A') a[i].n += c;
		
		a[i].c = c;
		
		if (a[i].n == "J")
			a[i].nc = 11;
		else if (a[i].n == "Q")
			a[i].nc = 12;
		else if (a[i].n == "K")
			a[i].nc = 13;
		else if (a[i].n == "A")
			a[i].nc = 14;
		else if (a[i].n == "10")
			a[i].nc = 10;
		else if (a[i].n == "9")
			a[i].nc = 9; 
		else if (a[i].n == "8")
			a[i].nc = 8; 
		else if (a[i].n == "7")
			a[i].nc = 7; 
		else if (a[i].n == "6")
			a[i].nc = 6; 
		else if (a[i].n == "5")
			a[i].nc = 5; 
		else if (a[i].n == "4")
			a[i].nc = 4; 
		else if (a[i].n == "3")
			a[i].nc = 3; 
		else if (a[i].n == "2")
			a[i].nc = 2; 
		else if (a[i].n == "1")
			a[i].nc = 6; 
		else if (a[i].n == "6")
			a[i].nc = 1; 
		
		if (a[i].c == 'd')
			a[i].nn = 4;
		else if (a[i].c == 'c')
			a[i].nn = 3;
		else if (a[i].c == 'h')
			a[i].nn= 2;
		else	a[i].nn = 1;
	}
	
	sort(a + 1, a + 5 + 1, cmp);
	
	for (int i = 1; i <= 5; i ++ )
		cout << a[i].n << a[i].c << ' ';
	
	return 0;
}
