#include <iostream>
#include <string>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 100010;

struct node
{
	string pos, name;
	int point;
}a[N];

bool cmp1(node p, node q)
{
	return p.pos < q.pos;
}

bool cmp2(node p, node q)
{
	return p.name < q.name;
}

bool cmp3(node p, node q)
{
	if (p.point == q.point)
		return p.pos < q.pos;
	return p.point < q.point;
}

int main()
{
	freopen("excel.in", "r", stdin);
	freopen("excel.out", "w", stdout);
	
	int n, nn = 0;
	
	while (cin >> n, n)
	{
		int c;
		cin >> c;
		
		for (int i = 1; i <= n; i ++ )	cin >> a[i].pos >> a[i].name >> a[i].point;
		
		nn ++ ;
		
		cout << "Case " << nn << ":" << endl;
		
		if (c == 1)
		{
			sort(a + 1, a + n + 1, cmp1);
			for (int i = 1; i <= n; i ++ )	cout << a[i].pos << ' ' << a[i].name << ' ' << a[i].point << endl;
		}
		else if (c == 2)
		{
			sort(a + 1, a + n + 1, cmp2);
			for (int i = 1; i <= n; i ++ )	cout << a[i].pos << ' ' << a[i].name << ' ' << a[i].point << endl;
		}
		else if (c == 3)
		{
			sort(a + 1, a + n + 1, cmp3);
			for (int i = 1; i <= n; i ++ )	cout << a[i].pos << ' ' << a[i].name << ' ' << a[i].point << endl;
		}
	}
}
