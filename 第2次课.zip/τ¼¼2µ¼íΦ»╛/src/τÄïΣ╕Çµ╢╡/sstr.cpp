#include <algorithm>
#include <iostream>
#include <cstring>

using namespace std;

const int N = 110;

char c[N];

bool cmp(char p, char q)
{
	return p < q;
}

int main()
{
	freopen("sstr.in", "r", stdin);
	freopen("sstr.out", "w", stdout);
	
	int t;
	cin >> t;
	
	while (t -- )
	{
		scanf("%s", c + 1);
		
		sort(c + 1, c + strlen(c + 1) + 1, cmp);
		
		printf("%s\n", c + 1);
	}
	
	return 0;
}
