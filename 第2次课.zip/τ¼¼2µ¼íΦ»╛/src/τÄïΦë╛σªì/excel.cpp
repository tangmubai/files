#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
struct stu{
	string id;
	string name;
	int score;
}s[100005];
bool cmp1(struct stu a,struct stu b){
	return a.id<b.id;
}
bool cmp2(struct stu a,struct stu b){
	if(a.name!=b.name)
	    return a.name<b.name;
	else 
	    return a.id<b.id;
}
bool cmp3(struct stu a,struct stu b){
	if(a.score!=b.score)
	    return a.score<b.score;
	else
	    return a.id<b.id;
}
int main(){
	freopen("excel.in","r",stdin);
	freopen("excel.out","w",stdout);
	int n,c,k=1;
	scanf("%d%d",&n,&c);
	while(n!=0){
		for(int i=0;i<n;i++){
		    cin>>s[i].id;
		    cin>>s[i].name;
		    scanf("%d",&s[i].score);
		}
		if(c==1){
			sort(s,s+n,cmp1);
			printf("Case %d:\n",k);
			for(int i=0;i<n;i++){
				cout<<s[i].id<<" ";
				cout<<s[i].name<<" ";
				printf("%d\n",s[i].score);
			}
		}
		if(c==2){
			sort(s,s+n,cmp2);
			printf("Case %d:\n",k);
			for(int i=0;i<n;i++){
				cout<<s[i].id<<" ";
				cout<<s[i].name<<" ";
				printf("%d\n",s[i].score);
			}
		}
		if(c==3){
			sort(s,s+n,cmp3);
			printf("Case %d:\n",k);
			for(int i=0;i<n;i++){
				cout<<s[i].id<<" ";
				cout<<s[i].name<<" ";
				printf("%d\n",s[i].score);
			}
		}
		k++;
		scanf("%d%d",&n,&c);
	}
	return 0;
}
