#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int main(){
	freopen("ssort.in","r",stdin);
	freopen("ssort.out","w",stdout);
	int t,n,a[1005];
	while(scanf("%d",&n)!=EOF){
		int max=0;
		for(int i=0;i<n;i++){
			scanf("%d",&a[i]);
			if(a[i]>max)max=a[i];
		}
		sort(a,a+n);
		printf("%d\n",max);
		for(int i=0;i<n-1;i++)
		    printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
