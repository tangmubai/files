#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int main(){
	freopen("sstr.in","r",stdin);
	freopen("sstr.out","w",stdout);
	int m;
	char a[25];
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		cin>>a;
		int len=strlen(a);
		sort(a,a+len);
		for(int j=0;j<len;j++)
		    printf("%c",a[j]);
		printf("\n");
	}
	return 0;
}
