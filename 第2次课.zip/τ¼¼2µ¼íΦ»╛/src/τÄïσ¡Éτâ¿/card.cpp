#include "cstdio"
#include "algorithm"
using namespace std;
struct node{
	int hs,num;
}a[100005];
char c[100005];
int cmp(node a,node b){
	return a.num<b.num||a.num==b.num&&a.hs<b.hs;
}
int main(){
	freopen ("card.in","r",stdin);
	freopen ("card.out","w",stdout);
	scanf("%s",c+1);
	for (int i=1;i<=10;i+=2){
		if (c[i]=='A') a[i/2+1].num=100;
		else if (c[i]=='J') a[i/2+1].num=11;
		else if (c[i]=='Q') a[i/2+1].num=12;
		else if (c[i]=='K') a[i/2+1].num=13;
		else a[i/2+1].num=c[i]-'0';
		if (c[i+1]=='d') a[i/2+1].hs=1;
		if (c[i+1]=='c') a[i/2+1].hs=2;
		if (c[i+1]=='h') a[i/2+1].hs=3;
		if (c[i+1]=='s') a[i/2+1].hs=4;
	}
	sort (a+1,a+1+5,cmp);
	for (int i=1;i<=10;i+=2){
		if (a[i/2+1].num==100) printf ("A");
		else if (a[i/2+1].num==11) printf ("J");
		else if (a[i/2+1].num==12) printf ("Q");
		else if (a[i/2+1].num==13) printf ("K");
		else printf ("%d",a[i/2+1].num);
		if (a[i/2+1].hs==1) printf ("d");
		else if (a[i/2+1].hs==2) printf ("c");
		else if (a[i/2+1].hs==3) printf ("h");
		else printf ("s");
		printf (" ");
	}
	return 0;
}
