#include "cstdio"
#include "cstring"
#include "algorithm"
using namespace std;
inline int read(){
	int s=0;char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		s=s*10+c-'0';
		c=getchar();
	}
	return s;
}
struct node{
	int num,sc;
	char s[10];
}a[1000005];
int cmp1(node a,node b){
	return a.num<b.num;
}
int cmp2(node a,node b){
	int t=strcmp(a.s,b.s);
	if (t!=0) return t<0;
	else return a.num<b.num; 
}
int cmp3(node a,node b){
	if (a.sc!=b.sc) return a.sc<b.sc;
	else return a.num<b.num;
}
int n,c;
int main(){
	freopen ("excel.in","r",stdin);
	freopen ("excel.out","w",stdout);
	int t=0;
	while (1){
		n=read();c=read();
		if (n==0) return 0;
		t++;
		
		for (int i=1;i<=n;i++){
			a[i].num=read();
			scanf ("%s",a[i].s);
			a[i].sc=read();
		}
		printf ("Case %d:\n",t);
		if (c==1) sort(a+1,a+1+n,cmp1);
		if (c==2) sort(a+1,a+1+n,cmp2);
		if (c==3) sort(a+1,a+1+n,cmp3);
		for (int i=1;i<=n;i++){
			printf ("%06d %s %d\n",a[i].num,a[i].s,a[i].sc);
		}
	}
	return 0;
}
