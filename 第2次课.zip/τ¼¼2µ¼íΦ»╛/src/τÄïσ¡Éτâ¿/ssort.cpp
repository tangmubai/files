#include "cstdio"
#include "algorithm"
using namespace std;
int n,a[10005];
int main(){
	freopen ("ssort.in","r",stdin);
	freopen ("ssort.out","w",stdout);
	while (scanf("%d",&n)!=EOF){
		for (int i=1;i<=n;i++) scanf ("%d",&a[i]);
		if (n==1){
			printf ("%d\n",a[1]);
			printf ("-1\n");
		}
		else{
			sort(a+1,a+1+n);
			printf ("%d\n",a[n]);
			for (int i=1;i<n;i++) printf ("%d ",a[i]);
			printf ("\n");
		}
	}
	return 0;
}
