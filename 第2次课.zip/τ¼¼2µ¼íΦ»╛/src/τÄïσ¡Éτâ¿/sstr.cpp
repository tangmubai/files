#include "cstdio"
#include "cstring"
#include "algorithm"
using namespace std;
char s[1005];int t;
int main(){
	freopen ("sstr.in","r",stdin);
	freopen ("sstr.out","w",stdout);
	scanf ("%d",&t);
	while (t--){
		scanf ("%s",s+1);
		int n=strlen(s+1);
		sort(s+1,s+1+n);
		for (int i=1;i<=n;i++) printf ("%c",s[i]);
		printf ("\n");
	}
	return 0;
}
