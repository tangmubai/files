#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
string a;
struct node{
	int c,num2;char num[5],hs;
}input[10];
char qread(){
	char c=getchar();
	while((c<'0'||c>'9')&&c!='J'&&c!='Q'&&c!='K'&&c!='A'&&c!='d'&&c!='c'&&c!='h'&&c!='s') c=getchar();
	return c;
}
bool qcmp(node a,node b){
	if(a.num2!=b.num2) return a.num2<b.num2;
	return a.c<b.c;
}
int main(){
	freopen("card.in","r",stdin);freopen("card.out","w",stdout);
	for(int i=1;i<=5;++i){
		input[i].num[1]=qread();
		input[i].num2=(input[i].num[1]^'0');
		input[i].hs=qread();
		if(input[i].hs!='d'&&input[i].hs!='c'&&input[i].hs!='h'&&input[i].hs!='s'){
			input[i].num[2]=input[i].hs;
			input[i].hs=qread();
			input[i].num2=input[i].num2*10+(input[i].num[2]^'0');
		}
		if(input[i].num[1]=='A') input[i].num2=14;
		if(input[i].num[1]=='K') input[i].num2=13;
		if(input[i].num[1]=='Q') input[i].num2=12;
		if(input[i].num[1]=='J') input[i].num2=11;
		if(input[i].hs=='d') input[i].c=1;
		if(input[i].hs=='c') input[i].c=2;
		if(input[i].hs=='h') input[i].c=3;
		if(input[i].hs=='s') input[i].c=4;
	}
	sort(input+1,input+6,qcmp);
	for(int i=1;i<=5;++i){
		printf("%s",input[i].num+1);printf("%c",input[i].hs);putchar(' ');
	}
	puts("");
	return 0;
}
