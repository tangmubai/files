#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
struct node{
	int cj;string xh,name;
}input[100005];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
bool qcmp1(node a,node b){
	return a.xh<b.xh;
}
bool qcmp2(node a,node b){
	if(a.name!=b.name) return a.name<b.name;
	return a.xh<b.xh;
}
bool qcmp3(node a,node b){
	if(a.cj!=b.cj) return a.cj<b.cj;
	return a.xh<b.xh;
}
int main(){
	freopen("excel.in","r",stdin);freopen("excel.out","w",stdout);
	int n=qread(),c=qread(),i=1;
	while(n!=0){
		for(int j=1;j<=n;++j){
			cin>>input[j].xh>>input[j].name;input[j].cj=qread();
		}
		if(c==1) sort(input+1,input+1+n,qcmp1);
		if(c==2) sort(input+1,input+1+n,qcmp2);
		if(c==3) sort(input+1,input+1+n,qcmp3);
		printf("Case %d:",i++);puts("");
		for(int j=1;j<=n;++j){
			cout<<input[j].xh;putchar(' ');cout<<input[j].name;putchar(' ');printf("%d",input[j].cj);puts("");
		}
		n=qread();c=qread();
	}
	return 0;
}
