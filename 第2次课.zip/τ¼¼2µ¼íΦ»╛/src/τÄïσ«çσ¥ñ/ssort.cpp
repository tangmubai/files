#include<algorithm>
#include<stdio.h>
using namespace std;
int sj[1005];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("ssort.in","r",stdin);freopen("ssort.out","w",stdout);
	int n;
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;++i) sj[i]=qread();
		sort(sj+1,sj+1+n);
		printf("%d",sj[n]);puts("");
		if(n==1) puts("-1");
		else{
			for(int i=1;i<n;++i){
				printf("%d",sj[i]);putchar(' ');
			}
			puts("");
		}
	}
	return 0;
}
