#include<algorithm>
#include<string.h>
#include<stdio.h>
using namespace std;
char zf[25];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("sstr.in","r",stdin);freopen("sstr.out","w",stdout);
	int m=qread(),len;
	while(m--){
		scanf("%s",zf);
		len=strlen(zf);
		sort(zf,zf+len);
		printf("%s",zf);puts("");
	}
	return 0;
}
