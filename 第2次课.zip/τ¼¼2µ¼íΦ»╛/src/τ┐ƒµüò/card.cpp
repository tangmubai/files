#include <cstdio>
using namespace std;

int main () {
	freopen ("card.in","r",stdin);
	freopen ("card.out","w",stdout);
	
	return 0;
}
