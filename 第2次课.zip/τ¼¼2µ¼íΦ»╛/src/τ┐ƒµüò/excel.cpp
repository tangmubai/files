#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n,c,i,t;
struct xs {char xh[101],xm[101]; int cj;}a[100001];
int ss (char a[],char b[]) {
	for (int i=0;i<strlen(a);i++) if (a[i]!=b[i]) {
		if (a[i]<b[i]) return 1; return 0;
	}
	return 2;
}
bool cmp (xs a,xs b) {
	if (c==1) return ss(a.xh,b.xh)==1;
	if (c==2&&ss(a.xm,b.xm)!=2) return ss(a.xm,b.xm)==1;
	if (c==3&&a.cj!=b.cj) return a.cj<b.cj;
	return ss(a.xh,b.xh)==1; 
}
int main () {
	freopen ("excel.in","r",stdin);
	freopen ("excel.out","w",stdout);
	while (1) {
		scanf ("%d%d",&n,&c);
		if (n==0) return 0;
		for (i=1;i<=n;i++) scanf ("%s%s%d",a[i].xh,a[i].xm,&a[i].cj);
		sort (a+1,a+n+1,cmp);
		printf ("Case %d:\n",++t);
		for (i=1;i<=n;i++) printf ("%s %s %d\n",a[i].xh,a[i].xm,a[i].cj);
	}
}
