#include <cstdio>
#include <algorithm>
using namespace std;
int n,i,a[1001];
int main () {
	freopen ("ssort.in","r",stdin);
	freopen ("ssort.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) scanf ("%d",&a[i]);
	sort (a+1,a+n+1);
	printf ("%d\n",a[n]);
	for (i=1;i<n;i++) printf ("%d ",a[i]);
	return 0;
}
