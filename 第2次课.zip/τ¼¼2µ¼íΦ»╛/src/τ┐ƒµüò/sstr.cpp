#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n,i; char a[101];
bool cmp (char a,char b) {return a<b;}
int main () {
	freopen ("sstr.in","r",stdin);
	freopen ("sstr.out","w",stdout);
	scanf ("%d",&n);
	while (n--) {
		scanf ("%s",a+1);
		sort (a+1,a+strlen(a+1)+1,cmp);
		printf ("%s\n",a+1);
	}
	return 0;
}
