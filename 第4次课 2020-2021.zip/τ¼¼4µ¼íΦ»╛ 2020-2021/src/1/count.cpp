#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;

int n,t;
int a[1000005]={0};//����x�Ĵ�С����������顣 

int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
    	cin>>t;
    	a[t]++;
    }
    for(int i=1;i<=1000000;i++)
    {
    	if(a[i]!=0) cout<<i<<' '<<a[i]<<endl;
    }
    return 0;
}
