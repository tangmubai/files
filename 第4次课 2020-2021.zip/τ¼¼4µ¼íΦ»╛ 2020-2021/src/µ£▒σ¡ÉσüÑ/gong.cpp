#include <cstdio>
#define max(a,b) ((a)>(b)?(a):(b))
int m,n,p1[1003],p2[1003],f[1003][1003];
int main(){
	freopen("gong.in","r",stdin);freopen("gong.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=m;i++) scanf("%d",&p1[i]);
	for(int j=1;j<=n;j++) scanf("%d",&p2[j]);
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			if(p1[i]==p2[j]) f[i][j]=f[i-1][j-1]+1;
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	printf("%d\n",f[m][n]);
	return 0;
}
