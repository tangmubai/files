#include<iostream>
using namespace std;
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin>>n;
	while(n!=0){
		int a[105][105];
		for(int i=1;i<=n;i++)for(int j=1;j<=i;j++)cin>>a[i][j];
		int f[105][105]={0};
		for(int i=1;i<=n;i++)f[n][i]=a[n][i];
		for(int i=n;i>=1;i--)for(int j=1;j<=n;j++)f[i][j]=max(f[i+1][j]+a[i][j],f[i+1][j+1]+a[i][j+1]);
		cout<<f[1][1]<<endl;
		cin>>n;
	}
	return 0;
}
