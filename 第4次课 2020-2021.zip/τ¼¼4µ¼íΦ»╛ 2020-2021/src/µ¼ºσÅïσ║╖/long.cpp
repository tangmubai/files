#include <cstdio>
#include <algorithm>

using namespace std;

int len,f[1010],i,x,n;

int main () {
	freopen ("long.in","r",stdin);
	freopen ("long.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) {
		scanf ("%d",x);
		if (x>=f[len]) 
			f[++len]=x;
		else 
			f[(lower_bound (f+1,f+1+len,x))-f]=x;
	}
	printf ("%d\n",len);//rp++;
	return 0;
}
