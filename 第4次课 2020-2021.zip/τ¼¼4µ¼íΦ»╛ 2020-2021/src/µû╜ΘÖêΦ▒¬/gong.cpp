#include<stdio.h>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;
int s1[1005],s2[1005],n,m;
int f[1005][1005];
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d",&s1[i]);
	for(int i=1;i<=m;i++)scanf("%d",&s2[i]);
	memset(f,0,sizeof(f));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(s1[i]==s2[j])f[i][j]=f[i-1][j-1]+1;
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	printf("%d",f[n][m]);
	return 0;
}
