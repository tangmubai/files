#include <cstdio>
int a[1000010];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n,x;scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		a[x]++;
	}
	for(int i=0;i<=1000000;i++)
		if(a[i])printf("%d %d\n",i,a[i]);
	return 0;
}
