#include <cstdio>

int n,len,x,i,l,r,mid;
int d[1005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Lower_Bound(int x){
	l=1,r=len;
	while(l<=r){
		mid=(l+r)>>1;
		if(d[mid]>=x){
			r=mid-1;
		}else {
			l=mid+1;
		}
	}
	return l;
}

int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	n=read();
	for(i=1;i<=n;++i){
		x=read();
		if(x>d[len] || len==0){
			d[++len]=x;
		}else {
			d[Lower_Bound(x)]=x;
		}
	}
	printf("%d",len);
	return 0;
}
