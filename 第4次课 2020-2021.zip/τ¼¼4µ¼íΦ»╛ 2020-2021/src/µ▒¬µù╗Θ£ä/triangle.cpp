#include<stdio.h>
#include<string.h>
int f[105][105],a[105][105];
int n;
int max(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("triangle.in","r",stdin);freopen("triangle.out","w",stdout);
	while(1){
		scanf("%d",&n);
		if(!n)return 0;
		memset(f,0,sizeof(f));
		for(register int i=1;i<=n;++i)
		for(register int j=1;j<=i;++j)
		scanf("%d",&a[i][j]);
		for(register int i=n;i>=1;--i)
		for(register int j=1;j<=i;++j)
		f[i][j]=max(f[i+1][j],f[i+1][j+1])+a[i][j];
		printf("%d\n",f[1][1]);
	}
}
