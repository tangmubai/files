#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#include<map>
#include<algorithm>
using namespace std;
int n,x;
map<int,int>a;
map<int,int>::iterator it;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&x);
		a[x]++;
	}
	for(it=a.begin();it!=a.end();it++)
	   	printf("%d %d\n",it->first,it->second);
	return 0;
};

