#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
using namespace std;
int n;
int a[105][105];
int f[105][105];
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(cin>>n){
		if(!n)break;
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++)
		for(int j=1;j<=i;j++)
		scanf("%d",&a[i][j]);
		for(int i=n;i>=1;i--)
		for(int j=1;j<=i;j++)
		f[i][j]=max(f[i+1][j],f[i+1][j+1])+a[i][j];
		cout<<f[1][1]<<endl;
	}
}
