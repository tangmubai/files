#include<stdio.h>

using namespace std;

long long max,a[1005],f[1000005];
int main()
{

freopen("count.in","r",stdin);
freopen("count.out","w",stdout);
	int n,i,j;
	
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		scanf("%lld",&a[i]);
		f[a[i]]++;
		if(a[i]>max)max=a[i];
	}
	for(i=0;i<=max;i++)
	{
		if(f[i]>0)printf("%d %d\n",i,f[i]);
	}
}


