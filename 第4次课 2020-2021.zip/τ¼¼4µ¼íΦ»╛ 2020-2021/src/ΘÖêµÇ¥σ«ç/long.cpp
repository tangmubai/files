#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;

int a[1005];
int main()
{
freopen("long.in","r",stdin);
freopen("long.out","w",stdout);
   
	int i,j,n,l=0,maxl=0;
	cin>>n;
	
	for(i=0;i<n;i++)
		cin>>a[i];
		
	for(i=0;i<n;i++)
	{
		for(j=i;j<n;j++)
		{
			if(a[j]<a[j-1])
			{         
				if(maxl<l)maxl=l;
				l=0;
			}
			else l++;
		}
	} 
	cout<<maxl<<endl;
}

