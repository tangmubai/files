#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int n,a[1005],ans=0,f[10005];
int main(){
	freopen("long.in","r",stdin);freopen("long.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		if(f[ans]>a[i]){
			int x=lower_bound(f,f+i,ans)-f;
			f[x]=a[i];
		}
		else f[++ans]=a[i];
	}
	printf("%d\n",ans);
	return 0;
}

