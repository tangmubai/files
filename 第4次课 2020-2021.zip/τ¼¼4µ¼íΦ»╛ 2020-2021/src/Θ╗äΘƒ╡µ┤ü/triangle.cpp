#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int max(int x,int y){
	if(x>y) return x;
	return y;
}
int t,a[105][105],f[105][105];
int main(){
	freopen("triangle.in","r",stdin);freopen("triangle.out","w",stdout);
	while(1){
		scanf("%d",&t);
		if(t==0) break;
		for(int i=1;i<=t;i++) for(int j=1;j<=i;j++) scanf("%d",&a[i][j]);
		for(int i=t-1;i>=1;i--){
			for(int j=1;j<=i;j++){
				a[i][j]+=max(a[i+1][j],a[i+1][j+1]);
			}
		}
		printf("%d\n",a[1][1]);
	}
	return 0;
}

