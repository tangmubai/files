#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int n,a[1010],sum;
bool cmp(int x,int y){return x<y;}
int main()
{freopen("count.in","r",stdin);freopen("count.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++) cin>>a[i];
 sort(a+1,a+n+1,cmp);
 a[n+1]=2000000;
 for(int i=1;i<=n;i++)
{if(a[i]!=a[i+1])
{sum++;
 cout<<a[i]<<" "<<sum<<endl;
 sum=0;
}
 else sum++;
}
 return 0;
}
