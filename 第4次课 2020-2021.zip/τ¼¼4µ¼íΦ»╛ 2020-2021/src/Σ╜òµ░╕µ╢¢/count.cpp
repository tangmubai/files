#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int a[1000005],n,x;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		x=read();a[x]++;
	}
	for(register int i=1;i<=1000000;i++)
	if(a[i]) printf("%d %d\n",i,a[i]);
	return 0;
}
