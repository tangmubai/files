#include"stdio.h"
#include"algorithm"
#include"cmath"
#include"cstring"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
using namespace std;
int a[105][105],dp[105][105],n;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	n=read();
	while(n){
		memset(dp,0,sizeof(dp));
		for(register int i=1;i<=n;i++){
			for(register int j=1;j<=i;j++)
			a[i][j]=read();
		}
		for(register int i=n;i>=1;i--){
			for(register int j=1;j<=n;j++)
			dp[i][j]=max(dp[i+1][j],dp[i+1][j+1])+a[i][j];
		}
		printf("%d\n",dp[1][1]);
		n=read();
	}
	return 0;
}
