#include<cstdio>
#include<algorithm>
using namespace std;
int a[1010];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	int cnt=1;
	for(int i=2;i<=n;i++){
		if(a[i-1]!=a[i]){
			printf("%d %d\n",a[i-1],cnt);
			cnt=1;
		}
		else cnt++;
	}
	printf("%d %d",a[n],cnt);
	return 0;
}
