#include<cstdio>
#include<algorithm>
using namespace std;
int a[1010],f[1010];
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	f[1]=1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<i;j++)
			if(a[j]<a[i]) f[i]=max(f[i],f[j]+1);
	printf("%d",f[n]);
	return 0;
}
