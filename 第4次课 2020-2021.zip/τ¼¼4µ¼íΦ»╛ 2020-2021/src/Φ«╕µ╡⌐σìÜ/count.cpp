#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n, a[1000005], t[1000005];
void read(int &x)
{
	char c = getchar(); int f = 1; x = 0;
	while (c < '0' || c > '9')
	{
		if (c == '-') f = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9')
	{
		x = x * 10 + c - '0';
		c = getchar();
	}
	x *= f;
}
int main()
{
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	read(n);
	for (int i = 1; i <= n; i++) read(a[i]), t[a[i]]++;
	for (int i = 1; i <= 1000000; i++)
		if (t[i]) printf("%d %d\n", i, t[i]);
	return 0;
}

