#include<stdio.h>
#include<iostream>
#include<algorithm>
const int N = 1e3;
using namespace std;

int n, a[N + 5];

int main() {
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout); 
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i)
		scanf("%d", a + i);
	sort(a + 1, a + n + 1);
	int now = a[1], tp = 1;
	for(int i = 2; i <= n; ++i)
		if (a[i] == a[i - 1])
			++tp;
		else {
			printf("%d %d\n", now, tp);
			now = a[i]; tp = 1;
		}	
	printf("%d %d\n", now, tp);	
	return 0;	
}
