#include<stdio.h>
const int N = 1e3;
int n, m, a[N + 5], b[N + 5];
int f[N + 5][N + 5];

int max(int x, int y) {return (x > y? x: y);}

int main() {
	freopen("gong.in", "r", stdin);
	freopen("gong.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++i)
		scanf("%d", a + i);
	for(int i = 1; i <= m; ++i)
		scanf("%d", b + i);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
			if (a[i] == b[j])
				f[i][j] = f[i - 1][j - 1] + 1;
			else f[i][j] = max(f[i - 1][j], f[i][j - 1]);
	printf("%d\n", f[n][m]);				
	return 0;		
}
