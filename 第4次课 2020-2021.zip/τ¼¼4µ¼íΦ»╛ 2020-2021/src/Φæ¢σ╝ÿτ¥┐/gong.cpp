#include <stdio.h>
int n,m,a[1005],b[1005],f[1005][1005];
int mx(int a,int b){
	if(a>b)return a;
	else return b;
}
int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			if(a[i]==b[j])
				f[i][j]=mx(f[i][j],f[i-1][j-1]+1);
			f[i][j]=mx(f[i][j],f[i-1][j]);
			f[i][j]=mx(f[i][j],f[i][j-1]);
		}
	printf("%d",f[n][m]);
	return 0;	
}
