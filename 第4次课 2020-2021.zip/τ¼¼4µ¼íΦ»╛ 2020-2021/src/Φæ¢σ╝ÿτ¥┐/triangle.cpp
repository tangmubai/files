#include <stdio.h>
#include <cstring>
int n,a[105][105],f[105][105],ans;
int mx(int a,int b){
	if(a>b)return a;
	else return b;
}
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(~scanf("%d",&n)){
		ans=-1;
		memset(f,0,sizeof(f));
		memset(a,0,sizeof(a));
		if(n==0)	
			break;
		for(int i=1;i<=n;i++)	
			for(int j=1;j<=i;j++)
				scanf("%d",&a[i][j]);	
		for(int i=1;i<=n;i++)	
			for(int j=1;j<=i;j++)
				f[i][j]=mx(f[i-1][j],f[i-1][j-1])+a[i][j];
		for(int i=1;i<=n;i++)
			ans=mx(ans,f[n][i]);
		printf("%d\n",ans);
	}	
	return 0;
}
