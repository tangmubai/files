#include <cstdio>
#include <algorithm>
using namespace std;
template<typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
int a[1005],b[1005],dp[1005][1005];
int main(){
	freopen("gong.in","r",stdin);freopen("gong.out","w",stdout);
	int n,m;in(n);in(m);
	for(int i=1;i<=n;++i) in(a[i]);
	for(int i=1;i<=m;++i) in(b[i]);
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			if(a[i]==b[j]) dp[i][j]=dp[i-1][j-1]+1;
			else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
		}
	}
	printf("%d\n",dp[n][m]);
	return 0;
}
