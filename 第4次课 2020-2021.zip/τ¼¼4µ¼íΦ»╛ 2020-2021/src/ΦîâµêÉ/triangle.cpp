#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
int dp[105][105];
int main(){
	freopen("triangle.in","r",stdin);freopen("triangle.out","w",stdout);
	ios::sync_with_stdio(false);
	int n;
	while(cin>>n&&n){
		for(int i=1;i<=n;++i){
			for(int j=1;j<=i;++j){
				cin>>dp[i][j];
			}
		}
		for(int i=n-1;i;--i){
			for(int j=1;j<=i;++j){
				dp[i][j]+=max(dp[i+1][j],dp[i+1][j+1]);
			}
		}
		cout<<dp[1][1]<<endl;
	}
	return 0;
}
