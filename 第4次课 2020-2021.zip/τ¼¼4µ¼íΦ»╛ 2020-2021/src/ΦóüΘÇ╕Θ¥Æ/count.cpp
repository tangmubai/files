#include <stdio.h>
#include <string.h>
using namespace std;
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
int t[1000005], mx;
main() {
	freopen ("count.in", "r", stdin);
	freopen ("count.out", "w", stdout);
	int n;
	read(n);
	while (n --) {
		int x;
		read(x);
		t[x] ++;
		mx = mx > x ? mx : x;
	}
	for (register int i = 1; i <= mx; i ++)
		if (t[i]) printf ("%d %d\n", i, t[i]);
	return 0;
}
