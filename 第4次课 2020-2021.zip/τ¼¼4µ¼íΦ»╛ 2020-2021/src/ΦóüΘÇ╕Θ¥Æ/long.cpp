#include <stdio.h>
#include <string.h>
using namespace std;
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline int mx(int x, int y) {
	return x > y ? x : y;
}
int a[1005], f[1005];
int ans;
main() {
	freopen ("long.in", "r", stdin);
	freopen ("long.out", "w", stdout);
	int n;
	read(n);
	for (register int i = 1; i <= n; i ++) read(a[i]);
	for (register int i = 1; i <= n; i ++) f[i] = 1;
	for (register int i = 2; i <= n; i ++) {
		for (register int j = 1; j < i; j ++) {
		//f[i] = mx(f[i], f[j] + (a[i] > a[j]));
			if (a[i] > a[j]) f[i] = mx(f[i], f[j]+1);
		}
	}
	for (register int i = 1; i <= n; i ++) ans = ans > f[i] ? ans : f[i];
	printf ("%d\n", ans);
	return 0;
}
