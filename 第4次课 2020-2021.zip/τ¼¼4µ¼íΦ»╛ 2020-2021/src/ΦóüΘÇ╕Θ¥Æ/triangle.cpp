#include <stdio.h>
#include <string.h>
using namespace std;
inline int read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}
inline int mx(int x, int y) {
	return x > y ? x : y;
}
int a[105][105], f[105][105];
main() {
	freopen ("triangle.in", "r", stdin);
	freopen ("triangle.out", "w", stdout);
	int n;
	while (scanf ("%d", &n) == 1) {
		if (n == 0) break;
		for (register int i = 1; i <= 100; i ++)
			for (register int j = 1; j <= 100; j ++)
				f[i][j] = a[i][j] = 0;
		for (register int i = 1; i <= n; i ++)
			for (register int j = 1; j <= i; j ++)
				read(a[i][j]);
		for (register int i = n-1; i >= 0; i --) {
			for (register int j = 1; j <= n; j ++) {
				f[i][j] = mx(f[i+1][j]+a[i+1][j], f[i+1][j+1] + a[i+1][j+1]);
			}
		}
		printf ("%d\n", f[0][1]);
	}
	return 0;
}
