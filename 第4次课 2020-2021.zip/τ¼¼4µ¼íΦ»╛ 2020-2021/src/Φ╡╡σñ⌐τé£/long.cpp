#include <cstdio>
#include <cstring>
int n;
const int N = 1005;
int a[N];
int mem[N];
int max (int a, int b) {
	return a > b ? a : b;
}
int search (int step) {
	if (mem[step] != -1)
		return mem[step];
	if (step == n + 1)
		return 0;
	int res = 0;
	for (int i = step + 1; i <= n; i ++)
		if (a[i] > a[step]) {
			res = max (res, search (i) + 1);
		}	
	return mem[step] = res;
}
int ans = 0;
int main () {
	freopen ("long.in", "r", stdin);
	freopen ("long.out", "w", stdout);
	memset (mem, -1, sizeof(mem));
	scanf ("%d", &n);
	for (int i = 1; i <= n; i ++)
		scanf ("%d", &a[i]);
	for (int i = 1; i <= n; i ++) {
		ans = max (ans, search (i) + 1);
	}
	printf ("%d", ans);
}
/*
void ��
int ��
 
*/
