#include <cstdio>
#include <cstring>
int n;
const int N = 105;
int a[N][N];
int mem[N][N];
int max (int a, int b) {
	return a > b ? a : b;
}
int search (int x, int y) {
	if (mem[x][y] != -1)
		return mem[x][y];
	if (x == n + 1)
		return 0;
	int res = -19260817;
	res = max (search (x + 1, y + 1), search (x + 1, y)) + a[x][y];
	return mem[x][y] = res;
}
int main () {
	freopen ("triangle.in", "r", stdin);
	freopen ("triangle.out", "w", stdout);
	while (1) {
		scanf ("%d", &n);
		if (n == 0)
			break;
		memset (mem, -1, sizeof(mem));
		for (int i = 1; i <= n; i ++) {
			for (int j = 1; j <= i; j ++) {
				scanf ("%d", &a[i][j]);
			}
		}
		int ans = search (1, 1);
		printf ("%d\n", ans);
	}
}
