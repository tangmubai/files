#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int f[1005]={0};
int a[1005]={0};
int main(){freopen("long.in","r",stdin);freopen("long.out","w",stdout);
	ll n;
	scanf("%d",&n);
	for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
	f[1]=1;
	for(ll i=2;i<=n;i++){
		f[i]=1;
		for(ll j=1;j<=i-1;j++){
			if(a[j]<a[i]){
				f[i]=max(f[i],f[j]+1);
			}
		}
	}ll ans=0;
	for(ll i=1;i<=n;i++)ans=max(ans,f[i]);
	printf("%d",ans);
	return 0;
}
/*
7
1 7 3 5 9 4 8
*/


