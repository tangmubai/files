#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int a[105][105]={0};
int f[105][105]={0};
int main(){freopen("triangle.in","r",stdin);freopen("triangle.out","w",stdout);
	ll n=1;
	while(scanf("%d",&n)){
		if(n==0)break;
		for(ll i=1;i<=n;i++)for(ll j=1;j<=i;j++)scanf("%d",&a[i][j]);
		for(ll i=1;i<=n;i++)f[n][i]=a[n][i];
		for(ll i=n-1;i>=1;i--){
			for(ll j=1;j<=i;j++){
				f[i][j]=max(f[i+1][j],f[i+1][j+1])+a[i][j];
			}
		}
		printf("%d\n",f[1][1]);
	}
	return 0;
}



