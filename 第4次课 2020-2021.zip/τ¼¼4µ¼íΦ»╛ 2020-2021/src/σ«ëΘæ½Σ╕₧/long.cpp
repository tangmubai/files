#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int a[1005],b[1005];
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	int n,i,j,len=1;
	scanf("%d",&n);
	for(i=1;i<=n;i++)scanf("%d",&a[i]);
	b[1]=a[1];
	for(i=2;i<=n;i++){
		if(a[i]>b[len])b[++len]=a[i];
		else{
			int j=lower_bound(b+1,b+1+len,a[i])-b;
			b[j]=a[i];
		}
	}
	printf("%d",len);
	return 0;
}
