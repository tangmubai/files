#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int n,a[1005];
int f[1005]={-1};
int dfs(int x){
	if(f[x]!=-1)return f[x];
	if(x>n)return 0;
	int tmp1=0,tmp2=0;
	tmp1=dfs(x+1);
	if(a[x+1]>a[x])tmp2=dfs(x+1)+1;
	return f[x]=max(tmp1,tmp2);
}
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	printf("%d",dfs(1));
	return 0;
}
