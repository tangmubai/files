#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int n,a[105][105];
int f[105][105];
int dfs(int x,int last){
	if(f[x][last]!=-1)return f[x][last];
	if(x>n)return 0;
	int tmp1=0,tmp2=0;
	if(last!=0)tmp1+=dfs(x+1,last)+a[x][last];
	if(last+1<=n)tmp2+=dfs(x+1,last+1)+a[x][last+1];
	return f[x][last]=max(tmp1,tmp2);
}
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		for(int i=1;i<=n;i++)for(int j=1;j<=i;j++)scanf("%d",&a[i][j]);
		memset(f,-1,sizeof(f));
		printf("%d\n",dfs(1,0));
	}
	return 0;
}
