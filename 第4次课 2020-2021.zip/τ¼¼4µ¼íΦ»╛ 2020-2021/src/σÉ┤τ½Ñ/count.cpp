#include<stdio.h>
#include<algorithm>
#define N 1001
inline char nc()
{
	static char buf[9999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,9999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
main()
{
	freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	register int n,a[N];read(n);
	for(register int i=0;i<n;read(a[i++]));
	std::sort(a,a+n);a[n]=-1;
	for(register int i=1,num=a[0],cnt=1;i<=n;++i)
		if(a[i]==num)++cnt;
		else{printf("%d %d\n",num,cnt);num=a[i];cnt=1;}
}
