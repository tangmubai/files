#include<stdio.h>
#define N 1001
inline char nc()
{
	static char buf[9999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,9999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
inline void max(int&x,const int&y){if(x<y)x=y;}
main()
{
	freopen("gong.in","r",stdin);freopen("gong.out","w",stdout);
	register int n,m,a[N],b[N],ans[2][N];read(n);read(m);
	for(register int i=1;i<=n;read(a[i++]));
	for(register int i=1;i<=m;read(b[i++]));
	for(register int i=0;i<=n;++i)for(register int j=0;j<=m;++j)
	{
		if(i&&j&&a[i]==b[j])ans[i&1][j]=ans[(i-1)&1][j-1]+1;
		else ans[i&1][j]=0;
		if(i)max(ans[i&1][j],ans[(i-1)&1][j]);
		if(j)max(ans[i&1][j],ans[i&1][j-1]);
	}
	printf("%d",ans[n&1][m]);
}
