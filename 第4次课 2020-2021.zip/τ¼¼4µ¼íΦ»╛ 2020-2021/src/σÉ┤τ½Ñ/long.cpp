#include<stdio.h>
#include<algorithm>
#define N 1001
inline char nc()
{
	static char buf[9999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,9999,stdin),l==r)?EOF:*l++;
}
inline void read(short&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
main()
{
	freopen("long.in","r",stdin);freopen("long.out","w",stdout);
	register short n,x,ans=1,a[N];
	for(read(n),read(a[1]);--n;)
	{
		read(x);
		if(x>a[ans])a[++ans]=x;
		else*std::lower_bound(a+1,a+ans,x)=x;
	}
	printf("%d",(int)(ans));
}
