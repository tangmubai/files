#include <cstdio>
#include <algorithm>
using namespace std;

int a[1005], f[1005], tot;

void in(int &x)
{
	int w = 0, f = 1;
	char c = getchar();
	while (c < '0' || c > '9')	{if (c == '-')f = -1;c = getchar();}
	while (c >= '0' && c <= '9'){w = w * 10 + c - '0';c = getchar();}
	x = w * f;
}

int main()
{
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	int n;
	in(n);
	for (int i = 1; i <= n; i++)
		in(a[i]), f[i] = -1;
	tot = 1;f[1] = a[1];	
	for (int i = 2; i <= n;i++)
	{
		if (a[i] > f[tot])
			f[++tot] = a[i];
		else
		{
			int j = upper_bound(f + 1, f + 1 + tot, a[i]) - f;
			f[j] = a[i];
		}
	}
	printf("%d\n", tot);
	return 0;
}

