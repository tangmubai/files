#include <stdio.h>
#include <algorithm>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-')
			w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, a[1005];
int main(void) {
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	read(n);
	for (int i = 1; i <= n; ++i)
		read(a[i]);
	std:: stable_sort(a + 1, a + 1 + n);
	int cnt = 1;
	for (int i = 2; i <= n; ++i)
		if (a[i] != a[i - 1]) {
			printf("%d %d\n", a[i - 1], cnt);
			cnt = 1;
		}
		else
			++cnt;
	printf("%d %d\n", a[n], cnt);
	return 0;
}
