#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e6+5;
int n,a,m;
int s[N];
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a);
		s[a]++;
		m=max(a,m);
	}
	for(int i=0;i<=m;i++)
	{
		if(s[i])
		{
			printf("%d %d\n",i,s[i]);
		}
	}
	return 0;
}
