#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n,a,ans;
int s[N];
int main()
{
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	memset(s,0x3f,sizeof(s));
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a);
		int j=lower_bound(s+1,s+ans+1,a)-s;
		if(j>=1&&j<=ans)
		{
			s[j]=a;
		}
		else
		{
			s[++ans]=a;
		}
	}
	printf("%d",ans);
	return 0;
}
