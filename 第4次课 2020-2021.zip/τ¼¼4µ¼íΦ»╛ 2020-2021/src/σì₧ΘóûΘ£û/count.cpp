#include<stdio.h>
using namespace std;
int n,a[1010],ma,b[1000010];
int main(){
	freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		b[a[i]]++;ma=a[i]>ma?a[i]:ma;
	}
	for(int i=1;i<=ma;i++)if(b[i]!=0)printf("%d %d\n",i,b[i]);
	return 0;
}
