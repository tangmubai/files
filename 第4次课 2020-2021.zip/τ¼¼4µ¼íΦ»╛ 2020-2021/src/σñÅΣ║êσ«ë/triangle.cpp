#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int n,a[105][105],f[105][105];
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(cin>>n && n!=0){
		for(int i=1;i<=n;i++)
			for(int j=1;j<=i;j++)
				scanf("%d",&a[i][j]);
		memset(f,0,sizeof(f));
		f[1][1]=a[1][1];
		for(int i=2;i<=n;i++){
			for(int j=1;j<=i;j++)
				f[i][j]=max(f[i-1][j],f[i-1][j-1])+a[i][j];
		}
		int ans=0;
		for(int i=1;i<=n;i++)
			ans=max(ans,f[n][i]);
		printf("%d\n",ans);
	}
	return 0;
}
