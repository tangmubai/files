#include<cstdio>
#include<algorithm>
#include<map>
#define rg register


inline int ma_x(int x,int y){return x>y?x:y;}

std::map<int,int> p;
int n,a[1001];
int main(){	
freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	
	scanf("%d",&n);
	for(rg int i=1;i<=n;i++)scanf("%d",&a[i]),p[a[i]]++;
	std::sort(a+1,a+1+n);
	for(rg int i=1;i<=n;i++)if(a[i]!=a[i-1])printf("%d %d\n",a[i],p[a[i]]);
	return 0;
}
