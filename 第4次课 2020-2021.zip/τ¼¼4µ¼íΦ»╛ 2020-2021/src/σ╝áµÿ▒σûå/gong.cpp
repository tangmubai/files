#include<cstdio>
#include<cstring>
#define rg register

int n,m,a1[1001],a2[1001],f[1001][1001];

inline int ma_x(int p,int q){return p>q?p:q;}

int main(){
	freopen("gong.in","r",stdin);
	freopen("gong.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(rg int i=1;i<=n;i++)scanf("%d",&a1[i]);
	for(rg int i=1;i<=m;i++)scanf("%d",&a2[i]);
	for(rg int i=1;i<=n;i++)
		for(rg int j=1;j<=m;j++)
	if(a1[i]==a2[j])f[i][j]=f[i-1][j-1]+1;
	else f[i][j]=ma_x(f[i-1][j],f[i][j-1]);
	
	printf("%d\n",f[n][m]);
	
	return 0;
}
