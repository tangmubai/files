#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n;
int a[1005],mem[1005];
int sc(int step){
	if(mem[step]!=-1) return mem[step];
	if(step==n+1) return 0;
	int res=0;
	for(int i=step+1;i<=n;i++){
		if(a[i]>a[step]){
			res=max(res,sc(i)+1);
		}
	}
	return mem[step]=res;
}
int ans;
int main(){
	freopen("long.in","r",stdin);
	freopen("long.out","w",stdout);
	memset(mem,-1,sizeof(mem));
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		ans=max(ans,sc(i)+1);
	}
	cout<<ans<<endl;
	return 0;
}

