#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int a[105][105];
int max1[105][105];
int n;
int sc(int x,int y){
	if(max1[x][y]!=-1) return max1[x][y];
	if(x==n+1) return 0;
	int ab=-1;
	ab=max(sc(x+1,y+1),sc(x+1,y))+a[x][y];
	return max1[x][y]=ab;
}
int main(){
	freopen("triangle.in","r",stdin);
	freopen("triangle.out","w",stdout);
	while(1){

	scanf("%d",&n);
	if(n==0) break;
	memset(max1,-1,sizeof(max1));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			cin>>a[i][j];
		}
	}
	cout<<sc(1,1)<<endl;
	}
	return 0;
}

