#include <iostream>

using namespace std;

inline void read(int &x)
{
	int f = 1;
	char c;
	c = getchar();
	while (c < '0' || c > '9')
	{
		if (c == '-')
			f = -1;
		c = getchar();
	}
	
	while (c >= '0' && c <= '9')
	{
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	
	x *= f;
}

const int N = 1010;

int a[N], b[N], f[N][N];

int main()
{
	 freopen("gong.in", "r", stdin);
	 freopen("gong.out", "w", stdout);
	
	int n, m;
	read(n), read(m);
	for (int i = 1; i <= n; i ++ )	read(a[i]);
	for (int i = 1; i <= m; i ++ )	read(b[i]);
	
	f[0][0]	= 1;
//	for (int i = 0; i <= n; i ++ )
//		f[i][0] = 1;
//	
//	for (int i = 0; i <= m; i ++ )
//		f[0][i] = 1;
	
	for (int i = 1; i <= n; i ++ )
		for (int j = 1; j <= m; j ++ )
		{
			f[i][j] = max(f[i - 1][j], f[i][j - 1]);
			if (a[i] == b[j])
				f[i][j] = max(f[i][j], f[i - 1][j - 1] + 1);
		}
		
	cout << f[n][m] << endl;
	return 0;
}

