#include <iostream>

using namespace std;

const int N = 1010;

inline void read(int &x)
{
	int f = 1;
	char c;
	c = getchar();
	while (c < '0' || c > '9')
	{
		if (c == '-')
			f = -1;
		c = getchar();
	}
	
	while (c >= '0' && c <= '9')
	{
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	
	x *= f;
}

int a[N], f[N];

int main()
{
	 freopen("long.in", "r", stdin);
	 freopen("long.out", "w", stdout);
	
	int n, ans = 0;
	read(n);
	
	for (int i = 1; i <= n; i ++ )	read(a[i]);
	
	for (int i = 1; i <= n; i ++ )
	{
		f[i] = 1;
		for (int j = 1; j < i; j ++ )
			if (a[i] > a[j])
				f[i] = max(f[i], f[j] + 1);
		
		ans = max(ans, f[i]);
	}
	
	cout << ans << endl;
	return 0;
}

