#include <iostream>

using namespace std;

const int N = 1010;

inline void read(int &x)
{
	int f = 1;
	char c;
	c = getchar();
	while (c < '0' || c > '9')
	{
		if (c == '-')
			f = -1;
		c = getchar();
	}
	
	while (c >= '0' && c <= '9')
	{
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	
	x *= f;
}

int f[N][N];

int main()
{
	 freopen("triangle.in", "r", stdin);
	 freopen("triangle.out", "w", stdout);
	
	int n;
	while (cin >> n, n)
	{
		for (int i = 1; i <= n; i ++ )
			for (int j = 1; j <= i; j ++ )
				read(f[i][j]);
			
		for (int i = n - 1; i >= 1; i -- )
			for (int j = 1; j <= i; j ++ )
				f[i][j] += max(f[i + 1][j], f[i + 1][j + 1]);
		cout << f[1][1] << endl;
	}
	
	return 0;
}

