#include<stdio.h>
#include<map>
using namespace std;
map<int,int>t;
map<int,int>::iterator it;
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
int main(){
	freopen("count.in","r",stdin);freopen("count.out","w",stdout);
	int n=qread();
	for(int i=1,a;i<=n;++i){
		a=qread();
		if(t.count(a)) ++t[a];
		else t[a]=1;
	}
	for(it=t.begin();it!=t.end();++it){
		printf("%d %d\n",((*it).first),((*it).second));
	}
	return 0;
}
