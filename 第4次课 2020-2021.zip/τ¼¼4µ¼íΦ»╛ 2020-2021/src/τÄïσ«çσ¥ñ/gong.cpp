#include<iostream>
#include<stdio.h>
using namespace std;
int p1[1005],p2[1005],ans[5][1005];
int qread(){
	int a=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a*f;
}
int main(){
	freopen("gong.in","r",stdin);freopen("gong.out","w",stdout);
	int m=qread(),n=qread();
	for(int i=1;i<=m;++i) p1[i]=qread();
	for(int i=1;i<=n;++i) p2[i]=qread();
	for(int i=1;i<=m;++i){
		for(int j=1;j<=n;++j){
			if(i&&j&&p1[i]==p2[j]) ans[i&1][j]=ans[(i-1)&1][j-1]+1;
			else ans[i&1][j]=0;
			if(i) ans[i&1][j]=max(ans[i&1][j],ans[(i-1)&1][j]);
			if(j) ans[i&1][j]=max(ans[i&1][j],ans[i&1][j-1]);
		}
	}
	printf("%d\n",ans[m&1][n]);
	return 0;
}
