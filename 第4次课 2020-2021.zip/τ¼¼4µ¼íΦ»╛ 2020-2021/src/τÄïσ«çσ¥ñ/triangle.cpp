#include<WangYuKun.h>
using namespace std;
int n,ans;
int num[105][105];
int qread(){
	int a=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		a=(a<<1)+(a<<3)+(c^'0');
		c=getchar();
	}
	return a;
}
void qs(int i,int j,int now){
	if(i>n){
		ans=max(ans,now);
		return;
	}
	now+=num[i][j];
	qs(i+1,j,now);
	qs(i+1,j+1,now);
	return;
}
int main(){
	freopen("triangle.in","r",stdin);freopen("triangle.out","w",stdout);
	while(n=qread()){
		ans=0;
		for(int i=1,j;i<=n;++i){
			for(int j=1;j<=i;++j) num[i][j]=qread();
		}
		qs(1,1,0);
		printf("%d\n",ans);
	}
	return 0;
}
