#include <cstdio>
using namespace std;
int n,i,j,x,a[1001],s[1001];
int main () {
	freopen ("long.in","r",stdin);
	freopen ("long.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) {scanf ("%d",&a[i]); s[i]=1;}
	for (i=n;i;i--) for (j=i+1;j<=n;j++) if (a[i]<a[j]&&s[j]>=s[i]) s[i]=s[j]+1;
	for (i=1,x=0;i<=n;i++) if (s[i]>x) x=s[i];
	printf ("%d",x);
	return 0;
}
