#include <cstdio>

const int N = 105;

bool ok = false;
int ans, maxn = -100000;
int a[N][N], sum[N][N];

void read(int &x)
{
	int f = 1; char c = getchar();
	while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar();}
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
	if (f == -1) x = -x;
}

int max(int x, int y) { return x > y ? x : y; }

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n; read(n);
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			read(a[i][j]);
			sum[i][j] = sum[i - 1][j] + a[i][j];
			maxn = max(maxn, a[i][j]);
		}
	}
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n; j++)
//		{
//			printf("%d ", sum[i][j]);
//		}
//		printf("\n");
//	}
	for (int first = 1; first <= n; first++)
	{
		for (int last = first; last <= n; last++)
		{
			int now = 0;
			for (int k = 1; k <= n; k++)
			{
				now += sum[last][k] - sum[first - 1][k];
				if (now < 0) now = 0;
//				ans = max(ans, now);
				if (ans < now)
				{
					ans = now;
					ok = true;
				}
			}
		}
	}
//	printf("%d\n", ans);
	if (ok)
		printf("%d\n", ans);
	else
		printf("%d\n", maxn);
	return 0;
}

