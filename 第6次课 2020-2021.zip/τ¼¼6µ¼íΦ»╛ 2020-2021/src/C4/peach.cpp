#include <cstdio>
#include <cstring>
using namespace std;

const int N = 105;

int f[N][N], a[N][N];

void read(int &x)
{
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
}

int max(int x, int y) { return x > y ? x : y; }

int main()
{
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	int t; read(t);
	while (t--)
	{
		memset(f, 0, sizeof(f));
		int n, m; read(n), read(m);
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= m; j++)
			{
				read(a[i][j]);
			}
		}
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= m; j++)
			{
				f[i][j] = max(f[i - 1][j], f[i][j - 1]) + a[i][j];
			}
		}
		printf("%d\n", f[n][m]);
	}
	return 0;
}

