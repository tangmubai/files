#include <cstdio>
#include <algorithm>
using namespace std;

const int N = 105;

int a[N], ans;
int f[N][N];

void read(int &x)
{
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
}

int main()
{
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	int n, k; read(n), read(k);
	for (int i = 1; i <= n; i++) read(a[i]), f[i][a[i] % k] = a[i];
	for (int i = 1; i <= n; i++)
	{
		for (int j = 0; j < k; j++)
		{
			if (f[i - 1][j])
				f[i][(j + a[i]) % k] = f[i - 1][j] + a[i];
		}
	}
	printf("%d\n", f[n][0]);
	return 0;
}
