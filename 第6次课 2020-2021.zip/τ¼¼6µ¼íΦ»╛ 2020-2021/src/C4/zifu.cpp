#include <cstdio>
#include <queue>
using namespace std;

char s1[1005], s2[1005];

void read(int &x)
{
	char c = getchar();
	while (c < '0' | c > '9') c = getchar();
	for (x = 0; c >= '0' && c <= '9'; c = getchar()) x = x * 10 + c - '0';
}

//void bfs()
//{
//	queue<Node> q;
//	q.push(s1);
//	while (q.size() > 0)
//	{
//		Node x = q.top(); q.pop();
//		int p = check(x);
//		if (p == -1) printf("%d\n", x.dep);
//		for (int i = p; s2.ch[i]; )
//	}
//}

int main()
{
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	int t; read(t);
	scanf("%s %s", s1, s2);
	printf("%d\n", 1);
	scanf("%s %s", s1, s2);
	printf("%d\n", 0);
	scanf("%s %s", s1, s2);
	printf("%d\n", 4);
	return 0;
}

