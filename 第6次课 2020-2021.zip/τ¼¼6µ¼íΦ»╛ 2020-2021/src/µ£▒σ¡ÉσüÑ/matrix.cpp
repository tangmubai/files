#include <cstdio>
#define max(a,b) ((a)>(b)?(a):(b))
int n,a[103][103],s[103][103],ans=-(1<<30);
int main(){
	freopen("matrix.in","r",stdin);freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) s[i][j]=s[i-1][j]+a[i][j];
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++) printf("%d ",s[i][j]);
//		puts("");
//	}
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			int now=0;
			for(int k=1;k<=n;k++){
				if(now<0) now=0;
				now+=s[j][k]-s[i-1][k];
				ans=max(ans,now);
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
/*
0 -2 -7 0
9 0 -13 2
5 1 -17 3
4 9 -17 1
*/
