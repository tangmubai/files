#include <cstdio>
#define max(a,b) ((a)>(b)?(a):(b))
int T,R,C,a[103][103],f[103][103];
int main(){
	freopen("peach.in","r",stdin);freopen("peach.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&R,&C);
		for(int i=1;i<=R;i++) for(int j=1;j<=C;j++) scanf("%d",&a[i][j]);
		for(int i=1;i<=R;i++){
			for(int j=1;j<=C;j++){
				f[i][j]=max(f[i][j-1],f[i-1][j])+a[i][j];
			}
		}
		printf("%d\n",f[R][C]);
	}
	return 0;
}

