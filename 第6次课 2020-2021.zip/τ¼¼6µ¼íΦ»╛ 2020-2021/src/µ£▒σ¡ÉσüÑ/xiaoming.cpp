#include <cstdio>
#define max(a,b) ((a)>(b)?(a):(b))
int n,k,a[103],f[103][103];
int main(){
	freopen("xiaoming.in","r",stdin);freopen("xiaoming.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		f[i][a[i]%k]=a[i];
		for(int j=0;j<k;j++) if(f[i-1][j]) f[i][(j+a[i])%k]=f[i-1][j]+a[i];
		for(int j=0;j<k;j++) f[i][j]=max(f[i][j],f[i-1][j]);
	}
	printf("%d\n",f[n][0]);
	return 0;
}
