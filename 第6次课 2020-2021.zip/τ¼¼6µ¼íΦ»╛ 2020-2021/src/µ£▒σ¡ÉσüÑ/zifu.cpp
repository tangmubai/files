#include <cstdio>
#include <cstring>
#define min(a,b) ((a)<(b)?(a):(b))
int n,len1,len2,f[1003][1003];
char s1[1003],s2[1003];
int main(){
	freopen("zifu.in","r",stdin);freopen("zifu.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		scanf("%s%s",s1+1,s2+1);
		if(!strcmp(s1+1,s2+1)) puts("0");
		else{
			len1=strlen(s1+1),len2=strlen(s2+1);
			memset(f,0x3f,sizeof f);
			for(int i=0;i<=len1;i++) f[i][0]=i;
			for(int i=0;i<=len2;i++) f[0][i]=i;
			for(int i=1;i<=len1;i++)
				for(int j=1;j<=len2;j++){
					if(s1[i]==s2[j]) f[i][j]=f[i-1][j-1];
					else f[i][j]=min(min(f[i-1][j],f[i][j-1]),f[i-1][j-1])+1;
				}
			printf("%d\n",f[len1][len2]);
		}
	}
	return 0;
}
