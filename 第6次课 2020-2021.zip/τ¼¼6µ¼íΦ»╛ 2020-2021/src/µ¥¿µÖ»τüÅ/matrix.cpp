#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <map>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return -1;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int sum[110][110];
#define get_sum(x1, y1, x2, y2) (sum[x2][y2] - sum[(x1)-1][y2] - sum[x2][(y1)-1] + sum[(x1)-1][(y1)-1])
#define set_sum(x, y, num) sum[x][y] = (sum[(x)-1][y] + sum[x][(y)-1] - sum[(x)-1][(y)-1] + (num))


int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	
	
	int n;
	in(n);
	
	
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)
		{
			int num;
			in(num);
			
			
			set_sum(i, j, num);
		}
	
	
	inline int ans = 0xbfbfbfbf;
	
	for(inline int x1=1; x1<=n; x1++)
		for(inline int y1=1; y1<=n; y1++)
			for(inline int x2=x1; x2<=n; x2++)
				for(inline int y2=y1; y2<=n; y2++)
					ans = max(ans, get_sum(x1, y1, x2, y2));
	
	
	out(ans);
}

