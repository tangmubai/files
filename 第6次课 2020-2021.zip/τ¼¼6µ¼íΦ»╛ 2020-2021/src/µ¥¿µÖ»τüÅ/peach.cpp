#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <map>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return -1;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int a[110][110], f[110][110];

int main()
{
	freopen("peach.in", "r", stdin);
	freopen("peach.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	
	for(int ii=1; ii<=tt; ii++)
	{
		int n, m;
		in(n), in(m);
		
		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++)
				in(a[i][j]);
		
		
		memset(f, 0, sizeof(f));
		
		
		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++)
				f[i][j] = max(f[i-1][j], f[i][j-1]) + a[i][j];
		
		
		out(f[n][m]), enter;
	}
}

