#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <map>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return -1;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int f[110][110];

int main()
{
	freopen("xiaoming.in", "r", stdin);
	freopen("xiaoming.out", "w", stdout);
	
	
	int n, k;
	in(n), in(k);
	
	
	memset(f, -1, sizeof(f));
	f[0][0] = 0;
	
	
	for(int i=1; i<=n; i++)
	{
		int num;
		in(num);
		
		int mod = num % k;
		
		
		for(int j=0; j<k; j++)
		{
			f[i][j] = f[i-1][j];
			
			if(f[i-1][(j - mod + k) % k] != -1)
				f[i][j] = max(f[i][j], f[i-1][(j - mod + k) % k] + num);
		}
	}
	
	
	out(f[n][0] == -1 ? 0 : f[n][0]);
}

