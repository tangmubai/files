#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <map>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline int in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
			return -1;
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
	return 1;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int f[1010][1010];
char a[1010], b[1010];

int main()
{
	freopen("zifu.in", "r", stdin);
	freopen("zifu.out", "w", stdout);
	
	
	int tt;
	in(tt);
	
	
	for(int ii=1; ii<=tt; ii++)
	{
		scanf("%s%s", a + 1, b + 1);
		int lena = strlen(a+1), lenb = strlen(b+1);
		
		
		f[0][0] = 0;
		
		for(int i=1; i<=lena; i++)
			f[i][0] = i;
		
		for(int i=1; i<=lenb; i++)
			f[0][i] = i;
		
		
		for(int i=1; i<=lena; i++)
			for(int j=1; j<=lenb; j++)
			{
				f[i][j] = min(f[i-1][j], min(f[i][j-1], f[i-1][j-1])) + 1;
				
				if(a[i] == b[j])
					f[i][j] = min(f[i][j], f[i-1][j-1]);
			}
		
		
		out(f[lena][lenb]), enter;
	}
}

