#include<iostream>
#include<cstring>
using namespace std;
int r,c;
int a[105][105];
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		cin>>r>>c;
		for(int i=1;i<=r;i++)for(int j=1;j<=c;j++)cin>>a[i][j];
		for(int i=1;i<=r;i++)for(int j=1;j<=c;j++)a[i][j]+=max(a[i-1][j],a[i][j-1]);
		cout<<a[r][c]<<endl;
	}
	return 0;
}
