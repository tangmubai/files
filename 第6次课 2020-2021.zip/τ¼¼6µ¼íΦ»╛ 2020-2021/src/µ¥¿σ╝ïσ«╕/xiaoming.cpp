#include<iostream>
#include<algorithm>
using namespace std;
int f[1000005];
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n,k;
	cin>>n>>k;
	int a[105];
	for(int i=1;i<=n;i++)cin>>a[i];
	int f[105][105];
	for(int i=1;i<=n;i++)for(int j=i;j<=n;j++)f[i][j]=f[i][j-1]+a[j];
	int ans=0;
	for(int i=1;i<=n;i++)for(int j=i;j<=n;j++)if(f[i][j]%k==0)ans=max(ans,f[i][j]);
	cout<<ans;
	return 0;
}
