#include<iostream>
#include<cstring>
using namespace std;
int f[1005][1005];
int main(){
//	freopen("zifu.in","r",stdin);
//	freopen("zifu.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin>>n;
	while(n--){
		char a[1005],b[1005];
		cin>>a>>b;
		int x=strlen(a),y=strlen(b);
		for(int i=1;i<=x;i++)f[i][0]=i;
		for(int i=1;i<=y;i++)f[0][i]=i;
		for(int i=1;i<=x;i++)for(int j=1;j<=y;j++){
			if(a[i-1]==a[j-1])f[i][j]=f[i-1][j-1];
			f[i][j]=min(min(f[i-1][j],f[i][j-1]),f[i-1][j-1])+1;
		}
		cout<<f[x][y]<<endl;
	}
	return 0;
}
