#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
ll a[105][105],ans,f[105][105];
int main(){
//	freopen("matrix.in","r",stdin);
//	freopen("matrix.out","w",stdout);
	ll n,t,x;
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++)for(ll j=1;j<=n;j++)scanf("%lld",&a[i][j]);
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=n;j++)f[i][j]+=a[i][j];
	}
	for(ll s=1;s<=n;s++){
		for(ll e=s;e<=n;e++){
			ll sum=0;
			for(ll t=1;t<=n;t++){
				sum+=f[t][e]-f[t][s-1];
				ans=max(ans,sum);
				sum=max(sum,0);
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}



