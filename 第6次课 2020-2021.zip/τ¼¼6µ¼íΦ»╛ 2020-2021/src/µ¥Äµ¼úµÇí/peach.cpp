#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
using namespace std;
int dx[4]={0,1,0},dy[4]={0,0,1},ans,a[105][105],r,c,t,vis[105][105];
int Max(int p,int q){
	return p>q?p:q;
}
void dfs(int x,int y,int sum){
	if(x==r&&y==c){
			ans=Max(ans,sum);
			return;			
		}
	for(int i=1;i<=2;i++){
		int nx=x+dx[i],ny=y+dy[i];
		if(nx>=1&&nx<=r&&ny>=1&&ny<=c&&!vis[nx][ny]){
			vis[nx][ny]=1;
			dfs(nx,ny,sum+a[nx][ny]);
			vis[nx][ny]=0;
		}
	}
}
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&r,&c);
		memset(vis,0,sizeof(vis));ans=0;
		for(int i=1;i<=r;i++)for(int j=1;j<=c;j++)scanf("%d",&a[i][j]);
		dfs(1,1,a[1][1]);
		printf("%d\n",ans);
	}
	return 0;
}

/*
2       
2 2     
1 1     
3 4   
2 3  
2 3 4   
1 6 5 
*/

