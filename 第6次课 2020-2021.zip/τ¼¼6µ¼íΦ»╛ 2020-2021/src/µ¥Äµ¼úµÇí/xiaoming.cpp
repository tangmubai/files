#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
ll f[105][105];
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	ll n,k,t;
	scanf("%lld%lld",&n,&k);
	for(ll i=1;i<=n;i++){
		scanf("%lld",&t);
		f[i][t%k]=t;
		for(ll j=0;j<k;j++){
			if(f[i-1][j])f[i][(j+t)%k]=f[i-1][j]+t;
			for(ll j=0;j<k;j++)f[i][j]=max(f[i][j],f[i-1][j]);
		}
	}
	printf("%lld\n",f[n][0]);
	return 0;
}



