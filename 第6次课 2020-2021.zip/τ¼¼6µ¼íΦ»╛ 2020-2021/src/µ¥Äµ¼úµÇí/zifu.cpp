#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
char a[1005],b[1005];
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	int n,ans=0;
	scanf("%d",&n);
	while(n--){
		ans=0;
		scanf("%s%s",a+1,b+1);
		int s1=strlen(a+1),s2=strlen(b+1);
		for(int i=1;i<=max(s1,s2);i++)ans+=int(a[i]!=b[i]);
		printf("%d\n",ans);	
	}
	
	return 0;
}

/*
3                                            
abcdefg   abcdef                             
ab ab                                        
mnklj jlknm   
*/

