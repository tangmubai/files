#include<stdio.h>
#define max(a,b)(a)>(b)?(a):(b)
#define min(a,b)(a)<(b)?(a):(b)
#define file(a)freopen(a".in","r",stdin),freopen(a".out","w",stdout)
int a[200][200],f[200][200];
int getsum(int h1,int l1,int h2,int l2){
	return f[h2][l2]-f[h1-1][l2]-f[h2][l1-1]+f[h1-1][l1-1];
}
int main(){
	file("matrix");
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			f[i][j]=f[i-1][j]+f[i][j-1]-f[i-1][j-1]+a[i][j];
		}
	}
	int ans=-2e9;
	for(int h1=1;h1<=n;h1++){
		for(int l1=1;l1<=n;l1++){
			for(int h2=h1;h2<=n;h2++){
				for(int l2=l1;l2<=n;l2++){
					ans=max(ans,getsum(h1,l1,h2,l2));
				}
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
