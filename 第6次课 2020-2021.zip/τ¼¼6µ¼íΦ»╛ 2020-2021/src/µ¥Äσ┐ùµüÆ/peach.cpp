#include<stdio.h>
#define max(a,b)(a)>(b)?(a):(b)
#define min(a,b)(a)<(b)?(a):(b)
#define file(a)freopen(a".in","r",stdin),freopen(a".out","w",stdout)
int a[200][200],dp[200][200];
void work(){
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			a[i][j]=dp[i][j]=0;
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			dp[i][j]=max(dp[i-1][j]+a[i][j],dp[i][j-1]+a[i][j]);
		}
	}
	printf("%d\n",dp[n][m]);
}
int main(){
	file("peach");
	int t;
	scanf("%d",&t);
	while(t--){
		work();
	}
	return 0;
}
