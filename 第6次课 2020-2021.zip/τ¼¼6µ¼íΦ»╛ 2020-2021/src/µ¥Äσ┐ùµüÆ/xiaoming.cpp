#include<stdio.h>
#define max(a,b)(a)>(b)?(a):(b)
#define file(a)freopen(a".in","r",stdin),freopen(a".out","w",stdout)
int n,k,t;
int f[150][150];
int main(){
	file("xiaoming");
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&t);
		f[i][t%k]=t;
		for(int j=0;j<k;j++){
			if(f[i-1][j]){
				f[i][(j+t)%k]=f[i-1][j]+t;
			}
		}
		for(int j=0;j<k;j++){
			f[i][j]=max(f[i][j],f[i-1][j]);
		}
	}
	printf("%d\n",f[n][0]);
	return 0;
}
