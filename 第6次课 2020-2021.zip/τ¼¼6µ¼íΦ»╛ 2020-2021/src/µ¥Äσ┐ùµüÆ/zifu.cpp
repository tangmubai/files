#include<stdio.h>
#define min(a,b)((a)<(b)?(a):(b))
#define file(a)freopen(a".in","r",stdin),freopen(a".out","w",stdout)
char a[1050],b[1050];
int dp[1050][1050];
int strlen(char a[]){
	int res=1;
	while(a[res]){
		res++;
	}
	return res-1;
}
void work(){
	scanf("%s %s",a+1,b+1);
	int n=strlen(a),m=strlen(b);
	for(int i=0;i<=n;i++){
		for(int j=0;j<=m;j++){
			dp[i][j]=0;
		}
	}
	for(int i=0;i<=m;i++){
		dp[0][i]=i;
	}
	for(int i=0;i<=n;i++){
		dp[i][0]=i;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i]==b[j]){
				dp[i][j]=dp[i-1][j-1];
			}else{
				dp[i][j]=min(min(dp[i-1][j]+1,dp[i][j-1]+1),dp[i-1][j-1]+1);
			}
		}
	}
	printf("%d\n",dp[n][m]);
	return;
}
int main(){
	file("zifu");
	int t;
	scanf("%d",&t);
	while(t--){
		work();
	}
	return 0;
}
