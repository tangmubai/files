#include <cstdio>
#include <algorithm>

using namespace std;

int a[110][110],n,i,j,b[110][110],s,ans,k,l;

int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}

int main () {
	freopen ("matrix.in","r",stdin);
	freopen ("matrix.out","w",stdout); 
	n=read ();
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++) {
			a[i][j]=read ();
			b[i][j]=b[i-1][j]+b[i][j-1]-b[i-1][j-1]+a[i][j];
		}
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			s=0;
			for (k=1;k<=i;k++) {
				for (l=1;l<=j;l++) {
					s+=b[i][j]+b[k][l]-b[i][l]-b[k][j];
					ans=max (s,ans);
				}
			}
		}
	}
	printf ("%d\n",ans);
	return 0;
}
