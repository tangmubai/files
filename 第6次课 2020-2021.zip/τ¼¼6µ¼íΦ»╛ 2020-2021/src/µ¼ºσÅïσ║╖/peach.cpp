#include <cstdio>
#include <algorithm>

using namespace std;

int a[110][110],n,m,i,j,f[110][110],t;

int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}

int main () {
	freopen ("peach.in","r",stdin);
	freopen ("peach.out","w",stdout);
	t=read ();
	while (t--) {
		n=read ();
		m=read ();
		for (i=1;i<=n;i++)
			for (j=1;j<=m;j++) {
				a[i][j]=read ();
				f[i][j]=0;
			}
		for (i=1;i<=n;i++)
			for (j=1;j<=m;j++)
				f[i][j]=max (f[i-1][j],f[i][j-1])+a[i][j];
		printf ("%d\n",f[n][m]);
	}
	return 0;
}
