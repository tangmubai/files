#include <cstdio>
#include <algorithm>

using namespace std;

int n,k,f[110][110],i,j,x,ans;

int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return k*f;
}

int main () {
	freopen ("xiaoming.in","r",stdin);
	freopen ("xiaoming.out","w",stdout);
	n=read ();
	k=read ();
	for (i=1;i<=n;i++) {
		x=read ();
		f[i][x%k]=x;
		for (j=0;j<k;j++) 
			if (f[i-1][j])
				f[i][(j+x)%k]=f[i-1][j]+x;
	}
	printf ("%d\n",f[n][0]);
	return 0;
}
