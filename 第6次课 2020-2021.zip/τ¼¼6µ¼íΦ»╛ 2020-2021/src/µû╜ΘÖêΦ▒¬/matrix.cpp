#include<stdio.h>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int s[105][105],f[105][105];
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			scanf("%d",&s[i][j]);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			f[i][j]=f[i-1][j]+f[i][j-1]-f[i-1][j-1]+s[i][j];
		}
	}
	int ans=(-200000000);
	for(int a=1;a<=n;a++){
		for(int b=1;b<=n;b++){
			for(int c=a;c<=n;c++){
				for(int d=b;d<=n;d++){
					int ss=f[c][d]-f[c][b-1]-f[a-1][d]+f[a-1][b-1];
					ans=max(ans,ss);
				}
			}
		}
	}
	printf("%d",ans);
	return 0;
}
