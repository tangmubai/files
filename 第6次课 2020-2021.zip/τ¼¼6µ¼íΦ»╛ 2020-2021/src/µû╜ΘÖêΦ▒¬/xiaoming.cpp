#include<stdio.h>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int a[105];
int f[105][105]={0};
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		int o=a[i]%k;
		f[i][o]=max(a[i],f[i-1][o]);
		for(int j=k-1;j>=0;j--){
			if(f[i-1][j]){
				f[i][(o+j)%k]=max(f[i][(o+j)%k],f[i-1][j]+a[i]);
			}
		}
	}
	printf("%d",f[n][0]);
	return 0;
}
