#include<stdio.h>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
char s1[1005],s2[1005];
int f[1005][1005];
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		memset(f,0,sizeof(f));
		scanf("%s%s",s1+1,s2+1);
		int l1=strlen(s1+1),l2=strlen(s2+1);
		for(int i=1;i<=l1;i++)f[i][0]=i;
		for(int i=1;i<=l2;i++)f[0][i]=i;
		for(int i=1;i<=l1;i++){
			for(int j=1;j<=l2;j++){
				if(s1[i]==s2[j])f[i][j]=f[i-1][j-1];
				else {
					f[i][j]=f[i-1][j-1]+1;
					f[i][j]=min(f[i][j],f[i-1][j]+1);
					f[i][j]=min(f[i][j],f[i][j-1]+1);
				}
			}
		}
		printf("%d\n",f[l1][l2]);
	}
	return 0;
}
