#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n,ans=-0x7fffffff;
int a[105][105],c[105][105],f[105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Maxsub(int from,int to){
	--from;
	int ret=-0x7fffffff;
	for(int i=2;i<=n;++i){
		f[i]=-0x7fffffff;
	}
	f[1]=c[to][1]-c[from][1];
	for(int i=2;i<=n;++i){
		int now=c[to][i]-c[from][i];
		f[i]=max(now,f[i-1]+now);
		ret=max(ret,f[i]);
	}
	return ret;
}

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			a[i][j]=read();
			c[i][j]=c[i-1][j]+a[i][j];
		}
	}
	for(int i=1;i<=n;++i){
		for(int j=i;j<=n;++j){
			ans=max(ans,Maxsub(i,j));
		}
	}
	printf("%d",ans);
	return 0;
}
