#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n,m,test_num;
int a[105][105],f[105][105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	test_num=read();
	while(test_num--){
		n=read(),m=read();
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				a[i][j]=read();
			}
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				f[i][j]=max(f[i][j-1],f[i-1][j])+a[i][j];
			}
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
