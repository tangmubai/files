#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n,k,ans;
int a[105],f[105][105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;++i){
		a[i]=read();
	}
	f[1][a[1]%k]=a[1];
	for(int i=2;i<=n;++i){
		for(int j=0;j<k;++j){
			if(a[i]%k==j){
				f[i][j]=f[i-1][j]+a[i];
			}else {
				f[i][j]=f[i-1][j];
				if(f[i-1][((j-a[i])%k+k)%k]!=0){
					f[i][j]=max(f[i][j],f[i-1][((j-a[i])%k+k)%k]+a[i]);
				}
			}
		}
	}
	printf("%d",f[n][0]);
	return 0;
}
