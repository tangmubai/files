#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int test_num,n,m;
int f[1005][1005];
char a[1005],b[1005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	test_num=read();
	while(test_num--){
		scanf("%s%s",a+1,b+1);
		n=strlen(a+1),m=strlen(b+1);
		memset(f,0x3f,sizeof(f));
		for(int i=1;a[i];++i){
			f[i][0]=i;
		}
		for(int j=1;b[j];++j){
			f[0][j]=j;
		}
		f[0][0]=0;
		for(int i=1;a[i];++i){
			for(int j=1;b[j];++j){
				if(a[i]==b[j]){
					f[i][j]=f[i-1][j-1];
				}else {
					f[i][j]=min(f[i-1][j-1],min(f[i-1][j],f[i][j-1]))+1;
				}
			}
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
