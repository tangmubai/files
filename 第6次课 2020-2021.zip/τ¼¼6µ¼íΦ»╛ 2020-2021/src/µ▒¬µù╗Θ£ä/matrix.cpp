#include<stdio.h>
int A(){
	char c=getchar();
	int k=1,a=0;
	while(c>'9'||c<'0'){
		(c=='-')?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int n,a[105][105],f[105][105],maxx=-1000000000;
inline int max(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("matrix.in","r",stdin);freopen("matrix.out","w",stdout);
	n=A();
	for(register int i=1;i<=n;++i)
	for(register int j=1;j<=n;++j)
	f[i][j]=f[i-1][j]+f[i][j-1]-f[i-1][j-1]+A();
	for(register int i=1;i<=n;++i)
	for(register int j=1;j<=n;++j)
	for(register int a=i+1;a<=n;++a)
	for(register int b=j+1;b<=n;++b)
	maxx=max(maxx,f[a][b]+f[i-1][j-1]-f[a][j-1]-f[i-1][b]);
	printf("%d",maxx);
}
