#include<stdio.h>
#include<string.h>
int f[2][105],t,n,m,x,y,z;
int A(){
	char c=getchar();
	int k=1,a=0;
	while(c>'9'||c<'0'){
		(c=='-')?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
inline int max(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("peach.in","r",stdin);freopen("peach.out","w",stdout);
	t=A();
	while(t--){
		n=A(),m=A();
		x=1,y=0;
		for(register int i=1;i<=n;++i,z=x,x=y,y=z)
		for(register int j=1;j<=m;++j)
		f[x][j]=max(f[y][j],f[x][j-1])+A();
		printf("%d\n",f[y][m]);
		memset(f,0,sizeof(f));
	}
}
