#include<stdio.h>
int A(){
	char c=getchar();
	int k=1,a=0;
	while(c>'9'||c<'0'){
		(c=='-')?k=-1:0;c=getchar();
	}
	while(c>='0'&&c<='9')a=(a<<1)+(a<<3)+c-'0',c=getchar();
	return a*k;
}
int n,k,a,b;
int f[105][105];
inline int max(int x,int y){
	return x>y?x:y;
}
int main(){
//	freopen("xiaoming.in","r",stdin);freopen("xiaoming.out","w",stdout);
	n=A(),k=A();
	for(register int i=1;i<=n;++i){
		a=A();
		f[i][a%k]=a;
		for(register int j=0;j<k;++j)
		if(f[i-1][j])f[i][(j+a)%k]=f[i-1][j]+a;
		for(register int j=0;j<k;++j)
		f[i][j]=max(f[i][j-1],f[i][j]);
	}
	printf("%d",f[n][0]);
}
