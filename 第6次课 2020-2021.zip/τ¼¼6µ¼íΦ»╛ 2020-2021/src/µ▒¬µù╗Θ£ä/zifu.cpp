#include<stdio.h>
#include<string.h>
int f[1005][1005],t,lena,lenb;
char a[1005],b[1005];
inline int min(int x,int y){
	return x<y?x:y;
}
int main(){
	freopen("zifu.in","r",stdin);freopen("zifu.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s%s",a+1,b+1);lena=strlen(a+1);lenb=strlen(b+1);
		for(register int i=1;i<=lena;++i)
		f[i][0]=i;
		for(register int i=1;i<=lenb;++i)
		f[0][i]=i;
		for(register int i=1;i<=lena;++i)
		for(register int j=1;j<=lenb;++j){
			if(a[i]==b[j]){
				f[i][j]=f[i-1][j-1];continue;
			}
			f[i][j]=min(min(f[i-1][j],f[i-1][j-1]),f[i][j-1])+1;
		}
		printf("%d\n",f[lena][lenb]);
	}
}
