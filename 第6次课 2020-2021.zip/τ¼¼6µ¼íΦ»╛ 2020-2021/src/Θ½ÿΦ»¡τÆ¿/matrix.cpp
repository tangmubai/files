#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;
int n,a[110][110],ans,h[110][110],s[110][110],sum;
/*struct node{
	int num,x,y;
}f[110][110];*/
int maxn(int a,int b){
	return (a>b?a:b);
}
int qh(int i,int j,int i1,int j1){
	int u=0;
	for(int k=i;k<=i1;k++)
	    u+=(h[k][j1]-h[k][j-1]);
	return u;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++){
	        scanf("%d",&a[i][j]);
	        h[i][j]=h[i][j-1]+a[i][j];
	        s[i][j]=s[i-1][j]+a[i][j];
	    }
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++){
	    	sum=0;
	    	for(int k=1;k<=i;k++){
	    		for(int l=1;l<=j;l++){
	    			sum=qh(k,l,i,j);
	    		}
	    		ans=maxn(ans,sum);
	    	}
	    	/*int x=a[i][j];
			int y=f[i-1][j].num+(h[i][j]-h[i][f[i-1][j].x-1]);
			int z=f[i][j-1].num+(s[i][j]-s[i][f[i][j-1].y-1]);
	    	if(x>=y&&x>=z){
	    		f[i][j].num=x;
	    		f[i][j].x=i;
	    		f[i][j].y=j;
	    	}
	    	else{
	    		if(y>=x&&y>=z){
	    			f[i][j].num=y;
	    			f[i][j].x=f[i-1][j].x;
	    			f[i][j].y=f[i-1][j].y;
	    		}
	    		else{
	    			f[i][j].num=z;
	    			f[i][j].x=f[i][j-1].x;
	    			f[i][j].y=f[i][j-1].y;
	    		}
	    	}
	    	ans=maxn(ans,f[i][j].num);*/
	    }
	printf("%d\n",ans);
	return 0;
}
/*
4
0 -2 -7  0
9  2 -6  2
-4 1 -4  1
-1 8  0 -2

15
*/
