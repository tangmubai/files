#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;
int t,r,c,a[110][110],f[110][110];
int maxn(int a,int b){
	return (a>b?a:b);
}
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&r,&c);
		for(int i=1;i<=r;i++)
		    for(int j=1;j<=c;j++)
		        scanf("%d",&a[i][j]);
		for(int i=1;i<=r;i++)
		    for(int j=1;j<=c;j++)
		        f[i][j]=maxn(f[i-1][j],f[i][j-1])+a[i][j];
	    printf("%d\n",f[r][c]);
	}
	return 0;
}
/*
2  
2 2   
1 1
3 4 
2 3 
2 3 4
1 6 5 

8
16
*/
