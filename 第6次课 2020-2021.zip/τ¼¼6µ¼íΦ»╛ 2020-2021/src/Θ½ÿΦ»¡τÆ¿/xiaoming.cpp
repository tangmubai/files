#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;
int n,k,a[110],sum,l,ans;
void dfs(int i,int s){
	if((s%k==0&&s>0)||s>sum){
		if(s>ans&&s<=sum)
		    ans=s;
		//printf("*%d\n",s);
		return;
	}
	for(int t=i;t<=n;t++)
	    dfs(t+1,s+a[i]);
	return;
}
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	if(sum%k==0){
		printf("%d\n",n);
		return 0;
	}
	for(int i=1;i<=n;i++)
	    dfs(i,0);
	printf("%d\n",ans);
	return 0;
}
/*
5 7
1
2
3
4
5

14
*/
