#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n;
int a[105][105];
int sum[105][105];
inline int work(int i,int j,int k,int l){
	return sum[k][l]-sum[i-1][l]-sum[k][j-1]+sum[i-1][j-1];
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+a[i][j];
	int ans=-2147483647;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	for(int k=i;k<=n;k++)
	for(int l=j;l<=n;l++)
	ans=max(ans,work(i,j,k,l));
	cout<<ans;
}
