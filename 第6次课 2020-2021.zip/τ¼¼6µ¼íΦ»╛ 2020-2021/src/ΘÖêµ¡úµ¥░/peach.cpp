#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
using namespace std;
int t;
int n,m;
int a[105][105];
int f[105][105];
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		scanf("%d",&a[i][j]);
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
		cout<<f[n][m]<<endl;
	}
}
