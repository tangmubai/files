#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;
int n,k;
int a[105];
int f[105][105];
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
	for(int j=n;j>=1;j--)
	for(int p=0;p<k;p++){
		f[j][(f[j-1][p]+a[i])%k]=max(f[j][(f[j-1][p]+a[i])%k],f[j-1][p]+a[i]);
	}
	cout<<f[n][0];
}
