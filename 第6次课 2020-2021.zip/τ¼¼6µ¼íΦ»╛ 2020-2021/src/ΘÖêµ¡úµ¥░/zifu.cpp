#include <iostream>
#include <cstring>
using namespace std;
int n;
char c1[1005],c2[1005];
int f[1005][1005];
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	cin>>n;
	while(n--){
		cin>>c1>>c2;
		int c1c=strlen(c1);
		int c2c=strlen(c2);
		memset(f,0,sizeof(f));
		for(int i=1;i<=c1c;i++)
		f[i][0]=i;
		for(int i=1;i<=c2c;i++)
		f[0][i]=i;
		for(int i=1;i<=c1c;i++)
		for(int j=1;j<=c2c;j++){
			if(c1[i-1]==c2[j-1])f[i][j]=f[i-1][j-1];
			else
			f[i][j]=min(min(f[i-1][j],f[i][j-1]),f[i-1][j-1])+1;
		}
		cout<<f[c1c][c2c]<<endl;
	}
}
