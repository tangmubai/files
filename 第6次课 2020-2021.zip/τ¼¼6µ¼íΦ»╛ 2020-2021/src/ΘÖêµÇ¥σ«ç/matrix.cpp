#include<iostream>
#include<stdio.h>
using namespace std;
int a[105][105],f[105][105];


int main()
{

	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,i,j;long long ans=0;
	scanf("%d",&n);
	
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			scanf("%d",&a[i][j]);
			ans+=a[i][j];
		}
	}
	
	cout<<ans;
}

