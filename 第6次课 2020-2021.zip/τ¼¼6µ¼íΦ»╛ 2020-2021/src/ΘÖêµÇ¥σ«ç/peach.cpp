#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[105][105],f[105][105],r,c;
int main()
{

	//freopen("peach.in","r",stdin);
	//freopen("peach.out","w",stdout);
	int i,j,t;
	scanf("%d",&t);
	
	while(t--)
	{

		scanf("%d%d",&r,&c);
		for(i=1;i<=r;i++)
		{
			for(j=1;j<=c;j++)
				scanf("%d",&a[i][j]);
			f[i][j]=a[i][j];
		}
		for(i=1;i<=r;i++)
		{
			for(j=1;j<=c;j++)
			{
				f[i][j]=max(a[i-1][j],a[i][j-1])+a[i][j];
			}
		}
		printf("%lld\n",f[r][c]);
	}
}

