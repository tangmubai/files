#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

int n,m,a[105][105],f[105][105];

int main(){
	freopen("peach.in","r",stdin);freopen("peach.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		memset(f,0,sizeof(f));
		scanf("%d %d",&n,&m);
		for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) scanf("%d",&a[i][j]);
		for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
		printf("%d\n",f[n][m]);
	}
	return 0;
}
