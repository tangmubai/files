#include<cstdio>
#include<algorithm>
using namespace std;

int n,k,a[105],f[105][105];

int main(){
	freopen("xiaoming.in","r",stdin);freopen("xiaoming.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	f[1][a[1]%k]=a[1];
	for(int i=2;i<=n;i++){
		for(int j=0;j<k;j++) f[i][(j+a[i])%k]=f[i-1][j]+a[i];
		for(int j=0;j<k;j++) f[i][j]=max(f[i][j],f[i-1][j]);
	}
	printf("%d\n",f[n][0]);
	return 0;
}
