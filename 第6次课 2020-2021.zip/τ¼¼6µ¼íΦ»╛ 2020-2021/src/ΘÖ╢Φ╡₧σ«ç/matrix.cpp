#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int sum[105][105];
int f[105];
int ans;
int a[105][105];
int n;
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	read(n);
	ans=-100000;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			read(a[i][j]);
			ans=mx(ans,a[i][j]);
			sum[i][j]=sum[i][j-1]+a[i][j];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++)
		{
			for(int k=0;k<=n;k++) f[k]=-10000000;
			for(int k=1;k<=n;k++){
				f[k]=mx(sum[k][j]-sum[k][i-1],f[k-1]+sum[k][j]-sum[k][i-1]);
				ans=mx(ans,f[k]);
			}
		}
	}
	printf("%d\n",ans);
	return 0;
} 


