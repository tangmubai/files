#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int T;
int n,m;
int f[105][105];
int a[105][105];
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
int main()
{
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n);read(m);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
			{
				read(a[i][j]);
			}
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				f[i][j]=mx(f[i-1][j],f[i][j-1])+a[i][j];
			}
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}


