#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int n,k;
int a[105];
int f[105][105];
inline int read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}
int main()
{
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	read(n);read(k);
	for(int i=1;i<=n;i++) read(a[i]);
	memset(f,-1,sizeof(f));
	f[0][0]=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<k;j++)
		{
			int ys=(j-a[i]%k+k)%k;  
			if(f[i-1][j]!=-1) f[i][j]=mx(f[i][j],f[i-1][j]);
			if(f[i-1][ys]!=-1) f[i][j]=mx(f[i][j],f[i-1][ys]+a[i]);
		}
//		for(int j=0;j<k;j++) printf("%d ",f[i][j]);puts("");
	}
	printf("%d\n",f[n][0]);
	return 0;
}


