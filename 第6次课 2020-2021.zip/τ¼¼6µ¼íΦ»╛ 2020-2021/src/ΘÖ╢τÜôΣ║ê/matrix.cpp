#include<stdio.h>
#include<algorithm>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
int a[105][105];long long ans[105][105];
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n=read();long long js=-2147483647;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++){
			scanf("%d",&a[i][j]);ans[i][j]=ans[i-1][j]+ans[i][j-1]-ans[i-1][j-1]+a[i][j];
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int x=1;x<=i;x++)
				for(int y=1;y<=j;y++)
					js=max(js,ans[i][j]-ans[i][y-1]-ans[x-1][j]+ans[x-1][y-1]);
	printf("%lld",js);
	return 0;
}

