#include<stdio.h>
#include<algorithm>
#include<cstring>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
long long dp[105][105];
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	int t=read();
	while(t--){
		memset(dp,0,sizeof(dp));
		int n=read(),m=read();
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				dp[i][j]=read();
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				dp[i][j]+=max(dp[i-1][j],dp[i][j-1]);
		printf("%lld\n",dp[n][m]);
	}
	return 0;
}

