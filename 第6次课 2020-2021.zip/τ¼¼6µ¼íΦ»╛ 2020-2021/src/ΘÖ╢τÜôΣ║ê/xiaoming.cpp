#pragma GCC optimize(2)
#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
int max(int a,int b){return a>b?a:b;}
int dp[105][105],n,k;
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;i++){
		int t=read();dp[i][t%k]=t;
		for(int j=0;j<k;j++)
			if(dp[i-1][j])
				dp[i][(j+t)%k]=dp[i-1][j]+t;
		for(int j=0;j<k;j++)
			dp[i][j]=max(dp[i][j],dp[i-1][j]);
	}
	printf("%d",dp[n][0]);
	return 0;
}

