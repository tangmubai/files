#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,a[105][105],ans,sum[105][105];
int main(){
	freopen("matrix.in","r",stdin);freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
		for(int j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
			ans=max(a[i][j],ans);
//			sum[i][j]=sum[i-1][j]+a[i][j];
		}
	for(int i=1;i<=n;i++){
		for(int j=1;j<+n;j++){
			int s=0;
			for(int k=1;k<=n;k++){
				s+=a[k][j]-a[k][i-1];
				ans=max(ans,s);
				s=max(s,0);
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}

