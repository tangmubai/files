#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int t,r,c,a[105][105],ans=0;
int main(){
	freopen("peach.in","r",stdin);freopen("peach.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&r,&c);
		ans=0;
		for(int i=1;i<=r;i++) for(int j=1;j<=c;j++) scanf("%d",&a[i][j]);
		for(int i=1;i<=r;i++)
			for(int j=1;j<=c;j++)
				a[i][j]+=max(a[i-1][j],a[i][j-1]);
		printf("%d\n",a[r][c]);
	}
	return 0;
}

