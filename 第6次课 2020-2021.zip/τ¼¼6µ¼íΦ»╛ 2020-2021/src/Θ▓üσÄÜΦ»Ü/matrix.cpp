#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,ans,a[110][110],s[110][110];
int main()
{freopen("matrix.in","r",stdin);freopen("matrix.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++)
 for(int j=1;j<=n;j++)
 cin>>a[i][j];
 for(int i=1;i<=n;i++)
 for(int j=1;j<=n;j++)
 s[i][j]=s[i][j-1]+a[i][j];
 for(int i=1;i<=n;i++)
 for(int j=i;j<=n;j++)
{int sum=0;
 for(int k=1;k<=n;k++)
{sum+=s[k][j]-s[k][i-1];
 ans=max(ans,sum);
 sum=max(sum,0);
}
}
 cout<<ans<<endl;
 return 0;
}
