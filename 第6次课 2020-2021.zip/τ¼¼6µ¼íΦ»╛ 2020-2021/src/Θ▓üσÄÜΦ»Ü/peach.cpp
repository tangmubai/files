#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int t,r,c,a[110][110],f[110][110];
int main()
{freopen("peach.in","r",stdin);freopen("peach.out","w",stdout);
 cin>>t;
 while(t--)
{cin>>r>>c;
 for(int i=1;i<=r;i++) for(int j=1;j<=c;j++) cin>>a[i][j];
 for(int i=1;i<=r;i++)
 for(int j=1;j<=c;j++)
 f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
 cout<<f[r][c]<<endl;
}
 return 0;
}
