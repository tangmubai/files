#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,k,ans,a[110],f[110][110];
bool cmp(int x,int y){return x<y;}
int main()
{freopen("xiaoming.in","r",stdin);freopen("xiaoming.out","w",stdout);
 cin>>n>>k;
 for(int i=1;i<=n;i++) cin>>a[i];
 for(int i=1;i<=n;i++)
{f[i][a[i]%k]=a[i];
 for(int j=0;j<k;j++) if(f[i-1][j]) f[i][(j+a[i])%k]=f[i-1][j]+a[i];
 for(int j=0;j<k;j++) f[i][j]=max(f[i][j],f[i-1][j]);
}
 cout<<f[n][0]<<endl;
 return 0;
}
