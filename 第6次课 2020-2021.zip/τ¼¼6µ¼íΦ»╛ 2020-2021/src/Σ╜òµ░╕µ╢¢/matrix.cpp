#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int a[105][105],n,x,sum,ans=-2000000;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			x=read();
			a[i][j]=a[i-1][j]+a[i][j-1]-a[i-1][j-1]+x;
		}
	}
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			for(register int k=1;k<=i;k++){
				for(register int l=1;l<=j;l++){
					sum=a[i][j]-a[k-1][j]-a[i][l-1]+a[k-1][l-1];
					ans=max(sum,ans);
				}
			}
		}
	}
	printf("%d",ans);
	return 0;
}
