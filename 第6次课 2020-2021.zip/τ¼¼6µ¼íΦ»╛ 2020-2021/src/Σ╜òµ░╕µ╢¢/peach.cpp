#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int f[105][105],t,n,m,x;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	t=read();
	while(t--){
		n=read();m=read();
		memset(f,0,sizeof(f));
		for(register int i=1;i<=n;i++){
			for(register int j=1;j<=m;j++){
				x=read();
				f[i][j]=max(f[i-1][j],f[i][j-1])+x;
			}
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
