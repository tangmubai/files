#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int f[105][105],n,k,x,ans;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
bool cmp(const int x,const int y){
	return x>y;
}
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	n=read();k=read();
	for(register int i=1;i<=n;i++){
		x=read();
		f[i][x%k]=x;
		for(register int j=0;j<k;j++)
		if(f[i-1][j]) f[i][(j+x)%k]=f[i-1][j]+x;
		for(register int j=0;j<k;j++)
		f[i][j]=max(f[i][j],f[i-1][j]);
	}
	printf("%d",f[n][0]);
	return 0;
}
