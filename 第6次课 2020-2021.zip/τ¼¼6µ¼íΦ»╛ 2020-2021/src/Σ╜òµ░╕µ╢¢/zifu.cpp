#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int f[1005][1005],t,n,m,x;char a[1005],b[1005];
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	t=read();
	while(t--){
		scanf("%s %s",a,b);
		m=strlen(a);n=strlen(b);
		memset(f,0,sizeof(f));
		for(register int i=1;i<=m;i++) f[i][0]=i;
		for(register int i=1;i<=n;i++) f[0][i]=i;
		for(register int i=1;i<=m;i++){
			for(register int j=1;j<=n;j++){
				if(a[i-1]==b[j-1]) f[i][j]=f[i-1][j-1];
				else f[i][j]=min(min(f[i-1][j],f[i][j-1]),f[i-1][j-1])+1;
			}
		}
		printf("%d\n",f[m][n]);
	}
	return 0;
}
