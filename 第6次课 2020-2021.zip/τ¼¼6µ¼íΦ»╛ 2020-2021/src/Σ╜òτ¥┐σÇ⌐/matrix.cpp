#include<cstdio>
#include<algorithm>
using namespace std;
int a[110][110],s[110][110];
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++)	
//			printf("%d ",s[i][j]);
//		printf("\n");
//	}
	int ans=-1000000;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int x=i;x<=n;x++)
				for(int y=j;y<=n;y++)
					ans=max(ans,s[x][y]-s[i-1][y-j+1]-s[x-i+1][j-1]+s[i-1][j-1]);
	printf("%d",ans);
	return 0;
}
