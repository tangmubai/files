#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
char a[1010],b[1010];
int f[1010][1010];
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--){
		memset(a,'\0',sizeof(a));
		memset(b,'\0',sizeof(b));
		memset(f,0,sizeof(f));
		scanf("%s ",a+1);
		scanf("%s ",b+1);
		int al=strlen(a+1),bl=strlen(b+1);
		for(int i=1;i<=al;i++) f[i][0]=i;
		for(int i=1;i<=bl;i++) f[0][i]=i;
		for(int i=1;i<=al;i++)
			for(int j=1;j<=bl;j++)
				if(a[i]==b[j]) f[i][j]=f[i-1][j-1];
				else f[i][j]=min(min(f[i-1][j],f[i][j-1]),f[i-1][j-1])+1;
		printf("%d\n",f[al][bl]);
	}
	return 0;
}
