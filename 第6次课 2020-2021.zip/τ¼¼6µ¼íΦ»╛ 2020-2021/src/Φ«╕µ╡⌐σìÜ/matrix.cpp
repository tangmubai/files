#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n, matrix[1005][1005], rowsum[1005][1005], f[1005][1005], ans = -1e9;
int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			scanf("%d", &matrix[i][j]);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			rowsum[i][j] = rowsum[i - 1][j] + rowsum[i][j - 1] - rowsum[i - 1][j - 1] + matrix[i][j];
	for (int first = 1; first <= n; first++)
		for (int last = first; last <= n; last++)
		{
			int sum = 0;
			for (int i = 1; i <= n; i++)
			{
				sum += rowsum[i][last] - rowsum[i][first - 1];
				ans = max(ans, sum);
				sum = max(sum,0);
			}
		}
	printf("%d", ans);
	return 0;
}

