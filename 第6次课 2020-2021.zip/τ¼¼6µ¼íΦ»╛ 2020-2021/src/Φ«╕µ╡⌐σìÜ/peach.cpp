#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int t, r, c,a[1005][1005];
int main()
{
	freopen("peach.in", "r", stdin);
	freopen("peach.out", "w", stdout);
	cin>>t;
	while(t--)
	{
		cin>>r>>c;
		for (int i = 1; i <= r; i++)
			for (int j = 1; j <= c; j++)
				cin>>a[i][j];
		for (int i = 1; i <= r; i++)
			for (int j = 1; j <= c; j++)
				a[i][j]+=max(a[i-1][j],a[i][j-1]);
		cout << a[r][c] << endl;
	}
	return 0;
}

