#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n, k, t, f[505][505];
int main()
{
	freopen("xiaoming.in", "r", stdin);
	freopen("xiaoming.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &t);
		f[i][t % k] = t;
		for (int j = 0; j < k; j++)
			if (f[i - 1][j]) f[i][(j+t)%k]=f[i - 1][j]+t;
		for (int j = 0; j < k; j++)
			f[i][j] = max(f[i][j], f[i - 1][j]);
	}
	printf("%d", f[n][0]);
	return 0;
}

