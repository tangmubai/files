#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int t, f[1005][1005]; char a[10005],b[10005];
int main()
{
//	freopen("zifu.in", "r", stdin);
//	freopen("zifu.out", "w", stdout);
	cin>>t;
	while(t--)
	{
	scanf("%s%s",a,b);
	int l1 = strlen(a), l2 = strlen(b);
	memset(f, 0, sizeof(f));
	for (int i = 1; i <= l1; i++) f[i][0] = i;
	for (int i = 1; i <= l2; i++) f[0][i] = i;
	for (int i = 1; i <= l1; i++)
		for (int j = 1; j <= l2; j++)
		{
			if (a[i-1]==b[j-1]) f[i][j]=f[i-1][j-1];
			else f[i][j]=min(f[i-1][j],min(f[i][j-1],f[i-1][j-1]))+1;
		}
		printf("%d\n",f[l1][l2]);
	}
	return 0;
}

