#include<stdio.h>
const int N = 100;
int n, a[N + 5][N + 5], s[N + 5][N + 5], ans;
int max(int x, int y) {return x > y ? x : y;}
int main() {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= n; ++j) {
			scanf("%d", &a[i][j]);
			s[i][j] = s[i][j - 1] + a[i][j];
		}
	ans = -0x7fffffff;	
	for(int i = 1; i <= n; ++i)
		for(int j = i; j <= n; ++j)	{
			int tp = 0;
			for(int k = 1; k <= n; ++k) {
				int nowx = s[k][j] - s[k][i - 1];
				if (tp <= 0) tp = nowx;
				else tp += nowx;
				ans = max(ans, tp);
			}
		}
	printf("%d\n", ans);	
	return 0;
}
