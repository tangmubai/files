#include<stdio.h>
#include<string.h>
#include<iostream>
const int N = 100;
using namespace std;
int T, n, m, a[N + 5][N + 5], f[N + 5][N + 5];

int max(int x, int y) {return x > y ? x : y;}

int dfs(int x, int y) {

	if (f[x][y] != -1044266559)
		return f[x][y];
	int nx = x + 1, ny = y, mx = x, my = y + 1;
	if (nx <= n && nx >= 1 && ny <= m && ny >= 1)
		f[x][y] = max(f[x][y], dfs(nx, ny) + a[x][y]);
	if (mx <= n && mx >= 1 && my <= m && my >= 1)
		f[x][y] = max(f[x][y], dfs(mx, my) + a[x][y]);
	return f[x][y];		   	
}

int main() {
	freopen("peach.in", "r", stdin);
	freopen("peach.out", "w", stdout);
	scanf("%d", &T);
	while(T--) {
		scanf("%d%d", &n, &m);
		memset(f, -0x3f, sizeof(f));
		for(int i = 1; i <= n; ++i)
			for(int j = 1; j <= m; ++j)
				scanf("%d", &a[i][j]);
		f[n][m] = a[n][m];		
		printf("%d\n", dfs(1, 1));//dfs(1, 1);		
	}
	return 0;
}
