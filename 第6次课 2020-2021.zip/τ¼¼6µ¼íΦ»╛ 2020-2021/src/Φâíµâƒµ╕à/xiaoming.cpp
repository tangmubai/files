#include<stdio.h>
const int N = 100;
int n, k, a[N + 5], f[N + 5], g[N + 5];
int max(int x, int y) {return x > y ? x : y;}
int main() {
	freopen("xiaoming.in", "r", stdin);
	freopen("xiaoming.out", "w", stdout);
	scanf("%d%d", &n, &k);
	f[0] = 0;
	for(int i = 1; i < k; ++i)
		f[i] = -0x3fffffff;
	for(int i = 1; i <= n; ++i) {
		scanf("%d", a + i);
		for(int j = 0; j < k; ++j)
			g[j] = f[j];
		for(int j = 0; j < k; ++j) {
			int tp = f[j] + (a[i] + j) / k;
			g[(j + a[i]) % k] = max(g[(j + a[i]) % k], tp); 
		}
		for(int j = 0; j < k; ++j)
			f[j] = g[j];
	}
	printf("%d", f[0] * k);
	return 0;
}
