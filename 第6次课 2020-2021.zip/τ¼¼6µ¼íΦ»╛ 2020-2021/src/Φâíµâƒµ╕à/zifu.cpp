#include<stdio.h>
#include<iostream>
#include<string.h>
const int N = 1000;
using namespace std;
int T, f[N + 5][N + 5];
char s1[N + 5], s2[N + 5]; 
int max(int x, int y){return x > y ? x: y;}
int min(int x, int y) {return x < y ? x : y;} 
int main() {
	freopen("zifu.in", "r", stdin);
	freopen("zifu.out", "w", stdout);
	 cin >> T;
	 while(T--) {
	 	memset(f, 0, sizeof(f));
	 	cin >> s1 + 1 >> s2 + 1;
	 	int l1 = strlen(s1 + 1), l2 = strlen(s2 + 1);
		for(int i = 0; i <= l1; ++i) f[i][0] = i;
		for(int i = 0; i <= l2; ++i) f[0][i] = i;
		for(int i = 1; i <= l1; ++i)
		 for(int j = 1; j <= l2; ++j)
		 	if (s1[i] == s2[j]) f[i][j] = f[i - 1][j - 1];
			 else f[i][j] = min(f[i - 1][j - 1], min(f[i][j - 1], f[i - 1][j])) + 1;
		printf("%d\n", f[l1][l2]);	 			
	 }
	 return 0;
}
