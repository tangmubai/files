#include <stdio.h>
int n,p,a[105][105],s[105][105],f2[105],f1[105];


int main(){
//	freopen("matrix.in","r",stdin);
//	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
		}
	ans=a[1][1];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=i;k<=n;k++)
				
	return 0;
}
