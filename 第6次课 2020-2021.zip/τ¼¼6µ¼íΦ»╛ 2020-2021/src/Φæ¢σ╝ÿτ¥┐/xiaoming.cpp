#include <stdio.h>
#include <map>
using namespace std;
#define ll long long
ll n,k,a,s,f[1005][1005];
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a);
		f[i][a%k]=a;
		for(int j=0;j<k;j++){
			if(f[i-1][j])
				f[i][(j+a)%k]=f[i-1][j]+a;
		}	
		for(int j=0;j<k;j++)
			f[i][j]=max(f[i][j],f[i-1][j]);
	}
	printf("%d",f[n][0]);
	return 0;
}
