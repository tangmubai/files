#include <stdio.h>
#include <cstring>
#include <iostream>
using namespace std;
char a[1005],b[1005];
int f[1005][1005],t,len1,len2;
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	scanf("%d",&t);
	scanf("%d",&t);
	while(t--){
		memset(f,0x3f,sizeof(f));
		scanf("%s\n%s",a+1,b+1);
		len1=strlen(a+1);len2=strlen(b+1);
		f[0][0]=0;f[0][1]=1;f[1][0]=1;
		for(int i=1;i<=len1;i++)
			for(int j=1;j<=len2;j++){
				f[i][j]=min(f[i-1][j],min(f[i][j-1],f[i-1][j-1]))+1;
				if(a[i]==b[j])
					f[i][j]=min(f[i][j],f[i-1][j-1]);
			}
		printf("%d\n",f[len1][len2]);
	}
	return 0;
}
