#include <cstdio>
#include <algorithm>
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
using namespace std;
int s[105][105];
int main(){
	frin("matrix.in");frout("matrix.out");
	int n;scanf("%d",&n);
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			scanf("%d",&s[i][j]);
			s[i][j]+=s[i-1][j];
		}
	}
	int ans=-(1<<29);
	for(int i=1;i<=n;++i){
		for(int j=i;j<=n;++j){
			int now=0;
			for(int k=1;k<=n;++k){
				now+=s[j][k]-s[i-1][k];
				ans=max(ans,now);
				if(now<0) now=0;
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
