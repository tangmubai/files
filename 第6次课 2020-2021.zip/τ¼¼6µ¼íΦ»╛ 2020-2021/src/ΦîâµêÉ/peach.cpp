#include <cstdio>
#include <cstring>
#include <algorithm>
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
using namespace std;
template <typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
int dp[105][105];
int main(){
	frin("peach.in");frout("peach.out");
	int T;in(T);
	while(T--){
		int n,m;in(n);in(m);
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				in(dp[i][j]);
				if(i==1&&j==1){
					continue;
				}
				if(i==1){
					dp[i][j]+=dp[i][j-1];
				}
				else if(j==1){
					dp[i][j]+=dp[i-1][j];
				}
				else dp[i][j]+=max(dp[i-1][j],dp[i][j-1]);
			}
		}
		printf("%d\n",dp[n][m]);
	}
	return 0;
}
