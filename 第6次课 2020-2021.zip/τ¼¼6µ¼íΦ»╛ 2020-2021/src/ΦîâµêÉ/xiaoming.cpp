#include <cstdio>
#include <cstring>
#include <algorithm>
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
using namespace std;
typedef long long ll;
ll dp[105][105];
inline void chmx(ll &x,ll y){
	if(x<y) x=y;
}
int n,k;
int f(int x){
	return (x%k+k)%k;
}
int main(){
	frin("xiaoming.in");frout("xiaoming.out");
	scanf("%d%d",&n,&k);
	memset(dp,-1,sizeof(dp));
	dp[0][0]=0;
	for(int i=1;i<=n;++i){
		int a;scanf("%d",&a);
		for(int j=0;j<k;++j){
			dp[i][j]=dp[i-1][j];
			if(dp[i-1][f(j-a)]!=-1) chmx(dp[i][j],dp[i-1][f(j-a)]+a);
		}
	}
	printf("%lld",dp[n][0]);
	return 0;
}
