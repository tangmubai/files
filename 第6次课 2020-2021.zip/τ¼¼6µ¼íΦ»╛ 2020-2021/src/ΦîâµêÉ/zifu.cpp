#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
using namespace std;
char a[1005],b[1005];
int dp[1005][1005];
inline void chmn(int &x,int y){
	if(x>y) x=y;
}
int main(){
	frin("zifu.in");frout("zifu.out");
	ios::sync_with_stdio(false);
	int T;cin>>T;
	while(T--){
		cin>>a+1>>b+1;
		int l1=strlen(a+1),l2=strlen(b+1);
		memset(dp,0,sizeof(dp));
		for(int i=0;i<=l1;++i) dp[i][0]=i;
		for(int i=0;i<=l2;++i) dp[0][i]=i;
		for(int i=1;i<=l1;++i){
			for(int j=1;j<=l2;++j){
				if(a[i]==b[j]) dp[i][j]=dp[i-1][j-1];
				else dp[i][j]=dp[i-1][j-1]+1;
				chmn(dp[i][j],dp[i-1][j]+1);
				chmn(dp[i][j],dp[i][j-1]+1);
			}
		}
		printf("%d\n",dp[l1][l2]);
	}
	return 0;
}
