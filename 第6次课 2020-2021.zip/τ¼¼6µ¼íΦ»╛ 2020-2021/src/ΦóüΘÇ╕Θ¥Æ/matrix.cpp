#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
typedef long long ll;
const int oo = 1e9;
const int maxn = 1e2+5;
inline void read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	x *= f;
}
int a[maxn][maxn];
int t[maxn][maxn];
int ans = -oo;
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen ("matrix.in", "r", stdin);
	freopen ("matrix.out", "w", stdout);
	//ios::sync_with_stdio(false);
	int n, k;
	read(n);
	for (register int i = 1; i <= n; i ++)
		for (register int j = 1; j <= n; j ++)
			read(a[i][j]);
	for (register int i = 1; i <= n; i ++)
		for (register int j = 1; j <= n; j ++)
			t[i][j] = t[i-1][j] + t[i][j-1] - t[i-1][j-1] + a[i][j];
	for (register int i = 1; i <= n; i ++) {
		for (register int j = 1; j <= n; j ++) {
			for (register int l = 1; l <= i; l ++) {
				for (register int w = 1; w <= j; w ++) {
					ans = mx(ans, t[i][j] - t[i][j-w] - t[i-l][j] + t[i-l][j-w]);
				}
			}
		}
	}
	printf ("%d\n", ans);
	return 0;
}
