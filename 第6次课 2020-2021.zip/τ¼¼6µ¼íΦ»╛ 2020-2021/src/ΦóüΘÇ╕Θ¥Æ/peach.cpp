#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
typedef long long ll;
const int oo = 1e9;
const int maxn = 1e2+5;
inline void read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	x *= f;
}
int a[maxn][maxn];
int f[maxn][maxn];
int ans = -oo;
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen ("peach.in", "r", stdin);
	freopen ("peach.out", "w", stdout);
	//ios::sync_with_stdio(false);
	int t;
	read(t);
	while (t --) {
		int r, c;
		read(r);
		read(c);
		memset(a, 0, sizeof (a));
		memset(f, 0, sizeof (f));
		for (register int i = 1; i <= r; i ++)
			for (register int j = 1; j <= c; j ++)
				read(a[i][j]);
		//f[i][j]��ʾ��(i,j)��λ����ժ�������peach�� ��ans=f[r][c] => �Ҵ�������
		//a[i][j]�Ǹ�����һֱ�� 
		 for (register int i = 1; i <= r; i ++) {
		 	for (register int j = 1; j <= c; j ++) {
		 		f[i][j] = mx(f[i-1][j], f[i][j-1]) + a[i][j];
		 	}
		 }
		 printf ("%d\n", f[r][c]);
	}
	return 0;
}
