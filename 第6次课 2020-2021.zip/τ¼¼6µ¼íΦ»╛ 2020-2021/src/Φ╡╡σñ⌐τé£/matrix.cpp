#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
const int N = 105;
int n;
int qz[N][N], a[N][N];
int ans = -2147483647;
int main () {
//	freopen ("matrix.in", "r", stdin);
	
	freopen ("matrix.in", "r", stdin);
	freopen ("matrix.out", "w", stdout);
	n = read();
	for (int i = 1; i <= n; i ++) {
		for (int j = 1; j <= n; j ++)
			a[i][j] = read(), 
			qz[i][j] = qz[i - 1][j] + qz[i][j - 1] - qz[i - 1][j - 1] + a[i][j];;
	}
	for (int x1 = 1; x1 <= n; x1 ++) {
		for (int y1 = 1; y1 <= n; y1 ++) {
			for (int x2 = x1; x2 <= n; x2 ++) {
				for (int y2 = y1; y2 <= n; y2 ++) {
					int sum = qz[x2][y2] - qz[x1 - 1][y2] - qz[x2][y1 - 1] + qz[x1 - 1][y1 - 1];
//					printf ("%d %d %d %d %d\n", x1, y1, x2, y2, sum);
					if (sum > ans)
						ans = sum;
				}
			}
		}
	}
	printf ("%d", ans);
} 

