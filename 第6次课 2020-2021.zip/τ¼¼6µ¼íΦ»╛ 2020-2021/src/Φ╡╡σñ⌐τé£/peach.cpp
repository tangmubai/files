#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
const int N = 105;
int t;
int n, m;
int a[N][N];
int f[N][N];
int main () {
	freopen ("peach.in", "r", stdin);
	freopen ("peach.out", "w", stdout);
	
	t = read();
	while (t --) {
		n = read(), m = read();
		for (int i = 1; i <= n; i ++) {
			for (int j = 1; j <= m; j ++) {
				a[i][j] = read();
			}
		}
		for (int i = 1; i <= n; i ++) {
			for (int j = 1; j <= m; j ++) {
				f[i][j] = max (f[i - 1][j], f[i][j - 1]) + a[i][j];
			}
		}
		printf ("%d\n", f[n][m]);
	}
}
/*
2
2 2
1 1 
3 4
2 3
2 3 4
1 6 5

*/

