#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int n, k;
const int N = 105;
int a[N];
int mem[N][N];
int search (int step, int y) {
	if (mem[step][y] != -1)
		return mem[step][y];
	if (step == n + 1) {
		if (y == 0)
			return 0;
		return -2147483647;
	}
	int res = search (step + 1, y);
	res = max (res, search (step + 1, (y + a[step]) % k) + a[step]);
	return mem[step][y] = res;
}
int main () {
	freopen ("xiaoming.in", "r", stdin);
	freopen ("xiaoming.out", "w", stdout);
	memset (mem, -1, sizeof(mem));
	n = read(), k = read();
	for (int i = 1; i <= n; i ++)
		a[i] = read();
	int ans = search (1, 0);
	printf ("%d", ans);
}


