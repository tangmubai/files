#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int read() { 
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') { 
		if (ch == '-') 
			f = 0;
		ch = getchar();
	} 
	while (ch >= '0' && ch <= '9') { 
		x = x * 10 + ch - 48;
		ch = getchar();
	} 
	return f ? x : -x;
} 
int t;
const int N = 55;
char s1[N], s2[N];
int len1, len2;
int f[N][N];
int main () { 
//	freopen ("zifu.in", "r", stdin);
//	freopen ("zifu.out", "w", stdout);
	t = read();
	while (t --) {
		memset (f, 0, sizeof(f));
		scanf ("%s%s", s1 + 1, s2 + 1);
		len1 = strlen (s1 + 1), len2 = strlen (s2 + 1);
		for (int i = 1; i <= len1; i ++)
			f[i][0] = i;
		for (int i = 1; i <= len2; i ++)
			f[0][i] = i;
		
		for (int i = 1; i <= len1; i ++) {
			for(int j = 1; j <= len2; j ++) {
				f[i][j] = min (f[i][j - 1], f[i - 1][j]) + 1;
				if (s1[i] == s2[j])
					f[i][j] = min (f[i][j], f[i - 1][j - 1]);
			}
		}
		printf ("%d\n", f[len1][len2]);
	} 
} 
/*
abc
abdd
*/

