#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 12800000

using namespace std;
int a[105][105]={0};
int sum[105][105]={0};
int main(){freopen("matrix.in","r",stdin);freopen("matrix.out","w",stdout);
	ll n;
	ll ans=-maxs; 
	scanf("%d",&n);
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
			sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+a[i][j];
		}
	}
	ans=a[1][1];
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=n;j++){
			for(ll k=i;k<=n;k++){
				for(ll l=j;l<=n;l++){
					ans=max(ans,sum[k][l]-sum[k][j-1]-sum[i-1][l]+sum[i-1][j-1]);
				}
			}
		}
	}
	printf("%d",ans);
	return 0;
}
/*
4
0 -2 -7  0
9  2 -6  2
-4 1 -4  1
-1 8  0 -2

*/
