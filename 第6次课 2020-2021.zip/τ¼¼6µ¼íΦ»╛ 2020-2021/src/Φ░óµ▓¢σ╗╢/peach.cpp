#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int a[105][105]={0};
int f[105][105]={0};
int main(){freopen("peach.in","r",stdin);freopen("peach.out","w",stdout);
	ll t;
	ll n,m;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		for(ll i=1;i<=n;i++)for(ll j=1;j<=m;j++)scanf("%d",&a[i][j]);
		memset(f,0,sizeof f);
		f[1][1]=a[1][1];
		for(ll i=1;i<=n;i++){
			for(ll j=1;j<=m;j++)f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
/*
2
2 2
1 1
3 4 
2 3
2 3 4  
1 6 5  

*/
