#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int f[105][105]={0};
int a[105]={0};
int main(){freopen("xiaoming.in","r",stdin);freopen("xiaoming.out","w",stdout);
	ll n,k,sum,now;
	scanf("%d%d",&n,&k);
	for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
	memset(f,-1,sizeof f);f[0][0]=0;
	sort(a+1,a+1+n);
	for(ll i=1;i<=n;i++)for(ll j=0;j<k;j++){
		ll last=(j-a[i]%k+k)%k;
		if(f[i-1][j]!=-1)f[i][j]=max(f[i][j],f[i-1][j]);
		if(f[i-1][last]!=-1)f[i][j]=max(f[i-1][last]+a[i],f[i][j]);
	}
	printf("%d",f[n][0]);
	return 0;
}
