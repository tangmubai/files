#include<stdio.h>
#include<iostream>
using namespace std;
int a[105][105],b[105][105];
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,i,j,k;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
			b[i][j]=b[i][j-1]+a[i][j];
		}
	}
	int maxx=-2147483647;
	for(i=1;i<=n;i++){
		for(j=i;j<=n;j++){
			int s=0;
			for(k=1;k<=n;k++){
				s=max(0,s+b[k][j]-b[k][i-1]);
				maxx=max(maxx,s);
			}
		}
	}
	printf("%d",maxx);
	return 0;
}
