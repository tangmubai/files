#include<stdio.h>
#include<iostream>
using namespace std;
int a[105][105],f[105][105];
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m,i,j;
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++){
			for(j=1;j<=m;j++){
				scanf("%d",&a[i][j]);
				f[i][j]=0;
			}
		}
		for(i=1;i<=m;i++)f[1][i]=a[1][i]+f[1][i-1];
		for(i=1;i<=n;i++)f[i][1]=a[i][1]+f[i-1][1];
		for(i=2;i<=n;i++){
			for(j=2;j<=m;j++){
				f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
			}
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
