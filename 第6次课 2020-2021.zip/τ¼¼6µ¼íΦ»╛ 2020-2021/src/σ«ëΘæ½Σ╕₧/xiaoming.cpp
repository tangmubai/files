#include<stdio.h>
using namespace std;
int a[105][2],f[10005];
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	int n,i,j,k,h;
	scanf("%d%d",&n,&k);
	for(i=1;i<=n;i++){
		scanf("%d",&h);
		a[i][0]=h%k;a[i][1]=h/k;
	}
	for(j=1;j<=n*k;j++){
		f[j]=-1;
	}
	for(i=1;i<=n;i++){
		for(j=n*k;j>=a[i][0];j--){
			if(f[j]<f[j-a[i][0]]+a[i][1]&&f[j-a[i][0]]!=-1){
				f[j]=f[j-a[i][0]]+a[i][1];
			}
		}
	}
	int max=0;
	for(i=k;i<=n*k;i+=k){
		if(max<f[i]*k+i&&f[i]!=-1)max=f[i]*k+i;
	}
	printf("%d",max);
	return 0;
}
