#include<stdio.h>
#include<iostream>
using namespace std;
char a[1005],b[1005];
int f[1005][1005];
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int n=0,m=0,i,j;
		scanf("%s%s",a+1,b+1);
		for(n=1;a[n];n++);
		for(m=1;b[m];m++);
		n--;m--;
		for(i=1;i<=n;i++){
			for(j=1;j<=m;j++){
				if(a[i]==b[j]){
					f[i][j]=f[i-1][j-1];
				}
				else f[i][j]=min(f[i-1][j],min(f[i][j-1],f[i-1][j-1]))+1;
			}
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
