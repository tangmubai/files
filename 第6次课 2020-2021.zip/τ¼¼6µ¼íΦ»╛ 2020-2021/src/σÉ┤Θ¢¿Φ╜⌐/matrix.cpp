#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
#define itn int
int n,a[105][105],ans=-1270001;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)for(int j=1;j<=n;j++)scanf("%d",&a[i][j]);
	int s;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int r=i;r<=n;r++){
				for(int c=j;c<=n;c++){
					s=0;
					for(int x=i;x<=r;x++)
						for(int y=j;y<=c;y++)
							s+=a[x][y];
				   	ans=max(ans,s);
				}
			}
		}
	}

	printf("%d",ans);
	return 0;
}
