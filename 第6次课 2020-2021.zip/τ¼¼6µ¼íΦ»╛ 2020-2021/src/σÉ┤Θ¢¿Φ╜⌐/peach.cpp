#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
#define itn int
int k,n,m,a[105][105];
int f[105][105],t[105][105];
int dfs(int x,int y){
	if(f[x][y]!=-1)return f[x][y];
	if(x>n||y>m)return 0;
	int tmp1,tmp2;
	if(t[x+1][y]==0){
		t[x+1][y]=1;
		tmp1=dfs(x+1,y)+a[x][y];
		t[x+1][y]=0;
	}
	if(t[x][y+1]==0){
		t[x][y+1]=1;
		tmp2=dfs(x,y+1)+a[x][y];
		t[x][y+1]=0;
	}
	return f[x][y]=max(tmp1,tmp2);
}
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	scanf("%d",&k);
	while(k--){
		scanf("%d %d",&n,&m);
		for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)scanf("%d",&a[i][j]);
		memset(f,-1,sizeof(f));memset(t,0,sizeof(t));
		t[1][1]=1;
		printf("%d\n",dfs(1,1));
	}
	return 0;
}
