#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
#define itn int
int n,k;
int f[105][105];
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	scanf("%d %d",&n,&k);
	int x;
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		f[i][x%k]=x;
		for(int j=1;j<=n;j++)if(f[i-1][j])f[i][(j+x)%k]=f[i-1][j]+x;
		for(int j=1;j<=n;j++)f[i][j]=max(f[i][j],f[i-1][j]);
	}
	printf("%d",f[n][0]);
	return 0;
}
