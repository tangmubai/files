#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
#define itn int
int t,ans,f[1005][1005];
char a1[1005],a2[1005];
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%s",a1);
		scanf("%s",a2);
		int m=strlen(a1),n=strlen(a2);
		for(int i=1;i<=m;i++)f[i][0]=i;
		for(int i=1;i<=n;i++)f[0][i]=i;
		for(int i=1;i<=m;i++){
			for(int j=1;j<=n;j++){
				if(a1[i-1]==a2[j-1])f[i][j]=f[i-1][j-1];
				else f[i][j]=min(f[i-1][j],f[i-1][j-1]+1);
			}
		}
		printf("%d\n",f[m][n]);
	}
	return 0;
}
