#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,m,a[110][110],f[110][110],t;
int main()
{
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		cin>>n>>m;
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cin>>a[i][j];
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
			}
		}
		cout<<f[n][m]<<endl;
	}
	return 0;
}

