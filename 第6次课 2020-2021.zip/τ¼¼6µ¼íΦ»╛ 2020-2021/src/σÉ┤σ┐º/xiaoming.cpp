#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int ans,f[110][110],n,k,a[110];

int main()
{
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		int o=a[i]%k;
		f[i][o]=max(a[i],f[i-1][o]);
		for(int j=k-1;j>=0;j--)
		{
			if(f[i-1][j])
			{
				f[i][(o+j)%k]=max(f[i][(o+j)%k],f[i-1][j]+a[i]);
			}
		}
	}
	cout<<f[n][0]<<endl;
	return 0;
}
