#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
string a,b;
int f[1100][1100],lena,lenb,t,lenm;
int main()
{
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		cin>>a>>b;
		lena=a.size();
		lenb=b.size();
		for(int i=)
		cout<<f[lenm-1][lenm-1]<<endl;
	}
	return 0;
}

