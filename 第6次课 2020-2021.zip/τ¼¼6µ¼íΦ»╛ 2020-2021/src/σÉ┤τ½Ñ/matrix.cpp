#include<stdio.h>
#define N 101
inline char nc()
{
	static char buf[11111],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,11111,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register bool t=0;register char c=nc();for(;c<'0'||'9'<c;t|=c=='-',c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());if(t)x=-x;
}
int a[N][N];
main()
{
	freopen("matrix.in","r",stdin);freopen("matrix.out","w",stdout);
	register int n,ans=-(1<<30),now;
	read(n);
	for(register int i=1;i<=n;++i)for(register int j=1;j<=n;++j)read(a[i][j]),a[i][j]+=a[i-1][j];
	for(register int i=0;i<n;++i)for(register int j=i+1;j<=n;++j)
	{
		now=0;
		for(register int k=1;k<=n;++k)
		{
			if(now<0)now=0;
			now+=a[j][k]-a[i][k];
			if(now>ans)ans=now;
		}
	}
	printf("%d",ans);
}
