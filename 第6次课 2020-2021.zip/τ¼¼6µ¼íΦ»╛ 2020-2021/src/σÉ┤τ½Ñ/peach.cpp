#include<stdio.h>
#define N 100
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
int a[N][N];
inline int max(const int&x,const int&y){return x>y?x:y;}
main()
{
	freopen("peach.in","r",stdin);freopen("peach.out","w",stdout);
	register int t,n,m;
	for(read(t);t--;printf("%d\n",a[n-1][m-1]))
	{
		read(n);read(m);
		for(register int i=0;i<n;++i)for(register int j=0;j<m;++j)read(a[i][j]);
		for(register int i=1;i<n;++i)a[i][0]+=a[i-1][0];
		for(register int j=1;j<m;++j)a[0][j]+=a[0][j-1];
		for(register int i=1;i<n;++i)for(register int j=1;j<m;++j)
			a[i][j]+=max(a[i-1][j],a[i][j-1]);
	}
}
