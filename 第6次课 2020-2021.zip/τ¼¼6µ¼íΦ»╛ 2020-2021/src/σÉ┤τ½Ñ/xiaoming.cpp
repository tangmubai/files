#include<stdio.h>
inline char nc()
{
	static char buf[999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
inline int max(const int&x,const int&y){return x>y?x:y;}
main()
{
	freopen("xiaoming.in","r",stdin);freopen("xiaoming.out","w",stdout);
	register int n,k,a,ans[2][100];
	read(n);read(k);
	for(register int j=1;j<k;++j)ans[0][j]=-(1<<30);ans[0][0]=0;
	for(register int i=1;i<=n;++i)
	{
		read(a);
		for(register int j=0;j<k;++j)
			ans[i&1][j]=max(ans[i&1^1][j],ans[i&1^1][((j-a)%k+k)%k]+a);
	}
	printf("%d",max(ans[n&1][0],0));
}
