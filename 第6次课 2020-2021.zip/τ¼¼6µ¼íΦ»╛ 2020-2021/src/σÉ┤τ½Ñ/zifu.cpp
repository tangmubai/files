#include<stdio.h>
#include<string.h>
#define N 1111
inline void min(int&x,const int&y){if(x>y)x=y;}
main()
{
	freopen("zifu.in","r",stdin);freopen("zifu.out","w",stdout);
	register int t,n,m;register char a[N],b[N];register int ans[2][N];
	for(scanf("%d",&t);t--;printf("%d\n",ans[n&1][m]))
	{
		scanf("%s%s",a+1,b+1);n=strlen(a+1);m=strlen(b+1);
		ans[0][0]=0;
		for(register int i=0;i<=n;++i)for(register int j=0;j<=m;++j)if(i||j)
		{
			if(i&&j)ans[i&1][j]=ans[i&1^1][j-1]+(a[i]!=b[j]);
			else ans[i&1][j]=1<<30;
			if(i)min(ans[i&1][j],ans[i&1^1][j]+1);
			if(j)min(ans[i&1][j],ans[i&1][j-1]+1);
		}
	}
}
