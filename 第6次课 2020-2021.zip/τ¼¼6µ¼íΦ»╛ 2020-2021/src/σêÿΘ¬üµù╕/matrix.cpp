#include <stdio.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, mp[105][105], s[105][105], f[105][105];
inline int mx(int p, int q) {
	return p > q ? p : q;
}
int main(void) {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	read(n);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			read(mp[i][j]);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			s[i][j] = s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1] + mp[i][j];
	int ans = 0;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j) {
			f[i][j] = 0;
			for (int a = 1; a <= i; ++a)
				for (int b = 1; b <= j; ++b)
					f[i][j] = mx(s[i][j] - s[a - 1][j] - s[i][b - 1] + s[a - 1][b - 1], f[i][j]);
			ans = mx(f[i][j], ans);
		}
	printf("%d\n", ans);
	return 0;
}
