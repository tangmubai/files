#include <stdio.h>
#include <string.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, m, a[105][105], f[105][105];
inline int mx(int p, int q) {
	return p > q ? p : q;
}
int main(void) {
	freopen("peach.in", "r", stdin);
	freopen("peach.out", "w", stdout);
	int t;
	for (read(t); t--; ) {
		memset(f, 0, sizeof f);
		read(n); read(m);
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				read(a[i][j]);
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				f[i][j] = mx(f[i - 1][j], f[i][j - 1]) + a[i][j];
		printf("%d\n", f[n][m]);
	}
	return 0;
}
