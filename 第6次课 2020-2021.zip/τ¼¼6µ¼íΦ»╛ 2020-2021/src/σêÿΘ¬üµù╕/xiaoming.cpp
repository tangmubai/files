#include <stdio.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = 0; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = !w ? x : -x;
}
int n, K, a[105], f[105][105];
inline int mx(int p, int q) {
	return p > q ? p : q;
}
int main(void) {
	freopen("xiaoming.in", "r", stdin);
	freopen("xiaoming.out", "w", stdout);
	read(n); read(K);
	for (int i = 1; i <= n; ++i) read(a[i]);
	int ans = 0;
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j < i; ++j)
			for (int k = 0; k < K; ++k)
				f[i][k] = mx(f[j][(k - a[i] + K) % K] + a[i], f[i][k]);
		ans = mx(f[i][0], ans);
	}
	printf("%d\n", ans);
	return 0;
}
