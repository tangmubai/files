#include <stdio.h>
#include <string.h>
char a[1005], b[1005];
int f[1005][1005];
inline int mx(int p, int q) {
	return p > q ? p : q;
}
int main(void) {
	freopen("zifu.in", "r", stdin);
	freopen("zifu.out", "w", stdout);
	int t;
	for (scanf("%d", &t); t--; ) {
		memset(f, 0, sizeof f);
		scanf("%s %s", a + 1, b + 1);
		for (int i = 1; a[i] != '\0'; ++i)
			for (int j = 1; b[j] != '\0'; ++j)
				if (a[i] == b[j])
					f[i][j] = mx(f[i - 1][j - 1] + 1, f[i][j]);
				else
					f[i][j] = mx(f[i - 1][j], f[i][j - 1]);
		printf("%d\n", mx(strlen(a + 1), strlen(b + 1)) - f[strlen(a + 1)][strlen(b + 1)]);
	}
	return 0;
}
