#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
const int INF=1<<30;
int n,a,ans=-INF;
int f[N][N];
inline int read()
{
	int s=0,t=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') t=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*t;
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	{
		a=read();
		f[i][j]=f[i][j-1]+a;
	}
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	{
		f[i][j]+=f[i-1][j];
	}
	for(int x2=1;x2<=n;x2++)
	for(int y2=1;y2<=n;y2++)
	for(int x1=1;x1<=x2;x1++)
	for(int y1=1;y1<=y2;y1++)
	{
		ans=max(ans,f[x2][y2]-f[x1-1][y2]-f[x2][y1-1]+f[x1-1][y1-1]);
	}
	printf("%d",ans);
}
