#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int t,n,m,a;
int f[N][N];
inline int read()
{
	int s=0,t=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') t=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*t;
}
int main()
{
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	t=read();
	while(t--)
	{
		memset(f,0,sizeof(f));
		n=read();
		m=read();
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			a=read();
			f[i][j]=max(f[i-1][j],f[i][j-1])+a;
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
