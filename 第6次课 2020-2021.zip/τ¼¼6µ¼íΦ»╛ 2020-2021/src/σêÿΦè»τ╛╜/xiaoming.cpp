#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n,k,a;
int f[N][N];
inline int read()
{
	int s=0,t=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') t=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*t;
}
int main()
{
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	n=read();
	k=read();
	for(int i=1;i<=n;i++)
	{
		a=read();
		f[i][a%k]=a;
		for(int j=0;j<k;j++)
		{
			if(f[i-1][j]) f[i][(j+a)%k]=f[i-1][j]+a;
		}
		for(int j=0;j<k;j++)
		{
			f[i][j]=max(f[i][j],f[i-1][j]);
		}
	}
	printf("%d",f[n][0]);
	return 0;
}
