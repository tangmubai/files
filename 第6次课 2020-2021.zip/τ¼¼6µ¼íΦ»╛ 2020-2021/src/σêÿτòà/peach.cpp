#include<iostream>
#include<stdio.h>
using namespace std;
int f[110][110],a[110][110];
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	int s;scanf("%d",&s);
	int n,k,ans=0;
	for(int i=1;i<=s;i++){
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=k;j++)
		    cin>>a[i][j];	 
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=k;j++)
	       a[i][j]+=max(a[i-1][j],a[i][j-1]);
	cout<<a[n][k]<<endl;
	}
	return 0;
}
