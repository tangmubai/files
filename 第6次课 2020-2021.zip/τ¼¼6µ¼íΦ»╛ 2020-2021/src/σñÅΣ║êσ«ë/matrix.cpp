#include<cstdio>
#include<algorithm>
using namespace std;
int n;
int a[110][110],s[110][110],ans=-2147483640;
int ll(int i,int j,int x,int y){
	return s[x][y]-s[i-1][y]-s[x][j-1]+s[i-1][j-1];
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int x=i;x<=n;x++)
				for(int y=j;y<=n;y++)
					ans=max(ans,ll(i,j,x,y));
	printf("%d\n",ans);
	return 0;
}
