#include<cstdio>
#include<algorithm>
using namespace std;
int t,x,y;
int a[110][110],f[110][110];
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&x,&y);
		for(int i=1;i<=x;i++)
			for(int j=1;j<=y;j++){
				scanf("%d",&a[i][j]);
			}
		for(int i=1;i<=x;i++)
			for(int j=1;j<=y;j++){
				f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
			}
		printf("%d\n",f[x][y]);
	}
	return 0;
}
