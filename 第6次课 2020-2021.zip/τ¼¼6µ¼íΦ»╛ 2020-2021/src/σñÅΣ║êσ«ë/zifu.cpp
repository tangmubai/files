#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
using namespace std;
int t;
char a[1005],b[1005];
int f[1005][1005];
int main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	scanf("%d",&t);
//	for(int i=1;i<=n;i++){
//		int ans=0;
//		cin>>a>>b;
//		for(int i=0;i<min(a.length(),b.length());i++)
//			if(a[i]==b[i]) ans++;
//		if(ans==a.length()) printf("%d\n",b.length()-a.length());
//		else if(ans==b.length()) printf("%d\n",a.length()-b.length());
//		else printf("%d\n",a.length()+b.length()-ans*2);
//	}
	while(t--){
		cin>>a>>b;
		int m=strlen(a);
		int n=strlen(b);
		for(int i=1;i<=m;i++)
			f[i][0]=i;
		for(int i=1;i<=n;i++)
			f[0][i]=i;
		for(int i=1;i<=m;i++)
			for(int j=1;j<=n;j++)
				if(a[i-1]==b[j-1]) f[i][j]=f[i-1][j-1];
				else f[i][j]=min(min(f[i-1][j],f[i][j-1]),f[i-1][j-1])+1;
		printf("%d\n",f[m][n]);
	}
	return 0;
}
