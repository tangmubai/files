#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e2 + 5;

int a[N][N];
int sum[N][N];
int f[N][N];

int main() {
	ios :: sync_with_stdio(false);
	//freopen("matrix.in", "r", stdin);
	//freopen("matrix.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; ++ i) {
		for (int j = 1; j <= m; ++ j) {
			cin >> a[i][j];
			sum[i][j] = sum[i - 1][j] + sum[i][j - 1] = sum[i - 1][j - 1] + a[i][j];
		}
	}
	for (int i = 0; i <= n; ++ i) 
		f[i][0] = -0x7ffffff;
	for (int i = 0; i <= m; ++ i)
		f[0][i] = -0x7ffffff;
	for (int i = 1; i <= n; ++ i) {
		for (int j = 1; j <= m; ++ j) {
			for (int p = i; p <= n; ++ p) {
				for (int q = j; q <= m; ++ q) {
					if (p == i and q == j) continue;
					ans = Max(ans, sum[p][q] - sum[p - i][q] + sum[i][j])
				}
			}
		}
	}
	return 0;
}

