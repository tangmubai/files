#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e2 + 5;

int a[N][N], f[N][N];
int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("peach.in", "r", stdin);
	freopen("peach.out", "w", stdout);
	int t, n, m;
	cin >> t;
	while (t --) {
		cin >> n >> m;
		for (int i = 1; i <= n; ++ i) {
			for (int j = 1; j <= m; ++ j) {
				cin >> a[i][j];
				f[i][j] = Max(f[i - 1][j], f[i][ j - 1]) + a[i][j];
			}
		}
		cout << f[n][m] << endl;
	}
	return 0;
}
/*
2 
2 2 
1 1 
3 4
2 3
2 3 4
1 6 5
*/
