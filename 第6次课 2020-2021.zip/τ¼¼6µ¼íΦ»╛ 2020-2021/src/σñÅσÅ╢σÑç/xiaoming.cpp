#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 1e2 + 5;

int n, k, ans;
int a[N][N], cnt[N];
bool cmp(int x, int y) {
	return x > y;
}

int main() {
	ios :: sync_with_stdio(false);
	freopen("xiaoming.in", "r", stdin);
	freopen("xiaoming.out", "w", stdout);
	cin >> n >> k;
	for (int i = 1; i <= n ; ++ i) {
		int x;
		cin >> x;
		a[x % k][++ cnt[x % k]] = x;
	}
	for (int i = 1; i <= n; ++ i) {
		sort(a[i] + 1, a[i] + 1 + n, cmp);
	}
	if (k % 2 == 0) {
		for (int i = 1; i <= cnt[k >> 1]; ++ i) {
			ans += a[k >> 1][i];
		}
		if (cnt[k >> 1] % 2 == 1) ans -= a[k >> 1][cnt[k >> 1]];
	}
	for (int i = 1; i << 1 < k; ++ i) {
		for (int j = 1; j <= min(a[i][cnt[i]], a[k - i][cnt[k - i]]); ++ j) {
			ans += a[i][j] + a[k - i][j];
		}
	}
	cout << ans << endl;
	return 0;
}
/*
5 7
1 2 3 4 5
*/
