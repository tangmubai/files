#include <cstdio>

const int N = 101, INF = 0x3d7f7f7f;

int sum[N][N];

template <typename Tp>
inline void read(Tp &num) {
    Tp neg = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') neg = -1;
        ch = getchar();
    }
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
    num *= neg;
}

int main() {
    freopen("matrix.in", "r", stdin);
    freopen("matrix.out", "w", stdout);
    int n, ans = -INF;
    read(n);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) {
            read(sum[i][j]);
            sum[i][j] += sum[i][j - 1];
        }
    for (int b = 1; b <= n; b++)
        for (int e = b; e <= n; e++) {
            int now = 0;
            for (int i = 1; i <= n; i++) {
                now += sum[i][e] - sum[i][b - 1];
                if (now > ans) ans = now;
                if (now < 0) now = 0;
            }
        }
    printf("%d\n", ans);
    return 0;
}
