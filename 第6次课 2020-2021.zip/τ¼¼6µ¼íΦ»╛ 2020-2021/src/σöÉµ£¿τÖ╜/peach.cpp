#include <cstdio>

const int N = 101;

int dp[N][N], mp[N][N];

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

int main() {
    freopen("peach.in", "r", stdin);
    freopen("peach.out", "w", stdout);
    int T;
    for (read(T); T; T--) {
        int n, m;
        read(n); read(m);
        for (int i = 1; i <= n; i++) 
            for (int j = 1; j <= m; j++)
                read(mp[i][j]);
        dp[1][1] = mp[1][1];
        for (int j = 2; j <= m; j++) dp[1][j] = dp[1][j - 1] + mp[1][j];
        for (int i = 2; i <= n; i++) dp[i][1] = dp[i - 1][1] + mp[i][1];
        for (int i = 2; i <= n; i++)
            for (int j = 2; j <= m; j++) {
                if (dp[i - 1][j] > dp[i][j - 1]) dp[i][j] = dp[i - 1][j];
                else dp[i][j] = dp[i][j - 1];
                dp[i][j] += mp[i][j];
            }
        printf("%d\n", dp[n][m]);
    }
    return 0;
}
