#include <cstdio>
#include <cstring>

const int N = 101;

int dp[N][N];

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

int main() {
    freopen("xiaoming.in", "r", stdin);
    freopen("xiaoming.out", "w", stdout);
    int n, k, ans = 0;
    read(n); read(k);
    memset(dp, -1, sizeof dp);
    dp[0][0] = 0;
    for (int i = 1; i <= n; i++) {
        int num;
        read(num);
        for (int j = 0; j < k; j++) dp[i][j] = dp[i - 1][j];
        for (int j = 0; j < k; j++) {
            if (dp[i - 1][j] < 0) continue;
            int tmp = dp[i - 1][j] + num;
            if (tmp > dp[i][(j + num) % k]) dp[i][(j + num) % k] = tmp;
        }
        if(dp[i][0] > ans) ans = dp[i][0];
    }
    printf("%d\n", ans);
    return 0;
}
