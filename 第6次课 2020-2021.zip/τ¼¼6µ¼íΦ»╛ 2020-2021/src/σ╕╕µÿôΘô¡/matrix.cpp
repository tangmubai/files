#include <cstdio>
#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
#define ll long long
using namespace std;

int read(){
	int a1=0,k1=1;char c1=getchar();
	while(!isdigit(c1)){
		if(c1=='-')k1=-1;c1=getchar();
	}
	while(isdigit(c1)){
		a1=a1*10+c1-'0';
		c1=getchar();
	}
	return a1*k1;
}
int a[105][105],f[105][105],sum,ans=-10000000;
int main(){
    freopen("matrix.in","r",stdin);
    freopen("matrix.out","w",stdout);
    int n=read();
    for(int i=1;i<=n;i++){
    	for(int j=1;j<=n;j++){
    		a[i][j]=read();
    	}
    }
    for(int i=1;i<=n;i++){
    	for(int j=1;j<=n;j++){
    		f[i][j]=f[i][j-1]+a[i][j];
    	}
    }
    for(int i=1;i<=n;i++){          
    	for(int j=i;j<=n;j++){
    		sum=0;
    		for(int k=1;k<=n;k++){
    			sum+=f[k][j]-f[k][i-1];  
    			ans=max(ans,sum);   
    			sum=max(sum,f[k][j]-f[k][i-1]);      
    		}
    	}
    }
    printf("%d",ans);
	return 0;
}
