#include <stdio.h>
#include <algorithm>
using namespace std;

int read(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=a1*10+ch-'0';
		ch=getchar();
	}
	return a1*k1;
}
int a[105][105];
main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	int t=read();
	while(t--){
		int r=read(),c=read();
		for(int i=1;i<=r;++i){
			for(int j=1;j<=c;++j){
				a[i][j]=read();
			}
		}
		for(int i=1;i<=r;++i){
			for(int j=1;j<=c;++j){
				a[i][j]+=max(a[i-1][j],a[i][j-1]);
			}
		}
		printf("%d\n",a[r][c]);
	}
	return 0;
}

