#prag\
ma GCC optimize("O1")
#include <stdio.h>
#include <cstring>
#define ll long long
using namespace std;

int read(){
	int a1=0,k1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-')k1=-1;c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		a1=a1*10+c1-'0';
		c1=getchar();
	}
	return a1*k1;
}
inline void out1(ll n) {
	if(n < 0)
		putchar ('-') , n = -n;
	if(n > 9)
		out1(n / 10);
	putchar(n % 10 + '0');
}
inline void out(ll n){
	out1(n);printf("\n");
}
inline int min(int x,int y,int z){
	int ok=x>y?y:x;
	int ko=y>z?z:y;
	return ok>ko?ko:ok;
}
char a[1005],b[1005];
int f[1001][1001];
int/*signed*/ main(){
	freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	int t=read();
	while(t--){
		scanf("%s %s",a+1,b+1);
		memset(f,0,sizeof f);
		int len1=strlen(a+1),len2=strlen(b+1);
		for(int i=1;i<=len1;++i)f[i][0]=i;   
		for(int j=1;j<=len2;++j)f[0][j]=j;  
		for(int i=1;i<=len1;++i){
			for(int j=1;j<=len2;++j){
				if(a[i]==b[j])f[i][j]=f[i-1][j-1];
				else{
					f[i][j]=min(f[i-1][j],f[i][j-1],f[i-1][j-1])+1;
				}
			}
		}
		out(f[len1][len2]);
	}
	return 0;
}
