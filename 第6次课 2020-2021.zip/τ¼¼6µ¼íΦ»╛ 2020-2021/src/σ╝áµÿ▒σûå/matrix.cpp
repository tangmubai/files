#include<cstdio>
#include<algorithm>
using namespace std;
int n,a[101][101],f[101][101],ans=-(1<<20);
int main(){
		freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
		f[i][j]=f[i-1][j]+f[i][j-1]-f[i-1][j-1]+a[i][j];
for(int a=1;a<=n;a++)
for(int b=1;b<=n;b++)
for(int c=1;c<=n;c++)
for(int d=1;d<=n;d++){
	int p=	f[c][d]-f[c][b-1]+f[a-1][b-1]-f[a-1][d];
ans=max(ans,p);
}
	printf("%d\n",ans);
	return 0;
}
