#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,a[101][101],t,f[101][101];
int main(){
			freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		memset(f,0,sizeof(f));
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)scanf("%d",&a[i][j]);
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			if(i==1&&j==1){
				f[i][j]=a[i][j];
				continue;
			}
			f[i][j]=max(f[i-1][j],f[i][j-1])+a[i][j];
		}
		int ans=-1;
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)ans=max(ans,f[i][j]);
		printf("%d\n",ans);
	}
	return 0;
}
