#include<cstdio>
#include<algorithm>
inline int ma_x(int x,int y){return x>y?x:y;}

int n,k,a[101],dp[101][101];
int main(){
//	freopen("xiaoming.in","r",stdin);
//	freopen("xiaoming.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		int p=a[i]%k;
		dp[i][p]=a[i];
		for(int j=1;j<i;j++)
		for(int mod=0;mod<k;mod++)
		    if(dp[j][mod]!=0)
		dp[i][(p+mod)%k]=ma_x(dp[i][(p+mod)%k],dp[i][p]+dp[j][mod]);
		
	}
	printf("%d\n",dp[n][0]);
	return 0;
}
