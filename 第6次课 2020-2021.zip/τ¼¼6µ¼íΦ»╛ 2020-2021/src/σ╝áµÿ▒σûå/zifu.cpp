#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
inline int mi_n(int x,int y){return x<y?x:y;}
using namespace std;
int n,m,f[1001][1001],t;
char s1[1005],s2[1005];
int main(){
		freopen("zifu.in","r",stdin);
	freopen("zifu.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		cin>>s1>>s2;
		memset(f,0,sizeof(f));
		n=strlen(s1);
		m=strlen(s2);
		for(int i=1;i<=n;i++)f[i][0]=i;
		for(int i=1;i<=m;i++)f[0][i]=i;
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			if(s1[i-1]==s2[j-1])f[i][j]=f[i-1][j-1];
			else f[i][j]=mi_n(mi_n(f[i-1][j],f[i][j-1]),f[i-1][j-1])+1;
		}
		printf("%d\n",f[n][m]);
	}
	return 0;
}
