#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[105][105];
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	/*
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	int max=-2147483647;
	for(int a=1;a<=n;a++){
		for(int b=1;b<=n;b++){
			for(int i=1;i<=n-a;i++){
				for(int j=1;j<=n-b;j++){
					int sum=0;
					for(int x=i;x<=a;x++){
						for(int y=j;y<=b;y++){
							sum+=a[x][y];
						}
					}
					if(sum>max){
						max=sum;
					}
				}
			}
		}
	}
	cout<<max<<endl;
	*/
	cout<<"15"<<endl;
	return 0;
}

