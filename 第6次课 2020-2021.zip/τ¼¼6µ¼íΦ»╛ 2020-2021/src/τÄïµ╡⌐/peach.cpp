#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[105][105],f[105][105];
int main(){
	freopen("peach.in","r",stdin);
	freopen("peach.out","w",stdout);
	int t;
	cin>>t;
	while(t--){
		int R,C;;
		cin>>R>>C;
		for(int i=1;i<=R;i++){
			for(int j=1;j<=C;j++){
				cin>>a[i][j];
			}
		}
		for(int i=1;i<=R;i++){
			for(int j=1;j<=C;j++){
				a[i][j]+=max(a[i-1][j],a[i][j-1]);
			
			}
		}
		cout<<a[R][C]<<endl;
	}
	return 0;
}

