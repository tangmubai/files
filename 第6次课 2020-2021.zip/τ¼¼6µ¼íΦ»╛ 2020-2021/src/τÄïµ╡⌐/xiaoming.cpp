#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[105][105];
int main(){
	freopen("xiaoming.in","r",stdin);
	freopen("xiaoming.out","w",stdout);
	int n,k,t;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>t;
		a[i][t%k]=t;
		for(int j=0;j<k;j++){
			if(a[i-1][j])
				a[i][(j+t)%k]=a[i-1][j]+t;
		}
		for(int j=0;j<k;j++){
			a[i][j]=max(a[i][j],a[i-1][j]);			
		}
	}
	cout<<a[n][0]<<endl;	
	return 0;
}
