#include <stdio.h>

#define mx(x, y) x > y ? x : y

const int N = 110;

int n;
int sum[N][N], f[N][N];

int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	
	scanf("%d", &n);
	for (int i = 1; i <= n; i ++ )
		for (int j = 1; j <= n; j ++ )
		{
			int x;
			scanf("%d", &x);
			sum[i][j] = sum[i][j - 1] + x;
		}
	
	int ans = -10000000;
	for (int j = 1; j <= n; j ++ )
	{
		for (int i = 1; i <= n; i ++ )
		{
			f[i][j] = -10000;
			f[i][j] = mx(f[i - 1][j] + sum[i][j], sum[i][j]);
//			for (int k = 1; k <= n; k ++ )	f
			ans = mx(ans, f[i][j]);
		}
	}
	
	printf("%d\n", ans);
	return 0;
}
