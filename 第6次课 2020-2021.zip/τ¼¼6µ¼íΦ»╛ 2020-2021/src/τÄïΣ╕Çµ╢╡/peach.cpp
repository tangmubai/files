#include <stdio.h>

#define mx(x, y) x > y ? x : y

const int N = 110;

int f[N][N];

int main()
{
	freopen("peach.in", "r", stdin);
	freopen("peach.out", "w", stdout);
	
	int t;
	scanf("%d", &t);
	while (t -- )
	{
		int r, c;
		scanf("%d%d", &r, &c);
		for (int i = 1; i <= r; i ++ )
			for (int j = 1; j <= c; j ++ )
				scanf("%d", &f[i][j]);
		for (int i = 1; i <= r; i ++ )
			for (int j = 1; j <= c; j ++ )
				f[i][j] += mx(f[i - 1][j], f[i][j - 1]);
		
		printf("%d\n", f[r][c]);
	}
	
	return 0;
}
