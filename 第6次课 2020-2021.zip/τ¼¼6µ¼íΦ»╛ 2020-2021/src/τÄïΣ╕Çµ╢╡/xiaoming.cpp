#include <stdio.h>

const int N = 110;

int n, k, res;
int t[N], a[N];

int main()
{
	freopen("xiaoming.in", "r", stdin);
	freopen("xiaoming.out", "w", stdout);
	
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; i ++ )
	{
		scanf("%d", &a[i]);
		t[a[i] % k] ++ ;
		res += a[i];
	}
	
	int m = res / k;
	int tt = m;
	int s = res - k * m;
	
	while (tt -- )
	{
		bool f = false;
		for (int i = 0; i <= 6; i ++ )
		{
			for (int k = 0; k <= 6; k ++ )
				for (int j = 0; j <= t[i]; j ++ )
					for (int b = 0; b <= t[k]; b ++ )
					{
						if (t[i] * j + t[k] * b % 7 == s)
							f = true;
					}
		}
		
		if (f)
		{
			printf("%d\n", m * k);
			return 0;
		}
		
		s += k;
		m -- ;
	}
	
	printf("0");
	
	return 0;
}
