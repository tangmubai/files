#include <stdio.h>
#include <string.h>
#include <algorithm>

using namespace std;

//#define mn(x, y) x < y ? x : y

const int N = 1010;

char a[N], b[N];
int f[N][N];

int main()
{
	freopen("zifu.in", "r", stdin);
	freopen("zifu.out", "w", stdout);
	
	int t;
	scanf("%d", &t);
	while (t -- )
	{
		memset(f,0,sizeof(f));
		scanf("%s", 1+a);
		scanf("%s", 1+b);
		int l1 = strlen(1+a), l2 = strlen(1+b);
		for (int i = 1; i <= l1; i ++ )	f[i][0] = i;
		for (int i = 1; i <= l2; i ++ )	f[0][i] = i;
		for (int i = 1; i <= l1; i ++ )
		{
			for (int j = 1; j <= l2; j ++ )
			{
//				f[i][j] = 100000;
//				if (a[i] == b[j])
//					f[i][j] = f[i - 1][j - 1];
//				f[i][j] = mn(f[i - 1][j - 1] + 1, mn(f[i][j], mn(f[i - 1][j], f[i][j - 1])));
				f[i][j]=min(f[i-1][j-1]+(a[i]!=b[j]),min(f[i-1][j],f[i][j-1])+1);
			}
		}
		printf("%d\n", f[l1][l2]);
	}
	
	return 0;
}
