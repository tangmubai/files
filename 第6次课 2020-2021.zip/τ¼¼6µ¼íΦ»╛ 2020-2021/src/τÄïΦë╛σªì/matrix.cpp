#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int a[105][105],f[105][105],n,ans=0,maxx;
int main(){
	//freopen("matrix.in","r",stdin);
	//freopen("matrix.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++){
	    	scanf("%d",&a[i][j]);
	    	f[i][j]=1;
	    }
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			int sum=0;
			for(int t=1;t<=n;t++){
				sum+=f[t][j]-f[t][i-1];
				ans=max(ans,sum);
				sum=max(sum,0);
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
