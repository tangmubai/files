#include "cstdio"
#include "algorithm"
using namespace std;
int n,a[1005][1005],s[1005][1005];
int main(){
	freopen ("matrix.in","r",stdin);
	freopen ("matrix.out","w",stdout);
	scanf ("%d",&n);
	int m=10000000;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++){
			scanf ("%d",&a[i][j]);
			m=min(m,a[i][j]);
		}
	int ans=m;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
	for (int i=1;i<=n;i++){
		for (int j=1;j<=n;j++){
			for (register int x=i;x<=n;x++){
				for (register int y=j;y<=n;y++){
					ans=max(ans,s[x][y]-s[i-1][y]-s[x][j-1]+s[i-1][j-1]);
				}
			}
		}
	}
	printf ("%d\n",ans);
	return 0;
}
