#include<iostream>
#include<stdio.h>
using namespace std;
int sum[105][105],a[105][105]; 
int qread(){
	int a=0,f=1;char c=getchar();
	for(;c<'0'||c>'9';c=getchar()){
		if(c=='-') f=-1;
	}
	for(;c>='0'&&c<='9';a=(a<<1)+(a<<3)+(c^'0'),c=getchar());
	return a*f;
}
int main(){
	freopen("matrix.in","r",stdin);freopen("matrix.out","w",stdout);
	int n=qread(),maxn=-127;
	for(int i=0;i<n;++i){
		for(int j=0;j<n;++j) sum[i][j]=sum[i-1][j]+(a[i][j]=qread());
	}
	for(int i=0,now;i<n;++i){
		for(int j=0;j<n;++j){
			now=0;
			for(int k=0;k<n;++k){
				now=max(now,0);
				now+=sum[j][k]-sum[i][k];
				maxn=max(maxn,now);
			}
		}
	}
	printf("%d\n",maxn);
	return 0;
}
