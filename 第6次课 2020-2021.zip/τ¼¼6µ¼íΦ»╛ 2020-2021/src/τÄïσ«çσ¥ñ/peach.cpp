#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
int n,m;
int jl[105][105],a[105][105];
int qread(){
	int a=0;char c=getchar();
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';a=(a<<1)+(a<<3)+(c^'0'),c=getchar());
	return a;
}
int qs(int i,int j){
	if(i>n||j>m) return -100000;
	if(i==n&&j==m) return a[i][j];
	if(jl[i][j]!=-1) return jl[i][j];
	return jl[i][j]=max(qs(i+1,j),qs(i,j+1))+a[i][j];
}
int main(){
	freopen("peach.in","r",stdin);freopen("peach.out","w",stdout); 
	int t=qread();
	while(t--){
		n=qread();
		m=qread();
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j) a[i][j]=qread();
		}
		memset(jl,-1,sizeof(jl));
		printf("%d\n",qs(1,1));
	}
	return 0;
}
