#include<iostream>
#include<stdio.h>
using namespace std;
int f[105][105];
int qread(){
	int a=0;char c=getchar();
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';a=(a<<1)+(a<<3)+(c^'0'),c=getchar());
	return a;
}
int main(){
	freopen("xiaoming.in","r",stdin);freopen("xiaoming.out","w",stdout);
	int n=qread(),k=qread();
	for(int i=1,t;i<=n;++i){
		t=qread();
		f[i][t%k]=t;
		for(int j=0;j<k;++j){
			if(f[i-1][j]) f[i][(j+t)%k]=f[i-1][j]+t;
		}
		for(int j=0;j<k;++j) f[i][j]=max(f[i][j],f[i-1][j]);
	}
	printf("%d\n",f[n][0]);
	return 0;
}
