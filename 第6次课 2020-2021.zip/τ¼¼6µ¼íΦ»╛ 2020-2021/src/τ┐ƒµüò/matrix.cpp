//Σ��Σ��Σ����Σ������Σ���������� ����
#include <cstdio>
using namespace std;
int n,i,j,i1,j1,a[101][101],s[101][101],s1,ans;
int main () {
	freopen ("matrix.in","r",stdin);
	freopen ("matrix.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) for (j=1;j<=n;j++) {
		scanf ("%d",&a[i][j]);
		s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
	}
	for (i=1;i<=n;i++) for (j=1;j<=n;j++) {
		for (i1=0;i1<i;i1++) for (j1=0;j1<j;j1++) {
			s1=s[i][j]-s[i1][j]-s[i][j1]+s[i1][j1];
			if (s1>ans) ans=s1;
		}
	}
	printf ("%d",ans);
	return 0;
}
