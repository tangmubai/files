#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;

int sum=0;

int main()
{
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
    int k;
    cin>>k;
    for(int i=2;i<=k;i++)
    {
	   long long t=1;
	   int kk=k;	
       for(int j=1;j<=i;j++)
        {
      	  t=t*kk; 
      	  kk--;
        }
       for(int j=1;j<=i;j++)
      	 {
      	 	t=t/j;
      	 }
     sum+=2*t;  
    }
    cout<<sum<<endl;
    return 0;
}
