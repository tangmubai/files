#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;

long long f[62][62]={0};
long long sum=0;
int main()
{
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
    int k;
    cin>>k;
    for(int i=2;i<=k;i++)
    	f[i][2]=i*(i-1);//�����߽� 
    for(int i=3;i<=k;i++)
     for(int j=3;j<=i;j++)
       	f[i][j]=f[i-1][j]+f[i-1][j-1];//ת�Ʒ��� 
    for(int i=2;i<=k;i++)
     sum+=f[k][i];
    cout<<sum<<endl;
    return 0;
}
