#include<iostream>
#include<algorithm>
#include <math.h>
using namespace std;

int d[100005],a[100005];
int n;
int ans=-10005;

int main()
{
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
    cin>>n;
    cin>>a[0];
    d[0]=a[0];
    for(int i=1;i<n;i++)
    {
    	cin>>a[i];
    	d[i]=max(d[i-1]+a[i],a[i]);// d[i-1]+a[i]����ԭ�������У�a[i]���¿�һ�����С� 
    }
    for(int i=0;i<n;i++)
    {
    	ans=max(ans,d[i]);
    }
    cout<<ans;
  
    return 0;
}
