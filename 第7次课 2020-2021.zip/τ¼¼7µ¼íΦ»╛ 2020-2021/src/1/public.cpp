#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;

int f[1001][1001];
char a[1001],b[1001];
int main()
{
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
    cin>>a>>b;
    int m,n;
    m=strlen(a);
    n=strlen(b);
    for(int i=0;i<=m;i++) f[i][0]=0; //��2����Ϊ0ʱ 
    for(int j=0;j<=n;j++) f[0][j]=0; //��1����Ϊ0ʱ 
	 
    for(int i=1;i<=m;i++)
     for(int j=1;j<=n;j++)
     {
        if(a[i-1]==b[j-1]) f[i][j]=f[i-1][j-1]+1;
        else f[i][j]=max(f[i][j-1],f[i-1][j]);
     }
     
     cout<<f[m][n]<<endl;
    return 0;
}
