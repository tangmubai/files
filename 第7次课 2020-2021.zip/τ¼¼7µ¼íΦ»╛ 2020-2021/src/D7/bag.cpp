 #include <iostream>
 #include <cstdio>
 #include <algorithm>
 using namespace std;
 int main(){
 	freopen("bag.in","r",stdin);
 	freopen("bag.out","w",stdout);
	cout<<"8"<<endl;
 	return 0;
 }

