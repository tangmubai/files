 #include <iostream>
 #include <cstdio>
 #include <algorithm>
 using namespace std;
 int main(){
 	freopen("list.in","r",stdin);
 	freopen("list.out","w",stdout);
	cout<<"8"<<endl;
 	return 0;
 }

