 #include <iostream>
 #include <cstdio>
 #include <algorithm>
 #include <cmath>
 using namespace std;
 int a[10005];
 int main(){
 	freopen("mlong.in","r",stdin);
 	freopen("mlong.out","w",stdout);
 	int n;
 	cin>>n;
 	int ans=-2147483637;
 	for(int i=1;i<=n;i++){
 		cin>>a[i];
		a[i]+=a[i-1];
		ans=max(ans,a[i]);
		a[i]=max(a[i],0);
 	}
 	cout<<ans<<endl;
 	return 0;
 }
