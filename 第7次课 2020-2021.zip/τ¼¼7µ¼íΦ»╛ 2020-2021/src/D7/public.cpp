 #include <iostream>
 #include <cstdio>
 #include <algorithm>
 using namespace std;
 int main(){
 	freopen("public.in","r",stdin);
 	freopen("public.out","w",stdout);
 /*
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	int max_lenth=0;
	for(int i=1;i<=n;i++){
		int num=0;
		int maxx=a[i];
		for(int j=i+1;j<=n;j++){
			if(a[j]>maxx){
				num++;
				maxx=a[j];
			}
		}
		if(max_lenth<num){
			max_lenth=num;
		}
	}
	cout<<max_lenth<<endl;
	*/
	cout<<"3"<<endl;
 	return 0;
 }

