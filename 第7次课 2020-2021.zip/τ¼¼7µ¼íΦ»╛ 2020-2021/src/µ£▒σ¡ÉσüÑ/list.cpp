#include <cstdio>
int main(){
	freopen("list.in","r",stdin);freopen("list.out","w",stdout);
	long long k;scanf("%lld",&k);
	printf("%lld\n",((1ll<<k)-k-1)<<1ll);
	return 0;
}
