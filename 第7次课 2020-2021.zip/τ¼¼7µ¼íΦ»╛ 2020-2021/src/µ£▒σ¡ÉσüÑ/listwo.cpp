#include <cstdio>
long long f[63];
int main(){
	freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	int k;scanf("%d",&k);
	f[2]=2,f[3]=8;
	for(int i=4;i<=k;i++) f[i]=(f[i-1]<<1ll)+(i-1<<1ll);
	printf("%lld\n",f[k]);
	return 0;
}
