#include <cstdio>
#include <algorithm>
int n,a,len,f[1003];
int main(){
	freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout);
	scanf("%d%d",&n,&a);
	f[len=1]=a;
	while(--n){
		scanf("%d",&a);
		if(a>f[len]) f[++len]=a;
		else *std::lower_bound(f+1,f+1+len,a)=a;
	}
	printf("%d\n",len);
	return 0;
}
