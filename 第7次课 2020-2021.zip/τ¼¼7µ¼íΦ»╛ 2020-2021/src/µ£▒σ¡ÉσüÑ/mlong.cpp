#include <cstdio>
int n,s,ans=-(1<<30);
int main(){
	freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		int a;scanf("%d",&a);
		if(s<0) s=0;
		s+=a;
		if(ans<s) ans=s;
	}
	printf("%d\n",ans);
	return 0;
}
