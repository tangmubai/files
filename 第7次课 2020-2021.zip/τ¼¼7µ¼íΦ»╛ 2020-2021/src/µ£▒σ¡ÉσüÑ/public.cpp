#include <cstdio>
#include <cstring>
#define max(a,b) ((a)>(b)?(a):(b))
char a[1003],b[1003];
int f[1003][1003],lena,lenb; 
int main(){
	freopen("public.in","r",stdin);freopen("public.out","w",stdout);
	scanf("%s%s",a+1,b+1);
	lena=strlen(a+1),lenb=strlen(b+1);
	for(int i=1;i<=lena;i++){
		for(int j=1;j<=lenb;j++){
			if(a[i]==b[j]) f[i][j]=f[i-1][j-1]+1;
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	printf("%d\n",f[lena][lenb]);
	return 0;
}
