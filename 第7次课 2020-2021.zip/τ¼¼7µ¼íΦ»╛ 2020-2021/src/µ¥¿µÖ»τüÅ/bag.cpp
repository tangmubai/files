#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline void in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
		{
			x = EOF;
			return;
		}
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int c[210], w[210], f[5010];

int main()
{
	freopen("bag.in", "r", stdin);
	freopen("bag.out", "w", stdout);
	
	
	int n, m;
	in(n), in(m);
	
	for(int i=1; i<=n; i++)
		in(c[i]), in(w[i]);
		
	
	for(int i=1; i<=n; i++)
		for(int j=m; j>=c[i]; j--)
			f[j] = max(f[j - c[i]] + w[i], f[j]);
	
	
	out(f[m]);
}

