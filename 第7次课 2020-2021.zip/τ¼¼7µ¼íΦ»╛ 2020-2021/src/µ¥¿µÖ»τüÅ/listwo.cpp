#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline void in(long long &x)
{
	long long num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
		{
			x = EOF;
			return;
		}
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
}

inline void out(long long n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int main()
{
	freopen("listwo.in", "r", stdin);
	freopen("listwo.out", "w", stdout);
	
	
	long long n, ans = 0, num = 0;
	in(n);
	
	
	for(long long i=1; i<=n; i++)
		ans = ans * 2 + num, num += 2;
	
	
	out(ans);
}

