#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline void in(int &x)
{
	int num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
		{
			x = EOF;
			return;
		}
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
}

inline void out(int n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


int main()
{
	freopen("longrise.in", "r", stdin);
	freopen("longrise.out", "w", stdout);
	
	
	int n;
	in(n);
	
	vector<int> f;
	
	
	for(int i=1; i<=n; i++)
	{
		int num;
		in(num);
		
		
		if(f.empty() || *(f.end() - 1) < num)
			f.push_back(num);
		
		else
			*lower_bound(f.begin(), f.end(), num) = num;
	}
	
	
	out(f.size());
}

