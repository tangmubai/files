#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;

#define enter putchar('\n')
#define space putchar(' ')

inline void in(long long &x)
{
	long long num = 0, sign = 0;
	char ch = ' ';
	while (!isdigit(ch))
	{
		ch = getchar(), sign |= (ch == '-');
		if(ch == EOF)
		{
			x = EOF;
			return;
		}
	}
	while (isdigit(ch))
		num = num * 10 + (ch - '0'), ch = getchar();
	x = sign ? -num : num;
}

inline void out(long long n)
{
	if (n < 0)
		putchar('-'), n = -n;
	if (n > 9)
		out(n / 10);
	putchar(n % 10 + '0');
}


long long a[100010], f[100010];

int main()
{
	freopen("mlong.in", "r", stdin);
	freopen("mlong.out", "w", stdout);
	
	
	long long n;
	in(n);
	
	
	long long ans = 0xbfbfbfbfbfbfbfbf;
	
	for(long long i=1; i<=n; i++)
	{
		in(a[i]);
		
		
		f[i] = max(f[i-1], 0ll) + a[i];
		
		ans = max(f[i], ans);
	}
	
	
	out(ans);
}

