#include<iostream>
using namespace std;
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n,m;
	cin>>n>>m;
	int w[205],c[205];
	for(int i=1;i<=n;i++)cin>>w[i]>>c[i];
	int f[5005]={0};
	for(int i=1;i<=n;i++)for(int j=m;j>=w[i];j--)f[j]=max(f[j],f[j-w[i]]+c[i]);
	cout<<f[m]<<endl;
	return 0;
}
