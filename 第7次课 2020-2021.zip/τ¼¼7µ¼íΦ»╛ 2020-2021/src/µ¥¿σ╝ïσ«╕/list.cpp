#include<iostream>
using namespace std;
bool visit[25];
int k;
int a[25];
int ans=0;
int num[21]={0,0,2,8,22,52,114,240,494,1004,2026,4072,8166,16356,32738,65504,131038,262108,524250,1048536,2097110};
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>k;
	cout<<num[k]<<endl;
	return 0;
}
