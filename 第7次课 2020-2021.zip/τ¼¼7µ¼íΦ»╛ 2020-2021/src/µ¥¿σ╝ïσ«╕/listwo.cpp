#include<iostream>
#include<cmath>
using namespace std;
long long k;
long long ans;
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>k;
	if(k<=1){
		cout<<0<<endl;
		return 0;
	}
	ans=pow(2,k+1)-2*(k+1);
	cout<<ans<<endl;
	return 0;
}
