#include<iostream>
#include<cstring>
using namespace std;
char a[1005],b[1005];
int f[1005][1005];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>a>>b;
	int len1=strlen(a),len2=strlen(b);
	for(int i=0;i<=len1;i++)f[i][0]=0;
	for(int i=0;i<=len2;i++)f[0][i]=0;
	for(int i=0;i<len1;i++){
		for(int j=0;j<len2;j++){
			if(a[i]==b[j])f[i][j]=f[i-1][j-1]+1;
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	cout<<f[len1-1][len2-1]<<endl;
	return 0;
}
