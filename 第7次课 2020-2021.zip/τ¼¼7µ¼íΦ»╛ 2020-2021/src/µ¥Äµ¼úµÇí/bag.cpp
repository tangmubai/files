#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
ll w[205],c[205],f[5005][5005];
ll Max(ll p,ll q){
	return p>q?p:q;
}
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	ll n,m;
	scanf("%lld%lld",&n,&m);
	for(ll i=1;i<=n;i++)scanf("%lld%lld",&w[i],&c[i]);
	for(ll i=1;i<=n;i++){
		for(ll j=m;j>=1;j--){
			if(w[i]>j)f[i][j]=f[i-1][j];
			else f[i][j]=Max(f[i-1][j],f[i-1][j-w[i]]+c[i]);
		}
	}
	printf("%lld\n",f[n][m]);
	return 0;
}



