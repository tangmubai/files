#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#include<cmath>
#define ll long long
using namespace std;
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	ll n;
	scanf("%lld",&n);
	if(n==1)cout<<0<<endl;
	else printf("%lld",2*((long long)(pow(2,n))-1-n));
	return 0;
}



