#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<set>
#include<cstring>
#define ll long long
using namespace std;
ll f[1005],a[1005];
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	ll n,ans=0;
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(ll i=1;i<=n;i++){
		if(a[i]>f[ans]){
			f[++ans]=a[i];
		}
		else{
			ll j=upper_bound(f+1,f+1+ans,a[i])-f;
			f[j]=a[i];
		}
	}
	printf("%lld\n",ans);
	return 0;
}



