#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#define ll long long
using namespace std;
ll f[100005],a[100005];
ll Max(ll p,ll q){
	return p>q?p:q;
}
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	ll n,ans=0;
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++)scanf("%lld",&a[i]);
	f[1]=a[1];
	for(ll i=2;i<=n;i++)f[i]=Max(f[i-1]+a[i],a[i]);
	for(ll i=1;i<=n;i++)ans=Max(ans,f[i]);
	printf("%lld\n",ans);
	return 0;
}



