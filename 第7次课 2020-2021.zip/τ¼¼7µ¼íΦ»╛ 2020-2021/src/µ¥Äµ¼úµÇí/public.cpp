#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<set>
#include<cstring>
#define ll long long
using namespace std;
ll f[1005][1005];char a[1005],b[1005];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	ll n,m,ans=0;
	scanf("%lld%lld",&n,&m);
	scanf("%s%s",a+1,b+1);
	n=strlen(a+1);
	m=strlen(b+1);
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=m;j++){
			if(a[i]==b[j])f[i][j]=f[i-1][j-1]+1;
			if(a[i]!=b[j])f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	printf("%lld\n",f[n][m]);
	return 0;
}



