#include<stdio.h>
int a[30]={0,0,2,8,22,52,114,240,494,1004,2026,4072,8166,16356,32768,65504,131038};
int ans,k;
//void dfs(int i_2,int i_1,int step){
////	for(int i=1;i<=step;i++){
////		printf("\t");
////	}
////	printf("%d\n",i_1);
//	if(i_2<i_1){
//		for(int i=1;i<i_2;i++){
//			dfs(i_1,i,step+1);
//		}
//	}else{
//		for(int i=i_2+1;i<=k;i++){
//			dfs(i_1,i,step+1);
//		}
//	}
//	ans++;
//}
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	int k;
	scanf("%d",&k);
//	for(int i=1;i<=k;i++){
//		for(int j=1;j<=k;j++){
//			if(i-j){
////				printf("%d\n",i);
//				dfs(i,j,1);
//			}
//		}
//	}
	printf("%d\n",a[k]);
	return 0;
}
