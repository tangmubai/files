#include<stdio.h>
int a[1050],dp[1050];
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		dp[i]=1;
	}
	for(int i=n-1;i>=1;i--){
		for(int j=i+1;j<=n;j++){
			if(a[j]>a[i]&&dp[j]+1>dp[i]){
				dp[i]=dp[j]+1;
			}
		}
	}
	printf("%d\n",dp[1]);
	return 0;
}
