#include<stdio.h>
#define max(a,b)((a)>(b)?(a):(b))
int a[100050];
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	int n;
	scanf("%d",&n);
	bool flag=1;
	int maxn=-1e9;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(a[i]>=0){
			flag=0;
		}
		maxn=max(maxn,a[i]);
	}
	if(flag){
		printf("%d\n",maxn);
		return 0;
	}
	int ans=0,tmp=0;
	for(int i=1;i<=n;i++){
		tmp+=a[i];
		if(tmp<0){
			tmp=0;
		}
		ans=max(ans,tmp);
	}
	printf("%d\n",ans);
}
