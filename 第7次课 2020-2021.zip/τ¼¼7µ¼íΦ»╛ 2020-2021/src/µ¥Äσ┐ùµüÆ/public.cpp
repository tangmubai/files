#include<stdio.h>
#define max(a,b)((a)>(b)?(a):(b))
char a[1050],b[1050];
int dp[1050][1050];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s %s",a+1,b+1);
	int n=0;
	while(a[++n]);
	n--;
	int m=0;
	while(b[++m]);
	m--;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i]==b[j]){
				dp[i][j]=dp[i-1][j-1]+1;
			}else{
				dp[i][j]=max(dp[i][j-1],dp[i-1][j]);
			}
		}
	}
	printf("%d\n",dp[n][m]);
	return 0;
}
