#include <cstdio>
using namespace std;
int f[5010],n,i,w[210],v[210],m,j;
int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return f*k;
}
int max (int a,int b) {
	return a > b ? a : b;
}
int main () {
	freopen ("bag.in","r",stdin);
	freopen ("bag.out","w",stdout);
	n=read ();
	m=read ();
	for (i=1;i<=n;i++) {
		w[i]=read ();
		v[i]=read ();
	}
	for (i=1;i<=n;i++) 
		for (j=m;j>=w[i];j--) 
			f[j]=max (f[j],f[j-w[i]]+v[i]);
	printf ("%d\n",f[m]);
	return 0;
}
