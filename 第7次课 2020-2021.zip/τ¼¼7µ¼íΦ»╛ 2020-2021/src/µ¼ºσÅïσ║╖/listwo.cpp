#include <cstdio>
using namespace std;
long long k,f[1010],ans,i,t,a[1010];
long long read () {
	long long k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return f*k;
}
int max (int a,int b) {
	return a > b ? a : b;
}
void dfs (int step) {
	if (step>3&&a[step-2]>a[step-3]&&a[step-1]>a[step-3]) return;
	if (step>3&&a[step-2]<a[step-3]&&a[step-1]<a[step-3]) return;
	for (int i=step;i<=k;i++) {
		if (a[step]==0) {
			a[step]=i;
			dfs (step+1);
			a[step]=0;
			ans++;
		}
	} 
	return;
}
int main () {
	freopen ("listwo.in","r",stdin);
	freopen ("listwo.out","w",stdout);
	k=read ();
//	if (k==3) {
//		puts ("8");
//		return 0;
//	}
	for (i=t=2;i<=k;i++,t+=2) 
		f[i]=f[i-1]*2+t;
	printf ("%lld\n",f[k]);
	return 0;
}
