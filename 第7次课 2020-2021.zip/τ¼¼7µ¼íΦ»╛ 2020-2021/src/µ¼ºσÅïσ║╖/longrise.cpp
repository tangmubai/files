#include <cstdio>
#include <algorithm>
using namespace std;
int len,f[1010],i,x,n;
int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return f*k;
}
int main () {
	freopen ("longrise.in","r",stdin);
	freopen ("longrise.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) {
		scanf ("%d",&x);
		if (f[len]<x) 
			f[++len]=x;
		else 
			f[(lower_bound (f+1,f+1+len,x)-f)]=x;
	}
	printf ("%d\n",len);
	return 0;
}
