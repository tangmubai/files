#include <cstdio>
using namespace std;
int f[100010],n,i,a[100010],ans=-0x7fffffff;
int read () {
	int k=0,f=1;
	char c=getchar ();
	while (c<'0'||c>'9') {if (c=='-') f=-1;c=getchar ();}
	while (c>='0'&&c<='9') {k=k*10+c-'0';c=getchar ();}
	return f*k;
}
int max (int a,int b) {
	return a > b ? a : b;
}
int main () {
	freopen ("mlong.in","r",stdin);
	freopen ("mlong.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) 
		scanf ("%d",&a[i]);
	for (i=1;i<=n;i++) 
		f[i]=max (f[i-1]+a[i],f[i]);
	for (i=1;i<=n;i++) 
		ans=max (ans,f[i]);
	printf ("%d\n",ans);
	return 0;
}
