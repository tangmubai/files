#include <cstdio>
#include <cstring>
using namespace std;
char a[1010],b[1010];
int i,j,lena,lenb,f[1010][1010];
int max (int a,int b) {
	return a > b ? a : b;
}
int main () {
	freopen ("public.in","r",stdin);
	freopen ("public.out","w",stdout);
	scanf ("%s\n%s",a+1,b+1);
	lena=strlen (a+1);
	lenb=strlen (b+1);
	for (i=1;i<=lena;i++) 
		for (j=1;j<=lenb;j++) 
			if (a[i]==b[j]) 
				f[i][j]=f[i-1][j-1]+1;
			else 
				f[i][j]=max (f[i-1][j],f[i][j-1]);
	printf ("%d\n",f[lena][lenb]);
	return 0;
}
