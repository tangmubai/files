#include<stdio.h>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int w[205],v[205];
int dp[205][5005]={0};
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&w[i],&v[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=m;j>=0;j--){
			if(j>=w[i])dp[i][j]=max(dp[i-1][j],dp[i-1][j-w[i]]+v[i]);
			else dp[i][j]=dp[i-1][j];
		}
	}
	printf("%d",dp[n][m]);
	return 0;
}

