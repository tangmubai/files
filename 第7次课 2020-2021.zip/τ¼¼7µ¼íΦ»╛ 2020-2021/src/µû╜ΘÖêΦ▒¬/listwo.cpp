#include<stdio.h>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n;
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	scanf("%d",&n);
	long long ans=0;
	long long t=0;
	for(int i=1;i<=n;i++){
		ans=ans*2+t;
		t+=2;
	}
	printf("%lld",ans);
	return 0;
}

