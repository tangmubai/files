#include<stdio.h>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int a[1005];
int f[1005];
int len;
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	len=1;
	f[1]=a[1];
	for(int i=2;i<=n;i++){
		if(a[i]>f[len])f[++len]=a[i];
		else f[lower_bound(f+1,f+1+len,a[i])-f]=a[i];
	}
	printf("%d",len);
	return 0;
}

