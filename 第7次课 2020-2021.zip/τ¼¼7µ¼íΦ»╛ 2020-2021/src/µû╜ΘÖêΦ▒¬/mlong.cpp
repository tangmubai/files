#include<stdio.h>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int a[100005];
int f[100005][2]={0};
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	f[0][0]=(-1000000);
	f[0][1]=(-1000000);
	for(int i=1;i<=n;i++){
		f[i][1]=max(f[i-1][1],0)+a[i];
		f[i][0]=max(f[i-1][0],f[i-1][1]);
	}
	printf("%d\n",max(f[n][0],f[n][1]));
	return 0;
}

