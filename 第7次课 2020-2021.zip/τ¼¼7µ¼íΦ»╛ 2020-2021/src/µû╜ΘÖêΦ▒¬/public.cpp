#include<stdio.h>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
char s1[1005],s2[1005];
int dp[1005][1005]={0};
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s%s",s1+1,s2+1);
	int l1=strlen(s1+1);
	int l2=strlen(s2+1);
	for(int i=1;i<=l1;i++){
		for(int j=1;j<=l2;j++){
			if(s1[i]==s2[j])dp[i][j]=dp[i-1][j-1]+1;
			else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
		}
	}
	printf("%d",dp[l1][l2]);
	return 0;
}
