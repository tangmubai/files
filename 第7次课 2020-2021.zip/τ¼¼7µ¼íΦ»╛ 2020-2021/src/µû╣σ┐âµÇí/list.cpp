#include <cstdio>
bool v[70];int k,a[70];long long ans;
void dfs(int i,int last,bool flag){
	ans++;//for(int j=1;j<i;j++)printf("%d ",a[j]);printf("\n");
	if(i>k)return;
	if(flag==0)
		for(int j=last;j<=k;j++){
			if(v[j])continue;
			v[j]=1;a[i]=j;
			dfs(i+1,a[i-1],1);
			v[j]=0;
		}
	else
		for(int j=1;j<last;j++){
			if(v[j])continue;
			v[j]=1;a[i]=j;
			dfs(i+1,a[i-1],0);
			v[j]=0;
		}
	return;
}
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	scanf("%d",&k);
	if(k<2){
		puts("0");
		return 0;
	}
	if(k==2){
		puts("2");
		return 0;
	}
	for(int i=1;i<=k;i++){
		v[i]=1;a[1]=i;
		for(int j=1;j<i;j++){
			v[j]=1;a[2]=j;
			dfs(3,a[1],0);
			v[j]=0;
		}
		for(int j=i+1;j<=k;j++){
			v[j]=1;a[2]=j;
			dfs(3,a[1],1);
			v[j]=0;
		}
		v[i]=0;
	}
	printf("%lld\n",ans);
	return 0;
}
