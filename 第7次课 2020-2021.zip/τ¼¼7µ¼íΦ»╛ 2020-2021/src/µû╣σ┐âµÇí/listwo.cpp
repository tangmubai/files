#include <cstdio>
int k;long long f[70];
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	scanf("%d",&k);
	if(k<2){
		puts("0");
		return 0;
	}
	long long tmp=2;
	for(int i=2;i<=k;i++){
		f[i]=f[i-1]*2+tmp;tmp+=2;
	}
	printf("%lld\n",f[k]);
	return 0;
}
