#include <cstdio>
long long f[100010];
void in(int &x){
	char c=getchar();
	int tmp=1;
	while(c<'0'||c>'9'){
		if(c=='-')tmp=-1;
		c=getchar();
	}
	x=0;
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	x*=tmp;
	return;
}
long long mx(long long a,long long b){
	return a>b?a:b;
}
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	int n,x;long long ans=-99999999;scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);//in(x);
		f[i]=mx(f[i-1]+x,x);
		if(f[i]>ans)ans=f[i];
	}
	printf("%lld\n",ans);
	return 0;
}
