#include <cstdio>
#include <algorithm>
using namespace std;

int n,m,w,c;
int f[5005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i){
		w=read(),c=read();
		for(int j=m;j>=w;--j){
			f[j]=max(f[j],f[j-w]+c);
		}
	}
	printf("%d",f[m]);
	return 0;
}
