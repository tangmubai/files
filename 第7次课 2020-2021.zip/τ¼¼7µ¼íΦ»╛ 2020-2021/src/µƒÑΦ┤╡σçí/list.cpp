#include <cstdio>
typedef long long LL;

LL n;

inline LL read(){
	LL s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

LL Pow(LL x,LL y){
	LL ret=1;
	while(y){
		if(y&1){
			ret=ret*x;
		}
		x*=x;
		y>>=1;
	}
	return ret;
}

int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	n=read();
	if(n==1){
		printf("0");
		return 0;
	}
	printf("%lld",2ll*(Pow(2ll,n)-1-n));
	return 0;
}
