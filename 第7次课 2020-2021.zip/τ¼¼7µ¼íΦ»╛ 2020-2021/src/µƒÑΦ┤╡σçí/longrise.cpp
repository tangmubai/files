#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n,x,len;
int f[1005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Lower_Bound(int x){
	int l=1,r=len,mid;
	while(l<=r){
		mid=(l+r)>>1;
		if(f[mid]>=x){
			r=mid-1;
		}else {
			l=mid+1;
		}
	}
	return l;
}

int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i){
		x=read();
		if(!len || x>f[len]){
			f[++len]=x;
		}else {
			f[Lower_Bound(x)]=x;
		}
	}
	printf("%d",len);
	return 0;
}
