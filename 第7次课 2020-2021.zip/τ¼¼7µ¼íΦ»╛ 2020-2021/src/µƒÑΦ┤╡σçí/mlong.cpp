#include <cstdio>
#include <algorithm>
using namespace std;

int n,x,ans=-0x7fffffff;
int f[100005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&x);
		f[i]=max(f[i-1]+x,x);
		ans=max(ans,f[i]);
	}
	printf("%d",ans);
	return 0;
}
