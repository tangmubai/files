#include<stdio.h>
int f[5005],v,w,n,m;
#define max(a,b) a>b?a:b
int main(){
	freopen("bag.in","r",stdin);freopen("bag.out","w",stdout);
	scanf("%d%d",&n,&m);
	while(n--){
		scanf("%d%d",&v,&w);
		for(register int i=m;i>=v;--i)
		f[i]=max(f[i],f[i-v]+w);
	}
	printf("%d",f[m]);
}
