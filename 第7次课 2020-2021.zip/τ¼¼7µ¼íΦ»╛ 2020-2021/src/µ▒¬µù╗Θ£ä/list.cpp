#include<stdio.h>
int f[22];
int n;
int main(){
	freopen("list.in","r",stdin);freopen("list.out","w",stdout);
	f[2]=2;
	scanf("%d",&n);
	for(register int i=3;i<=n;++i)
	f[i]=2*f[i-1]+2*(i-1);
	printf("%d",f[n]);
}
