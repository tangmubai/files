#include<stdio.h>
long long f[62];
int n;
int main(){
	freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	f[2]=2;
	scanf("%d",&n);
	for(register int i=3;i<=n;++i)
	f[i]=2*f[i-1]+2*(i-1);
	printf("%lld",f[n]);
}
