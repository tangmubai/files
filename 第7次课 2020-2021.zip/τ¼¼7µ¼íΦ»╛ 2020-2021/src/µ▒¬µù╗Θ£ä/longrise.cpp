#include<stdio.h>
int a[1005],f[1005];
int n,maxx=1;
#define max(a,b) a>b?a:b
int main(){
	freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;++i)scanf("%d",&a[i]);
	f[1]=1;
	for(register int i=2,k=0;i<=n;f[i]=f[k]+1,maxx=max(maxx,f[i]),++i,k=0)
	for(register int j=1;j<i;++j)
	if(a[j]<a[i]&&f[j]>f[k])k=j;
	printf("%d",maxx);
}
