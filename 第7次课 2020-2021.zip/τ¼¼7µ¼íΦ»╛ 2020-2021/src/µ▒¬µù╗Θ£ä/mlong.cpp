#include<stdio.h>
int s,x,n,maxx=-1000000000;
int main(){
	freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	while(n--){
		scanf("%d",&x);
		s+=x;maxx<s?maxx=s:0;
		s<0?s=0:0;
	}
	printf("%d",maxx);
}
