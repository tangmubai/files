#include<stdio.h>
#include<string.h>
char a[1005],b[1005];
int f[2][1005],n,m,x=1,y;
#define max(a,b) a>b?a:b
int main(){
	freopen("public.in","r",stdin);freopen("public.out","w",stdout);
	scanf("%s%s",a+1,b+1);n=strlen(a+1);m=strlen(b+1);
	for(register int i=1;i<=n;++i,x^=y^=x^=y)
	for(register int j=1;j<=m;++j)
	if(a[i]==b[j])f[x][j]=f[y][j-1]+1;
	else f[x][j]=max(f[y][j],f[x][j-1]);
	printf("%d",f[y][m]);
}
