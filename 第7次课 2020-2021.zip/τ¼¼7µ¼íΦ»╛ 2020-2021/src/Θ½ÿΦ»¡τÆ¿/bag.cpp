#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;
int f[5010],n,m,w[210],c[210];
int maxn(int a,int b){
	return (a>b?a:b);
}
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	    scanf("%d%d",&w[i],&c[i]);
	for(int i=1;i<=n;i++){
		for(int j=m;j>=w[i];j--)
			f[j]=maxn(f[j],f[j-w[i]]+c[i]);
	}
	printf("%d\n",f[m]);
	return 0;
}

