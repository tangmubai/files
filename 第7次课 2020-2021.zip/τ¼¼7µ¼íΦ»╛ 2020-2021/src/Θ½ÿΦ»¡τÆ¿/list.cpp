#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;
long long ans,k,t=2;
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	scanf("%d",&k);
	for(int i=2;i<=k;i++){
		ans=ans*2+t;
		t+=2;
	}
	printf("%lld\n",ans);
	return 0;
}

