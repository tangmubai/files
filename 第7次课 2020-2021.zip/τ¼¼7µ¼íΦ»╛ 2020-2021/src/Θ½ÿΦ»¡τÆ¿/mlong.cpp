#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;
int n,a[100010],f[100010],ans=-2147483647;
int maxn(int a,int b){
	return (a>b?a:b);
}
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
	    f[i]=maxn(f[i],f[i-1])+a[i];
	for(int i=1;i<=n;i++)
	    ans=maxn(ans,f[i]);
	printf("%d\n",ans);
	return 0;
}

