#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
#include<math.h>
#include<algorithm>
using namespace std;
char a[1010],b[1010],dp[1010][1010],l1,l2;
int maxn(int a,int b){
	return (a>b?a:b);
}
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s%s",a+1,b+1);
	l1=strlen(a+1);
	l2=strlen(b+1);
	for(int i=1;i<=l1;i++){
		for(int j=1;j<=l2;j++){
			if(a[i]==b[j])
				dp[i][j]=dp[i-1][j-1]+1;
			else
				dp[i][j]=maxn(dp[i-1][j],dp[i][j-1]);
		}
	}
	printf("%d\n",dp[l1][l2]);
	return 0;
}
/*
abcdgh
aedfhb
*/
