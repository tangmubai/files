#include <iostream>
using namespace std;
int n,m;
int w[205],c[205];
int f[5005];
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	cin>>w[i]>>c[i];
	for(int i=1;i<=n;i++)
	for(int j=m;j>=w[i];j--)
	f[j]=max(f[j],f[j-w[i]]+c[i]);
	cout<<f[m];
}
