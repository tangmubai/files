#include <iostream>
using namespace std;
int k;
int ans=0;
bool vis[25];
void dfs(int now,int las,int lass){
	if(now>2)ans++;
	if(now>k)return;
	if(las>lass){
		for(int i=lass-1;i>=1;i--){
			if(!vis[i]){
				vis[i]=1;
				dfs(now+1,i,las);
				vis[i]=0;
			}
		}
	}
	else{
		for(int i=lass+1;i<=k;i++){
			if(!vis[i]){
				vis[i]=1;
				dfs(now+1,i,las);
				vis[i]=0;
			}
		}
	}
}
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)
	for(int j=1;j<=k;j++){
		if(i==j)continue;
		dfs(3,i,j);
	}
	cout<<ans;
}
