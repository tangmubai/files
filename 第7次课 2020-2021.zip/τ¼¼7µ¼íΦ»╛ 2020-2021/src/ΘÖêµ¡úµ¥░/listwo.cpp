#include <iostream>
using namespace std;
int k;
bool vis[65];
long long f[65][65][65];
long long dfs(int now,int las,int lass){
	if(f[now][las][lass])return f[now][las][lass];
	f[now][las][lass]++;
	if(now>k)return 0ll;
	if(las>lass){
		for(int i=lass-1;i>=1;i--){
			if(!vis[i]){
				vis[i]=1;
				f[now][las][lass]+=dfs(now+1,i,las);
				vis[i]=0;
			}
		}
	}
	else{
		for(int i=lass+1;i<=k;i++){
			if(!vis[i]){
				vis[i]=1;
				f[now][las][lass]+=dfs(now+1,i,las);
				vis[i]=0;
			}
		}
	}
	return f[now][las][lass];
}
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	cin>>k;
	if(k==1){
		cout<<0;
		return 0;
	}
	long long ans=0;
	for(int i=1;i<=k;i++)
	for(int j=1;j<=k;j++){
		if(i==j)continue;
		ans+=dfs(3,i,j);
	}
	cout<<ans+2;
}
