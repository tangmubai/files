#include <iostream>
using namespace std;
int n;
int a[1005];
int f[1005];
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	for(int i=1;i<=n;i++){
		for(int j=1;j<i;j++)
		if(a[i]>a[j])f[i]=max(f[i],f[j]);
		f[i]++;
	}
	int ans=-1;
	for(int i=1;i<=n;i++)
	ans=max(ans,f[i]);
	cout<<ans;
}
