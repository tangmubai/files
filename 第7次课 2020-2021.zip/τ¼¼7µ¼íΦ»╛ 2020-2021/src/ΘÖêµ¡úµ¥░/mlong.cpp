#include <iostream>
#include <algorithm>
using namespace std;
int n;
int a[100005];
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	int mx=0,s=0;
	for(int i=1;i<=n;i++){
		if(s+a[i]>=0)s+=a[i];
		else s=0;
		mx=max(mx,s);
	}
	sort(a+1,a+1+n);
	if(a[n]<0)cout<<a[n];
	else cout<<mx;
}
