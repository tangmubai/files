#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
char c1[1005],c2[1005];
int f[1005][1005];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	cin>>c1+1>>c2+1;
	int c1c=strlen(c1+1);
	int c2c=strlen(c2+1);
	for(int i=1;i<=c1c;i++)
	for(int j=1;j<=c2c;j++){
		f[i][j]=max(f[i-1][j],f[i][j-1]);
		if(c1[i]==c2[j])f[i][j]=max(f[i][j],f[i-1][j-1]+1);
	}
	cout<<f[c1c][c2c];
}
