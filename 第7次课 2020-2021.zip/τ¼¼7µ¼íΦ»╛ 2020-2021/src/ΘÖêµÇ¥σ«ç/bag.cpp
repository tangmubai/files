#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
using namespace std;
int c[205],w[205],f[5005];
int max(int a,int b)
{
	if(a>b)return a;
	return b;
}
int main()
{
int n,m,i,j,k;
freopen("bag.in","r",stdin);
freopen("bag.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(f,0,sizeof(f));
	for(i=1;i<=n;i++)
	{
		scanf("%d%d",&w[i],&c[i]);
	}
	f[0]=0;
	for(i=1;i<=n;i++)
	{
		for(j=m;j>=w[i];j--)
		{
			f[j]=max(f[j],f[j-w[i]]+c[i]);	
		}
	}
	cout<<f[m];
}
