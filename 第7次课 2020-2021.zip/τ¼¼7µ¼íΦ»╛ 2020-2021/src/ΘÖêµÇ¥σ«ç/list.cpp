#include<stdio.h>
#include<math.h>
using namespace std;
int main()

{
int n,i,j;
freopen("list.in","r",stdin);
freopen("list.out","w",stdout);
long long ans=0;
scanf("%d",&n);
ans=pow(2,n+1)-4-2*(n-1);
printf("%d",ans);
}

