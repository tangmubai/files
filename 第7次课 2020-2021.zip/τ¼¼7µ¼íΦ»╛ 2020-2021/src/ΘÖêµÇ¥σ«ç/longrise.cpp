#include<stdio.h>
#include<algorithm>
using namespace std;
int a[1005],f[1005];
int main()
{
	int n,i,j,ans=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=n;i++)
	{
		f[i]=f[i-1]+1;
		if()
	}
	printf("%d",ans);
}

