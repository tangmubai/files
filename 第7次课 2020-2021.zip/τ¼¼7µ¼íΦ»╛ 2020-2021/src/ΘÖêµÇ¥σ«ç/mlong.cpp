#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int a[100005],b[100005];
int main()
{
	int n,i,j;
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
		cin>>n;b[0]=a[0];
	for(i=1;i<=n;i++)
	{
		cin>>a[i];b[i]=max(b[i-1]+a[i],a[i]);
	}
	int ans=0;
	for(i=1;i<=n;i++)ans=max(ans,b[i]);
	cout<<ans;
}
