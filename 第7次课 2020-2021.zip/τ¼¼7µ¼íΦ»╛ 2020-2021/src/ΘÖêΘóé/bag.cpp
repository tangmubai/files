#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,cost,value,f[5005];

void Zero_One_Pack(){
	for(int j=m;j>=cost;j--)
		f[j]=max(f[j],f[j-cost]+value);
}

int main(){
	freopen("bag.in","r",stdin);freopen("bag.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d %d",&cost,&value);
		Zero_One_Pack();
	}
	printf("%d\n",f[m]);
	return 0;
}
