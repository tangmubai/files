#include<cstdio>

int main(){
	freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	long long k;scanf("%lld",&k);
	printf("%lld\n",((1ll<<k)-k-1ll)*2ll);
	return 0;
}
/*
#1:              #2:             #3:			#4:			#5:
20               25              30				18			24
------           ------          ------			------		------
2097110          67108812        2147483586		524250		33554382
*/
