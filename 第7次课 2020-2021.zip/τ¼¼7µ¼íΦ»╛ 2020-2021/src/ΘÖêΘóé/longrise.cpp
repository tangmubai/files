#include<cstdio>
#include<algorithm>
using namespace std;

int n,d[1005],len;

int main(){
	freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int x;scanf("%d",&x);
		int pos=lower_bound(d+1,d+1+len,x)-d;
		d[pos]=x;
		len=max(len,pos);
	}
	printf("%d\n",len);
	return 0;
}
