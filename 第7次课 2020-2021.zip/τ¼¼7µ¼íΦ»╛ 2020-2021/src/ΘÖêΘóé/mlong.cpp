#include<cstdio>
#include<algorithm>
using namespace std;

int n,s,mx=-200000000,f[100005];

int main(){
	freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int x;scanf("%d",&x);
		f[i]=max(f[i-1]+x,0);
		s+=x<0;
		mx=max(mx,x);
	}
	if(s==n){
		printf("%d\n",mx);
		return 0;
	}
	else{
		int ans=-2147483640;
		for(int i=1;i<=n;i++) ans=max(ans,f[i]);
		printf("%d\n",ans);
	}
	return 0;
}
