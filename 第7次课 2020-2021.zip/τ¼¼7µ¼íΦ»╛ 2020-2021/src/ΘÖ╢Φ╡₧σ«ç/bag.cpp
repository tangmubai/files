#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m;
int w[205],c[205];
int f[5005];
inline void read(int &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline int mx(int _x,int _y)
{
	return _x>_y?_x:_y;
}
inline int mn(int _x,int _y)
{
	return _x<_y?_x:_y;
}

int main()
{
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	read(n);read(m);
	for(int i=1;i<=n;i++)
	{
		read(w[i]);read(c[i]);
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=m;j>=w[i];j--)
			f[j]=mx(f[j],f[j-w[i]]+c[i]);
	}
	printf("%d\n",f[m]);
	return 0;
}
