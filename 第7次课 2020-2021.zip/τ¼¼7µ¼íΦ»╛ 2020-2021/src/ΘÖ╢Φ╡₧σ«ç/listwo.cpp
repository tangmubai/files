#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
ll n;
ll f[65];
ll rev;
inline void read(ll &x)
{
	int f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
int main()
{
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	read(n);
	rev=4;
	f[1]=0;f[2]=2;
	for(int i=3;i<=n;i++)
	{
		f[i]=f[i-1]*2ll+rev;
		rev+=2;
	}
	printf("%lld\n",f[n]);
	return 0;
}
