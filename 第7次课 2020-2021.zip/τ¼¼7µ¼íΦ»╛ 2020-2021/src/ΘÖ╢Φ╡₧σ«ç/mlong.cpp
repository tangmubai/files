#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
const ll oo=5000000;
ll n;
ll a[100005];
ll f[100005];
ll ans;
inline void read(ll &x)
{
	ll f=1;char c;
	for(x=0,c=getchar();c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+(c^48); x*=f;
}
inline ll mx(ll _x,ll _y)
{
	return _x>_y?_x:_y;
}
inline ll mn(ll _x,ll _y)
{
	return _x<_y?_x:_y;
}
int main()
{
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
//	read(n);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	f[0]=-oo;ans=-oo;
	for(int i=1;i<=n;i++)
	{
		f[i]=mx(f[i-1]+a[i],a[i]);
	}
	for(int i=1;i<=n;i++) ans=mx(ans,f[i]);
	printf("%lld\n",ans);
	return 0;
}
