#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
int max(int a,int b){return a>b?a:b;}
int dp[5005],a[205],b[205];
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=n;i++)a[i]=read(),b[i]=read();
	for(int i=1;i<=n;i++)
		for(int j=m;j>=a[i];j--)
			dp[j]=max(dp[j],dp[j-a[i]]+b[i]);
	printf("%d",dp[m]);
	return 0;
}

