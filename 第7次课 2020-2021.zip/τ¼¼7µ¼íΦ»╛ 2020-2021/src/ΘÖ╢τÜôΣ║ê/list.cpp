#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
int a[25]={0,0,2,8,22,52,114,240,494,1004,2026
,4072,8166,16356,32738,65504,131038,262108,524250,1048536,2097110};
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	int n=read();
	printf("%d",a[n]);
	return 0;
}

