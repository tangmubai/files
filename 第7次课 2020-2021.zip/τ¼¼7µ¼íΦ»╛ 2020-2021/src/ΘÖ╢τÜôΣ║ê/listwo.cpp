#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
long long a[65];
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	int n=read();
	a[0]=0;a[1]=0;
	for(int i=2;i<=n;i++)a[i]=a[i-1]*2+(i-1)*2;
	printf("%lld",a[n]);
	return 0;
}

