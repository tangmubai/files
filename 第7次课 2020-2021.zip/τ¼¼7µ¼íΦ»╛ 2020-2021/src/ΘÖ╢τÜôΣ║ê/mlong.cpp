#pragma GCC optimize(2)
#include<stdio.h>
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
long long max(long long a,long long b){return a>b?a:b;}
int a[100005];long long dp[100005];
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	int n=read();
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	long long ans=-2147483647;bool flag=1;int sum=0;
	for(int i=1;i<=n;i++){
		sum=max(sum,a[i]);
		if(a[i]>0)flag=0;
		ans=max(ans,a[i]);
	}
	if(flag){
		printf("%lld",ans);return 0;
	}
	ans=0;int tmp=0;
	for(int i=1;i<=n;i++){
		tmp+=a[i];if(tmp<0)tmp=0;ans=max(ans,tmp);
	}
	printf("%lld",ans);
	return 0;
}

