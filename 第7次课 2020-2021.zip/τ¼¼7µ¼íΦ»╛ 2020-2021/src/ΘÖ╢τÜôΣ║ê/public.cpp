#include<stdio.h>
#include<cstring>
#include<string>
#include<iostream>
using namespace std;
inline int read(){
	int k=0,j=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')j=-1;c=getchar();}
	while(c>='0'&&c<='9')k=k*10+(c-'0'),c=getchar();
	return k*j;
}
char a[1005],b[1005];int dp[1005][1005];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	cin>>a+1>>b+1;
	for(int i=1;i<=strlen(a+1);i++)
		for(int j=1;j<=strlen(b+1);j++)
			dp[i][j]=max(dp[i-1][j],max(dp[i][j-1],dp[i-1][j-1]+(a[i]==b[j])));
	printf("%d",dp[strlen(a+1)][strlen(b+1)]);
	return 0;
}

