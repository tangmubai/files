#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
#define ll long long
ll k,f[65];
int main(){
	freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++) f[i]=2*(f[i-1]+i);
//	for(int i=1;i<=k;i++)
//		for(int j=1;j<=k;j++)
//			f[i][j]=f[i-1][j]+f[i-1][j-1];
	printf("%lld\n",f[k-1]);
	return 0;
}

