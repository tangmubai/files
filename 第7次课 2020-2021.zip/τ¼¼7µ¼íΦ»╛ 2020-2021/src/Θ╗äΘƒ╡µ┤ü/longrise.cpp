#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,len,f[1005],a[1005],ans=0;
int main(){
	freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		if(f[ans]<a[i]) f[++ans]=a[i];
		else{
			int j=lower_bound(f+1,f+1+ans,a[i])-f;
			f[j]=a[i];
		}
	}
	printf("%d\n",ans);
	return 0;
}

