#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,a[100005],f[100005],ans=-2147483647;
int main(){
	freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	f[1]=a[1];
	for(int i=2;i<=n;i++) f[i]=max(f[i-1]+a[i],a[i]);
	for(int i=1;i<=n;i++) ans=max(ans,f[i]);
	printf("%d\n",ans);
	return 0;
}

