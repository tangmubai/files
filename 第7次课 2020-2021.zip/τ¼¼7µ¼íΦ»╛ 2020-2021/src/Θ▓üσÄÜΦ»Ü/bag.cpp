#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,w[210],c[210],f[5010];
int main()
{freopen("bag.in","r",stdin);freopen("bag.out","w",stdout);
 cin>>n>>m;
 for(int i=1;i<=n;i++) cin>>w[i]>>c[i];
 for(int i=1;i<=n;i++)
 for(int j=m;j>=w[i];j--)
 f[j]=max(f[j],f[j-w[i]]+c[i]);
 cout<<f[m]<<endl;
 return 0;
}
