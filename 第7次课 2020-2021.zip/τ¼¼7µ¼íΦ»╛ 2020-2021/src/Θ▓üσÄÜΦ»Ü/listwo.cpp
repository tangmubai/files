#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int n;
long long f[100];
int main()
{freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
 cin>>n;
 f[0]=0;f[1]=0;f[2]=2;
 for(int i=3;i<=n;i++) f[i]=f[i-1]*2+(i-1)*2;
 cout<<f[n]<<endl;
 return 0;
}
