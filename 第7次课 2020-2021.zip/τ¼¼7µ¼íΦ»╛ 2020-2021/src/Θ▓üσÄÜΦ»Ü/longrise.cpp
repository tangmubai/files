#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int n,a[1010],f[1010],cnt;
int main()
{freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++) cin>>a[i];
 for(int i=1;i<=n;i++)
{int d=lower_bound(f+1,f+cnt+1,a[i])-f;
 f[d]=a[i];
 cnt=max(cnt,d);
}
 cout<<cnt<<endl;
 return 0;
}
