#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int n,a[100010],sum,ans=-2e9;
int main()
{freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
 cin>>n;
 for(int i=1;i<=n;i++) cin>>a[i];
 for(int i=1;i<=n;i++)
{sum=max(sum+a[i],a[i]);
 ans=max(sum,ans); 
}
 cout<<ans<<endl;
 return 0;
}
