#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int a[25],n;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	n=read();
	a[0]=0;a[1]=0;a[2]=2;
	for(register int i=3;i<=n;i++) a[i]=2*a[i-1]+2*(i-1);
	printf("%d",a[n]);
	return 0;
}
