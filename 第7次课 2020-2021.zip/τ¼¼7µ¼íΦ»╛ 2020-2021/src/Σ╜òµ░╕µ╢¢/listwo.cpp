#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int n;long long a[65];
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	n=read();
	a[0]=0ll;a[1]=0ll;a[2]=2ll;
	for(register int i=3;i<=n;i++) a[i]=2ll*a[i-1]+2ll*(i-1);
	printf("%lld",a[n]);
	return 0;
}
