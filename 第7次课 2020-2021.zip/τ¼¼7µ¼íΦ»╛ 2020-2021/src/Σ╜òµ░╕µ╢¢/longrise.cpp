#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int a[1005],b[1005],n,t,ans;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++) a[i]=read();
	for(register int i=2;i<=n;i++){
		int x=lower_bound(b+1,b+ans+1,a[i])-b;
		b[x]=a[i];
		ans=max(ans,x);
	}
	printf("%d",ans);
	return 0;
}
