#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
int a[100005],n,x,ans=-1000000005;
int read(){
	int b1=0,d1=1;char c1=getchar();
	while(c1<'0'||c1>'9'){
		if(c1=='-') d1=-1;
		c1=getchar();
	}
	while(c1>='0'&&c1<='9'){
		b1=b1*10+(c1-'0');
		c1=getchar();
	}
	return b1*d1;
}
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		x=read();a[i]=a[i-1]+x;
	}
	for(register int i=0;i<n;i++){
		for(register int j=i+1;j<=n;j++){
			ans=max(ans,a[j]-a[i]);
		}
	}
	printf("%d",ans);
	return 0;
}
