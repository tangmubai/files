#include"stdio.h"
#include"algorithm"
#include"cstring"
#include"cmath"
#include"iostream"
#include"iomanip"
#include"vector"
#include"queue"
#include"map"
#include"set"
#include"stack"
using namespace std;
char a[1005],b[1005];
int f[1005][1005],n1,n2;
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s%s",a+1,b+1);n1=strlen(a+1);n2=strlen(b+1);
	for(register int i=1;i<=n1;i++){
		for(register int j=1;j<=n2;j++){
			if(a[i]==b[j]) f[i][j]=f[i-1][j-1]+1;
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
		}
	}
	printf("%d",f[n1][n2]);
	return 0;
}
