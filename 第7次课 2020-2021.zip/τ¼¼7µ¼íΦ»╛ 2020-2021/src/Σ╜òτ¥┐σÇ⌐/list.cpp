#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	long long n;scanf("%lld",&n);
	long long ans=((1<<n)-n-1)*2;
	printf("%lld",ans);
	return 0;
}
