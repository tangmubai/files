#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	long long n;scanf("%lld",&n);
	long long ans=((1<<n)-n-1)*2;
	printf("%lld",ans);
	return 0;
}
