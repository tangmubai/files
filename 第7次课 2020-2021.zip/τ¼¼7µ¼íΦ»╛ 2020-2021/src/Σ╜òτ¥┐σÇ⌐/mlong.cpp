#include<cstdio>
#include<algorithm>
using namespace std;
long long a[100010],b[100010];
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		b[i]=max(b[i-1]+a[i],a[i]);
	}
	long long ans=-10000000000;
	for(int i=1;i<=n;i++)
		ans=max(ans,b[i]);
	printf("%lld\n",ans);
	return 0;
}
