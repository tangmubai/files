#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
char a[1010],b[1010];
int f[1010][1010];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s ",a+1);
	scanf("%s ",b+1);
	memset(f,0,sizeof(f));
	int al=strlen(a+1),bl=strlen(b+1);
	for(int i=1;i<=al;i++) f[i][0]=0;
	for(int i=1;i<=bl;i++) f[0][i]=0;
	for(int i=1;i<=al;i++)
		for(int j=1;j<=bl;j++)
			if(a[i]==b[j]) f[i][j]=f[i-1][j-1]+1;
			else f[i][j]=max(f[i-1][j],f[i][j-1]);
	printf("%d\n",f[al][bl]);
//	for(int i=1;i<=al;i++){
//		for(int j=1;j<=bl;j++)
//			printf("%d ",f[i][j]);
//		printf("\n");
//	}
			
	return 0;
}
