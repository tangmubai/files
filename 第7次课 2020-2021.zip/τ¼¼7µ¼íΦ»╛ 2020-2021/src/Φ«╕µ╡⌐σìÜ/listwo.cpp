#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
typedef long long ll;
ll f[605], n;
int main()
{
	freopen("listwo.in", "r", stdin);
	freopen("listwo.out", "w", stdout);
	scanf("%lld", &n);
	f[1] = 0; f[2] = 2; f[3] = 8;
	for (int i = 4; i <= 60; i++)  f[i] = f[i - 1] * 2 + (ll)2 * (i - 1);
	printf("%lld", f[n]);
	return 0;
}
