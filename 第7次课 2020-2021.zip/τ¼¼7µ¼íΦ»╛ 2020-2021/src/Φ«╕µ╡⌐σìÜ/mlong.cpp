#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int oo = 100000000;
typedef long long ll;
ll n, a[100005], f[100005], ans;

int main()
{
	freopen("mlong.in", "r", stdin);
	freopen("mlong.out", "w", stdout);
	scanf("%lld", &n);
	for (int i = 1; i <= n; i++)
		scanf("%lld", &a[i]);
	f[0] = -oo; ans = -oo;
	for (int i = 1; i <= n; i++)
	{
		f[i] = max(f[i - 1] + a[i], a[i]);
	}
	for (int i = 1; i <= n; i++) 
		ans = max(ans, f[i]);
	printf("%lld", ans);
	return 0;
}
