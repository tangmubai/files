#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int f[1005][1005];
int lena, lenb;
char a[10005], b[10005];
int main()
{
	freopen("public.in", "r", stdin);
	freopen("public.out", "w", stdout);
	scanf("%s",1+a); scanf("%s",1+b);
	lena=strlen(1+a); lenb = strlen(1+b);
	for (int i = 1; i <= lena; i++)
	{
		for (int j = 1; j <= lenb; j++)
		{
			int t1 = f[i-1][j-1]+(a[i]==b[j]);
			int t2 = f[i - 1][j];
			int t3 = f[i][j - 1];
			f[i][j] = max(t1, max(t2, t3));
		}
	}
	printf("%d", f[lena][lenb]);
	return 0;
}
