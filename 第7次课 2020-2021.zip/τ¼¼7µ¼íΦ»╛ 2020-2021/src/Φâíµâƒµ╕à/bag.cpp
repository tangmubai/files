#include<stdio.h>
const int M = 5000; 
int n, m, f[M + 5], w, c, ans;

int max(int x, int y) {return x > y ? x : y;}

int main() {
	freopen("bag.in", "r", stdin);
	freopen("bag.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++i) {
		scanf("%d%d", &w, &c);
		for(int j = m; j >= w; --j)
			f[j] = max(f[j], f[j - w] + c);
			 
	}
	for(int i = 0; i <= m; ++i)
		ans = max(ans, f[i]);
	printf("%d\n", ans);
	return 0;
}
