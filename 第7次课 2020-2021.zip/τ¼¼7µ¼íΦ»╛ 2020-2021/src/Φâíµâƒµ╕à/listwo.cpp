#include<stdio.h>
#include<string.h>
const int N = 60;
#define LL long long

int n;
LL f[N + 5];

int main() {
	freopen("listwo.in", "r", stdin);
	freopen("listwo.out", "w", stdout);
	scanf("%d", &n);f[1] = 0; f[2] = 2; int tp = 4;
	for(int i = 3; i <= n; ++i){
		f[i] = f[i - 1] * 2 + tp;
		tp += 2;
	}
	printf("%lld", f[n]);
	return 0;
}
