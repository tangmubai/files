#include<stdio.h>

int n, now, ans, x;

int max(int x, int y) {return x > y ? x : y;}

int main() {
	freopen("mlong.in", "r", stdin);
	freopen("mlong.out", "w", stdout);
	scanf("%d%d", &n, &x); now = x; ans = x;
	for(int i = 2; i <= n; ++i) {
		scanf("%d", &x);
		if (now < 0) now = x;
		else now += x;
		ans = max(ans, now);
	}
	 printf("%d\n", ans);
	return 0;
}
