#include<stdio.h>
#include<string.h>
const int N = 1000;

int l1, l2, f[N + 5][N + 5];
char s1[N + 5], s2[N + 5];

int max(int x, int y) {return x > y ? x : y;}

int main() {
	freopen("public.in", "r", stdin);
	freopen("public.out", "w", stdout);
	scanf("%s %s", s1 + 1, s2 + 1);
	l1 = strlen(s1 + 1); l2 = strlen(s2 + 1);
	for(int i = 1; i <= l1; ++i)
		for(int j = 1; j <= l2; ++j)
			if (s1[i] == s2[j]) f[i][j] = f[i - 1][j - 1] + 1;
			else f[i][j] = max(f[i][j - 1], f[i - 1][j]);
	printf("%d", f[l1][l2]);		
	return 0;
} 
