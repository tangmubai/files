#include <stdio.h>
int n,m,a[205],b[205],f[5005];
int mx(int a,int b){
	return a>b?a:b;
}
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&a[i],&b[i]);
	for(int i=1;i<=n;i++)
		for(int j=m;j>=a[i];j--)
			f[j]=mx(f[j-a[i]]+b[i],f[j]);
	printf("%d",f[m]);
	return 0;
}
