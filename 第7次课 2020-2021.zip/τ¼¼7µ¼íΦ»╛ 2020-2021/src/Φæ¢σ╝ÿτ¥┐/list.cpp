#include <stdio.h>
long long f[1025],k,s[1005];
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	scanf("%lld",&k);
	f[2]=2;s[2]=2;
	for(int i=3;i<=k;i++){
		s[i]=s[i-1]*2+2;
		f[i]=f[i-1]+s[i];
	}
	printf("%lld",f[k]);
	return 0;
}
