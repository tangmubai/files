#include <stdio.h>
#define ll long long
ll n,a[1005],f[1005],ans=-1;
ll mx(ll a,ll b){
	return a>b?a:b;
}
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		f[i]=1;
	}
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(a[j]>a[i])
				f[j]=mx(f[j],f[i]+1);
	for(int i=1;i<=n;i++)
		ans=mx(ans,f[i]);
	printf("%lld",ans);
	return 0;
}
