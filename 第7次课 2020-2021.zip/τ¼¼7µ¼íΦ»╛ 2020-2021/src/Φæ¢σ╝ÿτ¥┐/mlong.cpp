#include <stdio.h>
int n,ans,a[100005],f[100005];
int mx(int a,int b){
	return a>b?a:b;
}
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		f[i]=mx(a[i]+f[i-1],a[i]);
	for(int i=1;i<=n;i++)
		ans=mx(ans,f[i]);
	printf("%d",ans);	
	return 0;
}
