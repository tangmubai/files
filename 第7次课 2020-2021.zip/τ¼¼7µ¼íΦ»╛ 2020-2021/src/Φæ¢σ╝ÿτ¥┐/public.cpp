#include <stdio.h>
#include <cstring>
#include <iostream>
using namespace std;
#define ll long long
char a[1005],b[1005];
int f[1005][1005];
ll len1,len2;
ll mx(ll a,ll b){
	return a>b?a:b;
}
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s\n%s",a+1,b+1);
	f[1][1]=(a[1]==b[1]);
	len1=strlen(a+1);len2=strlen(b+1);
	for(int i=1;i<=len1;i++)
		for(int j=1;j<=len2;j++){
			f[i][j]=mx(f[i][j],f[i-1][j]);
			f[i][j]=mx(f[i][j],f[i][j-1]);
			f[i][j]=mx(f[i][j],f[i-1][j-1]+(a[i]==b[j]?1:0));
		}
	printf("%d",f[len1][len2]);
	return 0;
}
