#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
int dp[5005];
int main(){
	frin("bag.in");frout("bag.out");
	int n,m;scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i){
		int w,c;scanf("%d%d",&w,&c);
		for(int j=m;j>=w;--j){
			dp[j]=max(dp[j],dp[j-w]+c);
		}
	}
	printf("%d\n",dp[m]);
	return 0;
}
