#include <cstdio>
#include <cmath>
using namespace std;
typedef long long ll;
int main(){
	freopen("list.in","r",stdin);freopen("list.out","w",stdout);
	int k;scanf("%d",&k);
	ll ans=2*((1LL<<k)-k-1);
    printf("%lld",ans);
	return 0;
}
