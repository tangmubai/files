#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
typedef long long ll;
int main(){
	frin("listwo.in");frout("listwo.out");
	int k;scanf("%d",&k);
	ll ans=2*((1LL<<k)-k-1);
    printf("%lld",ans);
	return 0;
}
