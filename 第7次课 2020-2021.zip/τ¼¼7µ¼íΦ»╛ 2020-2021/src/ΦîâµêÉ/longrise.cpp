#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
int d[1005],len;
int main(){
	frin("longrise.in");frout("longrise.out");
	int n;scanf("%d",&n);
	for(int i=1;i<=n;++i){
		int x;scanf("%d",&x);
		int k=lower_bound(d+1,d+len+1,x)-d;
		if(k>len) ++len;
		d[k]=x;
	}
	printf("%d",len);
	return 0;
}
