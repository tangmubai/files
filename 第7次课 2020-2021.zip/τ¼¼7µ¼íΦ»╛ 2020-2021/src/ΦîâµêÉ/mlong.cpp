#include <cstdio>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
template <typename _tp>
inline void in(_tp &x){
	x=0;int w=0;char c=getchar();
	for(;c<'0'||c>'9';w|=c=='-',c=getchar());
	for(;c>='0'&&c<='9';x=x*10+(c^'0'),c=getchar());
	if(w) x=-x;
}
int main(){
	frin("mlong.in");frout("mlong.out");
	int n;in(n);
	int ans=-2e9,now=0;
	for(int i=1;i<=n;++i){
		int x;in(x);
		now+=x;
		ans=max(ans,now);
		if(now<0) now=0;
	}
	printf("%d\n",ans);
	return 0;
}
