#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define frin(a) freopen(a,"r",stdin)
#define frout(a) freopen(a,"w",stdout)
const int N=1005;
char a[N],b[N];
int dp[N][N];
int main(){
	frin("public.in");frout("public.out");
	scanf("%s%s",a+1,b+1);
	int l1=strlen(a+1),l2=strlen(b+1);
	for(int i=1;i<=l1;++i){
		for(int j=1;j<=l2;++j){
			if(a[i]==b[j]) dp[i][j]=dp[i-1][j-1]+1;
			else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
		}
	}
	printf("%d\n",dp[l1][l2]);
	return 0;
}
