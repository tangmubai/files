#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
typedef long long ll;
const int oo = 1e9;
const int maxn = 2e2 + 10;
const int maxm = 5e3 + 10;
inline void read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	x *= f;
}
int w[maxn], c[maxn];
int f[maxm];
int ans;
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen ("bag.in", "r", stdin);
	freopen ("bag.out", "w", stdout);
	//ios::sync_with_stdio(false);
	int n, m;
	read(n);
	read(m);
	for (register int i = 1; i <= n; i ++) {
		read(w[i]);
		read(c[i]);
	}
	for (register int i = 1; i <= n; i ++)
		for (register int j = m; j >= w[i]; j --)
			f[j] = mx(f[j], f[j-w[i]] + c[i]);
	printf ("%d\n", f[m]);
	return 0;	
}
