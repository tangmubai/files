#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
typedef long long ll;
const int oo = 1e9;
const int maxn = 60 + 10;
inline void read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	x *= f;
}
long long sum[maxn], ans[maxn];
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen ("listwo.in", "r", stdin);
	freopen ("listwo.out", "w", stdout);
	//ios::sync_with_stdio(false);
	int n;
	read(n);
	sum[2] = ans[2] = 2;
	for (register int i = 2; i <= n; i ++) {
			 sum[i] = sum[i-1] * 2 + 2;
			 ans[i] = ans[i-1] + sum[i];
	}
	printf ("%lld\n",ans[n]);
	return 0;	
}
