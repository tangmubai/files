#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
typedef long long ll;
const int oo = 1e9;
const int maxn = 1e5+10;
inline void read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	x *= f;
}
int a[maxn];
int sum;
int ans;
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen ("mlong.in", "r", stdin);
	freopen ("mlong.out", "w", stdout);
	//ios::sync_with_stdio(false);
	int n;
	scanf ("%d", &n);
	for (register int i = 1; i <= n; i ++) scanf ("%d", &a[i]);
	ans = a[1];
	sum = mx(0, a[1]);
	for (register int i = 2; i <= n; i ++) {
		sum +=a[i];
		ans = mx(ans, sum);
		sum = sum < 0 ? 0 : sum;
	}
	printf ("%d\n", ans);
	return 0;	
}
