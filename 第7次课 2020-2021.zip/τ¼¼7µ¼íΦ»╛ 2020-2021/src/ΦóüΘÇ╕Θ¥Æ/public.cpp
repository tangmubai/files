#include <stdio.h>
#include <string>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;
typedef long long ll;
const int oo = 1e9;
const int maxn = 1e3+10;
inline void read(int &x) {
	x = 0;
	int f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	x *= f;
}
char a[maxn], b[maxn];
int f[maxn][maxn];
int ans;
inline int mn(int x, int y) {
	return x < y ? x : y;
}
inline int mx(int x, int y) {
	return x > y ? x : y;
}
main() {
	freopen ("public.in", "r", stdin);
	freopen ("public.out", "w", stdout);
	scanf ("%s\n%s", a+1, b+1);
	int lena = strlen(a+1);
	int lenb = strlen(b+1);
	f[1][1] = (a[1] == b[1]) ? 1 : 0;
	for (register int i = 1; i <= lena; i ++) {
		for (register int j = 1; j <= lenb; j ++) {
			//if (a[i] == b[j] && f[i][j] <= f[i-1][j-1]) f[i][j] = f[i-1][j-1] + 1;
			f[i][j] = mx(f[i][j], f[i-1][j-1] + ((a[i] == b[j]) ? 1 : 0));
			//f[i][j] = mx(f[i][j], mx(f[i-1][j], f[i][j-1]));
			f[i][j] = mx(f[i][j], mx(f[i-1][j], f[i][j-1]));
		}
	}
	printf ("%d\n", f[lena][lenb]);
	return 0;	
}
