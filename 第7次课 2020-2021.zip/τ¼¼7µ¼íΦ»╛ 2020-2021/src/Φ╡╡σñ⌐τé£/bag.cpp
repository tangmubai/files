#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int n, m;
int v[205], w[205];
int mem[205][5005];
int search (int step, int sum) {
	if (mem[step][sum] != -1)
		return mem[step][sum];
	if (step == n + 1)
		return 0;
	int res = search (step + 1, sum);
	if (sum + w[step] <= m)
		res = max (res, search (step + 1, sum + w[step]) + v[step]);
	return mem[step][sum] = res;
}
int main () {
	freopen ("bag.in", "r", stdin);
	freopen ("bag.out", "w", stdout);
	memset (mem, -1, sizeof(mem));
	n = read(), m = read();
	for (int i = 1; i <= n; i ++) {
		w[i] = read(), v[i] = read();
	}
	int ans = search (1, 0);
	printf ("%d", ans);
}

