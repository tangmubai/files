#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int n;
bool vis[65];
int ans;
void search (int llas, int las) {
	ans ++;
	if (las > llas) {
		for (int i = llas - 1; i >= 1; i --) {
			if (!vis[i]) {
				vis[i] = 1;
				search (las, i);
				vis[i] = 0;
			}
		}
	}
	else {
		for (int i = llas + 1; i <= n; i ++) {
			if (!vis[i]) {
				vis[i] = 1;
				search (las, i);
				vis[i] = 0;
			}
		}
	}
}
int main () {
	freopen ("list.in", "r", stdin);
	freopen ("list.out", "w", stdout);
	n = read();
	for (int i = 1; i <= n; i ++) {
		for (int j = 1; j <= n; j ++) {
			if (i != j) {
				vis[i] = vis[j] = 1;
				search (i, j);
				vis[i] = vis[j] = 0;
			}
		}
	}
	printf ("%d", ans);
}

