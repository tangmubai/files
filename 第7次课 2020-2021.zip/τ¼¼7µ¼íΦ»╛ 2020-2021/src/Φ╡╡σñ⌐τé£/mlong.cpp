#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int read() {
	char ch = getchar();
	int x = 0;
	bool f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-')
			f = 0;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	return f ? x : -x;
}
int n;
int a[100005];
int ans = -2147483647;
int main () {
	freopen ("mlong.in", "r", stdin);
	freopen ("mlong.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i ++) {
		scanf ("%d", &a[i]);
		a[i] += a[i - 1];
		ans = max (ans, a[i]);
		a[i] = max (a[i], 0);
	}
	printf ("%d", ans);
}

