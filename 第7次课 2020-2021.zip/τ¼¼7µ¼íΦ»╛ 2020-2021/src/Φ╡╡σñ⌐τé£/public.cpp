#include <cstdio>
#include <cstring>
int n, m;
const int N = 1005;
char a[N], b[N];
int mem[N][N];
int max (int a, int b) {
	return a > b ? a : b;
}
int search (int step1, int step2) {
	if (mem[step1][step2] != -1)
		return mem[step1][step2];
	if (step1 == n + 1 && step2 == m + 1)
		return 0;
	int res = 0;
	if (step1 <= n)
		res = max (res, search (step1 + 1, step2));
	if (step2 <= m)
		res = max (res, search (step1, step2 + 1));
	
	if (a[step1] == b[step2] && step1 <= n && step2 <= m)
		res = max (res, search (step1 + 1, step2 + 1) + 1);
	return mem[step1][step2] = res;
}
int main () {
	freopen ("public.in", "r", stdin);
	freopen ("public.out", "w", stdout); 
	memset (mem, -1, sizeof(mem));
	scanf ("%s%s", a + 1, b + 1);
	n = strlen (a + 1);
	m = strlen (b + 1);
	int ans = search (1, 1);
	printf ("%d", ans);
}
