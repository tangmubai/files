#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int w[205],c[205];
int f[5003]={0};
int main(){freopen("bag.in","r",stdin);freopen("bag.out","w",stdout);
	ll n,m;
	scanf("%d%d",&n,&m);
	for(ll i=1;i<=n;i++)scanf("%d%d",&w[i],&c[i]);
	for(ll i=1;i<=n;i++){
		for(ll j=m;j>=w[i];j--)f[j]=max(f[j],f[j-w[i]]+c[i]);
	}
	printf("%d",f[m]);
	return 0;
}



