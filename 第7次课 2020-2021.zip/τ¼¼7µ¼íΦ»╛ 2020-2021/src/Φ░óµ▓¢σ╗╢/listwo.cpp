#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll long long
#define maxs 20070707

using namespace std;
ll ans[100]={0};
ll sum[100]={0};
int main(){freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	ll n;
	scanf("%lld",&n);
	ans[2]=2ll;sum[2]=2ll;
	for(ll i=3;i<=n;i++){
		sum[i]=sum[i-1]*2ll+2ll;
		ans[i]=ans[i-1]+sum[i];
	}
	printf("%lld",ans[n]);
	return 0;
}



