#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int ans=1;
int f[10004]={0};
int a[10004]={0};
int main(){freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout);
	ll n;
	scanf("%d",&n),f[1]=1;
	for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
	for(ll i=2;i<=n;i++){
		f[i]=1;
		for(ll j=1;j<=i-1;j++)if(a[i]>a[j])f[i]=max(f[i],f[j]+1);
		ans=max(ans,f[i]);
	}
	printf("%d",ans);
	return 0;
}
