#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int a[100005]={0};
int mx(int a,int b){return a>b ? a : b;}
int main(){freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	ll n;
	ll sum=0;
	ll ans=0;
	scanf("%d",&n);
	for(ll i=1;i<=n;i++)scanf("%d",&a[i]);
	ans=a[1];
	sum=mx(0,a[1]);
	for(ll i=2;i<=n;i++){
		sum=mx(0,a[i]+sum);
		ans=max(sum,ans);
	}
	printf("%d",ans);
	return 0;
}
