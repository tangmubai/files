#include<iostream>
#include<stdio.h>
#include<cstdio>
#include<algorithm>
#include<string.h>
#include<cstring>
#include<cmath>
#include<math.h>
#include<string>
#define ll register int
#define maxs 20070707

using namespace std;
int f[1005][1005]={0};
char a[1005];
char b[1005];
int main(){freopen("public.in","r",stdin);freopen("public.out","w",stdout);
	scanf("%s\n%s",a+1,b+1);
	ll n=strlen(a+1),m=strlen(b+1);
	f[1][1]=(a[1]==b[1]);
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=m;j++){
			f[i][j]=max(f[i][j],f[i-1][j]);
			f[i][j]=max(f[i][j],f[i][j-1]);
			f[i][j]=max(f[i][j],f[i-1][j-1]+(a[i]==b[j] ? 1 : 0));
		}
	}
	printf("%d",f[n][m]);
	return 0;
}



