#include<stdio.h>
#include<iostream>
using namespace std;
int f[5005];
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	int n,m,i,j,a,b;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++){
		scanf("%d%d",&a,&b);
		for(j=m;j>=a;j--){
			f[j]=max(f[j],f[j-a]+b);
		}
	}
	printf("%d",f[m]);
	return 0;
}
