#include<stdio.h>
using namespace std;
long long a[25]={0ll,0ll,2ll,8ll,22ll,52ll,114ll,240ll,494ll,1004ll,2026ll,4072ll,8166ll,16356ll,32738ll,65504ll,131038ll,262108ll,524250ll,1048536ll,2097110ll};
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	int k;
	scanf("%d",&k);
	printf("%lld",a[k]);
	return 0;
}
