#include<stdio.h>
#include<algorithm>
using namespace std;
int b[1005];
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	int n,i,k,len=1;
	scanf("%d%d",&n,&k);
	b[1]=k;
	for(i=2;i<=n;i++){
		scanf("%d",&k);
		if(k>b[len])b[++len]=k;
		else{
			int j=lower_bound(b+1,b+1+len,k)-b;
			b[j]=k;
		}
	}
	printf("%d",len);
	return 0;
}
