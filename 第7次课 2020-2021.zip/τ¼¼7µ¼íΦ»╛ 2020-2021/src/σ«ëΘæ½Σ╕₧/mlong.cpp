#include<stdio.h>
using namespace std;
int a[100005];
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	int n,i;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	int ans=-2147483647,sum=0;
	for(i=1;i<=n;i++){
		sum+=a[i];
		if(sum>ans)ans=sum;
		if(sum<0)sum=0;
	}
	printf("%d",ans);
	return 0;
}
