#include<stdio.h>
#include<iostream>
using namespace std;
char a[1005],b[1005];
int f[1005][1005];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s%s",a+1,b+1);
	int i,j;
	for(i=1;a[i];i++){
		for(j=1;b[j];j++){
			if(a[i]==b[j]){
				f[i][j]=f[i-1][j-1]+1;
			}
			f[i][j]=max(f[i][j],max(f[i-1][j],f[i][j-1]));
		}
	}
	printf("%d",f[i-1][j-1]);
	return 0;
}
