#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
#include<map>
using namespace std;
#define itn int
int n,m,w[205],c[205],f[5005];
//int dfs(int x,int y){
//	if(f[x][y]!=-1)return 0;
//	if(x>n)return 0;
//	int tmp1=0,tmp2=0;
//	if(y-w[x]>=0)tmp1=dfs(x+1,y-w[x])+c[x];
//	tmp2=dfs(x+1,y);
//	return f[x][y]=max(tmp1,tmp2);
//}
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d %d",&w[i],&c[i]);
//	memset(f,-1,sizeof(f));
	for(int i=1;i<=n;++i){
		for(int j=m;j>=w[i];--j){
			f[j]=max(f[j],f[j-w[i]]+c[i]);
		}
	}
	printf("%d\n",f[m]);
	return 0;
}
