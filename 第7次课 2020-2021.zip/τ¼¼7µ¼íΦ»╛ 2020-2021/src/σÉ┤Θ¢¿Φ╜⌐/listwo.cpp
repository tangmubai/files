#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
#include<map>
using namespace std;
#define itn int
long long ans, k;
int main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	scanf("%lld",&k);
	ans=((1ll<<k)-k-1ll)*2ll;
	printf("%lld",ans);
}
