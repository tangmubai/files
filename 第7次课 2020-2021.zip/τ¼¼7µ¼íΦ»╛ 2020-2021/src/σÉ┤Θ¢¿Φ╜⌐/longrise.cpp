#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int n,a[1005];
int f[1005][10005];
int dfs(int x,int y){
	if(f[x][y]!=-1)return f[x][y];
	if(x>=n)return 0;
	int tmp1=0,tmp2=0;
	for(int i=x+1;i<=n;i++){
		if(a[i]>y)tmp1=max(tmp1,dfs(i,max(y,a[i]))+1);
		tmp2=max(tmp2,dfs(i,max(y,a[i])));
	}
	return f[x][y]=max(tmp1,tmp2);
}
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	memset(f,-1,sizeof(f));
	printf("%d",dfs(1,-1)+1);
	return 0;
}
