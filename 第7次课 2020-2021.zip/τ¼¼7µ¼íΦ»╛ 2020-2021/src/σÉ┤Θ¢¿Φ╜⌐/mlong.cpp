#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
#include<map>
using namespace std;
#define itn int
int n,sum,ans,maxn=-10001;
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	int x;
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		sum+=x;
		if(sum<0)sum=0;
		ans=max(ans,sum);
		maxn=max(x,maxn);
	}
	if(maxn>=0)printf("%d",ans);
	else printf("%d",maxn);
	return 0;
}
