#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
#include<map>
using namespace std;
#define itn int
char a[1005],b[1005];
int n,m,f[1005][1005];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s",a+1);
	scanf("%s",b+1);
	m=strlen(a+1);
	n=strlen(b+1);
	for(itn i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			f[i][j]=max(f[i-1][j],f[i][j-1]);
			if(a[i]==b[j])f[i][j]=f[i-1][j-1]+1;
		}
	}
	printf("%d",f[m][n]);
	return 0;
}
