#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
long long ans,t;
int n;
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++){
		ans=ans*2+t;
		t+=2;
	}
	cout<<ans<<endl;
	return 0;
}


