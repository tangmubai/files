#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[1100],b[1100];
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	memset(b,127,sizeof(b));
	b[1]=a[1];
	int num=1;
	for(int i=2;i<=n;i++){
		int j=lower_bound(b+1,b+num+1,a[i])-b;
		if(j>num){
			b[++num]=a[i];	
		}
		else{
			b[j]=a[i];
		}
	}
	cout<<num<<endl;
	return 0;
}

