#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int a[102000],f[100100],n,maxn=-2147483647;
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		f[i]=max(f[i],f[i-1])+a[i];
	}
	for(int i=1;i<=n;i++){
		maxn=max(maxn,f[i]);
	}
	cout<<maxn<<endl;
	return 0;
}


