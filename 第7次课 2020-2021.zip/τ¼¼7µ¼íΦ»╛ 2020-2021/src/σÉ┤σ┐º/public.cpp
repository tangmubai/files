#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
char a[1100],b[1100];
int dp[1100][1100];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s",a+1);
	scanf("%s",b+1);
	int la=strlen(a+1);
	int lb=strlen(b+1);
	for(int i=1;i<=la;i++){
		for(int j=1;j<=lb;j++){
			if(a[i]==b[j]) dp[i][j]=dp[i-1][j-1]+1;
			else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
		}
	}
	printf("%d\n",dp[la][lb]);
	return 0;
}
