#include<stdio.h>
#define N 5001
inline char nc()
{
	static char buf[999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
int ans[N];
inline void max(int&x,const int&y){if(x<y)x=y;}
main()
{
	freopen("bag.in","r",stdin);freopen("bag.out","w",stdout);
	register int n,m,v,w;
	for(read(n),read(m);n--;)
	{
		read(w);read(v);
		for(register int i=m;i>=w;--i)max(ans[i],ans[i-w]+v);
	}
	printf("%d",ans[m]);
}
