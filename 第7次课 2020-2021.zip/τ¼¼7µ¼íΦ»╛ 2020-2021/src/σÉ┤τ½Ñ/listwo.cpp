#include<stdio.h>
#define N 61
#define int long long
int ans1[N][N][N],ans2[N][N][N];
inline int dfs1(const int&len,const int&l,const int&r);
inline int dfs2(const int&len,const int&l,const int&r);
main()
{
	freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	register int n,tot=0;scanf("%lld",&n);
	for(register int i=2;i<=n;++i)for(register int j=0;j<n;++j)for(register int k=0;k<n;++k)
		tot+=dfs1(i,j,k)+dfs2(i,j,k);
	printf("%lld",tot);
}
inline int dfs1(const int&len,const int&l,const int&r)
{
	if(r-l+1<len)return 0;
	if(len==2)return 1;
	if(!ans1[len][l][r])for(register int i=l+1;i<=r;++i)ans1[len][l][r]+=dfs2(len-1,i,r);
	return ans1[len][l][r];
}//the last one is the smallest
inline int dfs2(const int&len,const int&l,const int&r)
{
	if(r-l+1<len)return 0;
	if(len==2)return 1;
	if(!ans2[len][l][r])for(register int i=l;i<r;++i)ans2[len][l][r]+=dfs1(len-1,l,i);
	return ans2[len][l][r];
}//the last one is the biggest
