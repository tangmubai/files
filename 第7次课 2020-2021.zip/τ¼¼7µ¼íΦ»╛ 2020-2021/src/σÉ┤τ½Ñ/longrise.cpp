#include<stdio.h>
#include<algorithm>
#define N 1001
using namespace std;
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register char c=nc();for(;c<'0'||'9'<c;c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());
}
int ans[N];
main()
{
	freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout);
	register int n,a,sz=0;
	for(read(n);n--;)
	{
		read(a);
		if(!sz||a>ans[sz-1])ans[sz++]=a;
		else*lower_bound(ans,ans+sz,a)=a;
	}
	printf("%d",sz);
}
