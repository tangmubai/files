#include<stdio.h>
inline char nc()
{
	static char buf[99999],*l,*r;
	return l==r&&(r=(l=buf)+fread(buf,1,99999,stdin),l==r)?EOF:*l++;
}
inline void read(int&x)
{
	register bool t=0;register char c=nc();for(;(c<'0'||'9'<c)&&c!=EOF;t|=c=='-',c=nc());
	for(x=0;'0'<=c&&c<='9';x=(x<<3)+(x<<1)+(c^48),c=nc());if(t)x=-x;
}
main()
{
	freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	register int n,a,ans=-(1<<30),sum=0;
	for(read(n);n--;)
	{
		read(a);
		if(sum<0)sum=0;
		sum+=a;
		if(sum>ans)ans=sum;
	}
	printf("%d",ans);
}
