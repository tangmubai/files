#include<stdio.h>
#include<string.h>
#define N 1024
char a[N],b[N];int ans[2][N];
inline void max(int&x,const int&y){if(x<y)x=y;}
main()
{
	freopen("public.in","r",stdin);freopen("public.out","w",stdout);
	register int n,m;
	scanf("%s%s",a+1,b+1);n=strlen(a+1);m=strlen(b+1);
	for(register int i=0;i<=n;++i)for(register int j=0;j<=m;++j)if(i||j)
	{
		if(i&&j)ans[i&1][j]=ans[i&1^1][j-1]+(a[i]==b[j]);
		else ans[i&1][j]=-(1<<30);
		if(i)max(ans[i&1][j],ans[i&1^1][j]);
		if(j)max(ans[i&1][j],ans[i&1][j-1]);
	}
	printf("%d",ans[n&1][m]);
}
