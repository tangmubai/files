#include <cstdio>
#include <algorithm>
using namespace std;

const int N = 205;
const int M = 5005;

int f[M], c[N], w[N];

int main() {
	
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	
	int n, m;
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++)
		scanf("%d %d", &w[i], &c[i]);
	
	for (int i = 1; i <= n; i++) {
		for (int j = m; j >= w[i]; j--) {
			f[j] = max(f[j], f[j - w[i]] + c[i]);
		}
	}
	
	printf("%d\n", f[m]);
	return 0;
}
