#include <cstdio>
#include <queue>
#define ll long long
using namespace std;

ll k;
ll ans;

ll f[1005];

int main() {
	
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	
	scanf("%lld", &k);
	ll p = 2;
	for (int i = 2; i <= k; i++, p += 2) {
		f[i] = f[i - 1] * 2 + p;
	}
	
	printf("%lld\n", f[k]);
}
