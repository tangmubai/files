#include <cstdio>
#include <algorithm>
using namespace std;

const int N = 100005;

int f[N], a[N];

int main() {
	
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		f[i] = max(f[i - 1] + a[i], a[i]);
		if (ans < f[i])
			ans = f[i];
	}
	
	printf("%d\n", ans);
	return 0;
}
