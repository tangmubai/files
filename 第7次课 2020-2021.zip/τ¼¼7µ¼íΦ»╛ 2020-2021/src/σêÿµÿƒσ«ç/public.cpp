#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int f[1005][1005];
char a[1005], b[1005];

int main() {
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s %s", a + 1, b + 1);
	int len = strlen(a + 1), len1 = strlen(b + 1);
	for (int i = 1; i <= len; i++) {
		for (int j = 1; j <= len1; j++) {
			if (a[i] == b[j])
				f[i][j] = f[i - 1][j - 1] + 1;
			else
				f[i][j] = max(f[i - 1][j], f[i][j - 1]);
		}
	}
	printf("%d\n", f[len][len1]);
	return 0;
}
