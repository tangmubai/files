#include <stdio.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = -1; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = w ? x : -x;
}
int n, m, w[205], c[205], f[5005];
int main(void) {
	freopen("bag.in", "r", stdin);
	freopen("bag.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; ++i) {read(w[i]); read(c[i]);}
	for (int i = 1; i <= n; ++i)
		for (int j = m; j >= w[i]; --j)
			f[j] = f[j - w[i]] + c[i] > f[j] ? f[j - w[i]] + c[i] : f[j];
	printf("%d\n", f[m]);
	return 0;
}

