#include <stdio.h>
typedef long long LL;
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = -1; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = w ? x : -x;
}
int k; LL f[25];
int main(void) {
	freopen("list.in", "r", stdin);
	freopen("list.out", "w", stdout);
	read(k); f[1] = 0; f[2] = 2;
	for (int i = 3; i <= k; ++i)
		f[i] = (f[i - 1] << 1) + (i - 1 << 1);
	printf("%lld\n", f[k]);
	return 0;
}
