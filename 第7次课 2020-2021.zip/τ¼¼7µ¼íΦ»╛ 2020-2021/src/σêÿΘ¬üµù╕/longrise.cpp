#include <stdio.h>
#include <algorithm>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = -1; char c = getchar();
	for (; c < '0' || c > '9'; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = w ? x : -x;
}
int n, a[1005], d[1005], cnt;
int main(void) {
	freopen("longrise.in", "r", stdin);
	freopen("longrise.out", "w", stdout);
	read(n); for (int i = 1; i <= n; ++i) read(a[i]);
	cnt = 0; d[++cnt] = a[1];
	for (int i = 2; i <= n; ++i)
		if (a[i] > d[cnt]) d[++cnt] = a[i];
		else {
			int l = std:: lower_bound(d + 1, d + 1 + cnt, a[i]) - d;
			d[l] = a[i];
		}
	printf("%d\n", cnt);
	return 0;
}

