#include <stdio.h>
template<typename TYPE>
inline void read(TYPE &x) {
	x = 0; int w = -1; char c = getchar();
	for (; (c < '0' || c > '9') && c != EOF; c = getchar())
		if (c == '-') w = ~w;
	for (; c >= '0' && c <= '9'; c = getchar())
		x = (x << 3) + (x << 1) + (c ^ 48);
	x = w ? x : -x;
}
int n, a[100005], f[100005];
int main(void) {
	freopen("mlong.in", "r", stdin);
	freopen("mlong.out", "w", stdout);
	read(n); for (int i = 1; i <= n; ++i) read(a[i]);
	f[0] = 0; int ans = 0;
	for (int i = 1; i <= n; ++i) {
		if (f[i - 1] + a[i] >= 0)
			f[i] = f[i - 1] + a[i];
		else
			f[i] = 0;
		ans = f[i] > ans ? f[i] : ans;
	}
	printf("%d\n", ans);
	return 0;
}
