#include <stdio.h>
#include <string.h>
int n, m, f[1005][1005];
char a[1005], b[1005];
inline int mx(int p, int q) {
	return p > q ? p : q;
}
int main(void) {
	freopen("public.in", "r", stdin);
	freopen("public.out", "w", stdout);
	scanf("%s %s", a + 1, b + 1);
	n = strlen(a + 1); m = strlen(b + 1);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j) {
			f[i][j] = mx(f[i - 1][j], f[i][j - 1]);
			if (a[i] == b[j]) f[i][j] = mx(f[i - 1][j - 1] + 1, f[i][j]);
		}
	printf("%d\n", f[n][m]);
	return 0;
}
