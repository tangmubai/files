#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=5e3+5;
int n,m,w,c;
int f[N];
int main()
{
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&w,&c);
		for(int j=m;j>=w;j--)
		{
			f[j]=max(f[j],f[j-w]+c);
		}
	}
	printf("%d",f[m]);
	return 0;
}
