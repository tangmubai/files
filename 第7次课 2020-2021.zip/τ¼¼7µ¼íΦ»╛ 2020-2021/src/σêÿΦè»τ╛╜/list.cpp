#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
#define ll long long
using namespace std;
const int N=65;
ll n,ans;
ll vis[N],a[N];
void dfs(ll i)
{
	if(i>2) 
	{
		ans++;
	}
	if(i>n) return;
	if(i<=2)
	{
		for(ll j=1;j<=n;j++)
		{
			if(vis[j]) continue;
			vis[j]=1;
			a[i]=j;
			dfs(i+1);
			a[i]=0;
			vis[j]=0;
		}
	}
	else if(a[i-2]<a[i-1])
	{
		for(ll j=1;j<a[i-2];j++)
		{
			if(vis[j]) continue;
			vis[j]=1;
			a[i]=j;
			dfs(i+1);
			a[i]=0;
			vis[j]=0;
		}
	}
	else if(a[i-2]>a[i-1])
	{
		for(ll j=a[i-2]+1;j<=n;j++)
		{
			if(vis[j]) continue;
			vis[j]=1;
			a[i]=j;
			dfs(i+1);
			a[i]=0;
			vis[j]=0;
		}
	}
	return;
}
int main()
{
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	scanf("%lld",&n);
	dfs(1);
	printf("%lld",ans);
	return 0;
}
