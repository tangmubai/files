#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e3+5;
int n,a,ans;
int sum[N];
int main()
{
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	memset(sum,0x3f,sizeof(sum));
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a);
		int j=lower_bound(sum+1,sum+ans+1,a)-sum;
		if(j>=1&&j<=ans)
		{
			sum[j]=a;
		}
		else sum[++ans]=a;
	}
	printf("%d",ans);
	return 0;
}
