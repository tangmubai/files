#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<map>
#include<queue>
using namespace std;
const int N=1e5+5;
int n,a,ans;
int f[N];
int main()
{
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a);
		f[i]=max(f[i-1],0)+a;
		ans=max(ans,f[i]);
	}
	printf("%d",ans);
	return 0;
}
