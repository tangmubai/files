#include<stdio.h>
#include<algorithm>
using namespace std;
int w[200],c[200],f[5010];
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	int n,v;scanf("%d %d",&n,&v);
	for(int i=1;i<=n;i++)scanf("%d %d",&w[i],&c[i]);
		for(int i=1;i<=n;i++)
			for(int j=v;j>=w[i];j--)
			   f[j]=max(f[j],f[j-w[i]]+c[i]);
	printf("%d\n",f[v]);		
}
