#include<stdio.h>
long long s;long long ans;
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	scanf("%lld",&s);
	ans=((1<<s)-s-1)*2;
	printf("%lld",ans);
}
