#include<stdio.h>
int a[1010],f[1010];
int main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	int n,ans=0;scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=2;i<=n;i++){
        f[i]=1;
	    for(int j=1;j<n;j++)
	        if(a[i]<a[j]&&f[j]+1>f[i]){
	           f[i]=f[j]+1;
		}
	}
	
	for(int i=1;i<=n;i++){
		if(f[i]>ans)ans=f[i];
	}
	printf("%d",ans);
}
