#include<stdio.h>
#include<cstring>
#include<algorithm>
using namespace std;
int dp[1010][1010];
char a[1010],b[1010];
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s",a);scanf("%s",b);
	int len1=strlen(a),len2=strlen(b);
	for(int i=2;i<=len1;i++){
	    for(int j=1;j<len2;j++)
	        dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
	}
	printf("%d",dp[len1][len2]);
	return 0;
}
