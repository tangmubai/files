#include<stdio.h>
#include<algorithm>
using namespace std;
int f[5010],n,c[210],m,w[210];
int main(){
	freopen("bag.in","r",stdin);freopen("bag.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d %d",&w[i],&c[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=m;j>=w[i];j--)f[j]=max(f[j-w[i]]+c[i],f[j]);
	}
	printf("%d",f[m]);
}

