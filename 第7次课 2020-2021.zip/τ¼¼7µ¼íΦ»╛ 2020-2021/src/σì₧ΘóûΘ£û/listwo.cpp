#include<stdio.h>
using namespace std;
long long n,f[100];
int main(){
	freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)f[i]=2*(f[i-1]+i);
	printf("%lld",f[n-1]);
	return 0;
}
