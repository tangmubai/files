#include<stdio.h>
#include<algorithm>
using namespace std;
int f[100010],n,a[100010],ans=-2147483646;
int main(){
	freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		a[i]+=a[i-1];
	}
	for(int i=1;i<=n;i++){
		f[i]=-2147483646;
		for(int j=i-1;j>0;j--){
			f[i]=max(f[i],a[i]-a[j]);
		}
	}
	for(int i=1;i<=n;i++)ans=max(ans,f[i]);
	printf("%d",ans);
}

