#include<cstdio>
using namespace std;
int f[5010];
int maxx(int a,int b){
	return a>b?a:b;
}
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	int n,m,w,c;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&w,&c);
		for(int j=m;j>=w;j--)
			f[j]=maxx(f[j],f[j-w]+c);
	}
	printf("%d\n",f[m]);
	return 0;
}
