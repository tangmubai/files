#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string>
#include <set>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

int n, m;
int w[N], c[N], f[N];

int main() {
	ios :: sync_with_stdio(false);
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	cin >> n >> m;
	for (int i = 1; i <= n; ++ i) {
		cin >> w[i] >> c[i];
	}
	for (int i = 1; i <= n; ++ i) {
		for (int j = m; j >= w[i]; -- j) {
			f[j] = Max(f[j], f[j - w[i]] + c[i]);
		}
	}
	cout << f[m] << endl;
	return 0;
}
/*
*/

