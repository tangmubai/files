#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string>
#include <set>
using namespace std;
typedef long long ll;
const int N = 65 + 5;

ll k;

int main() {
	ios :: sync_with_stdio(false);
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	cin >> k;
	ll ans = 2 * ((1LL << k) - k - 1);
	cout << ans << endl;
	return 0;
}
/*
12
21

12
13
312
213
21
31
32
23

12
13
14
21
23
24
31
32
34
41
42
43
213
214
241
312
341
342
1324
1342
2314
3142
3241
*/

