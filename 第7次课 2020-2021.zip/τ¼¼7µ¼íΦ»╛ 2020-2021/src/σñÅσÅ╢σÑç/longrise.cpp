#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string>
#include <set>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

int n;
int f[N], a[N];

int main() {
	ios :: sync_with_stdio(false);
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	cin >> n;
	int ans = 0;
	for (int i = 1; i <=n; ++ i) {
		cin >> a[i];
		for (int j = 1; j < i; ++ j) {
			if (a[i] < a[j] and f[i] <= f[j]) f[i] = f[j] + 1;
		}
		ans = Max(f[i], ans);
	}
	cout << ans + 1 << endl;
	return 0;
}
/*
*/

