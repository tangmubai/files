#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string>
#include <set>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

int n, ans;
int a[N], f[N];

int main() {
	ios :: sync_with_stdio(false);
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	cin >> n;
	f[0] = ans = -0X7FFFFFFF;
	for(int i = 1; i <= n; ++ i) {
		cin >> a[i];
		f[i] = Max(a[i], f[i - 1] + a[i]);
		ans = Max(f[i], ans);
	}
	cout << ans << endl;
	return 0;
}
/*
*/

