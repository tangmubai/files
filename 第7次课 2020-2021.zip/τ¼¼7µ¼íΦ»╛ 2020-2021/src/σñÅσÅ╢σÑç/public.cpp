#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
typedef long long ll;
const int N = 1e3 + 5;

int Max(int x, int y) {
	if (x > y) return x;
	else return y;
}

string a, b;
int f[N][N], ans;

int main() {
	ios :: sync_with_stdio(false);
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	cin >> a >> b;
	int la = a.size(), lb = b.size();
	for (int i = 0; i < la; ++ i) {
		for (int j = 0; j < lb; ++ j) {
			if (a[i] == b[j]) f[i + 1][j + 1] = f[i][j] + 1;
			else f[i + 1][j + 1] = Max(f[i + 1][j], f[i][j + 1]);
			ans = Max(f[i + 1][j + 1], ans);
		}
	}
	cout << ans << endl;
	return 0;
}
/*
 abcdgh
a111111
e111111
d111222
f111222
h111223
b121223
abcd
abcd
abcdgh
aedfhb
*/
