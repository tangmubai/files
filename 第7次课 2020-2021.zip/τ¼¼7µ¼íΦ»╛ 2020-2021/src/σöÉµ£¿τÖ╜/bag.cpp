#include <cstdio>
#include <cstring>

const int N = 5001, INF = 0x7f7f7f7f;

int dp[N];

template <typename Tp>
inline void read(Tp &num) {
    Tp neg = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') neg = -1;
        ch = getchar();
    } 
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
    num *= neg;
}

int main() {
    freopen("bag.in", "r", stdin);
    freopen("bag.out", "w", stdout);
    int n, m, ans = -INF;
    read(n); read(m);
    memset(dp, -1, sizeof dp); dp[0] = 0;
    for (int i = 1; i <= n; i++) {
        int wei, val;
        read(wei); read(val);
        if (wei < 0 || val < 0) continue;
        for (int j = m - wei; j >= 0; j--)
            if (dp[j] >= 0 && dp[j] + val > dp[j + wei])
                dp[j + wei] = dp[j] + val;
    }
    for (int i = 0; i <= m; i++)
        if (dp[i] > ans)
            ans = dp[i];
    printf("%d\n", ans);
    return 0;
}
