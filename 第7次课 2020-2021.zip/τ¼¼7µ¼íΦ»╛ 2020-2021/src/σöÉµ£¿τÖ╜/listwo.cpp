#include <cstdio>
#include <cstring>

const int N = 100;

long long dp[N];

int main() {
    freopen("listwo.in", "r", stdin);
    freopen("listwo.out", "w", stdout);
    int n;
    scanf("%d", &n);
    dp[1] =0; dp[2] = 2; dp[3] = 8;
    for (int i = 4; i <= n; i++) {
        dp[i] = dp[i - 1] * 2 + (i - 1) * 2;
    }
    printf("%lld\n", dp[n]);
    return 0;
}
