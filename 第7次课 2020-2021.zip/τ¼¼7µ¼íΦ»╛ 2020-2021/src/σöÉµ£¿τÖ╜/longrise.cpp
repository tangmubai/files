#include <cstdio>

const int N = 1001;

int dp[N], num[N];

template <typename Tp>
inline void read(Tp &num) {
    char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    for (num = 0; ch >= '0' || ch > '9'; ch = getchar()) num = (num << 3) + (num << 1) + (ch ^ '0');
}

int main() {
    freopen("longrise.in", "r", stdin);
    freopen("longrise.out", "w", stdout);
    int n, ans = 0;
    read(n);
    num[0] = -1;
    for (int i = 1; i <= n; i++) read(num[i]);
    for (int i = 1; i <= n; i++) {
        dp[i] = 1;
        for (int j = 0; j <= n; j++)
            if (num[j] < num[i] && dp[j] + 1 > dp[i])
                dp[i] = dp[j] + 1;
        if (dp[i] > ans) ans = dp[i];
    }
    printf("%d\n", ans);
    return 0;
}