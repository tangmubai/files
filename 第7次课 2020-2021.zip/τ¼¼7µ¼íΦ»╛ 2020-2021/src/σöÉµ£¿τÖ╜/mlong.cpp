#include <cstdio>

const int INF = 0x7f7f7f7f;


int main() {
    freopen("mlong.in", "r", stdin);
    freopen("mlong.out", "w", stdout);
    int n, sum = 0, ans = -INF;
    read(n);
    for (int i = 1; i <= n; i++) {
        int num;
        scnaf("%d", &n);
        sum += num;
        if (sum > ans) ans = sum;
        if (sum < 0) sum = 0;
    }
    printf("%d\n", ans);
    return 0;
}
