#include <cstdio>
#include <cstring>

const int N = 1001;

int dp[N][N];
char s1[N], s2[N];

template <typename Tp>
inline Tp max(const Tp num1, const Tp num2) {
    return num1 > num2 ? num1 : num2;
}

int main() {
    freopen("public.in", "r", stdin);
    freopen("public.out", "w", stdout);
    int n, m, ans = 0;
    scanf("%s%s", s1 + 1, s2 + 1);
    n = strlen(s1 + 1); m = strlen(s2 + 1);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            if (s1[i] == s2[j]) dp[i][j] = max(dp[i][j], dp[i - 1][j - 1] + 1);
            //else dp[i][j] = max(dp[i][j], dp[i - 1][j - 1]);
            if (dp[i][j] > ans) ans = dp[i][j];
        }
    printf("%d\n", ans);
    return 0;
}
