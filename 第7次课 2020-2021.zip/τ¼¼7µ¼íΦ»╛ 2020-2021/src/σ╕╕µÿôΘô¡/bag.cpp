#include <stdio.h>
using namespace std;

int read(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=a1*10+ch-'0';
		ch=getchar();
	}
	return a1*k1;
}
int w[205],v[205],f[5005];
inline int max(int x,int y){
	return x>y?x:y;
}
main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=n;++i){
		w[i]=read();v[i]=read();
	}
	for(int i=1;i<=n;++i){
		for(int j=m;j>=w[i];--j){
			f[j]=max(f[j],f[j-w[i]]+v[i]);
		}
	}

	printf("%d\n",f[m]);
	return 0;
}


