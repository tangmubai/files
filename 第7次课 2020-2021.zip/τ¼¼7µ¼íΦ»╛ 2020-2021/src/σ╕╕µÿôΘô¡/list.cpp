#include <stdio.h>
using namespace std;

int read(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=a1*10+ch-'0';
		ch=getchar();
	}
	return a1*k1;
}
int n,ans=0;
long long f[66];
//void dfs(int x,int last,int laster,int k){
//	if(k>n){
//		return ;
//	}
///*
//1  2
//1  3
//2  1
//2  1  3
//2  3
//2  3  1
//3  1
//3  2
//
//
//*/
//	ans++;
//	if(last>laster){
//		for(int i=laster-1;i>0;--i){
//			if(!vis[i]){
//				vis[i]=true;
//				dfs(i,x,last,k+1);
//				vis[i]=false;
//			}
//		}
//	}
//	if(last<laster){
//		for(int i=laster+1;i<=n;++i){
//			if(!vis[i]){
//				vis[i]=true;
//				dfs(i,x,last,k+1);
//				vis[i]=false;
//			}
//		}
//	}
//}
main(){
	freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	n=read();
	f[1]=0ll;f[2]=2ll;
	for(int i=3;i<=n;++i){
		f[i]=f[i-1]*2ll+(long long)(i-1)*2ll;
	}
	printf("%lld\n",f[n]);
	return 0;
}


/*
k=2		1
k=3     8
k=4     1
*/

