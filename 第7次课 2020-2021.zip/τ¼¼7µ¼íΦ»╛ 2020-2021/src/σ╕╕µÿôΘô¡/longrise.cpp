#include <stdio.h>
#include <algorithm>
#include <cstring>
using namespace std;

int a[1005],f[1005];
main(){
	freopen("longrise.in","r",stdin);
	freopen("longrise.out","w",stdout);
	int n,len=0;scanf("%d",&n);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]);
	memset(f,-1,sizeof f);
	for(int i=1;i<=n;++i){
		if(a[i]>f[len]){
			f[++len]=a[i];
		}
		else {
			int sb=lower_bound(f+1,f+1+len,a[i])-f;
			f[sb]=a[i];
		}
	}
	printf("%d\n",len);
	return 0;
}

