#include <stdio.h>
#include <cstring>
using namespace std;

int read(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=a1*10+ch-'0';
		ch=getchar();
	}
	return a1*k1;
}
int a[100005],f[100005];
inline int max(int x,int y){
	return x>y?x:y;
}
main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	int n=read(),maxn,ans=-0x3f3f3f,maxm;
//	memset(f,-0x3f3f3f,sizeof f);
	a[1]=read();maxn=a[1];maxm=a[1];
	for(int i=2;i<=n;++i){
		a[i]=read();
		if(a[i]<0)maxn=0;
		else maxn+=a[i];
		ans=max(ans,maxn);

//		f[i]=max(f[i-1]+a[i],a[i]);
//		ans=max(f[i],ans);
	}
	printf("%d\n",ans);
	return 0;
}


