#include <stdio.h>
#include <cstring>
using namespace std;

char a[1005],b[1005];
int f[1005][1005];
inline int max(int x,int y){
	return x>y?x:y;
}
main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	int n,m;n=m=0;
	scanf("%s",a+1);scanf("%s",b+1);
	n=strlen(a+1);m=strlen(b+1);
//	printf("%d %d\n",n,m);
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			f[i][j]=max(f[i-1][j],f[i][j-1]);
			if(a[i]==b[j])f[i][j]=f[i-1][j-1]+1;
		}
	}
	printf("%d\n",f[n][m]);
	return 0;
	
}

