#include <cstdio>
#include <cstring>
inline int ma_x(int p,int q){return p>q?p:q;}
int w[201],v[201],n,s,f[201][5001];
int main(){
	freopen("bag.in","r",stdin);
	freopen("bag.out","w",stdout);
	scanf("%d%d",&n,&s);
	for(int i=1;i<=n;i++)scanf("%d%d",&w[i],&v[i]);
	for(int i=1;i<=n;i++)
		for(int j=s;j>=0;j--)
			if(j>=w[i])f[i][j]=ma_x(f[i-1][j],f[i-1][j-w[i]]+v[i]);
			else f[i][j]=f[i-1][j];
	printf("%d\n",f[n][s]);
	return 0;
}
