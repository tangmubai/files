/*#include <cstdio>
#include <cstring>
#define rg register
typedef long long ll;
inline int ma_x(int p,int q){return p>q?p:q;}
int n,a[61];
bool vis[61];
ll ans;
void search(int i){
	if(i>2)++ans;
	if(i>n)return ;
	for(rg int j=1;j<=n;j++){
		if(vis[j])continue;
		if(i>2){
			if(a[i-1]>a[i-2]&&j>a[i-2])continue;
			if(a[i-1]<a[i-2]&&j<a[i-2])continue;
		}
		a[i]=j;
		vis[j]=1;
		search(i+1);
		vis[j]=0;
	}
}
int main(){
		freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
//	scanf("%d",&n);
	for(n=1;n<=20;n++){
		ans=0;
		search(1);
		printf("%lld,",ans);
	}
	return 0;
}*/
#include <cstdio>
#include <cstring>
long long ans[21]={0,0,2,8,22,52,114,240,494,1004,2026,4072,8166,16356,32738,65504,131038,262108,524250,1048536,2097110};
int main(){
		freopen("list.in","r",stdin);
	freopen("list.out","w",stdout);
	int n; scanf("%d",&n);
	printf("%lld\n",ans[n]);
	return 0;
}

