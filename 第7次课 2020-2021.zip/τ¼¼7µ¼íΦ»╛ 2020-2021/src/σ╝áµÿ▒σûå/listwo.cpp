#include <cstdio>
#include <cmath>
/*#include <cstring>
#define rg register
typedef long long ll;
inline int ma_x(int p,int q){return p>q?p:q;}
int n,a[61];
bool vis[61];
ll ans;
void search(int i){
	if(i>2)++ans;
	if(i>n)return ;
	for(rg int j=1;j<=n;j++){
		if(vis[j])continue;
		if(i>2){
			if(a[i-1]>a[i-2]&&j>a[i-2])continue;
			if(a[i-1]<a[i-2]&&j<a[i-2])continue;
		}
		a[i]=j;
		vis[j]=1;
		search(i+1);
		vis[j]=0;
	}
}
int main(){
		freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	scanf("%d",&n);
		search(1);
		printf("%lld\n",ans);
	return 0;
}*/
int n;
unsigned long long p[61]={1};
int main(){
	freopen("listwo.in","r",stdin);
	freopen("listwo.out","w",stdout);
	for(int i=1;i<=60;i++)p[i]=(p[i-1]<<1);
	long long ans;
	scanf("%d",&n);
	if(n==0||n==1){
		puts("0");
		return 0;
	}
	ans=p[n+1]-4-(n-1)*2;
	printf("%lld\n",ans);
	return 0;
}

