#include <cstdio>
#include <cstring>
inline int ma_x(int p,int q){return p>q?p:q;}
int n,a[100001],f[100001][2]={0};
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		f[i][0]=ma_x(f[i-1][0],f[i-1][1]);
		f[i][1]=ma_x(0,f[i-1][1])+a[i];
	}
	return printf("%d\n",ma_x(f[n][0],f[n][1]));
}






