#include <cstdio>
#include <algorithm>
#include <cstring>
char s1[1005],s2[1005];
int f[1005][1005]={0};
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	
	scanf("%s",s1+1); scanf("%s",s2+1);
	int len1=strlen(s1+1),len2=strlen(s2+1);
	for(int i=1;i<=len1;i++)
	for(int j=1;j<=len2;j++){
		if(s1[i]==s2[j])f[i][j]=f[i-1][j-1]+1;
		else f[i][j]=std::max(f[i-1][j],f[i][j-1]);
	}
	printf("%d\n",f[len1][len2]);
	return 0;
}
