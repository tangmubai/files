#include <cstdio>
#include <cstring>

using namespace std;

const int MAXN = 100010;

#define mx(x, y) (x) > (y) ? (x) : (y)

int n, m;
long long ans = 0;
long long w[MAXN], v[MAXN];
long long f[MAXN];

int main()
{
	freopen("bag.in", "r", stdin);
	freopen("bag.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i ++ ) scanf("%lld%lld", &w[i], &v[i]);
	for (int i = 1; i <= n; i ++ )
	{
		for (int j = m; j >= w[i]; j -- )
		{
			f[j] = mx(f[j], f[j - w[i]] + v[i]);
		}
	}
	
	printf("%lld\n", f[m]);
	return 0;
}
