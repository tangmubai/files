#include <iostream>

using namespace std;

const int N = 70;

unsigned long long f[N];

int main()
{
	freopen("list.in", "r",stdin);
	freopen("list.out", "w", stdout);
	
	int k, ss = 4;
	cin >> k;
	f[0] = 0;f[1]=2;
	for (int i = 2; i < k; i ++ )
	{
		f[i] = f[i - 1] * 2ll + ss;
		ss += 2;
	}
	cout << f[k - 1] << endl;
	return 0;
}
