#include <cstdio>
#include <cstring>

using namespace std;

const int MAXN = 1010;

#define mx(x, y) (x) > (y) ? (x) : (y)

int n, m, ans = 0;
int a[MAXN], b[MAXN];
int f[MAXN];

int main()
{
	freopen("longrise.in", "r", stdin);
	freopen("longrise.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i ++ ) scanf("%d", &a[i]);
//	for (int i = 1; i <= n; i ++ )	f[i][0] = 0;
//	for (int i = 1; i <= m; i ++ )	f[0][i] = i;
	for (int i = 1; i <= n; i ++ )
	{
		f[i] = 1;
		for (int j = 1; j < i; j ++ )
		{
			if (a[i] > a[j])
				f[i] = mx(f[i], f[j] + 1);
		}
		ans = mx(ans, f[i]);
	}
	
	printf("%d\n", ans);
	return 0;
}
