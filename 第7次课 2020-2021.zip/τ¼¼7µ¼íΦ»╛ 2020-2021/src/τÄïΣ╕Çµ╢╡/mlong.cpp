#include <cstdio>
#include <cstring>

using namespace std;

const int MAXN = 100010;

#define mx(x, y) (x) > (y) ? (x) : (y)

int n, m;
long long ans = 0;
long long a[MAXN], b[MAXN];
long long f[MAXN];

int main()
{
	freopen("mlong.in", "r", stdin);
	freopen("mlong.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i ++ ) scanf("%lld", &a[i]);
//	for (int i = 1; i <= n; i ++ )	f[i][0] = 0;
//	for (int i = 1; i <= m; i ++ )	f[0][i] = i;
	for (int i = 1; i <= n; i ++ )
	{
		f[i] = mx(f[i - 1] + a[i], a[i]);
		ans = mx(ans, f[i]);
	}
	
	printf("%lld\n", ans);
	return 0;
}
