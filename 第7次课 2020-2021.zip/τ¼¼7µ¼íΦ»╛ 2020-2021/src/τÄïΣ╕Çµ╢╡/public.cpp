#include <cstdio>
#include <cstring>

using namespace std;

const int MAXN = 1010;

#define mx(x, y) (x) > (y) ? (x) : (y)

int n, m;
char a[MAXN], b[MAXN];
int f[MAXN][MAXN];

int main()
{
	freopen("public.in", "r", stdin);
	freopen("public.out", "w", stdout);
	scanf("%s\n%s", a + 1, b + 1);
	n = strlen(a + 1);
	m = strlen(b + 1);
//	for (int i = 1; i <= n; i ++ )	f[i][0] = 0;
//	for (int i = 1; i <= m; i ++ )	f[0][i] = i;
	for (int i = 1; i <= n; i ++ )
	{
		for (int j = 1; j <= m; j ++ )
		{
			f[i][j] = -1;
			if (a[i] == b[j])
				f[i][j] = f[i - 1][j - 1] + 1;
			f[i][j] = mx(f[i][j], mx(f[i - 1][j], f[i][j - 1]));
		}
	}
	
	printf("%d\n", f[n][m]);
	return 0;
}
