#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int n,m,ans=0;
int w[205],c[205],f[205][205];
int main(){
	//freopen("bag.in","r",stdin);
	//freopen("bag.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&w[i],&c[i]);
	}
	for(int i=1;i<=n;i++){
		for(int v=m;v>0;v--){
			if(w[i]>v){
				f[i][v]=f[i-1][v];
			}
			else{
				f[i][v]=max(f[i-1][v],f[i-1][v-w[i]]+c[i]);
			}
		}
	}
	printf("%d\n",f[n][m]);
	return 0;
}
