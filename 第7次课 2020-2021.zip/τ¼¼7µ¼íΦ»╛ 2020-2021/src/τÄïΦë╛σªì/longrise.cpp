#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int n,a[1005],b[1005],ans=0;
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		b[i]=1;
	}
	for(int s=2;s<=n;s++){
		for(int t=1;t<s;t++){
			if(a[s]>a[t]&&b[s]<b[t]+1)b[s]=b[t]+1;
		}
	}
	for(int i=1;i<=n;i++)
	    ans=max(ans,b[i]);
	printf("%d\n",ans);
	return 0;
}
