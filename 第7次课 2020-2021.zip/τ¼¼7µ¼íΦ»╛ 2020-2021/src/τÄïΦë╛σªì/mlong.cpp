#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int n,ans=0;
int a[1005],b[1005];
int main(){
	freopen("mlong.in","r",stdin);
	freopen("mlong.out","w",stdout);
	scanf("%d",&n);
	b[0]=a[0];
	for(int i=1;i<n;i++){
		scanf("%d",&a[i]);
		b[i]=max(b[i-1]+a[i],a[i]);
	}
	for(int i=1;i<=n;i++)
	    ans=max(ans,b[i]);
	printf("%d\n",ans);
	return 0;
}
