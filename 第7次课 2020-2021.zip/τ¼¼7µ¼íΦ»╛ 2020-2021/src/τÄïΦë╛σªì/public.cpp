#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
char a[1005],b[1005];
int f[1005][1005],x=1,y;
int main(){
	freopen("public.in","r",stdin);
	freopen("public.out","w",stdout);
	scanf("%s%s",a+1,b+1);
	int n=strlen(a+1);
	int m=strlen(b+1);
	for(int i=1;i<=n;i++,x^=y^=x^=y){
		for(int j=1;j<=m;j++){
			if(a[i]==b[j])f[x][j]=f[y][j-1]+1;
			else f[x][j]=max(f[y][j],f[x][j-1]);
		}
	}
	printf("%d\n",f[y][m]);
	return 0;
}
