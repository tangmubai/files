#include "cstdio"
#include "algorithm"
using namespace std;
int w[100005],c[100005],n,m,f[1000005];
int main(){
	freopen ("bag.in","r",stdin);
	freopen ("bag.out","w",stdout);
	scanf ("%d%d",&n,&m);
	for (int i=1;i<=n;i++) scanf ("%d%d",&w[i],&c[i]);
	for (int i=1;i<=n;i++){
		for (int j=m;j>=w[i];j--){
			f[j]=max(f[j],f[j-w[i]]+c[i]);
		}
	}
	printf ("%d\n",f[m]);
	return 0;
}
