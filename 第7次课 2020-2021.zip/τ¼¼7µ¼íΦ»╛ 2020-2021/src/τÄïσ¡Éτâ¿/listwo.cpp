#include <stdio.h>
int n;
int main(){
	freopen ("listwo.in","r",stdin);
	freopen ("listwo.out","w",stdout);
	scanf ("%d",&n);
	long long ans=0;
	for (int i=2;i<=n;i++) ans=ans*2+(i-1)*2;
	printf ("%lld\n",ans);
	return 0;
}
