#include "cstdio"
#include "algorithm"
using namespace std;
int n,a[1000005],ans=-2000000000,sum=0;
int main(){
	freopen ("mlong.in","r",stdin);
	freopen ("mlong.out","w",stdout);
	scanf ("%d",&n);
	for (int i=1;i<=n;i++) scanf ("%d",&a[i]);
	for (int i=1;i<=n;i++){
		sum+=a[i];
		ans=max(ans,sum);
		sum=max(sum,0);
	}
	printf ("%d\n",ans);
	return 0;
}
