#include<iostream>
#include<stdio.h>
using namespace std;
int w[205],c[205],f[205][5005];
int read(){
	int a=0,f=1;char c=getchar();
	for(;c<'0'||c>'9';c=getchar()){
		if(c=='-') f=-1;
	}
	for(;c>='0'&&c<='9';a=(a<<1)+(a<<3)+(c^'0'),c=getchar());
	return a*f;
}
int main(){
	freopen("bag.in","r",stdin);freopen("bag.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=n;++i){
		w[i]=read();
		c[i]=read();
	}
	for(int i=1;i<=n;i++){
	   	for(int v=m;v>0;v--){
	   		if(w[i]>v) f[i][v]=f[i-1][v];
			else f[i][v]=max(f[i-1][v],f[i-1][v-w[i]]+c[i]); 
		}
	}
	printf("%d\n",f[n][m]);
	return 0;
}
