#include<stdio.h>
using namespace std;
long long ans[65][65][65];
long long s2(long long len,long long l,long long r);
long long read(){
	long long a=0;char c=getchar();
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';a=(a<<1)+(a<<3)+(c^'0'),c=getchar());
	return a;
}
long long s1(long long len,long long l,long long r){
	if(r-l+1<len) return 0;
	if(len==2) return 1;
	if(!ans[len][l][r]){
		for(long long i=l;i<r;++i) ans[len][l][r]+=s1(len-1,l,i);
	}
	return ans[len][l][r];
}
int main(){
	freopen("listwo.in","r",stdin);freopen("listwo.out","w",stdout);
	long long n=read(),tot=0;
	for(long long i=2;i<=n;++i){
		for(long long j=0;j<n;++j){
			for(long long k=0;k<n;++k) tot+=s1(i,j,k)+s2(i,j,k);
		}
	}
	printf("%lld\n",tot);
	return 0;
}
long long s2(long long len,long long l,long long r){
	if(r-l+1<len) return 0;
	if(len==2) return 1;
	if(!ans[len][l][r]){
		for(long long i=l+1;i<=r;++i) ans[len][l][r]+=s2(len-1,i,r);
	}
	return ans[len][l][r];
}
