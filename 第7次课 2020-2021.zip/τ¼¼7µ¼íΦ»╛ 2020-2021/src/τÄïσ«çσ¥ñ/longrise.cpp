#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
int f[1005];
int main(){
	freopen("longrise.in","r",stdin);freopen("longrise.out","w",stdout); 
	int n,ans=0;
	scanf("%d",&n);
	for(int i=1,a,j;i<=n;++i){
		scanf("%d",&a);
		j=lower_bound(f+1,f+1+ans,a)-f;
		f[j]=a;
		ans=max(ans,j);
	}
	printf("%d\n",ans);
	return 0;
}
