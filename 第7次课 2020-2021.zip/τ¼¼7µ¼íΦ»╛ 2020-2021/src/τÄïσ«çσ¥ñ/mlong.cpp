#include<iostream>
#include<stdio.h>
using namespace std;
int read(){
	int a=0,f=1;char c=getchar();
	for(;c<'0'||c>'9';c=getchar()){
		if(c=='-') f=-1;
	}
	for(;c>='0'&&c<='9';a=(a<<1)+(a<<3)+(c^'0'),c=getchar());
	return a*f;
}
int main(){
	freopen("mlong.in","r",stdin);freopen("mlong.out","w",stdout);
	int n=read(),ans=-1000000000;
	for(int i=1,now=0;i<=n;++i){
		now+=read();
		ans=max(ans,now);
		now=max(now,0);
	}
	printf("%d\n",ans);
	return 0;
}
