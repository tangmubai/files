#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
int ans[5][1005];char a[1005],b[1005];
int main(){
	freopen("public.in","r",stdin);freopen("public.out","w",stdout);
	int n,m;
	scanf("%s%s",a+1,b+1);
	n=strlen(a+1);
	m=strlen(b+1);
	for(int i=0;i<=n;++i){
		for(int j=0;j<=m;++j){
			if(i||j){
				if(i&&j) ans[i&1][j]=ans[i&1^1][j-1]+(a[i]==b[j]);
				else ans[i&1][j]=-(1<<30);
				if(i) ans[i&1][j]=max(ans[i&1][j],ans[i&1^1][j]);
				if(j) ans[i&1][j]=max(ans[i&1][j],ans[i&1][j-1]);
			}
		}
	}
	printf("%d\n",ans[n&1][m]);
	return 0;
}
