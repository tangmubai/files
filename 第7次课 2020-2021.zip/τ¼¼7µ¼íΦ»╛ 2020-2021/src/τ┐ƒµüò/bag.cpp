#include <cstdio>
using namespace std;
int n,m,w[201],c[201],i,j,f[201][5001];
int max (int a,int b) {return a>b?a:b;}
int main () {
	freopen ("bag.in","r",stdin);
	freopen ("bag.out","w",stdout);
	scanf ("%d%d",&n,&m);
	for (i=1;i<=n;i++) scanf ("%d%d",&w[i],&c[i]);
	for (i=1;i<=n;i++) for (j=m;j>=w[i];j--) {
		f[i][j]=max(f[i-1][j],f[i-1][j-w[i]]+c[i]);
	}
	printf ("%d",f[n][m]);
	return 0;
}
