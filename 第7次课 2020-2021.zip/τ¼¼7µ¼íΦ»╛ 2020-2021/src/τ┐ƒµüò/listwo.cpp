#include <cstdio>
using namespace std;
int t[100],k,i,x=2,a[100];
long long f[100];
int main () {
	freopen ("listwo.in","r",stdin);
	freopen ("listwo.out","w",stdout);
	scanf ("%d",&k);
	for (i=2;i<=k;i++,x+=2) f[i]=(f[i-1]*2+x);
	printf ("%lld",f[k]);
	return 0;
}
