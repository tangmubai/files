#include <cstdio>
using namespace std;
int n,i,j,a[1001],s[1001],ans;
int main () {
	freopen ("longrise.in","r",stdin);
	freopen ("longrise.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) {scanf ("%d",&a[i]); s[i]=1;}
	for (i=(n-1);i>=1;i--) for (j=(i+1);j<=n;j++) {
		if (a[i]<a[j]&&s[j]+1>s[i]) s[i]=(s[j]+1);
	}
	for (i=1;i<=n;i++) if (s[i]>ans) ans=s[i];
	printf ("%d",ans);
	return 0;
}
