#include <cstdio>
using namespace std;
int n,i,a[100001],s[100001],ans=-1000;
int main () {
	freopen ("mlong.in","r",stdin);
	freopen ("mlong.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++) scanf ("%d",&a[i]);
	for (i=1;i<=n;i++) if (a[i-1]>0) a[i]+=a[i-1]; 
	for (i=1;i<=n;i++) if (a[i]>ans) ans=a[i];
	printf ("%d",ans);
	return 0;
}
