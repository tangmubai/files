#include <cstdio>
using namespace std;
int i,j,f[1001][1001];
char a[1001],b[1001];
int max (int a,int b) {return a>b?a:b;}
int main () {
	freopen ("public.in","r",stdin);
	freopen ("public.out","w",stdout);
	scanf ("%s%s",a+1,b+1);
	for (i=1;a[i];i++) for (j=1;b[j];j++) {
		if (a[i]==b[j]) f[i][j]=f[i-1][j-1]+1;
		else f[i][j]=max(f[i-1][j-1],max(f[i-1][j],f[i][j-1]));
	}
	printf ("%d",f[i-1][j-1]);
	return 0;
}
